Authoritative Forge reproduction

Registry folder: 12294-h-12-attacker-can-prevent-the-system-from-entering-step-5-du_exp
Registry base commit: 554323ffc61255804dec30d430d85a9e953fcc39

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 12294-h-12-attacker-can-prevent-the-system-from-entering-step-5-du_exp -vvv
