Authoritative Forge reproduction

Registry folder: 16039-h-02-attacker-can-front-run-bond-buyer-and-make-them-buy-it_exp
Registry base commit: 33a2591e5da73b8bd7295c7e290b4440e25bc890

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 16039-h-02-attacker-can-front-run-bond-buyer-and-make-them-buy-it_exp -vvv
