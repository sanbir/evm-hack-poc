// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Synthetic reduction of AuditVault #16736 (AZTEC).
/// The real Swap validator omitted the Join-Split elliptic-curve pairing check.
/// This local model keeps the output-note acceptance boundary explicit.
contract SwapValidator {
    uint256 public credited;
    bool public lastPairingResult;

    event OutputNoteAccepted(uint256 inputValue, uint256 outputValue, bool pairingResult);

    function validateSwap(uint256 inputValue, uint256 outputValue, bool pairingResult) external {
        require(outputValue >= inputValue, "output below input");
        // FIX: require(pairingResult, "invalid output-note pairing");
        lastPairingResult = pairingResult; // @> VULN: output commitment is accepted without a pairing proof.
        credited += outputValue;
        emit OutputNoteAccepted(inputValue, outputValue, pairingResult);
    }
}

contract Exploit {
    SwapValidator public validator;
    uint256 public freeCredit;
    bool public acceptedInvalidNote;

    constructor() {
        validator = new SwapValidator();
    }

    function run() external {
        // The attacker chooses an unbound output commitment: pairingResult is false.
        validator.validateSwap(10, 100, false);
        freeCredit = validator.credited();
        acceptedInvalidNote = !validator.lastPairingResult() && freeCredit == 100;
        require(acceptedInvalidNote, "invalid output note was rejected");
    }
}
