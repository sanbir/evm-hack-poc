Authoritative Forge reproduction

Registry folder: 18099-hash-collisions-in-untyped-signatures-trailofbits-meson-prot_exp
Registry base commit: f78633893c5a663af736756859ec8d34772b9b85

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 18099-hash-collisions-in-untyped-signatures-trailofbits-meson-prot_exp -vvv
