Authoritative Forge reproduction

Registry folder: 18535-h-3-depositfee-can-be-bypassed-via-deposit-queue-sherlock-no_exp
Registry base commit: d475a18f58b1e327ca894f28ebd1b103e8296a36

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 18535-h-3-depositfee-can-be-bypassed-via-deposit-queue-sherlock-no_exp -vvv
