Authoritative Forge reproduction

Registry folder: 19124-h-02-first-vault-depositor-can-steal-subsequent-depositors-t_exp
Registry base commit: 8e73faf48ba0a764ad646b196a453408a78a4d46

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 19124-h-02-first-vault-depositor-can-steal-subsequent-depositors-t_exp -vvv
