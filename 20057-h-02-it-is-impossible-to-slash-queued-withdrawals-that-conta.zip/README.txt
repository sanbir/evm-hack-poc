EVM Hack Analyzer — crypto.training scripted POC (ZIP projection)

Slug:     20057-h-02-it-is-impossible-to-slash-queued-withdrawals-that-conta
Chain id: 1

Layout:
  anvil_state.json       — fork state (accounts + storage + code + block).
  sources/<addr>/…       — verified Solidity sources.
  sources/exploit/…      — attacker exploit source (if present).
  poc-data/runner.json   — scripted exploit config (no accounts/source bodies).
  manifest.json          — summary metadata.

Drop this ZIP onto the EVM Hack Analyzer — it re-runs the scripted exploit
in-browser and opens the opcode-level playground.
