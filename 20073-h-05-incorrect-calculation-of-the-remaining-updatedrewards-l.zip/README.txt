EVM Hack Analyzer — crypto.training scripted POC (ZIP projection)

Slug:     20073-h-05-incorrect-calculation-of-the-remaining-updatedrewards-l
Chain id: 31337

Layout:
  anvil_state.json       — fork state (accounts + storage + code + block).
  sources/<addr>/…       — verified Solidity sources.
  sources/exploit/…      — attacker exploit source (if present).
  poc-data/runner.json   — scripted exploit config (no accounts/source bodies).
  manifest.json          — summary metadata.

Drop this ZIP onto the EVM Hack Analyzer — it re-runs the scripted exploit
in-browser and opens the opcode-level playground.
