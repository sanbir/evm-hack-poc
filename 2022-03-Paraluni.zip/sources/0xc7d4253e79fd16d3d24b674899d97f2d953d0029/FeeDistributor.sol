// File: paraluni_protocol/contracts/libraries/Proxy.sol



pragma solidity >=0.6.0 <0.8.0;

/**
 * @dev This abstract contract provides a fallback function that delegates all calls to another contract using the EVM
 * instruction `delegatecall`. We refer to the second contract as the _implementation_ behind the proxy, and it has to
 * be specified by overriding the virtual {_implementation} function.
 *
 * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
 * different contract through the {_delegate} function.
 *
 * The success and return data of the delegated call will be returned back to the caller of the proxy.
 */
abstract contract Proxy {
    /**
     * @dev Delegates the current call to `implementation`.
     *
     * This function does not return to its internall call site, it will return directly to the external caller.
     */
    function _delegate(address implementation) internal virtual {
        // solhint-disable-next-line no-inline-assembly
        assembly {
            // Copy msg.data. We take full control of memory in this inline assembly
            // block because it will not return to Solidity code. We overwrite the
            // Solidity scratch pad at memory position 0.
            calldatacopy(0, 0, calldatasize())

            // Call the implementation.
            // out and outsize are 0 because we don't know the size yet.
            let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)

            // Copy the returned data.
            returndatacopy(0, 0, returndatasize())

            switch result
            // delegatecall returns 0 on error.
            case 0 { revert(0, returndatasize()) }
            default { return(0, returndatasize()) }
        }
    }

    /**
     * @dev This is a virtual function that should be overriden so it returns the address to which the fallback function
     * and {_fallback} should delegate.
     */
    function _implementation() internal view virtual returns (address);

    /**
     * @dev Delegates the current call to the address returned by `_implementation()`.
     *
     * This function does not return to its internall call site, it will return directly to the external caller.
     */
    function _fallback() internal virtual {
        _beforeFallback();
        _delegate(_implementation());
    }

    /**
     * @dev Fallback function that delegates calls to the address returned by `_implementation()`. Will run if no other
     * function in the contract matches the call data.
     */
    fallback () external payable virtual {
        _fallback();
    }

    /**
     * @dev Fallback function that delegates calls to the address returned by `_implementation()`. Will run if call data
     * is empty.
     */
    receive () external payable virtual {
        _fallback();
    }

    /**
     * @dev Hook that is called before falling back to the implementation. Can happen as part of a manual `_fallback`
     * call, or as part of the Solidity `fallback` or `receive` functions.
     *
     * If overriden should call `super._beforeFallback()`.
     */
    function _beforeFallback() internal virtual {
    }
}
// File: paraluni_protocol/contracts/ParaProxyStorage.sol


pragma solidity 0.6.12;

contract ParaProxyAdminStorage {
    /**
    * @notice Administrator for this contract
    */
    address public admin;

    /**
    * @notice Pending administrator for this contract
    */
    address public pendingAdmin;

    /**
    * @notice Active brains of Proxy
    */
    address public implementation;

    /**
    * @notice Pending brains of Proxy
    */
    address public pendingImplementation;
}
// File: paraluni_protocol/contracts/ParaProxy.sol


pragma solidity 0.6.12;


/**
 * @title ParaCore
 * @dev Storage for the comptroller is at this address, while execution is delegated to the `implementation`.
 * CTokens should reference this contract as their comptroller.
 */
contract ParaProxy is ParaProxyAdminStorage, Proxy{

    /**
      * @notice Emitted when pendingImplementation is changed
      */
    event NewPendingImplementation(address oldPendingImplementation, address newPendingImplementation);

    /**
      * @notice Emitted when pendingImplementation is accepted, which means comptroller implementation is updated
      */
    event NewImplementation(address oldImplementation, address newImplementation);

    /**
      * @notice Emitted when pendingAdmin is changed
      */
    event NewPendingAdmin(address oldPendingAdmin, address newPendingAdmin);

    /**
      * @notice Emitted when pendingAdmin is accepted, which means admin is updated
      */
    event NewAdmin(address oldAdmin, address newAdmin);

    constructor() public {
        // Set admin to caller
        admin = msg.sender;
    }

    /*** Admin Functions ***/
    function _setPendingImplementation(address newPendingImplementation) public returns (uint) {

        require(msg.sender == admin, "auth");

        address oldPendingImplementation = pendingImplementation;

        pendingImplementation = newPendingImplementation;

        emit NewPendingImplementation(oldPendingImplementation, pendingImplementation);

        return 0;
    }

    /**
    * @notice Accepts new implementation of comptroller. msg.sender must be pendingImplementation
    * @dev Admin function for new implementation to accept it's role as implementation
    * @return uint 0=success, otherwise a failure (see ErrorReporter.sol for details)
    */
    function _acceptImplementation() public returns (uint) {
        // Check caller is pendingImplementation and pendingImplementation ≠ address(0)
        if (msg.sender != pendingImplementation || pendingImplementation == address(0)) {
            return 1;
        }

        // Save current values for inclusion in log
        address oldImplementation = implementation;
        address oldPendingImplementation = pendingImplementation;

        implementation = pendingImplementation;

        pendingImplementation = address(0);

        emit NewImplementation(oldImplementation, implementation);
        emit NewPendingImplementation(oldPendingImplementation, pendingImplementation);

        return 0;
    }


    /**
      * @notice Begins transfer of admin rights. The newPendingAdmin must call `_acceptAdmin` to finalize the transfer.
      * @dev Admin function to begin change of admin. The newPendingAdmin must call `_acceptAdmin` to finalize the transfer.
      * @param newPendingAdmin New pending admin.
      * @return uint 0=success, otherwise a failure (see ErrorReporter.sol for details)
      */
    function _setPendingAdmin(address newPendingAdmin) public returns (uint) {
        // Check caller = admin
        if (msg.sender != admin) {
            return 1;
        }

        // Save current value, if any, for inclusion in log
        address oldPendingAdmin = pendingAdmin;

        // Store pendingAdmin with value newPendingAdmin
        pendingAdmin = newPendingAdmin;

        // Emit NewPendingAdmin(oldPendingAdmin, newPendingAdmin)
        emit NewPendingAdmin(oldPendingAdmin, newPendingAdmin);

        return 0;
    }

    /**
      * @notice Accepts transfer of admin rights. msg.sender must be pendingAdmin
      * @dev Admin function for pending admin to accept role and update admin
      * @return uint 0=success, otherwise a failure (see ErrorReporter.sol for details)
      */
    function _acceptAdmin() public returns (uint) {
        // Check caller is pendingAdmin and pendingAdmin ≠ address(0)
        if (msg.sender != pendingAdmin || msg.sender == address(0)) {
            return 1;
        }

        // Save current values for inclusion in log
        address oldAdmin = admin;
        address oldPendingAdmin = pendingAdmin;

        // Store admin with value pendingAdmin
        admin = pendingAdmin;

        // Clear the pending value
        pendingAdmin = address(0);

        emit NewAdmin(oldAdmin, admin);
        emit NewPendingAdmin(oldPendingAdmin, pendingAdmin);

        return 0;
    }

    function _implementation() internal view virtual override returns (address){
        return implementation;
    }

}
// File: paraluni_protocol/contracts/interfaces/IParaPair.sol

pragma solidity >=0.5.0;

interface IParaPair {
    event Approval(address indexed owner, address indexed spender, uint value);
    event Transfer(address indexed from, address indexed to, uint value);

    function name() external pure returns (string memory);
    function symbol() external pure returns (string memory);
    function decimals() external pure returns (uint8);
    function totalSupply() external view returns (uint);
    function balanceOf(address owner) external view returns (uint);
    function allowance(address owner, address spender) external view returns (uint);

    function approve(address spender, uint value) external returns (bool);
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address from, address to, uint value) external returns (bool);

    function DOMAIN_SEPARATOR() external view returns (bytes32);
    function PERMIT_TYPEHASH() external pure returns (bytes32);
    function nonces(address owner) external view returns (uint);

    function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;

    event Mint(address indexed sender, uint amount0, uint amount1);
    event Burn(address indexed sender, uint amount0, uint amount1, address indexed to);
    event Swap(
        address indexed sender,
        uint amount0In,
        uint amount1In,
        uint amount0Out,
        uint amount1Out,
        address indexed to
    );
    event Sync(uint112 reserve0, uint112 reserve1);

    function MINIMUM_LIQUIDITY() external pure returns (uint);
    function factory() external view returns (address);
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function price0CumulativeLast() external view returns (uint);
    function price1CumulativeLast() external view returns (uint);
    function kLast() external view returns (uint);

    function mint(address to) external returns (uint liquidity);
    function burn(address to) external returns (uint amount0, uint amount1);
    function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    function skim(address to) external;
    function sync() external;

    function initialize(address, address) external;
}

// File: paraluni_protocol/contracts/interfaces/IParaRouter01.sol


pragma solidity >=0.6.2;

interface IParaRouter01 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint amountADesired,
        uint amountBDesired,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB, uint liquidity);
    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);
    function removeLiquidity(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB);
    function removeLiquidityETH(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountToken, uint amountETH);
    function removeLiquidityWithPermit(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountA, uint amountB);
    function removeLiquidityETHWithPermit(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountToken, uint amountETH);
    function swapExactTokensForTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);
    function swapTokensForExactTokens(
        uint amountOut,
        uint amountInMax,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);
    function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline)
        external
        payable
        returns (uint[] memory amounts);
    function swapTokensForExactETH(uint amountOut, uint amountInMax, address[] calldata path, address to, uint deadline)
        external
        returns (uint[] memory amounts);
    function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline)
        external
        returns (uint[] memory amounts);
    function swapETHForExactTokens(uint amountOut, address[] calldata path, address to, uint deadline)
        external
        payable
        returns (uint[] memory amounts);

    function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
}
// File: paraluni_protocol/contracts/interfaces/IParaRouter02.sol

pragma solidity >=0.6.2;


interface IParaRouter02 is IParaRouter01 {
    function removeLiquidityETHSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountETH);
    function removeLiquidityETHWithPermitSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountETH);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable;
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
}
// File: paraluni_protocol/contracts/libraries/TransferHelper.sol



pragma solidity >=0.6.0;

// helper methods for interacting with BEP20 tokens and sending ETH that do not consistently return true/false
library TransferHelper {
    function safeApprove(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('approve(address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
        require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
    }

    function safeTransfer(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transfer(address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
        require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FAILED');
    }

    function safeTransferFrom(
        address token,
        address from,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
        require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
    }

    function safeTransferETH(address to, uint256 value) internal {
        (bool success, ) = to.call{value: value}(new bytes(0));
        require(success, 'TransferHelper: BNB_TRANSFER_FAILED');
    }
}
// File: paraluni_protocol/contracts/libraries/Address.sol



pragma solidity >=0.6.2 <0.8.0;

/**
 * @dev Collection of functions related to the address type
 */
library Address {
    /**
     * @dev Returns true if `account` is a contract.
     *
     * [IMPORTANT]
     * ====
     * It is unsafe to assume that an address for which this function returns
     * false is an externally-owned account (EOA) and not a contract.
     *
     * Among others, `isContract` will return false for the following
     * types of addresses:
     *
     *  - an externally-owned account
     *  - a contract in construction
     *  - an address where a contract will be created
     *  - an address where a contract lived, but was destroyed
     * ====
     */
    function isContract(address account) internal view returns (bool) {
        // This method relies on extcodesize, which returns 0 for contracts in
        // construction, since the code is only stored at the end of the
        // constructor execution.

        uint256 size;
        // solhint-disable-next-line no-inline-assembly
        assembly { size := extcodesize(account) }
        return size > 0;
    }

    /**
     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to
     * `recipient`, forwarding all available gas and reverting on errors.
     *
     * https://eips.ethereum.org/EIPS/eip-1884[EIP1884] increases the gas cost
     * of certain opcodes, possibly making contracts go over the 2300 gas limit
     * imposed by `transfer`, making them unable to receive funds via
     * `transfer`. {sendValue} removes this limitation.
     *
     * https://diligence.consensys.net/posts/2019/09/stop-using-soliditys-transfer-now/[Learn more].
     *
     * IMPORTANT: because control is transferred to `recipient`, care must be
     * taken to not create reentrancy vulnerabilities. Consider using
     * {ReentrancyGuard} or the
     * https://solidity.readthedocs.io/en/v0.5.11/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].
     */
    function sendValue(address payable recipient, uint256 amount) internal {
        require(address(this).balance >= amount, "Address: insufficient balance");

        // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
        (bool success, ) = recipient.call{ value: amount }("");
        require(success, "Address: unable to send value, recipient may have reverted");
    }

    /**
     * @dev Performs a Solidity function call using a low level `call`. A
     * plain`call` is an unsafe replacement for a function call: use this
     * function instead.
     *
     * If `target` reverts with a revert reason, it is bubbled up by this
     * function (like regular Solidity function calls).
     *
     * Returns the raw returned data. To convert to the expected return value,
     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].
     *
     * Requirements:
     *
     * - `target` must be a contract.
     * - calling `target` with `data` must not revert.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data) internal returns (bytes memory) {
      return functionCall(target, data, "Address: low-level call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with
     * `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but also transferring `value` wei to `target`.
     *
     * Requirements:
     *
     * - the calling contract must have an ETH balance of at least `value`.
     * - the called Solidity function must be `payable`.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(address target, bytes memory data, uint256 value) internal returns (bytes memory) {
        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");
    }

    /**
     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but
     * with `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(address target, bytes memory data, uint256 value, string memory errorMessage) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        require(isContract(target), "Address: call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.call{ value: value }(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data) internal view returns (bytes memory) {
        return functionStaticCall(target, data, "Address: low-level static call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data, string memory errorMessage) internal view returns (bytes memory) {
        require(isContract(target), "Address: static call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.staticcall(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionDelegateCall(target, data, "Address: low-level delegate call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {
        require(isContract(target), "Address: delegate call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = target.delegatecall(data);
        return _verifyCallResult(success, returndata, errorMessage);
    }

    function _verifyCallResult(bool success, bytes memory returndata, string memory errorMessage) private pure returns(bytes memory) {
        if (success) {
            return returndata;
        } else {
            // Look for revert reason and bubble it up if present
            if (returndata.length > 0) {
                // The easiest way to bubble the revert reason is using memory via assembly

                // solhint-disable-next-line no-inline-assembly
                assembly {
                    let returndata_size := mload(returndata)
                    revert(add(32, returndata), returndata_size)
                }
            } else {
                revert(errorMessage);
            }
        }
    }
}
// File: paraluni_protocol/contracts/interfaces/IERC20.sol


pragma solidity >=0.5.0;

interface IERC20 {
    event Approval(address indexed owner, address indexed spender, uint value);
    event Transfer(address indexed from, address indexed to, uint value);

    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
    function totalSupply() external view returns (uint);
    function balanceOf(address owner) external view returns (uint);
    function allowance(address owner, address spender) external view returns (uint);

    function approve(address spender, uint value) external returns (bool);
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address from, address to, uint value) external returns (bool);
}

// File: paraluni_protocol/contracts/interfaces/IFeeDistributor.sol


pragma solidity ^0.6.6;

interface IFeeDistributor {
    function incomeClaimFee(address user, address token, uint256 fee) external;
    function incomeWithdrawFee(address user, address token, uint256 fee, uint256 amount) external;
    function incomeSwapFee(address user, address token, uint256 fee) payable external;
    function setReferalByChef(address user, address referal) external;
    // function referrals(address user) external view returns (address); 
    // function poolTeam() external view returns (address);
}
// File: paraluni_protocol/contracts/libraries/SafeMath_para.sol

/**
 * @dev Wrappers over Solidity's arithmetic operations with added overflow
 * checks.
 *
 * Arithmetic operations in Solidity wrap on overflow. This can easily result
 * in bugs, because programmers usually assume that an overflow raises an
 * error, which is the standard behavior in high level programming languages.
 * `SafeMath` restores this intuition by reverting the transaction when an
 * operation overflows.
 *
 * Using this library instead of the unchecked operations eliminates an entire
 * class of bugs, so it's recommended to use it always.
 */
library SafeMath {
    /**
     * @dev Returns the addition of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryAdd(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        uint256 c = a + b;
        if (c < a) return (false, 0);
        return (true, c);
    }

    /**
     * @dev Returns the substraction of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function trySub(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        if (b > a) return (false, 0);
        return (true, a - b);
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryMul(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        // Gas optimization: this is cheaper than requiring 'a' not being zero, but the
        // benefit is lost if 'b' is also tested.
        // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522
        if (a == 0) return (true, 0);
        uint256 c = a * b;
        if (c / a != b) return (false, 0);
        return (true, c);
    }

    /**
     * @dev Returns the division of two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryDiv(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        if (b == 0) return (false, 0);
        return (true, a / b);
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryMod(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        if (b == 0) return (false, 0);
        return (true, a % b);
    }

    /**
     * @dev Returns the addition of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `+` operator.
     *
     * Requirements:
     *
     * - Addition cannot overflow.
     */
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");
        return c;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting on
     * overflow (when the result is negative).
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        require(b <= a, "SafeMath: subtraction overflow");
        return a - b;
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `*` operator.
     *
     * Requirements:
     *
     * - Multiplication cannot overflow.
     */
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        if (a == 0) return 0;
        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");
        return c;
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting on
     * division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        require(b > 0, "SafeMath: division by zero");
        return a / b;
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting when dividing by zero.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        require(b > 0, "SafeMath: modulo by zero");
        return a % b;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting with custom message on
     * overflow (when the result is negative).
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {trySub}.
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        return a - b;
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting with custom message on
     * division by zero. The result is rounded towards zero.
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {tryDiv}.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        return a / b;
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting with custom message when dividing by zero.
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {tryMod}.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b > 0, errorMessage);
        return a % b;
    }
}

// File: paraluni_protocol/contracts/libraries/SafeERC20.sol



pragma solidity >=0.6.0 <0.8.0;




/**
 * @title SafeERC20
 * @dev Wrappers around ERC20 operations that throw on failure (when the token
 * contract returns false). Tokens that return no value (and instead revert or
 * throw on failure) are also supported, non-reverting calls are assumed to be
 * successful.
 * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
 * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
 */
library SafeERC20 {
    using SafeMath for uint256;
    using Address for address;

    function safeTransfer(IERC20 token, address to, uint256 value) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    /**
     * @dev Deprecated. This function has issues similar to the ones found in
     * {IERC20-approve}, and its usage is discouraged.
     *
     * Whenever possible, use {safeIncreaseAllowance} and
     * {safeDecreaseAllowance} instead.
     */
    function safeApprove(IERC20 token, address spender, uint256 value) internal {
        // safeApprove should only be called when setting an initial allowance,
        // or when resetting it to zero. To increase and decrease it, use
        // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'
        // solhint-disable-next-line max-line-length
        require((value == 0) || (token.allowance(address(this), spender) == 0),
            "SafeERC20: approve from non-zero to non-zero allowance"
        );
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));
    }

    function safeIncreaseAllowance(IERC20 token, address spender, uint256 value) internal {
        uint256 newAllowance = token.allowance(address(this), spender).add(value);
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
    }

    function safeDecreaseAllowance(IERC20 token, address spender, uint256 value) internal {
        uint256 newAllowance = token.allowance(address(this), spender).sub(value, "SafeERC20: decreased allowance below zero");
        _callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, newAllowance));
    }

    /**
     * @dev Imitates a Solidity high-level call (i.e. a regular function call to a contract), relaxing the requirement
     * on the return value: the return value is optional (but if data is returned, it must not be false).
     * @param token The token targeted by the call.
     * @param data The call data (encoded using abi.encode or one of its variants).
     */
    function _callOptionalReturn(IERC20 token, bytes memory data) private {
        // We need to perform a low level call here, to bypass Solidity's return data size checking mechanism, since
        // we're implementing it ourselves. We use {Address.functionCall} to perform this call, which verifies that
        // the target address contains contract code and also asserts for success in the low-level call.

        bytes memory returndata = address(token).functionCall(data, "SafeERC20: low-level call failed");
        if (returndata.length > 0) { // Return data is optional
            // solhint-disable-next-line max-line-length
            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");
        }
    }
}
// File: paraluni_protocol/contracts/FeeDistributor.sol

pragma solidity 0.6.12;









contract FeeDistributor is ParaProxyAdminStorage, IFeeDistributor {
    using SafeMath for uint256;
    using SafeERC20 for IERC20;
    address public distributer;
    uint constant scale = 1e18;
    uint constant public TYPE_CLAIMFEE = 1;
    uint constant public TYPE_SWAPFEE = 2;
    uint constant public TYPE_WITHDRAW = 3;
    address public poolT42bonus;
    address public poolBuyback;
    address public poolFomo;
    address public poolTeam;

    IParaRouter02 public paraRouter;
    address public masterChef;
    mapping(address => address) public referrals;
    mapping(address => bool) public _whitelist;

    mapping(uint =>mapping(address => uint)) poolBalances;

    mapping(address => TokenInfo) public tokensInfo;

    mapping(address => UserInfo) public usersInfo;

    struct TokenInfo{
        uint price;
        address[] path;
    }

    struct UserInfo{
        uint commission;
        uint follower;
        uint swapProfit;
        uint claimProfit;
        uint followerWithdrawProfit;
        uint followerWithdraw;
    }

    event ReferalCommission(address indexed referral, address indexed user, uint256 indexed category, address token, uint256 commission);

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        require(admin == msg.sender, "Ownable: caller is not the owner");
        _;
    }

    /**
     * @dev Throws if called by any account other than the distributer.
     */
    modifier onlyDistributer() {
        require(distributer == msg.sender, "Ownable: caller is not the distributer");
        _;
    }

    constructor () public {
        admin = msg.sender;
    }
    
    function initialize(address bonus, address buyback, address fomo, address team, address _paraRouter, address _distributer, address _masterChef) external onlyOwner{
        setPools(bonus, buyback, fomo, team, _distributer, _masterChef);
        paraRouter = IParaRouter02(_paraRouter);
    }

    function _become(ParaProxy proxy) public {
        require(msg.sender == proxy.admin(), "only proxy admin can change brains");
        require(proxy._acceptImplementation() == 0, "change not authorized");
    }

    function setPools(address bonus, address buyback, address fomo, address team, address _distributer, address _masterChef) public onlyOwner {
        poolT42bonus = bonus;
        poolBuyback = buyback;
        poolFomo = fomo;
        poolTeam = team;
        distributer = _distributer;
        masterChef = _masterChef;
    }

    function setParaRouter(address _paraRouter) public onlyOwner {
        paraRouter = IParaRouter02(_paraRouter);
    }

    function _setTokenInfo(address token, uint price, address[] memory path) external onlyOwner {
        TokenInfo storage info = tokensInfo[token];
        info.price = price;
        info.path  = path;
    }

    function tokenInfo(address token) public view returns (uint price, address[] memory path){
        TokenInfo memory info = tokensInfo[token];
        price = info.price;
        path = info.path;
    }

    function setWhitelist(address _referral, bool _flag) public onlyOwner {
        _whitelist[_referral] = _flag;
        if(referrals[_referral] == address(0)){
            referrals[_referral] = _referral;
        }
    }
    
    function inWhiteList(address user) public view returns (bool) {
        return _whitelist[user];
    }

    function _setUserReferal(address user, address referal) private {
        if (_whitelist[referal] && referrals[user] == address(0)){
            referrals[user] = referal;
            UserInfo storage userInfo = usersInfo[referal];
            userInfo.follower = userInfo.follower.add(1);
        }
    }

    function setReferalByChef(address user, address referal) public override {
        require(msg.sender == masterChef, "auth");
        _setUserReferal(user, referal);
    }

    function setReferal(address referal) public {
        _setUserReferal(msg.sender, referal);
    }

    function _setReferals(address[] memory users, address[] memory referals) external onlyOwner {
        require(users.length == referals.length,"Ev");
        for(uint i = 0; i < users.length; i++){
            _setUserReferal(users[i], referals[i]);
        }
    }

    function incomeClaimFee(address user, address token, uint256 fee) override external {
        if(fee == 0)return;
        doTransferIn(token, msg.sender, fee, 0);
        uint256 commission = fee.div(10); 
        uint left = fee.sub(commission);                 
        address referral = referrals[user];
        if (referral != address(0)) {
            UserInfo storage userInfo = usersInfo[referral];
            uint profit = getUsdtFromToken(token, commission);
            userInfo.claimProfit = userInfo.claimProfit.add(profit);
            IERC20(token).safeTransfer(referral, commission);
            emit ReferalCommission(referral, user, TYPE_CLAIMFEE, token, commission);
        }else{
            IERC20(token).safeTransfer(poolTeam, commission);
            emit ReferalCommission(poolTeam, user, TYPE_CLAIMFEE, token, commission);
        }
        mapping(address => uint) storage asserts = poolBalances[TYPE_CLAIMFEE];
        asserts[token] = asserts[token].add(left);
    }

    function distributeClaimFee(address[] memory tokens) external onlyDistributer{
        for(uint i = 0; i < tokens.length; i++){
            address token = tokens[i];
            uint amount = poolBalances[TYPE_CLAIMFEE][token];
            uint poolT42bonusAmount = amount.div(9);
            uint poolBuybackAmount = amount.div(9);
            uint poolFomoAmount = amount.mul(2).div(9);
            uint poolTeamAmount = amount.sub(poolT42bonusAmount).sub(poolBuybackAmount).sub(poolFomoAmount);
            if(token != address(0)){
                IERC20(token).safeTransfer(poolT42bonus, poolT42bonusAmount);
                IERC20(token).safeTransfer(poolBuyback, poolBuybackAmount);
                IERC20(token).safeTransfer(poolFomo, poolFomoAmount);
               
                IERC20(token).safeTransfer(poolTeam, poolTeamAmount);
            }else{
                TransferHelper.safeTransferETH(poolT42bonus, poolT42bonusAmount);
                TransferHelper.safeTransferETH(poolBuyback, poolBuybackAmount);
                TransferHelper.safeTransferETH(poolFomo, poolFomoAmount);
                
                TransferHelper.safeTransferETH(poolTeam, poolTeamAmount);
            }
            poolBalances[TYPE_CLAIMFEE][token] = 0;
        }
    }

    function incomeSwapFee(address user, address token, uint256 fee) payable override external  {
        if(fee == 0)return;
        doTransferIn(token, msg.sender, fee, msg.value);
        uint256 commission = fee.mul(10).div(55); 
        uint left = fee.sub(commission);                 
        address referral = referrals[user];
        if (referral != address(0)) {
            UserInfo storage userInfo = usersInfo[referral];
            uint profit = getUsdtFromToken(token, commission);
            userInfo.swapProfit = userInfo.swapProfit.add(profit);
            doTransferOut(token, referral, commission);
            emit ReferalCommission(referral, user, TYPE_SWAPFEE, token, commission);
        }else{
            doTransferOut(token, poolTeam, commission);
            emit ReferalCommission(poolTeam, user, TYPE_SWAPFEE, token, commission);
        }
        mapping(address => uint) storage asserts = poolBalances[TYPE_SWAPFEE];
        asserts[token] = asserts[token].add(left);
    }

    function distributeSwapFee(address[] memory tokens) external onlyDistributer{
        for(uint i = 0; i < tokens.length; i++){
            address token = tokens[i];
            uint amount = poolBalances[TYPE_SWAPFEE][token];
            uint poolT42bonusAmount = amount.mul(10).div(45);
            uint poolBuybackAmount = amount.mul(10).div(45);
            uint poolFomoAmount = amount.mul(5).div(45);
            uint poolTeamAmount = amount.sub(poolT42bonusAmount).sub(poolBuybackAmount).sub(poolFomoAmount);
            if(token != address(0)){
                IERC20(token).safeTransfer(poolT42bonus, poolT42bonusAmount);
                IERC20(token).safeTransfer(poolBuyback, poolBuybackAmount);
                IERC20(token).safeTransfer(poolFomo, poolFomoAmount);
                
                IERC20(token).safeTransfer(poolTeam, poolTeamAmount);
            }else{
                TransferHelper.safeTransferETH(poolT42bonus, poolT42bonusAmount);
                TransferHelper.safeTransferETH(poolBuyback, poolBuybackAmount);
                TransferHelper.safeTransferETH(poolFomo, poolFomoAmount);
                
                TransferHelper.safeTransferETH(poolTeam, poolTeamAmount);
            }
            //set storage
            poolBalances[TYPE_SWAPFEE][token] = 0;
        }
    }

    function incomeWithdrawFee(address user, address token, uint256 fee, uint256 amount) override external {
        require(msg.sender == masterChef, "!F:E");
        if(fee == 0 && amount == 0)return;
        doTransferIn(token, msg.sender, fee, 0);
        address referral = referrals[user];
        uint left = fee;
        if (referral != address(0)) {
            UserInfo storage userInfo = usersInfo[referral];
            uint rate = getRate(userInfo.followerWithdraw);
            uint256 commission = amount.mul(rate).div(10000); 
            if(commission > fee){
                commission = fee;
                left = 0;
            }else{
                left = fee.sub(commission);
            }
            doTransferOut(token, referral, commission);
            uint profit = getUsdtFromToken(token, commission);
            userInfo.followerWithdrawProfit = userInfo.followerWithdrawProfit.add(profit);
            emit ReferalCommission(referral, user, TYPE_WITHDRAW, token, commission); 
            uint amountToUsdt = getUsdtFromToken(token, amount);
            userInfo.followerWithdraw = userInfo.followerWithdraw.add(amountToUsdt);
        }
        if(left > 0){
            doTransferOut(token, poolTeam, left);
        }
        emit ReferalCommission(poolTeam, user, TYPE_WITHDRAW, token, left);
    }

    function getUsdtFromToken(address token, uint amount) public view returns (uint usdtAmount){
        if(amount == 0){
            return 0;
        }
        TokenInfo memory tokenInfo = tokensInfo[token];
        uint price = tokenInfo.price;
        if(price == 0 && tokenInfo.path.length > 0){
            uint[] memory amounts = paraRouter.getAmountsOut(getOneOfToken(token), tokenInfo.path);
            price = amounts[amounts.length - 1].mul(10**12);
        }
        if(price == 111111 && tokenInfo.path.length > 0){
            price =  getLpPrice(token, tokenInfo.path);
        }
        usdtAmount = amountFilled(token, amount).mul(price).div(scale);
    }

    function getLpPrice(address _lp, address[] memory path) public view returns (uint lpPrice) {
        address token0 = IParaPair(_lp).token0();
        uint[] memory toToUSDTAmounts = paraRouter.getAmountsOut(getOneOfToken(token0), path);
        uint token0Price = toToUSDTAmounts[toToUSDTAmounts.length - 1].mul(10**12);
        lpPrice = amountFilled(token0, IERC20(token0).balanceOf(_lp)).mul(token0Price).mul(2).div(IERC20(_lp).totalSupply());
    }

    function amountFilled(address token, uint amount) public view returns(uint){
        uint decimal = IERC20(token).decimals();
       
        return amount.mul(10**(uint(18).sub(decimal)));
    }

    function getOneOfToken(address token) public view returns(uint){
        return 10**6;
    }

    function getRate(uint usdtAmount) internal view returns (uint){
        if(usdtAmount < uint(16000).mul(scale)){
            return 15;
        }
        if(usdtAmount >= uint(16000).mul(scale) && usdtAmount < uint(79000).mul(scale)){
            return 20;
        }
        if(usdtAmount >= uint(79000).mul(scale) && usdtAmount < uint(320000).mul(scale)){
            return 25;
        }
        if(usdtAmount >= uint(320000).mul(scale) && usdtAmount < uint(790000).mul(scale)){
            return 30;
        }
        if(usdtAmount >= uint(790000).mul(scale) && usdtAmount < uint(1600000).mul(scale)){
            return 35;
        }
        if(usdtAmount >= uint(1600000).mul(scale) && usdtAmount < uint(7900000).mul(scale)){
            return 40;
        }
        if(usdtAmount >= uint(7900000).mul(scale) && usdtAmount < uint(16000000).mul(scale)){
            return 45;
        }
        if(usdtAmount >= uint(16000000).mul(scale) && usdtAmount < uint(79000000).mul(scale)){
            return 50;
        }
        if(usdtAmount >= uint(79000000).mul(scale)){
            return 50;
        }
    }

    function doTransferIn(address token, address payer, uint amount, uint msgValue) private returns(uint){
        if(token != address(0)){
            IERC20(token).safeTransferFrom(
            payer,
            address(this),
            amount
            );
        }else{
            require(amount == msgValue,"invalid value");
        }
    }

    function doTransferOut(address token, address _to, uint amount) private{
        if(amount > 0){
            if(token != address(0)){
                IERC20(token).safeTransfer(_to, amount);
            }else{
                 TransferHelper.safeTransferETH(_to, amount);
            }
        }
    }
}