// SPDX-License-Identifier: MIT
pragma solidity ^ 0.8.0;

// import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
// import "@openzeppelin/contracts/utils/Address.sol";
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

abstract contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _setOwner(_msgSender());
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        _setOwner(address(0));
    }


    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _setOwner(newOwner);
    }

    function _setOwner(address newOwner) private {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

interface OLD {
    function userInfo(address add_) external view returns(address, uint);
}

contract Check_EGD is Ownable{

    OLD public oldCon;
    address public foundation;
    address public liuidityPool;
    bool public status;
    
    struct UserInfo{
        address invitor;
        uint bought;
    }

    mapping (address => UserInfo) public userInfo;

    event Invite(address indexed _invitor, address indexed _user);
    
    function initCon (bool com_, address foundation_, address liuidityPool_, address old) public onlyOwner {
        oldCon = OLD(old);
        foundation = foundation_;
        liuidityPool = liuidityPool_;
        status = com_;
    }

    //----------------------------o t h e r s-------------------------------
    function checkInvitor(address addr_) external view returns(address _in) {
        (address oldInvitor, ) = oldCon.userInfo(addr_);
        _in = oldInvitor;


        if (_in == address(0)){
            _in = foundation;
        } 
    }
    
    
    


}