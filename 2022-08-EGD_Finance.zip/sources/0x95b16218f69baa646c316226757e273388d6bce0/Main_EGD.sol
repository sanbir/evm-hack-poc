// SPDX-License-Identifier: MIT
pragma solidity ^ 0.8.0;

// import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
// import "@openzeppelin/contracts/utils/Address.sol";
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

abstract contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _setOwner(_msgSender());
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        _setOwner(address(0));
    }


    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _setOwner(newOwner);
    }

    function _setOwner(address newOwner) private {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

library Address {
    function isContract(address account) internal view returns (bool) {
        bytes32 codehash;
        bytes32 accountHash = 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470;
        // solhint-disable-next-line no-inline-assembly
        assembly {codehash := extcodehash(account)}
        return (codehash != 0x0 && codehash != accountHash);
    }
}

library SafeERC20 {

    using Address for address;

    function safeTransfer(IERC20 token, address to, uint value) internal {
        callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint value) internal {
        callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    function safeApprove(IERC20 token, address spender, uint value) internal {
        require((value == 0) || (token.allowance(address(this), spender) == 0),
            "SafeERC20: approve from non-zero to non-zero allowance"
        );
        callOptionalReturn(token, abi.encodeWithSelector(token.approve.selector, spender, value));
    }

    function callOptionalReturn(IERC20 token, bytes memory data) private {
        require(address(token).isContract(), "SafeERC20: call to non-contract");

        // solhint-disable-next-line avoid-low-level-calls
        (bool success, bytes memory returndata) = address(token).call(data);
        require(success, "SafeERC20: low-level call failed");

        if (returndata.length > 0) {// Return data is optional
            // solhint-disable-next-line max-line-length
            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");
        }
    }
}

interface IERC20 {

    function totalSupply() external view returns (uint256);

    function balanceOf(address account) external view returns (uint256);

    function transfer(address recipient, uint256 amount) external returns (bool);

    function allowance(address owner, address spender) external view returns (uint256);

    function approve(address spender, uint256 amount) external returns (bool);

    function burn(address addr_, uint amount_) external returns (bool);

    function checkHolder() external view returns (uint out);

    function getReserves() external view returns (uint112 _reserve0, uint112 _reserve1, uint32 _blockTimestampLast);

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}


contract Main_EGD is Ownable{
    using SafeERC20 for IERC20;

    uint public startTime;
    uint constant Acc = 1e18;
    address public bank;
    address public foundation;
    // address public liuidityPool;
    address public EGDToken;
    IERC20 public EGD;
    IERC20 public USDT;
    bool public status;
    
    struct UserInfo{
        address invitor;
        uint bought;
    }

    struct IDOInfo{
        bool status;
        uint total;
        uint quota;
        uint price;
        uint surplusl;
    }

    mapping (address => UserInfo) public userInfo;
    mapping (address => IDOInfo) public idoInfo;

    event IDO(address indexed _sender, uint indexed _amount);
    event Invite(address indexed _invitor, address indexed _user);
    
    function initCon (bool com_, address foundation_, address bank_, address u_, address egd_) public onlyOwner {
        bank = bank_;
        foundation = foundation_;
        USDT = IERC20(u_);
        EGD = IERC20(egd_);
        EGDToken = egd_;
        status = com_;
    }
 
    function initIDO(address token_, uint total_, uint quota_, uint price_) public onlyOwner{
        require(status, 'not start');
        idoInfo[token_].total = total_;
        idoInfo[token_].price = price_;
        idoInfo[token_].quota = quota_;
        idoInfo[token_].status = true;
        idoInfo[token_].surplusl = total_;
    }
    
    function setPrice(address token_, uint p_) public onlyOwner {
        idoInfo[token_].price = p_;
    }

    function safePull(address token_, address bank_, uint amount_) public onlyOwner {
        IERC20(token_).transfer(bank_, amount_);
    }

    //-------------------------------- IDO --------------------------------
    
    function addInvitor(address addr_) public returns(address _invitor) {
        require(userInfo[msg.sender].invitor == address(0) || userInfo[msg.sender].invitor == foundation, 'already has a invitor!');
        require(addr_ != msg.sender, '?');
        userInfo[msg.sender].invitor = addr_;
        _invitor = userInfo[addr_].invitor;
    }

    function swap(address token_, uint outAmount_, address invitor_) public returns(bool){
        require(outAmount_ > 0, 'no amount');
        require(invitor_ != msg.sender, '?');
        require(outAmount_ <= idoInfo[token_].surplusl, 'out of total');
        require(userInfo[msg.sender].bought + outAmount_ <= idoInfo[token_].quota, 'out of quota!');
        if (userInfo[msg.sender].invitor == address(0) || userInfo[msg.sender].invitor == foundation) {
            userInfo[msg.sender].invitor = invitor_;
        }

        uint _inAmount = calculateInput(token_, outAmount_);
        uint _award = outAmount_ * 10 / 100;
        USDT.safeTransferFrom(msg.sender, bank, _inAmount);
        
        EGD.safeTransfer(msg.sender, outAmount_);
        EGD.safeTransfer(userInfo[msg.sender].invitor, _award);
        
        userInfo[msg.sender].bought += outAmount_;
        idoInfo[token_].surplusl -= outAmount_;
        emit IDO(msg.sender, outAmount_);
        return true;
    }
    
    function calculateInput(address token_, uint outAmount_)public view returns(uint _inAmount){
        _inAmount = outAmount_ * idoInfo[token_].price / Acc;
    
    }
    //----------------------------o t h e r s-------------------------------
    function checkInvitor(address addr_) public view returns(address _in) {
        require(addr_ != msg.sender, '?');
        _in = userInfo[addr_].invitor;
    }
    
    
    


}