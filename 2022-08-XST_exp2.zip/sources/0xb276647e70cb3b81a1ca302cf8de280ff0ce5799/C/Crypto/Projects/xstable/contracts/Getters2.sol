// SPDX-License-Identifier: MIT

pragma solidity ^0.6.12;
pragma experimental ABIEncoderV2;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts-upgradeable/math/SafeMathUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/AddressUpgradeable.sol";
import "./external/IUniswapV2Factory.sol";
import "./external/IUniswapV2Router02.sol";
import "./Constants2.sol";
import "./State.sol";

contract Getters2 is State {
    using SafeMathUpgradeable for uint256;
    using AddressUpgradeable for address;

    function getLargeBalances(address account) public view returns (uint256) {
        return _largeBalances[account];
    }
    function getAllowances(address account, address spender) public view returns (uint256) {
        return _allowances[account][spender];
    } 
    function getSupportedPools(uint256 index) public view returns (address) {
        return _supportedPools[index];
    }
    function getPoolCounters(address pool) public view returns (address, uint256, uint256, uint256, uint256, uint256) {
        PoolCounter memory pc = _poolCounters[pool];
        return (pc.pairToken, pc.tokenBalance, pc.pairTokenBalance, pc.lpBalance, pc.startTokenBalance, pc.startPairTokenBalance);
    }
    function isSupportedPool(address pool) public view returns (bool) {
        return _isSupportedPool[pool];
    }
    function mainPool() public view returns (address) {
        return _mainPool;
    }
    function getCurrentEpoch() public view returns (uint256) {
        return _currentEpoch;
    }
    function getLockBoxes(uint256 box) public view returns (address, uint256, uint256, bool) {
        LockBox memory lb = _lockBoxes[box];
        return (lb.beneficiary, lb.lockedBalance, lb.unlockTime, lb.locked);
    }
    function getLockedBalance(address account) public view returns (uint256) {
        return _lockedBalance[account];
    }
    function hasLockedBalance(address account) public view returns (bool) {
        return _hasLockedBalance[account];
    }
    function getTotalLockedBalance() public view returns (uint256) {
        return _totalLockedBalance;
    }
    function getLargeTotal() public view returns (uint256) {
        return _largeTotal;
    }
    function getTotalSupply() public view returns (uint256) {
        return _totalSupply;
    }
    function getLiquidityReserve() public view returns (address) {
        return _liquidityReserve;
    }
    function getStabilizer() public view returns (address) {
        return _stabilizer;
    }
    function isPresaleDone() public view returns (bool) {
        return _presaleDone;
    }
    function getPresaleAddress() public view returns (address) {
        return _presaleCon;
    }
    function isPaused() public view returns (bool) {
        return _paused;
    }
    function isTaxLess() public view returns (bool) {
        return _taxLess;
    }
    function isTaxlessSetter(address account) public view returns (bool) {
        return _isTaxlessSetter[account];
    }
    function getUniswapRouter() public view returns (IUniswapV2Router02) {
        return IUniswapV2Router02(Constants.getRouterAdd());
    }
    function getUniswapFactory() public view returns (IUniswapV2Factory) {
        return IUniswapV2Factory(Constants.getFactoryAdd());
    }
    function getFactor() public view returns(uint256) {
        if (_presaleDone) {
            return _largeTotal.div(_totalSupply);
        } else {
            return _largeTotal.div(Constants.getLaunchSupply());
        }
    }
    function getUpdatedPoolCounters(address pool, address pairToken) public view returns (uint256, uint256, uint256) {
        uint256 lpBalance = IERC20(pool).totalSupply();
        uint256 tokenBalance = IERC20(address(this)).balanceOf(pool);
        uint256 pairTokenBalance = IERC20(address(pairToken)).balanceOf(pool);
        return (tokenBalance, pairTokenBalance, lpBalance);
    }
    function getMintRate(address pool) external view returns (uint256) {
        uint256 expansionR = (_poolCounters[pool].pairTokenBalance).mul(_poolCounters[pool].startTokenBalance).mul(100).div(_poolCounters[pool].startPairTokenBalance).div(_poolCounters[pool].tokenBalance);
        if (expansionR > (Constants.getBaseExpansionFactor()).add(10000).div(100)) {
            uint256 mintFactor = expansionR.mul(expansionR);
            return mintFactor.sub(10000);
        } else {
            return Constants.getBaseExpansionFactor();
        }
    }
    function getBurnRate(address pool) public view returns (uint256) {
        uint256 contractionR = (_poolCounters[pool].tokenBalance).mul(_poolCounters[pool].startPairTokenBalance).mul(100).div(_poolCounters[pool].pairTokenBalance).div(_poolCounters[pool].startTokenBalance);
        uint256 burnRate;
        if (contractionR > (Constants.getBaseContractionFactor().add(10000)).div(100)) {
            uint256 burnFactor = contractionR.mul(contractionR);
            burnRate = burnFactor.sub(10000);
            if (burnRate > Constants.getBaseContractionCap()) {
                return Constants.getBaseContractionCap();
            }
            return burnRate;

        } else {
            return Constants.getBaseContractionFactor();
        }
    }

    function getUtilityFee(uint256 amount) internal view returns(uint256, uint256) {
        uint256 currentFactor = getFactor();
        uint256 utilityFee = amount.mul(Constants.getBaseUtilityFee()).div(10000);
        return (utilityFee, utilityFee.mul(currentFactor));
    }
}