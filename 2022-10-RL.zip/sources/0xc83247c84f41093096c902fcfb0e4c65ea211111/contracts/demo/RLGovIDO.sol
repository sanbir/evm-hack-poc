// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@chainlink/contracts/src/v0.8/interfaces/AggregatorV3Interface.sol";
import "./interfaces.sol";
import "./pancakeSwap.sol";

contract RLGovIDO is Ownable, IKBKGovIDO {
    using SafeERC20 for IERC20;

    uint internal constant PriSaleLimit = 1e6 * 1e18;

    //for test
    //    uint internal constant Day1 = 10 * 60;// 10 min
    //    uint internal constant Day15 = 2 * Day1;// 20 min

    //for mainnet
    uint internal constant Day1 = 1 * 24 * 60 * 60;// 1 day
    uint internal constant Day5 = 5 * Day1;// 15 day

    uint internal constant PriceFactor = 1e9;//decimal is 9
    uint internal constant StartPriSalePrice = 2 * 1e9 / 10;//decimal is 9

    IERC20 public token;
    address usdt;
    uint public priSaleStartTime;
    uint public priSaleEndTime;
    uint public priSoldTotal;
    AggregatorV3Interface public priceFeed;
    IPancakeSwapV2Router02 pancakeSwapV2Router;
    address public communityReceiver;
    address public bnbReceiver;
    uint public lastReleaseTime;
    uint public releaseAmt;
    uint public releasedAmt;

    struct PriSaleInfo {
        uint priBoughtTotal;
        uint priBoughtRelease;
        uint releaseAmtOnce;
        uint lastReleaseTime;
        uint privateSalePrice;
    }

    mapping(address => PriSaleInfo) public priSoldInfo;
    mapping(address => bool) internal isPriSale;

    event UpdatePriSaleTime(uint start, uint end);
    event PartPriSale(address indexed user, uint kbkAmt, uint priBoughtTotal, uint priBoughtRelease, uint releaseAmtOnce, uint price);


    constructor(address _token, address _communityReceiver, address _bnbReceiver,
        address _usdt, address _priceFeed, address router) {
        priceFeed = AggregatorV3Interface(_priceFeed);
        token = IERC20(_token);
        communityReceiver = _communityReceiver;
        bnbReceiver = _bnbReceiver;
        pancakeSwapV2Router = IPancakeSwapV2Router02(router);
        usdt = _usdt;
    }

    function setToken(address newToken) public onlyOwner {
        token = IERC20(newToken);
    }

    function withdrawToken(address to, uint amount) public onlyOwner {
        IERC20(token).transfer(to, amount);
    }

    function updatePriSaleStartTime(uint _priSaleStartTime, uint _priSaleEndTime) onlyOwner public {
        if (_priSaleStartTime > 0) {
            priSaleStartTime = _priSaleStartTime;
        }
        if (_priSaleEndTime > 0) {
            priSaleEndTime = _priSaleEndTime;
        }
        emit UpdatePriSaleTime(_priSaleStartTime, _priSaleEndTime);
    }

    //private sale
    receive() external payable {
        payable(bnbReceiver).transfer(msg.value);
        if (block.timestamp >= priSaleEndTime) {
            IERC20(token).safeTransfer(communityReceiver, PriSaleLimit - priSoldTotal);
        } else {
            if (msg.value > 0) {
                partPriSale();
            }
        }
    }

    function partPriSale() internal {
        require(block.timestamp >= priSaleStartTime, "not start");
        uint bnbPrice = getBNBPrice();
        // USD
        uint amt = msg.value * bnbPrice / PriceFactor;
        uint kbkPrice = getPriSalePrice();
        uint kbkAmt = amt * PriceFactor / kbkPrice;
        if (kbkAmt == 0) {
            return;
        }
        require(priSoldTotal + kbkAmt <= PriSaleLimit, "sold out");

        address refer = ITokenInterface(address(token)).getFather(msg.sender);
        uint referAward = 0;
        if (refer != address(0)) {
            referAward = kbkAmt * 10 / 100;
        }
        uint release = kbkAmt / 100;
        PriSaleInfo storage user = priSoldInfo[msg.sender];
        user.privateSalePrice = (user.priBoughtTotal * user.privateSalePrice + kbkAmt * kbkPrice) / (user.priBoughtTotal + kbkAmt);
        user.priBoughtTotal += kbkAmt;
        user.priBoughtRelease += release;
        user.releaseAmtOnce += release;
        user.lastReleaseTime = block.timestamp;
        priSoldTotal += (kbkAmt + referAward);
        isPriSale[msg.sender] = true;
        if (release > 0) {
            IERC20(token).safeTransfer(msg.sender, release);
        }
        if (referAward > 0) {
            IERC20(token).safeTransfer(refer, referAward);
        }
        emit PartPriSale(msg.sender, kbkAmt, user.priBoughtTotal, user.priBoughtRelease, user.releaseAmtOnce, user.privateSalePrice);
    }


    function getPriSalePrice() public view returns (uint) {
        if (block.timestamp < priSaleStartTime) {
            return 0;
        } else if (block.timestamp > priSaleStartTime && block.timestamp <= priSaleStartTime + Day5) {
            //0.2
            return 2 * 1e9 / 10;
        } else if (block.timestamp > priSaleStartTime + Day5 && block.timestamp <= priSaleStartTime + Day5 * 2) {
            return 22 * 1e9 / 100;
        } else {
            return 24 * 1e9 / 100;
        }
    }

    function burnPriSale(uint amount) public onlyOwner {
        require(block.timestamp > priSaleEndTime, "not end");
        ITokenInterface(address(token)).burn(amount);
    }

    function isPriSaler(address user) external view override returns (bool) {
        return isPriSale[user];
    }

    function releasePriSale(address user) public override {
        if (block.timestamp < priSaleEndTime) {
            return;
        }
        uint price = getKbkPrice();
        if (price >= 4 * 1e9 / 10) {
            PriSaleInfo storage info = priSoldInfo[user];
            if (info.lastReleaseTime != 0 && Day1 <= block.timestamp - info.lastReleaseTime &&
                info.priBoughtRelease + info.releaseAmtOnce <= info.priBoughtTotal) {
                info.priBoughtRelease += info.releaseAmtOnce;
                info.lastReleaseTime = block.timestamp;
                token.safeTransfer(user, info.releaseAmtOnce);
            }
        }
    }

    function getKbkPrice() public view returns (uint) {
        address[] memory path = new address[](2);
        path[0] = address(token);
        path[1] = address(usdt);
        uint[] memory amounts = pancakeSwapV2Router.getAmountsOut(1e18, path);
        return amounts[1] * PriceFactor / amounts[0];
    }

    function getBNBPrice() public view returns (uint) {
        (
        /*uint80 roundID*/,
        int price,
        /*uint startedAt*/,
        /*uint timeStamp*/,
        /*uint80 answeredInRound*/
        ) = priceFeed.latestRoundData();
        uint8 decimals = priceFeed.decimals();
        //unify price decimals
        return uint(price) * PriceFactor / (10 ** decimals);
    }
}
