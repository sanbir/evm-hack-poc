// SPDX-License-Identifier: MIT
pragma solidity 0.8.12;

import "IVirtualBalanceRewardPool.sol";
import "IBooster.sol";
import "IRewardPool.sol";

import "IERC20.sol";
import "Address.sol";
import "SafeERC20.sol";
import "Math.sol";
import "Initializable.sol";
import "Ownable.sol";

/**
 * @notice distribute rewards during 7 days periods.
 * booster is in charge of keeping track of deposited amounts.
 */

contract RewardPool is IRewardPool, Initializable, Ownable {
    using SafeERC20 for IERC20;

    IERC20 public rewardToken;
    uint256 public duration;
    address public booster;
    address public rewardManager;

    uint256 public pid;
    uint256 public periodFinish;
    uint256 public rewardRate;
    uint256 public lastUpdateTime;
    uint256 public rewardPerTokenStored;
    uint256 public queuedRewards;
    uint256 public currentRewards;
    uint256 public historicalRewards;
    uint256 public constant NEW_REWARD_RATIO = 830;
    uint256 private _totalSupply;
    mapping(address => uint256) public userRewardPerTokenPaid;
    mapping(address => uint256) public rewards;
    mapping(address => uint256) private _balances;

    address[] public extraRewards;

    event RewardAdded(uint256 reward);
    event Staked(address indexed user, uint256 amount);
    event Withdrawn(address indexed user, uint256 amount);
    event RewardPaid(address indexed user, uint256 reward);
    event AddedExtraReward(address reward);
    event DeletedExtraRewards();
    event DurationUpdate(uint256 newDuration, uint256 newRate);

    function initialize(
        uint256 pid_,
        address rewardToken_,
        address booster_,
        address rewardManager_,
        address owner_
    ) external initializer {
        pid = pid_;
        rewardToken = IERC20(rewardToken_);
        booster = booster_;
        rewardManager = rewardManager_;
        duration = 12 hours;
        _transferOwnership(owner_);
    }

    /**
     * @notice
     *  The sum of all the staked tokens
     * @return _totalSupply The total supply
     */
    function totalSupply() public view override returns (uint256) {
        return _totalSupply;
    }

    /**
     * @notice
     *  Balance of staked tokens for a user
     * @param account address of the user
     * @return Balance of the user
     */
    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    /**
     * @notice
     *  Get the number of extraRewards
     * @return the extraRewards length
     */
    function extraRewardsLength() external view returns (uint256) {
        return extraRewards.length;
    }

    function setDuration(uint256 newDuration)
        external
        onlyOwner
        updateReward(address(0))
    {
        if (block.timestamp < periodFinish) {
            uint256 remaining = periodFinish - block.timestamp;
            uint256 leftover = remaining * rewardRate;
            rewardRate = leftover / newDuration;
        }
        duration = newDuration;
        emit DurationUpdate(newDuration, rewardRate);
    }

    /**
     * @notice
     *  Add an extraReward to the extraRewards list
     *  @param _reward The address of the reward pool.
     */
    function addExtraReward(address _reward) external override returns (bool) {
        require(msg.sender == rewardManager, "!authorized");
        require(_reward != address(0), "!reward setting");
        emit AddedExtraReward(_reward);
        extraRewards.push(_reward);
        return true;
    }

    /**
     * @notice
     *  Remove the list of extraRewards.
     */
    function clearExtraRewards() external {
        require(msg.sender == rewardManager, "!authorized");
        emit DeletedExtraRewards();
        delete extraRewards;
    }

    modifier updateReward(address account) {
        rewardPerTokenStored = _rewardPerToken();
        lastUpdateTime = lastTimeRewardApplicable();
        if (account != address(0)) {
            rewards[account] = earned(account);
            userRewardPerTokenPaid[account] = rewardPerTokenStored;
        }
        _;
    }

    /**
     * @notice
     *  Returns the timestamp to conside for reward distribution.
     * @return a timestamp
     */
    function lastTimeRewardApplicable() public view returns (uint256) {
        return Math.min(block.timestamp, periodFinish);
    }

    /**
     * @notice
     *  Returns the amount of rewards per staked token.
     * @return amount of rewards
     */
    function rewardPerToken() external view returns (uint256) {
        return _rewardPerToken();
    }

    function _rewardPerToken() internal view returns (uint256) {
        if (totalSupply() == 0) {
            return rewardPerTokenStored;
        }
        return
            rewardPerTokenStored +
            (((lastTimeRewardApplicable() - lastUpdateTime) *
                rewardRate *
                1e18) / totalSupply());
    }

    /**
     * @notice
     *  Get the aount of tokens earned by an account
     * @param account that staked tokens
     * @return amount of rewards
     */
    function earned(address account) public view returns (uint256) {
        return
            (balanceOf(account) *
                (_rewardPerToken() - userRewardPerTokenPaid[account])) /
            1e18 +
            rewards[account];
    }

    /**
     * @notice
     *  Stake for for a user that's not the sender.
     * @dev tokens are transfered from msg.sender but balance is increased for _for.
     * @param _for token will be staked for this account
     * @param _amount the amount of token to stake
     */
    function stake(address _for, uint256 _amount)
        external
        override
        updateReward(_for)
        returns (bool)
    {
        require(_amount > 0, "RewardPool : Cannot stake 0");
        require(msg.sender == booster, "!authorized");

        //also stake to linked rewards
        for (uint256 i = 0; i < extraRewards.length; i++) {
            IVirtualBalanceRewardPool(extraRewards[i]).stake(_for, _amount);
        }

        //give to _for
        _totalSupply += _amount;
        _balances[_for] += _amount;

        emit Staked(_for, _amount);

        return true;
    }

    /**
     * @notice
     *  Unstake tokens from the pool and then from the booster
     * @dev Before unstaking the rewards for the account are updated
     * @param amount amount of tokens to withdraw
     * @param claim claim the rewards
     */
    function unStake(
        address _for,
        uint256 amount,
        bool claim
    ) external override updateReward(_for) returns (bool) {
        require(msg.sender == booster, "!authorized");
        //also withdraw from linked rewards
        for (uint256 i = 0; i < extraRewards.length; i++) {
            IVirtualBalanceRewardPool(extraRewards[i]).withdraw(_for, amount);
        }

        _totalSupply -= amount;
        _balances[_for] -= amount;

        emit Withdrawn(_for, amount);

        //get rewards too
        if (claim) {
            getReward(_for, true);
        }
        return true;
    }

    /**
     * @notice
     *  Get rewards
     * @param _account account to get rewards for
     * @param _claimExtras claim extra rewards
     */
    function getReward(address _account, bool _claimExtras)
        public
        updateReward(_account)
        returns (bool)
    {
        uint256 reward = earned(_account);
        if (reward > 0) {
            rewards[_account] = 0;
            rewardToken.safeTransfer(_account, reward);
            emit RewardPaid(_account, reward);
        }

        //also get rewards from linked rewards
        if (_claimExtras) {
            for (uint256 i = 0; i < extraRewards.length; i++) {
                IVirtualBalanceRewardPool(extraRewards[i]).getReward(_account);
            }
        }
        return true;
    }

    /**
     * @notice
     *  Get rewards for msg.sender and claim extra rewards
     */
    function getReward() external override returns (bool) {
        getReward(msg.sender, true);
        return true;
    }

    /**
     * @notice
     *  Donate rewardToken to the pool
     *  @dev they will added to the queuedRewards and distribution will start once queueNewRewards is called.
     *  @param _amount amount of tokens to donate
     */
    function donate(uint256 _amount) external returns (bool) {
        IERC20(rewardToken).safeTransferFrom(
            msg.sender,
            address(this),
            _amount
        );
        queuedRewards = queuedRewards + _amount;
        return true;
    }

    /**
     * @notice
     *  Add some more rewards in to the pool
     *  @dev funds should be transfered before queueNewRewards is called
     *  @param _rewards amount of tokens to add to rewards
     */
    function queueNewRewards(uint256 _rewards)
        external
        override
        returns (bool)
    {
        IERC20(rewardToken).safeTransferFrom(
            msg.sender,
            address(this),
            _rewards
        );

        _rewards = _rewards + queuedRewards;

        if (block.timestamp >= periodFinish) {
            _notifyRewardAmount(_rewards);
            queuedRewards = 0;
            return true;
        }

        //et = now - (finish-duration)
        uint256 elapsedTime = block.timestamp - (periodFinish - duration);
        //current at now: rewardRate * elapsedTime
        uint256 currentAtNow = rewardRate * elapsedTime;
        uint256 queuedRatio = (currentAtNow * 1000) / _rewards;

        //uint256 queuedRatio = currentRewards * 1000 / _rewards;
        if (queuedRatio < NEW_REWARD_RATIO) {
            _notifyRewardAmount(_rewards);
            queuedRewards = 0;
        } else {
            queuedRewards = _rewards;
        }
        return true;
    }

    function _notifyRewardAmount(uint256 reward)
        internal
        updateReward(address(0))
    {
        historicalRewards = historicalRewards + reward;
        if (block.timestamp >= periodFinish) {
            rewardRate = reward / duration;
        } else {
            uint256 remaining = periodFinish - block.timestamp;
            uint256 leftover = remaining * rewardRate;
            reward = reward + leftover;
            rewardRate = reward / duration;
        }
        currentRewards = reward;
        lastUpdateTime = block.timestamp;
        periodFinish = block.timestamp + duration;
        emit RewardAdded(reward);
    }
}
