// SPDX-License-Identifier: MIT
pragma solidity 0.8.12;

import "IVirtualBalanceRewardPool.sol";
import "IBooster.sol";
import "IRewardPool.sol";

import "IERC20.sol";
import "SafeERC20.sol";
import "OwnableUpgradeable.sol";
import "UUPSUpgradeable.sol";

/**
 * @notice distribute rewards during 7 days periods.
 * booster is in charge of keeping track of deposited amounts.
 */

contract RewardPool is IRewardPool, OwnableUpgradeable, UUPSUpgradeable {
    using SafeERC20 for IERC20;

    uint256 constant PRECISION_FACTOR = 1e18;

    IERC20 public rewardToken;
    address public booster;
    address public rewardManager;
    uint256 public pid;

    uint256 public rewardPerTokenStored;
    uint256 public queuedRewards;
    uint256 public toDistribute;

    uint256 private _totalSupply;
    mapping(address => uint256) public userRewardPerTokenPaid;
    mapping(address => uint256) public rewards;
    mapping(address => uint256) private _balances;
    address public legacyRewardPool;

    address[] public extraRewards;

    event RewardAdded(uint256 reward);
    event Staked(address indexed user, uint256 amount);
    event Withdrawn(address indexed user, uint256 amount);
    event RewardPaid(address indexed user, uint256 reward);
    event AddedExtraReward(address reward);
    event DeletedExtraRewards();
    event RemovedExtraReward(address indexed reward);
    event UpdatedRewardManager(address indexed rewardManager);

    function initialize(
        uint256 pid_,
        address rewardToken_,
        address booster_,
        address rewardManager_,
        address owner_
    ) external initializer {
        pid = pid_;
        rewardToken = IERC20(rewardToken_);
        booster = booster_;
        rewardManager = rewardManager_;
        IBooster.PoolInfo memory poolInfo = IBooster(booster_).pools(pid_);
        legacyRewardPool = poolInfo.legacyRewardPool;
        _transferOwnership(owner_);
    }

    function _authorizeUpgrade(address _nextVersion)
        internal
        override
        onlyOwner
    {}

    /**
     * @notice
     *  The sum of all the staked tokens including supply from the legacy pool if it exists.
     * @return _totalSupply The total supply
     */
    function totalSupply() public view override returns (uint256) {
        if (legacyRewardPool != address(0x0)) {
            return _totalSupply + IRewardPool(legacyRewardPool).totalSupply();
        }
        return _totalSupply;
    }

    /**
     * @notice
     *  Balance of staked tokens for a user including balance from the legacy pool if it exists.
     * @param _account address of the user
     * @return Balance of the user
     */
    function balanceOf(address _account)
        public
        view
        override
        returns (uint256)
    {
        if (legacyRewardPool != address(0x0)) {
            return
                _balances[_account] +
                IRewardPool(legacyRewardPool).balanceOf(_account);
        }
        return _balances[_account];
    }

    /**
     * @notice
     *  Get the number of extraRewards
     * @return the extraRewards length
     */
    function extraRewardsLength() external view returns (uint256) {
        return extraRewards.length;
    }

    function setRewardManager(address _rewardManager) external returns (bool) {
        require(
            msg.sender == rewardManager || msg.sender == owner(),
            "!authorized"
        );

        require(_rewardManager != address(0), "_rewardManager 0x0 address");
        rewardManager = _rewardManager;
        emit UpdatedRewardManager(rewardManager);
        return true;
    }

    function setLegacyRewardPool(address _legacyRewardPool) external onlyOwner {
        legacyRewardPool = _legacyRewardPool;
    }

    /**
     * @notice
     *  Add an extraReward to the extraRewards list
     *  @param _reward The address of the reward pool.
     */
    function addExtraReward(address _reward) external override returns (bool) {
        require(
            msg.sender == rewardManager || msg.sender == owner(),
            "!authorized"
        );
        require(_reward != address(0), "!reward setting");
        emit AddedExtraReward(_reward);
        extraRewards.push(_reward);
        return true;
    }

    /** @notice remove extra rewards
     *  @param _extraReward the contract address
     */
    function removeExtraReward(address _extraReward) external returns (bool) {
        require(
            msg.sender == rewardManager || msg.sender == owner(),
            "!authorized"
        );
        uint256 index = type(uint256).max;
        uint256 length = extraRewards.length;
        for (uint256 i = 0; i < length; i++) {
            if (extraRewards[i] == _extraReward) {
                index = i;
                break;
            }
        }
        require(index != type(uint256).max, "extra reward not found");
        emit RemovedExtraReward(_extraReward);
        extraRewards[index] = extraRewards[extraRewards.length - 1];
        extraRewards.pop();
        return true;
    }

    /**
     * @notice
     *  Remove the list of extraRewards.
     */
    function clearExtraRewards() external {
        require(msg.sender == rewardManager, "!authorized");
        emit DeletedExtraRewards();
        delete extraRewards;
    }

    modifier updateReward(address account) {
        rewards[account] = earned(account);
        userRewardPerTokenPaid[account] = rewardPerTokenStored;
        _;
    }

    /**
     * @notice
     *  Returns the amount of rewards per staked token.
     * @return amount of rewards
     */
    function rewardPerToken() external view returns (uint256) {
        return rewardPerTokenStored;
    }

    /**
     * @notice
     *  Get the aount of tokens earned by an account
     * @param account that staked tokens
     * @return amount of rewards
     */
    function earned(address account) public view returns (uint256) {
        return
            (balanceOf(account) *
                (rewardPerTokenStored - userRewardPerTokenPaid[account])) /
            PRECISION_FACTOR +
            rewards[account];
    }

    function migrateStake(address _for, uint256 _amount)
        external
        returns (bool)
    {
        require(_balances[_for] == 0, "already have balance");
        require(
            IRewardPool(legacyRewardPool).balanceOf(_for) == 0,
            "non zero legacy balance"
        );

        require(msg.sender == booster, "!authorized");
        require(_amount > 0, "RewardPool : Cannot stake 0");

        _totalSupply += _amount;
        _balances[_for] += _amount;

        emit Staked(_for, _amount);
        return true;
    }

    /**
     * @notice
     *  Stake for for a user that's not the sender.
     * @dev tokens are transfered from msg.sender but balance is increased for _for.
     * @param _for token will be staked for this account
     * @param _amount the amount of token to stake
     */
    function stake(address _for, uint256 _amount)
        external
        override
        updateReward(_for)
        returns (bool)
    {
        require(msg.sender == booster, "!authorized");
        require(_amount > 0, "RewardPool : Cannot stake 0");

        //also stake to linked rewards
        for (uint256 i = 0; i < extraRewards.length; i++) {
            IVirtualBalanceRewardPool(extraRewards[i]).stake(_for, _amount);
        }

        _totalSupply += _amount;
        _balances[_for] += _amount;

        emit Staked(_for, _amount);

        return true;
    }

    /**
     * @notice
     *  Unstake tokens from the pool and then from the booster
     * @dev Before unstaking the rewards for the account are updated
     * @param amount amount of tokens to withdraw
     * @param claim claim the rewards
     */
    function unStake(
        address _for,
        uint256 amount,
        bool claim
    ) external override updateReward(_for) returns (bool) {
        require(msg.sender == booster, "!authorized");
        //also withdraw from linked rewards
        for (uint256 i = 0; i < extraRewards.length; i++) {
            IVirtualBalanceRewardPool(extraRewards[i]).withdraw(_for, amount);
        }

        _totalSupply -= amount;
        _balances[_for] -= amount;

        emit Withdrawn(_for, amount);

        //get rewards too
        if (claim) {
            getReward(_for, true);
        }
        return true;
    }

    /**
     * @notice
     *  Get rewards
     * @param _account account to get rewards for
     * @param _claimExtras claim extra rewards
     */
    function getReward(address _account, bool _claimExtras)
        public
        updateReward(_account)
        returns (bool)
    {
        if (legacyRewardPool != address(0x0)) {
            require(
                IRewardPool(legacyRewardPool).balanceOf(_account) == 0,
                "must migrate"
            );
        }

        uint256 reward = rewards[_account];
        if (reward > 0) {
            rewards[_account] = 0;
            toDistribute -= reward;
            IERC20(rewardToken).safeTransferFrom(booster, _account, reward);
            emit RewardPaid(_account, reward);
        }

        //also get rewards from linked rewards
        if (_claimExtras) {
            for (uint256 i = 0; i < extraRewards.length; i++) {
                IVirtualBalanceRewardPool(extraRewards[i]).getReward(_account);
            }
        }
        return true;
    }

    /**
     * @notice
     *  Get rewards for msg.sender and claim extra rewards
     */
    function getReward() external override returns (bool) {
        getReward(msg.sender, true);
        return true;
    }

    /**
     * @notice
     *  Add some more rewards in to the pool
     *  @dev funds should be transfered before queueNewRewards is called
     *  @param _rewards amount of tokens to add to rewards
     */
    function queueNewRewards(uint256 _rewards)
        external
        override
        returns (bool)
    {
        require(msg.sender == booster, "!authorized");
        if (totalSupply() == 0) {
            queuedRewards += _rewards;
            return true;
        }

        if (queuedRewards > 0) {
            _rewards += queuedRewards;
            queuedRewards = 0;
        }
        rewardPerTokenStored =
            (_rewards * PRECISION_FACTOR) /
            totalSupply() +
            rewardPerTokenStored;
        toDistribute += _rewards;
        emit RewardAdded(_rewards);

        return true;
    }
}
