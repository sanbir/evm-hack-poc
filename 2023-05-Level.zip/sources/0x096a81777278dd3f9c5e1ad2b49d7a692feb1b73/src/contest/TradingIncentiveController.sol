// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.15;

import {IERC20} from "openzeppelin/token/ERC20/IERC20.sol";
import {SafeERC20} from "openzeppelin/token/ERC20/utils/SafeERC20.sol";
import {Initializable} from "openzeppelin-upgradeable/proxy/utils/Initializable.sol";
import {OwnableUpgradeable} from "openzeppelin-upgradeable/access/OwnableUpgradeable.sol";
import {ILVLOracle} from "../interfaces/ILVLOracle.sol";
import {ILyLevel} from "src/interfaces/contest/ILyLevel.sol";
import {ITradingContest} from "src/interfaces/contest/ITradingContest.sol";

contract TradingIncentiveController is Initializable, OwnableUpgradeable {
    /*================= VARIABLES ================*/
    using SafeERC20 for IERC20;

    uint256 public constant MIN_EPOCH_DURATION = 1 days;
    uint256 public constant MAX_REWARD_TOKENS = 30_000e18;
    uint256 public constant LOYALTY_CAP = 50_000e30;
    uint256 public constant STEP_REVENUE = 50_000e30;
    uint256 public constant BASE_REVENUE = 100_000e30;
    uint256 public constant STEP_REWARD = 20_000e30;

    uint256 public currentEpoch;
    uint256 public lastEpochTimestamp;
    uint256 public epochDuration;
    uint256 public epochFee;

    address public poolHook;
    address public admin;
    IERC20 public LVL;
    ILVLOracle public lvlOracle;
    ILyLevel public lyLevel;
    ITradingContest public tradingContest;

    constructor() {
        _disableInitializers();
    }

    function initialize(address _lvl, address _lvlOracle, address _poolHook) external initializer {
        require(_lvl != address(0), "Invalid address");
        require(_lvlOracle != address(0), "Invalid address");
        require(_poolHook != address(0), "Invalid address");

        __Ownable_init();
        LVL = IERC20(_lvl);
        lvlOracle = ILVLOracle(_lvlOracle);
        lvlOracle.update();
        poolHook = _poolHook;
    }

    function reinit_setStartTime() external reinitializer(2) {
        lastEpochTimestamp = 1682604000;
    }

    /*=================== MULTATIVE =====================*/

    function record(uint256 _value) external {
        require(msg.sender == poolHook, "Only poolHook");
        epochFee += _value;
    }

    function allocate() external {
        require(msg.sender == admin, "!Admin");
        require(lastEpochTimestamp > 0, "Not started");

        uint256 _nextEpochTimestamp = lastEpochTimestamp + epochDuration;
        require(block.timestamp >= _nextEpochTimestamp, "now < trigger time");

        lvlOracle.update();
        uint256 _twap = lvlOracle.lastTWAP();
        uint256 _loyaltyRewards = LOYALTY_CAP / _twap;
        if (_loyaltyRewards > MAX_REWARD_TOKENS) {
            _loyaltyRewards = MAX_REWARD_TOKENS;
        }
        LVL.safeIncreaseAllowance(address(lyLevel), _loyaltyRewards);
        lyLevel.addReward(_loyaltyRewards);

        if (epochFee >= BASE_REVENUE) {
            uint256 _rewards = ((epochFee - BASE_REVENUE) / STEP_REVENUE + 1) * STEP_REWARD;

            uint256 _contestRewardTokens = _rewards / _twap;
            if (_contestRewardTokens > MAX_REWARD_TOKENS - _loyaltyRewards) {
                _contestRewardTokens = MAX_REWARD_TOKENS - _loyaltyRewards;
            }
            LVL.safeIncreaseAllowance(address(tradingContest), _contestRewardTokens);
            tradingContest.addReward(_contestRewardTokens);
        }

        epochFee = 0;
        lastEpochTimestamp = _nextEpochTimestamp;
        emit Allocated(currentEpoch);

        currentEpoch++;
        emit EpochStarted(currentEpoch);
    }

    function start(uint256 _startTime) external {
        require(lastEpochTimestamp == 0, "started");
        require(_startTime >= block.timestamp, "start time < current time");
        lastEpochTimestamp = _startTime;
        lvlOracle.update();
        emit EpochStarted(currentEpoch);
    }

    /*================ ADMIN ===================*/

    function setEpochDuration(uint256 _epochDuration) public onlyOwner {
        require(_epochDuration >= MIN_EPOCH_DURATION, "must >= MIN_EPOCH_DURATION");
        epochDuration = _epochDuration;
        emit EpochDurationSet(epochDuration);
    }

    function setPoolHook(address _poolHook) external onlyOwner {
        require(_poolHook != address(0), "Invalid address");
        poolHook = _poolHook;
        emit PoolHookSet(_poolHook);
    }

    function setLyLevel(address _lyLevel) external onlyOwner {
        require(_lyLevel != address(0), "Invalid address");
        lyLevel = ILyLevel(_lyLevel);
        emit LyLevelSet(_lyLevel);
    }

    function setTradingContest(address _tradingContest) external onlyOwner {
        require(_tradingContest != address(0), "Invalid address");
        tradingContest = ITradingContest(_tradingContest);
        emit TradingContestSet(_tradingContest);
    }

    function setOracle(address _oracle) external onlyOwner {
        require(_oracle != address(0), "Invalid address");
        lvlOracle = ILVLOracle(_oracle);
        lvlOracle.update();
        emit OracleSet(_oracle);
    }

    function setAdmin(address _admin) external onlyOwner {
        require(_admin != address(0), "Invalid address");
        admin = _admin;
        emit AdminSet(_admin);
    }

    function withdrawLVL(address _to, uint256 _amount) external onlyOwner {
        require(_to != address(0), "Invalid address");
        LVL.safeTransfer(_to, _amount);
        emit LVLWithdrawn(_to, _amount);
    }

    /*================ EVENTS ===================*/
    event TradingContestSet(address _addr);
    event LyLevelSet(address _addr);
    event PoolHookSet(address _addr);
    event OracleSet(address _oracle);
    event Allocated(uint256 _epoch);
    event EpochStarted(uint256 _epoch);
    event LVLWithdrawn(address _to, uint256 _amount);
    event EpochDurationSet(uint256 _duration);
    event AdminSet(address _admin);
}
