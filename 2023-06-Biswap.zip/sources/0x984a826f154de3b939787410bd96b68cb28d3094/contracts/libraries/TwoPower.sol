// SPDX-License-Identifier: MIT
pragma solidity 0.8.16;

library TwoPower {
    uint256 internal constant Pow128 = 0x100000000000000000000000000000000;
    uint256 internal constant pow128 = 0x100000000000000000000000000000000;
    uint256 internal constant Pow96 = 0x1000000000000000000000000;
    uint256 internal constant pow96 = 0x1000000000000000000000000;
    uint8 internal constant RESOLUTION = 96;
}
