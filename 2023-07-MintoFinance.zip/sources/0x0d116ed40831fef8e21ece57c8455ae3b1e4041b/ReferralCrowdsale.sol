// Sources flattened with hardhat v2.11.0 https://hardhat.org

// File contracts/interfaces/IStaking.sol

//SPDX-License-Identifier: MIT
pragma solidity 0.8.16;

interface IStaking {
    function userStake(address user)
        external
        view
        returns (
            uint256 _sum,
            uint256 _bonus,
            uint256 _stake
        );
}

interface IStakingOwn {
    struct StakeRecord {
        uint256 day;
        uint256 totalAmount;
        uint256 lockedAmount;
        uint256 unlockedAmount;
        uint256 previousAmount;
        uint256 reservedReward;
        uint256 claimedDay;
    }

    function userStakes(address user)
        external
        view
        returns (StakeRecord memory);
}


// File contracts/interfaces/IToken.sol


pragma solidity 0.8.16;

interface IToken {
    function mintLocked(
        address to,
        uint256 amount,
        uint256 timeInWeeks
    ) external;
}


// File contracts/interfaces/IPair.sol


pragma solidity 0.8.16;

interface IPair {
    function token0() external view returns (address);

    function token1() external view returns (address);

    function getReserves()
        external
        view
        returns (
            uint112 reserve0,
            uint112 reserve1,
            uint32 blockTimestampLast
        );
}


// File contracts/pancake-swap/libraries/TransferHelper.sol



pragma solidity ^0.8.0;

// helper methods for interacting with ERC20 tokens and sending ETH that do not consistently return true/false
library TransferHelper {
    function safeApprove(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('approve(address,uint256)')));
        (bool success, bytes memory data) =
            token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            "TransferHelper::safeApprove: approve failed"
        );
    }

    function safeTransfer(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transfer(address,uint256)')));
        (bool success, bytes memory data) =
            token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            "TransferHelper::safeTransfer: transfer failed"
        );
    }

    function safeTransferFrom(
        address token,
        address from,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
        (bool success, bytes memory data) =
            token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            "TransferHelper::transferFrom: transferFrom failed"
        );
    }

    function safeTransferETH(address to, uint256 value) internal {
        (bool success, ) = to.call{value: value}(new bytes(0));
        require(
            success,
            "TransferHelper::safeTransferETH: ETH transfer failed"
        );
    }
}


// File @openzeppelin/contracts/access/IAccessControl.sol@v4.7.3


// OpenZeppelin Contracts v4.4.1 (access/IAccessControl.sol)

pragma solidity ^0.8.0;

/**
 * @dev External interface of AccessControl declared to support ERC165 detection.
 */
interface IAccessControl {
    /**
     * @dev Emitted when `newAdminRole` is set as ``role``'s admin role, replacing `previousAdminRole`
     *
     * `DEFAULT_ADMIN_ROLE` is the starting admin for all roles, despite
     * {RoleAdminChanged} not being emitted signaling this.
     *
     * _Available since v3.1._
     */
    event RoleAdminChanged(bytes32 indexed role, bytes32 indexed previousAdminRole, bytes32 indexed newAdminRole);

    /**
     * @dev Emitted when `account` is granted `role`.
     *
     * `sender` is the account that originated the contract call, an admin role
     * bearer except when using {AccessControl-_setupRole}.
     */
    event RoleGranted(bytes32 indexed role, address indexed account, address indexed sender);

    /**
     * @dev Emitted when `account` is revoked `role`.
     *
     * `sender` is the account that originated the contract call:
     *   - if using `revokeRole`, it is the admin role bearer
     *   - if using `renounceRole`, it is the role bearer (i.e. `account`)
     */
    event RoleRevoked(bytes32 indexed role, address indexed account, address indexed sender);

    /**
     * @dev Returns `true` if `account` has been granted `role`.
     */
    function hasRole(bytes32 role, address account) external view returns (bool);

    /**
     * @dev Returns the admin role that controls `role`. See {grantRole} and
     * {revokeRole}.
     *
     * To change a role's admin, use {AccessControl-_setRoleAdmin}.
     */
    function getRoleAdmin(bytes32 role) external view returns (bytes32);

    /**
     * @dev Grants `role` to `account`.
     *
     * If `account` had not been already granted `role`, emits a {RoleGranted}
     * event.
     *
     * Requirements:
     *
     * - the caller must have ``role``'s admin role.
     */
    function grantRole(bytes32 role, address account) external;

    /**
     * @dev Revokes `role` from `account`.
     *
     * If `account` had been granted `role`, emits a {RoleRevoked} event.
     *
     * Requirements:
     *
     * - the caller must have ``role``'s admin role.
     */
    function revokeRole(bytes32 role, address account) external;

    /**
     * @dev Revokes `role` from the calling account.
     *
     * Roles are often managed via {grantRole} and {revokeRole}: this function's
     * purpose is to provide a mechanism for accounts to lose their privileges
     * if they are compromised (such as when a trusted device is misplaced).
     *
     * If the calling account had been granted `role`, emits a {RoleRevoked}
     * event.
     *
     * Requirements:
     *
     * - the caller must be `account`.
     */
    function renounceRole(bytes32 role, address account) external;
}


// File @openzeppelin/contracts/utils/Context.sol@v4.7.3


// OpenZeppelin Contracts v4.4.1 (utils/Context.sol)

pragma solidity ^0.8.0;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}


// File @openzeppelin/contracts/utils/Strings.sol@v4.7.3


// OpenZeppelin Contracts (last updated v4.7.0) (utils/Strings.sol)

pragma solidity ^0.8.0;

/**
 * @dev String operations.
 */
library Strings {
    bytes16 private constant _HEX_SYMBOLS = "0123456789abcdef";
    uint8 private constant _ADDRESS_LENGTH = 20;

    /**
     * @dev Converts a `uint256` to its ASCII `string` decimal representation.
     */
    function toString(uint256 value) internal pure returns (string memory) {
        // Inspired by OraclizeAPI's implementation - MIT licence
        // https://github.com/oraclize/ethereum-api/blob/b42146b063c7d6ee1358846c198246239e9360e8/oraclizeAPI_0.4.25.sol

        if (value == 0) {
            return "0";
        }
        uint256 temp = value;
        uint256 digits;
        while (temp != 0) {
            digits++;
            temp /= 10;
        }
        bytes memory buffer = new bytes(digits);
        while (value != 0) {
            digits -= 1;
            buffer[digits] = bytes1(uint8(48 + uint256(value % 10)));
            value /= 10;
        }
        return string(buffer);
    }

    /**
     * @dev Converts a `uint256` to its ASCII `string` hexadecimal representation.
     */
    function toHexString(uint256 value) internal pure returns (string memory) {
        if (value == 0) {
            return "0x00";
        }
        uint256 temp = value;
        uint256 length = 0;
        while (temp != 0) {
            length++;
            temp >>= 8;
        }
        return toHexString(value, length);
    }

    /**
     * @dev Converts a `uint256` to its ASCII `string` hexadecimal representation with fixed length.
     */
    function toHexString(uint256 value, uint256 length) internal pure returns (string memory) {
        bytes memory buffer = new bytes(2 * length + 2);
        buffer[0] = "0";
        buffer[1] = "x";
        for (uint256 i = 2 * length + 1; i > 1; --i) {
            buffer[i] = _HEX_SYMBOLS[value & 0xf];
            value >>= 4;
        }
        require(value == 0, "Strings: hex length insufficient");
        return string(buffer);
    }

    /**
     * @dev Converts an `address` with fixed length of 20 bytes to its not checksummed ASCII `string` hexadecimal representation.
     */
    function toHexString(address addr) internal pure returns (string memory) {
        return toHexString(uint256(uint160(addr)), _ADDRESS_LENGTH);
    }
}


// File @openzeppelin/contracts/utils/introspection/IERC165.sol@v4.7.3


// OpenZeppelin Contracts v4.4.1 (utils/introspection/IERC165.sol)

pragma solidity ^0.8.0;

/**
 * @dev Interface of the ERC165 standard, as defined in the
 * https://eips.ethereum.org/EIPS/eip-165[EIP].
 *
 * Implementers can declare support of contract interfaces, which can then be
 * queried by others ({ERC165Checker}).
 *
 * For an implementation, see {ERC165}.
 */
interface IERC165 {
    /**
     * @dev Returns true if this contract implements the interface defined by
     * `interfaceId`. See the corresponding
     * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]
     * to learn more about how these ids are created.
     *
     * This function call must use less than 30 000 gas.
     */
    function supportsInterface(bytes4 interfaceId) external view returns (bool);
}


// File @openzeppelin/contracts/utils/introspection/ERC165.sol@v4.7.3


// OpenZeppelin Contracts v4.4.1 (utils/introspection/ERC165.sol)

pragma solidity ^0.8.0;

/**
 * @dev Implementation of the {IERC165} interface.
 *
 * Contracts that want to implement ERC165 should inherit from this contract and override {supportsInterface} to check
 * for the additional interface id that will be supported. For example:
 *
 * ```solidity
 * function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
 *     return interfaceId == type(MyInterface).interfaceId || super.supportsInterface(interfaceId);
 * }
 * ```
 *
 * Alternatively, {ERC165Storage} provides an easier to use but more expensive implementation.
 */
abstract contract ERC165 is IERC165 {
    /**
     * @dev See {IERC165-supportsInterface}.
     */
    function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
        return interfaceId == type(IERC165).interfaceId;
    }
}


// File @openzeppelin/contracts/access/AccessControl.sol@v4.7.3


// OpenZeppelin Contracts (last updated v4.7.0) (access/AccessControl.sol)

pragma solidity ^0.8.0;




/**
 * @dev Contract module that allows children to implement role-based access
 * control mechanisms. This is a lightweight version that doesn't allow enumerating role
 * members except through off-chain means by accessing the contract event logs. Some
 * applications may benefit from on-chain enumerability, for those cases see
 * {AccessControlEnumerable}.
 *
 * Roles are referred to by their `bytes32` identifier. These should be exposed
 * in the external API and be unique. The best way to achieve this is by
 * using `public constant` hash digests:
 *
 * ```
 * bytes32 public constant MY_ROLE = keccak256("MY_ROLE");
 * ```
 *
 * Roles can be used to represent a set of permissions. To restrict access to a
 * function call, use {hasRole}:
 *
 * ```
 * function foo() public {
 *     require(hasRole(MY_ROLE, msg.sender));
 *     ...
 * }
 * ```
 *
 * Roles can be granted and revoked dynamically via the {grantRole} and
 * {revokeRole} functions. Each role has an associated admin role, and only
 * accounts that have a role's admin role can call {grantRole} and {revokeRole}.
 *
 * By default, the admin role for all roles is `DEFAULT_ADMIN_ROLE`, which means
 * that only accounts with this role will be able to grant or revoke other
 * roles. More complex role relationships can be created by using
 * {_setRoleAdmin}.
 *
 * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
 * grant and revoke this role. Extra precautions should be taken to secure
 * accounts that have been granted it.
 */
abstract contract AccessControl is Context, IAccessControl, ERC165 {
    struct RoleData {
        mapping(address => bool) members;
        bytes32 adminRole;
    }

    mapping(bytes32 => RoleData) private _roles;

    bytes32 public constant DEFAULT_ADMIN_ROLE = 0x00;

    /**
     * @dev Modifier that checks that an account has a specific role. Reverts
     * with a standardized message including the required role.
     *
     * The format of the revert reason is given by the following regular expression:
     *
     *  /^AccessControl: account (0x[0-9a-f]{40}) is missing role (0x[0-9a-f]{64})$/
     *
     * _Available since v4.1._
     */
    modifier onlyRole(bytes32 role) {
        _checkRole(role);
        _;
    }

    /**
     * @dev See {IERC165-supportsInterface}.
     */
    function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
        return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
    }

    /**
     * @dev Returns `true` if `account` has been granted `role`.
     */
    function hasRole(bytes32 role, address account) public view virtual override returns (bool) {
        return _roles[role].members[account];
    }

    /**
     * @dev Revert with a standard message if `_msgSender()` is missing `role`.
     * Overriding this function changes the behavior of the {onlyRole} modifier.
     *
     * Format of the revert message is described in {_checkRole}.
     *
     * _Available since v4.6._
     */
    function _checkRole(bytes32 role) internal view virtual {
        _checkRole(role, _msgSender());
    }

    /**
     * @dev Revert with a standard message if `account` is missing `role`.
     *
     * The format of the revert reason is given by the following regular expression:
     *
     *  /^AccessControl: account (0x[0-9a-f]{40}) is missing role (0x[0-9a-f]{64})$/
     */
    function _checkRole(bytes32 role, address account) internal view virtual {
        if (!hasRole(role, account)) {
            revert(
                string(
                    abi.encodePacked(
                        "AccessControl: account ",
                        Strings.toHexString(uint160(account), 20),
                        " is missing role ",
                        Strings.toHexString(uint256(role), 32)
                    )
                )
            );
        }
    }

    /**
     * @dev Returns the admin role that controls `role`. See {grantRole} and
     * {revokeRole}.
     *
     * To change a role's admin, use {_setRoleAdmin}.
     */
    function getRoleAdmin(bytes32 role) public view virtual override returns (bytes32) {
        return _roles[role].adminRole;
    }

    /**
     * @dev Grants `role` to `account`.
     *
     * If `account` had not been already granted `role`, emits a {RoleGranted}
     * event.
     *
     * Requirements:
     *
     * - the caller must have ``role``'s admin role.
     *
     * May emit a {RoleGranted} event.
     */
    function grantRole(bytes32 role, address account) public virtual override onlyRole(getRoleAdmin(role)) {
        _grantRole(role, account);
    }

    /**
     * @dev Revokes `role` from `account`.
     *
     * If `account` had been granted `role`, emits a {RoleRevoked} event.
     *
     * Requirements:
     *
     * - the caller must have ``role``'s admin role.
     *
     * May emit a {RoleRevoked} event.
     */
    function revokeRole(bytes32 role, address account) public virtual override onlyRole(getRoleAdmin(role)) {
        _revokeRole(role, account);
    }

    /**
     * @dev Revokes `role` from the calling account.
     *
     * Roles are often managed via {grantRole} and {revokeRole}: this function's
     * purpose is to provide a mechanism for accounts to lose their privileges
     * if they are compromised (such as when a trusted device is misplaced).
     *
     * If the calling account had been revoked `role`, emits a {RoleRevoked}
     * event.
     *
     * Requirements:
     *
     * - the caller must be `account`.
     *
     * May emit a {RoleRevoked} event.
     */
    function renounceRole(bytes32 role, address account) public virtual override {
        require(account == _msgSender(), "AccessControl: can only renounce roles for self");

        _revokeRole(role, account);
    }

    /**
     * @dev Grants `role` to `account`.
     *
     * If `account` had not been already granted `role`, emits a {RoleGranted}
     * event. Note that unlike {grantRole}, this function doesn't perform any
     * checks on the calling account.
     *
     * May emit a {RoleGranted} event.
     *
     * [WARNING]
     * ====
     * This function should only be called from the constructor when setting
     * up the initial roles for the system.
     *
     * Using this function in any other way is effectively circumventing the admin
     * system imposed by {AccessControl}.
     * ====
     *
     * NOTE: This function is deprecated in favor of {_grantRole}.
     */
    function _setupRole(bytes32 role, address account) internal virtual {
        _grantRole(role, account);
    }

    /**
     * @dev Sets `adminRole` as ``role``'s admin role.
     *
     * Emits a {RoleAdminChanged} event.
     */
    function _setRoleAdmin(bytes32 role, bytes32 adminRole) internal virtual {
        bytes32 previousAdminRole = getRoleAdmin(role);
        _roles[role].adminRole = adminRole;
        emit RoleAdminChanged(role, previousAdminRole, adminRole);
    }

    /**
     * @dev Grants `role` to `account`.
     *
     * Internal function without access restriction.
     *
     * May emit a {RoleGranted} event.
     */
    function _grantRole(bytes32 role, address account) internal virtual {
        if (!hasRole(role, account)) {
            _roles[role].members[account] = true;
            emit RoleGranted(role, account, _msgSender());
        }
    }

    /**
     * @dev Revokes `role` from `account`.
     *
     * Internal function without access restriction.
     *
     * May emit a {RoleRevoked} event.
     */
    function _revokeRole(bytes32 role, address account) internal virtual {
        if (hasRole(role, account)) {
            _roles[role].members[account] = false;
            emit RoleRevoked(role, account, _msgSender());
        }
    }
}


// File @openzeppelin/contracts/utils/cryptography/ECDSA.sol@v4.7.3


// OpenZeppelin Contracts (last updated v4.7.3) (utils/cryptography/ECDSA.sol)

pragma solidity ^0.8.0;

/**
 * @dev Elliptic Curve Digital Signature Algorithm (ECDSA) operations.
 *
 * These functions can be used to verify that a message was signed by the holder
 * of the private keys of a given address.
 */
library ECDSA {
    enum RecoverError {
        NoError,
        InvalidSignature,
        InvalidSignatureLength,
        InvalidSignatureS,
        InvalidSignatureV
    }

    function _throwError(RecoverError error) private pure {
        if (error == RecoverError.NoError) {
            return; // no error: do nothing
        } else if (error == RecoverError.InvalidSignature) {
            revert("ECDSA: invalid signature");
        } else if (error == RecoverError.InvalidSignatureLength) {
            revert("ECDSA: invalid signature length");
        } else if (error == RecoverError.InvalidSignatureS) {
            revert("ECDSA: invalid signature 's' value");
        } else if (error == RecoverError.InvalidSignatureV) {
            revert("ECDSA: invalid signature 'v' value");
        }
    }

    /**
     * @dev Returns the address that signed a hashed message (`hash`) with
     * `signature` or error string. This address can then be used for verification purposes.
     *
     * The `ecrecover` EVM opcode allows for malleable (non-unique) signatures:
     * this function rejects them by requiring the `s` value to be in the lower
     * half order, and the `v` value to be either 27 or 28.
     *
     * IMPORTANT: `hash` _must_ be the result of a hash operation for the
     * verification to be secure: it is possible to craft signatures that
     * recover to arbitrary addresses for non-hashed data. A safe way to ensure
     * this is by receiving a hash of the original message (which may otherwise
     * be too long), and then calling {toEthSignedMessageHash} on it.
     *
     * Documentation for signature generation:
     * - with https://web3js.readthedocs.io/en/v1.3.4/web3-eth-accounts.html#sign[Web3.js]
     * - with https://docs.ethers.io/v5/api/signer/#Signer-signMessage[ethers]
     *
     * _Available since v4.3._
     */
    function tryRecover(bytes32 hash, bytes memory signature) internal pure returns (address, RecoverError) {
        if (signature.length == 65) {
            bytes32 r;
            bytes32 s;
            uint8 v;
            // ecrecover takes the signature parameters, and the only way to get them
            // currently is to use assembly.
            /// @solidity memory-safe-assembly
            assembly {
                r := mload(add(signature, 0x20))
                s := mload(add(signature, 0x40))
                v := byte(0, mload(add(signature, 0x60)))
            }
            return tryRecover(hash, v, r, s);
        } else {
            return (address(0), RecoverError.InvalidSignatureLength);
        }
    }

    /**
     * @dev Returns the address that signed a hashed message (`hash`) with
     * `signature`. This address can then be used for verification purposes.
     *
     * The `ecrecover` EVM opcode allows for malleable (non-unique) signatures:
     * this function rejects them by requiring the `s` value to be in the lower
     * half order, and the `v` value to be either 27 or 28.
     *
     * IMPORTANT: `hash` _must_ be the result of a hash operation for the
     * verification to be secure: it is possible to craft signatures that
     * recover to arbitrary addresses for non-hashed data. A safe way to ensure
     * this is by receiving a hash of the original message (which may otherwise
     * be too long), and then calling {toEthSignedMessageHash} on it.
     */
    function recover(bytes32 hash, bytes memory signature) internal pure returns (address) {
        (address recovered, RecoverError error) = tryRecover(hash, signature);
        _throwError(error);
        return recovered;
    }

    /**
     * @dev Overload of {ECDSA-tryRecover} that receives the `r` and `vs` short-signature fields separately.
     *
     * See https://eips.ethereum.org/EIPS/eip-2098[EIP-2098 short signatures]
     *
     * _Available since v4.3._
     */
    function tryRecover(
        bytes32 hash,
        bytes32 r,
        bytes32 vs
    ) internal pure returns (address, RecoverError) {
        bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
        uint8 v = uint8((uint256(vs) >> 255) + 27);
        return tryRecover(hash, v, r, s);
    }

    /**
     * @dev Overload of {ECDSA-recover} that receives the `r and `vs` short-signature fields separately.
     *
     * _Available since v4.2._
     */
    function recover(
        bytes32 hash,
        bytes32 r,
        bytes32 vs
    ) internal pure returns (address) {
        (address recovered, RecoverError error) = tryRecover(hash, r, vs);
        _throwError(error);
        return recovered;
    }

    /**
     * @dev Overload of {ECDSA-tryRecover} that receives the `v`,
     * `r` and `s` signature fields separately.
     *
     * _Available since v4.3._
     */
    function tryRecover(
        bytes32 hash,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) internal pure returns (address, RecoverError) {
        // EIP-2 still allows signature malleability for ecrecover(). Remove this possibility and make the signature
        // unique. Appendix F in the Ethereum Yellow paper (https://ethereum.github.io/yellowpaper/paper.pdf), defines
        // the valid range for s in (301): 0 < s < secp256k1n ÷ 2 + 1, and for v in (302): v ∈ {27, 28}. Most
        // signatures from current libraries generate a unique signature with an s-value in the lower half order.
        //
        // If your library generates malleable signatures, such as s-values in the upper range, calculate a new s-value
        // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
        // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
        // these malleable signatures as well.
        if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
            return (address(0), RecoverError.InvalidSignatureS);
        }
        if (v != 27 && v != 28) {
            return (address(0), RecoverError.InvalidSignatureV);
        }

        // If the signature is valid (and not malleable), return the signer address
        address signer = ecrecover(hash, v, r, s);
        if (signer == address(0)) {
            return (address(0), RecoverError.InvalidSignature);
        }

        return (signer, RecoverError.NoError);
    }

    /**
     * @dev Overload of {ECDSA-recover} that receives the `v`,
     * `r` and `s` signature fields separately.
     */
    function recover(
        bytes32 hash,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) internal pure returns (address) {
        (address recovered, RecoverError error) = tryRecover(hash, v, r, s);
        _throwError(error);
        return recovered;
    }

    /**
     * @dev Returns an Ethereum Signed Message, created from a `hash`. This
     * produces hash corresponding to the one signed with the
     * https://eth.wiki/json-rpc/API#eth_sign[`eth_sign`]
     * JSON-RPC method as part of EIP-191.
     *
     * See {recover}.
     */
    function toEthSignedMessageHash(bytes32 hash) internal pure returns (bytes32) {
        // 32 is the length in bytes of hash,
        // enforced by the type signature above
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
    }

    /**
     * @dev Returns an Ethereum Signed Message, created from `s`. This
     * produces hash corresponding to the one signed with the
     * https://eth.wiki/json-rpc/API#eth_sign[`eth_sign`]
     * JSON-RPC method as part of EIP-191.
     *
     * See {recover}.
     */
    function toEthSignedMessageHash(bytes memory s) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n", Strings.toString(s.length), s));
    }

    /**
     * @dev Returns an Ethereum Signed Typed Data, created from a
     * `domainSeparator` and a `structHash`. This produces hash corresponding
     * to the one signed with the
     * https://eips.ethereum.org/EIPS/eip-712[`eth_signTypedData`]
     * JSON-RPC method as part of EIP-712.
     *
     * See {recover}.
     */
    function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));
    }
}


// File @openzeppelin/contracts/token/ERC20/IERC20.sol@v4.7.3


// OpenZeppelin Contracts (last updated v4.6.0) (token/ERC20/IERC20.sol)

pragma solidity ^0.8.0;

/**
 * @dev Interface of the ERC20 standard as defined in the EIP.
 */
interface IERC20 {
    /**
     * @dev Emitted when `value` tokens are moved from one account (`from`) to
     * another (`to`).
     *
     * Note that `value` may be zero.
     */
    event Transfer(address indexed from, address indexed to, uint256 value);

    /**
     * @dev Emitted when the allowance of a `spender` for an `owner` is set by
     * a call to {approve}. `value` is the new allowance.
     */
    event Approval(address indexed owner, address indexed spender, uint256 value);

    /**
     * @dev Returns the amount of tokens in existence.
     */
    function totalSupply() external view returns (uint256);

    /**
     * @dev Returns the amount of tokens owned by `account`.
     */
    function balanceOf(address account) external view returns (uint256);

    /**
     * @dev Moves `amount` tokens from the caller's account to `to`.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transfer(address to, uint256 amount) external returns (bool);

    /**
     * @dev Returns the remaining number of tokens that `spender` will be
     * allowed to spend on behalf of `owner` through {transferFrom}. This is
     * zero by default.
     *
     * This value changes when {approve} or {transferFrom} are called.
     */
    function allowance(address owner, address spender) external view returns (uint256);

    /**
     * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * IMPORTANT: Beware that changing an allowance with this method brings the risk
     * that someone may use both the old and the new allowance by unfortunate
     * transaction ordering. One possible solution to mitigate this race
     * condition is to first reduce the spender's allowance to 0 and set the
     * desired value afterwards:
     * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
     *
     * Emits an {Approval} event.
     */
    function approve(address spender, uint256 amount) external returns (bool);

    /**
     * @dev Moves `amount` tokens from `from` to `to` using the
     * allowance mechanism. `amount` is then deducted from the caller's
     * allowance.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) external returns (bool);
}


// File @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol@v4.7.3


// OpenZeppelin Contracts v4.4.1 (token/ERC20/extensions/IERC20Metadata.sol)

pragma solidity ^0.8.0;

/**
 * @dev Interface for the optional metadata functions from the ERC20 standard.
 *
 * _Available since v4.1._
 */
interface IERC20Metadata is IERC20 {
    /**
     * @dev Returns the name of the token.
     */
    function name() external view returns (string memory);

    /**
     * @dev Returns the symbol of the token.
     */
    function symbol() external view returns (string memory);

    /**
     * @dev Returns the decimals places of the token.
     */
    function decimals() external view returns (uint8);
}


// File @openzeppelin/contracts-upgradeable/utils/AddressUpgradeable.sol@v4.8.1


// OpenZeppelin Contracts (last updated v4.8.0) (utils/Address.sol)

pragma solidity ^0.8.1;

/**
 * @dev Collection of functions related to the address type
 */
library AddressUpgradeable {
    /**
     * @dev Returns true if `account` is a contract.
     *
     * [IMPORTANT]
     * ====
     * It is unsafe to assume that an address for which this function returns
     * false is an externally-owned account (EOA) and not a contract.
     *
     * Among others, `isContract` will return false for the following
     * types of addresses:
     *
     *  - an externally-owned account
     *  - a contract in construction
     *  - an address where a contract will be created
     *  - an address where a contract lived, but was destroyed
     * ====
     *
     * [IMPORTANT]
     * ====
     * You shouldn't rely on `isContract` to protect against flash loan attacks!
     *
     * Preventing calls from contracts is highly discouraged. It breaks composability, breaks support for smart wallets
     * like Gnosis Safe, and does not provide security since it can be circumvented by calling from a contract
     * constructor.
     * ====
     */
    function isContract(address account) internal view returns (bool) {
        // This method relies on extcodesize/address.code.length, which returns 0
        // for contracts in construction, since the code is only stored at the end
        // of the constructor execution.

        return account.code.length > 0;
    }

    /**
     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to
     * `recipient`, forwarding all available gas and reverting on errors.
     *
     * https://eips.ethereum.org/EIPS/eip-1884[EIP1884] increases the gas cost
     * of certain opcodes, possibly making contracts go over the 2300 gas limit
     * imposed by `transfer`, making them unable to receive funds via
     * `transfer`. {sendValue} removes this limitation.
     *
     * https://diligence.consensys.net/posts/2019/09/stop-using-soliditys-transfer-now/[Learn more].
     *
     * IMPORTANT: because control is transferred to `recipient`, care must be
     * taken to not create reentrancy vulnerabilities. Consider using
     * {ReentrancyGuard} or the
     * https://solidity.readthedocs.io/en/v0.5.11/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].
     */
    function sendValue(address payable recipient, uint256 amount) internal {
        require(address(this).balance >= amount, "Address: insufficient balance");

        (bool success, ) = recipient.call{value: amount}("");
        require(success, "Address: unable to send value, recipient may have reverted");
    }

    /**
     * @dev Performs a Solidity function call using a low level `call`. A
     * plain `call` is an unsafe replacement for a function call: use this
     * function instead.
     *
     * If `target` reverts with a revert reason, it is bubbled up by this
     * function (like regular Solidity function calls).
     *
     * Returns the raw returned data. To convert to the expected return value,
     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].
     *
     * Requirements:
     *
     * - `target` must be a contract.
     * - calling `target` with `data` must not revert.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, "Address: low-level call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with
     * `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but also transferring `value` wei to `target`.
     *
     * Requirements:
     *
     * - the calling contract must have an ETH balance of at least `value`.
     * - the called Solidity function must be `payable`.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");
    }

    /**
     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but
     * with `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value,
        string memory errorMessage
    ) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        (bool success, bytes memory returndata) = target.call{value: value}(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data) internal view returns (bytes memory) {
        return functionStaticCall(target, data, "Address: low-level static call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        (bool success, bytes memory returndata) = target.staticcall(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Tool to verify that a low level call to smart-contract was successful, and revert (either by bubbling
     * the revert reason or using the provided one) in case of unsuccessful call or if target was not a contract.
     *
     * _Available since v4.8._
     */
    function verifyCallResultFromTarget(
        address target,
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        if (success) {
            if (returndata.length == 0) {
                // only check isContract if the call was successful and the return data is empty
                // otherwise we already know that it was a contract
                require(isContract(target), "Address: call to non-contract");
            }
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    /**
     * @dev Tool to verify that a low level call was successful, and revert if it wasn't, either by bubbling the
     * revert reason or using the provided one.
     *
     * _Available since v4.3._
     */
    function verifyCallResult(
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal pure returns (bytes memory) {
        if (success) {
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    function _revert(bytes memory returndata, string memory errorMessage) private pure {
        // Look for revert reason and bubble it up if present
        if (returndata.length > 0) {
            // The easiest way to bubble the revert reason is using memory via assembly
            /// @solidity memory-safe-assembly
            assembly {
                let returndata_size := mload(returndata)
                revert(add(32, returndata), returndata_size)
            }
        } else {
            revert(errorMessage);
        }
    }
}


// File @openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol@v4.8.1


// OpenZeppelin Contracts (last updated v4.8.1) (proxy/utils/Initializable.sol)

pragma solidity ^0.8.2;

/**
 * @dev This is a base contract to aid in writing upgradeable contracts, or any kind of contract that will be deployed
 * behind a proxy. Since proxied contracts do not make use of a constructor, it's common to move constructor logic to an
 * external initializer function, usually called `initialize`. It then becomes necessary to protect this initializer
 * function so it can only be called once. The {initializer} modifier provided by this contract will have this effect.
 *
 * The initialization functions use a version number. Once a version number is used, it is consumed and cannot be
 * reused. This mechanism prevents re-execution of each "step" but allows the creation of new initialization steps in
 * case an upgrade adds a module that needs to be initialized.
 *
 * For example:
 *
 * [.hljs-theme-light.nopadding]
 * ```
 * contract MyToken is ERC20Upgradeable {
 *     function initialize() initializer public {
 *         __ERC20_init("MyToken", "MTK");
 *     }
 * }
 * contract MyTokenV2 is MyToken, ERC20PermitUpgradeable {
 *     function initializeV2() reinitializer(2) public {
 *         __ERC20Permit_init("MyToken");
 *     }
 * }
 * ```
 *
 * TIP: To avoid leaving the proxy in an uninitialized state, the initializer function should be called as early as
 * possible by providing the encoded function call as the `_data` argument to {ERC1967Proxy-constructor}.
 *
 * CAUTION: When used with inheritance, manual care must be taken to not invoke a parent initializer twice, or to ensure
 * that all initializers are idempotent. This is not verified automatically as constructors are by Solidity.
 *
 * [CAUTION]
 * ====
 * Avoid leaving a contract uninitialized.
 *
 * An uninitialized contract can be taken over by an attacker. This applies to both a proxy and its implementation
 * contract, which may impact the proxy. To prevent the implementation contract from being used, you should invoke
 * the {_disableInitializers} function in the constructor to automatically lock it when it is deployed:
 *
 * [.hljs-theme-light.nopadding]
 * ```
 * /// @custom:oz-upgrades-unsafe-allow constructor
 * constructor() {
 *     _disableInitializers();
 * }
 * ```
 * ====
 */
abstract contract Initializable {
    /**
     * @dev Indicates that the contract has been initialized.
     * @custom:oz-retyped-from bool
     */
    uint8 private _initialized;

    /**
     * @dev Indicates that the contract is in the process of being initialized.
     */
    bool private _initializing;

    /**
     * @dev Triggered when the contract has been initialized or reinitialized.
     */
    event Initialized(uint8 version);

    /**
     * @dev A modifier that defines a protected initializer function that can be invoked at most once. In its scope,
     * `onlyInitializing` functions can be used to initialize parent contracts.
     *
     * Similar to `reinitializer(1)`, except that functions marked with `initializer` can be nested in the context of a
     * constructor.
     *
     * Emits an {Initialized} event.
     */
    modifier initializer() {
        bool isTopLevelCall = !_initializing;
        require(
            (isTopLevelCall && _initialized < 1) || (!AddressUpgradeable.isContract(address(this)) && _initialized == 1),
            "Initializable: contract is already initialized"
        );
        _initialized = 1;
        if (isTopLevelCall) {
            _initializing = true;
        }
        _;
        if (isTopLevelCall) {
            _initializing = false;
            emit Initialized(1);
        }
    }

    /**
     * @dev A modifier that defines a protected reinitializer function that can be invoked at most once, and only if the
     * contract hasn't been initialized to a greater version before. In its scope, `onlyInitializing` functions can be
     * used to initialize parent contracts.
     *
     * A reinitializer may be used after the original initialization step. This is essential to configure modules that
     * are added through upgrades and that require initialization.
     *
     * When `version` is 1, this modifier is similar to `initializer`, except that functions marked with `reinitializer`
     * cannot be nested. If one is invoked in the context of another, execution will revert.
     *
     * Note that versions can jump in increments greater than 1; this implies that if multiple reinitializers coexist in
     * a contract, executing them in the right order is up to the developer or operator.
     *
     * WARNING: setting the version to 255 will prevent any future reinitialization.
     *
     * Emits an {Initialized} event.
     */
    modifier reinitializer(uint8 version) {
        require(!_initializing && _initialized < version, "Initializable: contract is already initialized");
        _initialized = version;
        _initializing = true;
        _;
        _initializing = false;
        emit Initialized(version);
    }

    /**
     * @dev Modifier to protect an initialization function so that it can only be invoked by functions with the
     * {initializer} and {reinitializer} modifiers, directly or indirectly.
     */
    modifier onlyInitializing() {
        require(_initializing, "Initializable: contract is not initializing");
        _;
    }

    /**
     * @dev Locks the contract, preventing any future reinitialization. This cannot be part of an initializer call.
     * Calling this in the constructor of a contract will prevent that contract from being initialized or reinitialized
     * to any version. It is recommended to use this to lock implementation contracts that are designed to be called
     * through proxies.
     *
     * Emits an {Initialized} event the first time it is successfully executed.
     */
    function _disableInitializers() internal virtual {
        require(!_initializing, "Initializable: contract is initializing");
        if (_initialized < type(uint8).max) {
            _initialized = type(uint8).max;
            emit Initialized(type(uint8).max);
        }
    }

    /**
     * @dev Returns the highest version that has been initialized. See {reinitializer}.
     */
    function _getInitializedVersion() internal view returns (uint8) {
        return _initialized;
    }

    /**
     * @dev Returns `true` if the contract is currently initializing. See {onlyInitializing}.
     */
    function _isInitializing() internal view returns (bool) {
        return _initializing;
    }
}


// File @openzeppelin/contracts/utils/structs/EnumerableSet.sol@v4.7.3


// OpenZeppelin Contracts (last updated v4.7.0) (utils/structs/EnumerableSet.sol)

pragma solidity ^0.8.0;

/**
 * @dev Library for managing
 * https://en.wikipedia.org/wiki/Set_(abstract_data_type)[sets] of primitive
 * types.
 *
 * Sets have the following properties:
 *
 * - Elements are added, removed, and checked for existence in constant time
 * (O(1)).
 * - Elements are enumerated in O(n). No guarantees are made on the ordering.
 *
 * ```
 * contract Example {
 *     // Add the library methods
 *     using EnumerableSet for EnumerableSet.AddressSet;
 *
 *     // Declare a set state variable
 *     EnumerableSet.AddressSet private mySet;
 * }
 * ```
 *
 * As of v3.3.0, sets of type `bytes32` (`Bytes32Set`), `address` (`AddressSet`)
 * and `uint256` (`UintSet`) are supported.
 *
 * [WARNING]
 * ====
 *  Trying to delete such a structure from storage will likely result in data corruption, rendering the structure unusable.
 *  See https://github.com/ethereum/solidity/pull/11843[ethereum/solidity#11843] for more info.
 *
 *  In order to clean an EnumerableSet, you can either remove all elements one by one or create a fresh instance using an array of EnumerableSet.
 * ====
 */
library EnumerableSet {
    // To implement this library for multiple types with as little code
    // repetition as possible, we write it in terms of a generic Set type with
    // bytes32 values.
    // The Set implementation uses private functions, and user-facing
    // implementations (such as AddressSet) are just wrappers around the
    // underlying Set.
    // This means that we can only create new EnumerableSets for types that fit
    // in bytes32.

    struct Set {
        // Storage of set values
        bytes32[] _values;
        // Position of the value in the `values` array, plus 1 because index 0
        // means a value is not in the set.
        mapping(bytes32 => uint256) _indexes;
    }

    /**
     * @dev Add a value to a set. O(1).
     *
     * Returns true if the value was added to the set, that is if it was not
     * already present.
     */
    function _add(Set storage set, bytes32 value) private returns (bool) {
        if (!_contains(set, value)) {
            set._values.push(value);
            // The value is stored at length-1, but we add 1 to all indexes
            // and use 0 as a sentinel value
            set._indexes[value] = set._values.length;
            return true;
        } else {
            return false;
        }
    }

    /**
     * @dev Removes a value from a set. O(1).
     *
     * Returns true if the value was removed from the set, that is if it was
     * present.
     */
    function _remove(Set storage set, bytes32 value) private returns (bool) {
        // We read and store the value's index to prevent multiple reads from the same storage slot
        uint256 valueIndex = set._indexes[value];

        if (valueIndex != 0) {
            // Equivalent to contains(set, value)
            // To delete an element from the _values array in O(1), we swap the element to delete with the last one in
            // the array, and then remove the last element (sometimes called as 'swap and pop').
            // This modifies the order of the array, as noted in {at}.

            uint256 toDeleteIndex = valueIndex - 1;
            uint256 lastIndex = set._values.length - 1;

            if (lastIndex != toDeleteIndex) {
                bytes32 lastValue = set._values[lastIndex];

                // Move the last value to the index where the value to delete is
                set._values[toDeleteIndex] = lastValue;
                // Update the index for the moved value
                set._indexes[lastValue] = valueIndex; // Replace lastValue's index to valueIndex
            }

            // Delete the slot where the moved value was stored
            set._values.pop();

            // Delete the index for the deleted slot
            delete set._indexes[value];

            return true;
        } else {
            return false;
        }
    }

    /**
     * @dev Returns true if the value is in the set. O(1).
     */
    function _contains(Set storage set, bytes32 value) private view returns (bool) {
        return set._indexes[value] != 0;
    }

    /**
     * @dev Returns the number of values on the set. O(1).
     */
    function _length(Set storage set) private view returns (uint256) {
        return set._values.length;
    }

    /**
     * @dev Returns the value stored at position `index` in the set. O(1).
     *
     * Note that there are no guarantees on the ordering of values inside the
     * array, and it may change when more values are added or removed.
     *
     * Requirements:
     *
     * - `index` must be strictly less than {length}.
     */
    function _at(Set storage set, uint256 index) private view returns (bytes32) {
        return set._values[index];
    }

    /**
     * @dev Return the entire set in an array
     *
     * WARNING: This operation will copy the entire storage to memory, which can be quite expensive. This is designed
     * to mostly be used by view accessors that are queried without any gas fees. Developers should keep in mind that
     * this function has an unbounded cost, and using it as part of a state-changing function may render the function
     * uncallable if the set grows to a point where copying to memory consumes too much gas to fit in a block.
     */
    function _values(Set storage set) private view returns (bytes32[] memory) {
        return set._values;
    }

    // Bytes32Set

    struct Bytes32Set {
        Set _inner;
    }

    /**
     * @dev Add a value to a set. O(1).
     *
     * Returns true if the value was added to the set, that is if it was not
     * already present.
     */
    function add(Bytes32Set storage set, bytes32 value) internal returns (bool) {
        return _add(set._inner, value);
    }

    /**
     * @dev Removes a value from a set. O(1).
     *
     * Returns true if the value was removed from the set, that is if it was
     * present.
     */
    function remove(Bytes32Set storage set, bytes32 value) internal returns (bool) {
        return _remove(set._inner, value);
    }

    /**
     * @dev Returns true if the value is in the set. O(1).
     */
    function contains(Bytes32Set storage set, bytes32 value) internal view returns (bool) {
        return _contains(set._inner, value);
    }

    /**
     * @dev Returns the number of values in the set. O(1).
     */
    function length(Bytes32Set storage set) internal view returns (uint256) {
        return _length(set._inner);
    }

    /**
     * @dev Returns the value stored at position `index` in the set. O(1).
     *
     * Note that there are no guarantees on the ordering of values inside the
     * array, and it may change when more values are added or removed.
     *
     * Requirements:
     *
     * - `index` must be strictly less than {length}.
     */
    function at(Bytes32Set storage set, uint256 index) internal view returns (bytes32) {
        return _at(set._inner, index);
    }

    /**
     * @dev Return the entire set in an array
     *
     * WARNING: This operation will copy the entire storage to memory, which can be quite expensive. This is designed
     * to mostly be used by view accessors that are queried without any gas fees. Developers should keep in mind that
     * this function has an unbounded cost, and using it as part of a state-changing function may render the function
     * uncallable if the set grows to a point where copying to memory consumes too much gas to fit in a block.
     */
    function values(Bytes32Set storage set) internal view returns (bytes32[] memory) {
        return _values(set._inner);
    }

    // AddressSet

    struct AddressSet {
        Set _inner;
    }

    /**
     * @dev Add a value to a set. O(1).
     *
     * Returns true if the value was added to the set, that is if it was not
     * already present.
     */
    function add(AddressSet storage set, address value) internal returns (bool) {
        return _add(set._inner, bytes32(uint256(uint160(value))));
    }

    /**
     * @dev Removes a value from a set. O(1).
     *
     * Returns true if the value was removed from the set, that is if it was
     * present.
     */
    function remove(AddressSet storage set, address value) internal returns (bool) {
        return _remove(set._inner, bytes32(uint256(uint160(value))));
    }

    /**
     * @dev Returns true if the value is in the set. O(1).
     */
    function contains(AddressSet storage set, address value) internal view returns (bool) {
        return _contains(set._inner, bytes32(uint256(uint160(value))));
    }

    /**
     * @dev Returns the number of values in the set. O(1).
     */
    function length(AddressSet storage set) internal view returns (uint256) {
        return _length(set._inner);
    }

    /**
     * @dev Returns the value stored at position `index` in the set. O(1).
     *
     * Note that there are no guarantees on the ordering of values inside the
     * array, and it may change when more values are added or removed.
     *
     * Requirements:
     *
     * - `index` must be strictly less than {length}.
     */
    function at(AddressSet storage set, uint256 index) internal view returns (address) {
        return address(uint160(uint256(_at(set._inner, index))));
    }

    /**
     * @dev Return the entire set in an array
     *
     * WARNING: This operation will copy the entire storage to memory, which can be quite expensive. This is designed
     * to mostly be used by view accessors that are queried without any gas fees. Developers should keep in mind that
     * this function has an unbounded cost, and using it as part of a state-changing function may render the function
     * uncallable if the set grows to a point where copying to memory consumes too much gas to fit in a block.
     */
    function values(AddressSet storage set) internal view returns (address[] memory) {
        bytes32[] memory store = _values(set._inner);
        address[] memory result;

        /// @solidity memory-safe-assembly
        assembly {
            result := store
        }

        return result;
    }

    // UintSet

    struct UintSet {
        Set _inner;
    }

    /**
     * @dev Add a value to a set. O(1).
     *
     * Returns true if the value was added to the set, that is if it was not
     * already present.
     */
    function add(UintSet storage set, uint256 value) internal returns (bool) {
        return _add(set._inner, bytes32(value));
    }

    /**
     * @dev Removes a value from a set. O(1).
     *
     * Returns true if the value was removed from the set, that is if it was
     * present.
     */
    function remove(UintSet storage set, uint256 value) internal returns (bool) {
        return _remove(set._inner, bytes32(value));
    }

    /**
     * @dev Returns true if the value is in the set. O(1).
     */
    function contains(UintSet storage set, uint256 value) internal view returns (bool) {
        return _contains(set._inner, bytes32(value));
    }

    /**
     * @dev Returns the number of values on the set. O(1).
     */
    function length(UintSet storage set) internal view returns (uint256) {
        return _length(set._inner);
    }

    /**
     * @dev Returns the value stored at position `index` in the set. O(1).
     *
     * Note that there are no guarantees on the ordering of values inside the
     * array, and it may change when more values are added or removed.
     *
     * Requirements:
     *
     * - `index` must be strictly less than {length}.
     */
    function at(UintSet storage set, uint256 index) internal view returns (uint256) {
        return uint256(_at(set._inner, index));
    }

    /**
     * @dev Return the entire set in an array
     *
     * WARNING: This operation will copy the entire storage to memory, which can be quite expensive. This is designed
     * to mostly be used by view accessors that are queried without any gas fees. Developers should keep in mind that
     * this function has an unbounded cost, and using it as part of a state-changing function may render the function
     * uncallable if the set grows to a point where copying to memory consumes too much gas to fit in a block.
     */
    function values(UintSet storage set) internal view returns (uint256[] memory) {
        bytes32[] memory store = _values(set._inner);
        uint256[] memory result;

        /// @solidity memory-safe-assembly
        assembly {
            result := store
        }

        return result;
    }
}


// File contracts/ReferralCrowdsale.sol


pragma solidity 0.8.16;







contract ReferralCrowdsale is AccessControl, Initializable {
    using EnumerableSet for EnumerableSet.Bytes32Set;
    using EnumerableSet for EnumerableSet.AddressSet;

    uint256 public constant DENOMINATOR = 10000;
    uint256 public constant MAX_ENABLED_LINKS = 5;
    bytes32 public constant SIGNER_ROLE = keccak256("SIGNER_ROLE");
    bytes32 public constant BACKEND_ROLE = keccak256("BACKEND_ROLE");

    address public BTCMT;
    IStaking public AUTOFARM;
    IStakingOwn public STAKING;

    DexInfo public dexInfo;
    LevelInfo[] public levels;
    LockedPurchaseConfig[] public lockedConfiguration;

    EnumerableSet.AddressSet private paymentsTokens;

    mapping(address => KidStatistic) public kidStatistic;
    mapping(bytes32 => LinkStatistic) public linkStatistic;
    mapping(address => FatherStatistic) public fatherStatistic;

    mapping(address => KidInfo) public kids;
    mapping(bytes32 => LinkInfo) public links;
    mapping(address => FatherInfo) private fathers;

    mapping(uint256 => bool) private availableFatherPercents;

    struct FatherInfo {
        address[] allKids;
        bytes32[] allLinks;
        EnumerableSet.Bytes32Set linksEndbled;
    }

    struct KidInfo {
        bool registered;
        bool comeSecondTime;
        bytes32 fatherLink;
    }

    struct LinkInfo {
        bool enabled;
        address owner;
        uint256 ownerPercent;
    }

    struct LevelInfo {
        uint256 threshold;
        uint256 bonusPercent;
    }

    struct DexInfo {
        bool enabled;
        address pair;
        address token0;
        address token1;
        uint256 floorPrice;
        uint256 manualPrice;
    }

    struct LockedPurchaseConfig {
        uint256 weeksAmount;
        uint256 lockedPrice;
    }

    struct LinkStatistic {
        uint256 totalSons;
        uint256 totalSonsTwice;
        uint256 totalBought;
        uint256 totalBonuses;
    }

    struct FatherStatistic {
        uint256 totalKids;
        uint256 btcmtKidBought;
        uint256 usdtKidSpent;
        uint256 totalBonuses;
    }

    struct KidStatistic {
        uint256 numOfPurchases;
        uint256 sumOfPurchases;
        uint256 sumOfBonuses;
        uint256 firstPurchaseDate;
    }

    struct LinkParameters {
        bytes32 linkHash;
        address linkFather;
        address linkSon;
        uint256 fatherPercent;
        bytes linkSignature;
    }

    struct PurchaseParameters {
        bool give;
        bool lockedPurchase;
        address paymentToken;
        uint256 usdtAmount;
        uint256 btcmtAmount;
        uint256 lockIndex;
        uint256 expirationTime;
        bytes buySignature;
    }

    event PurchaseWithBonuses(
        bytes32 linkHash,
        uint256 boughtAmount,
        uint256 fatherBonus,
        address fatherAddress,
        uint256 sonBonus,
        address sonAddress,
        uint256 amountLeft
    );

    event NewLinkCreated(
        bytes32 link,
        address linkFather,
        uint256 fatherPercent,
        uint256 sonPercent
    );

    event NewUserRegistered(address newUser, address father, bytes32 link);

    event LinkDeactivated(bytes32 linkHash, address linkFather);

    /// @param _addresses 0 - BTCMT, 1 - USDT, 2 - regular staking, 3 - autofarm, 4 - BTCMT-USDT pair, 5 - signer, 6 - backend
    /// @param _prices 0 - floor price, 1 - manual price
    function initialize(
        address[7] memory _addresses,
        LevelInfo[] memory _levels,
        uint256[2] memory _prices,
        LockedPurchaseConfig[] memory _lockedConfig
    ) public initializer {
        require(
            _addresses[0] != address(0) &&
                _addresses[1] != address(0) &&
                _addresses[2] != address(0) &&
                _addresses[3] != address(0) &&
                _addresses[4] != address(0) &&
                _addresses[5] != address(0) &&
                _addresses[6] != address(0),
            "0x00..."
        );

        for (uint256 i; i < _lockedConfig.length; i++) {
            if (i == 0)
                require(
                    _lockedConfig[i].weeksAmount > 0,
                    "Wrong locked config 0"
                );
            else
                require(
                    _lockedConfig[i].weeksAmount >
                        _lockedConfig[i - 1].weeksAmount,
                    "Wrong locked config order"
                );
            lockedConfiguration.push(_lockedConfig[i]);
        }
        BTCMT = _addresses[0];
        STAKING = IStakingOwn(_addresses[2]);
        AUTOFARM = IStaking(_addresses[3]);
        dexInfo = DexInfo(
            true,
            _addresses[4],
            IPair(_addresses[4]).token0(),
            IPair(_addresses[4]).token1(),
            _prices[0],
            _prices[1]
        );
        require(
            BTCMT == dexInfo.token0 || BTCMT == dexInfo.token1,
            "Wrong pair address"
        );

        for (uint256 i; i < _levels.length; i++) {
            if (i > 0)
                require(
                    _levels[i - 1].threshold < _levels[i].threshold,
                    "Wrong order"
                );
            levels.push(_levels[i]);
        }
        availableFatherPercents[0] = true;
        availableFatherPercents[2500] = true;
        availableFatherPercents[5000] = true;
        availableFatherPercents[7500] = true;
        availableFatherPercents[10000] = true;

        links[bytes32(0)].enabled = true;

        paymentsTokens.add(_addresses[1]);

        _setupRole(DEFAULT_ADMIN_ROLE, _msgSender());
        _setupRole(SIGNER_ROLE, _addresses[5]);
        _setupRole(BACKEND_ROLE, _addresses[6]);
    }

    /** @dev Allows an admin to claim @param _token from this contract
     * @notice available for admin only
     */
    function claimTokens(address _token) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(_token != address(0), "0x00...");
        uint256 balance = IERC20(_token).balanceOf(address(this));
        if (balance > 0) {
            TransferHelper.safeTransfer(_token, _msgSender(), balance);
        }
    }

    /** @dev Allows an admin to change pair address
     * @param _pair address (BTCMT-USDT)
     * @notice available for admin only
     */
    function changePairAddress(address _pair)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        require(_pair != address(0), "0x00...");
        dexInfo.pair = _pair;
        dexInfo.token0 = IPair(_pair).token0();
        dexInfo.token1 = IPair(_pair).token1();
        require(
            (dexInfo.token0 == address(BTCMT) ||
                dexInfo.token1 == address(BTCMT)) &&
                (dexInfo.token0 != dexInfo.token1),
            "Wrong pair address"
        );
    }

    /** @dev Allows an admin to change dex status
     * (get price from pair or from backend)
     * @notice available for admin only
     */
    function changeDexStatus() external onlyRole(DEFAULT_ADMIN_ROLE) {
        dexInfo.enabled = !dexInfo.enabled;
    }

    /** @dev Allows an admin to add payment token
     * @notice available for admin only
     */
    function addPaymentToken(address _token)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        require(
            _token != address(0) &&
                !paymentsTokens.contains(_token) &&
                _token != BTCMT,
            "Wrong token address"
        );
        paymentsTokens.add(_token);
    }

    /** @dev Allows an admin to remove payment token
     * @notice available for admin only
     */
    function removePaymentToken(address _token)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        require(paymentsTokens.contains(_token), "Wrong token address");
        paymentsTokens.remove(_token);
    }

    /** @dev Allows an admin to change prices
     * @param _floorPrice new value for floor price
     * @param _manualPrice new value for manual price
     * @notice available for admin only
     */
    function changePrices(uint256 _floorPrice, uint256 _manualPrice)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        dexInfo.floorPrice = _floorPrice;
        dexInfo.manualPrice = _manualPrice;
    }

    /** @dev Allows an admin to change configuration for locked
     * tokens purchases
     * @param _config new configuration
     * @notice available for admin only
     */
    function changeLockedConfig(LockedPurchaseConfig[] memory _config)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        delete (lockedConfiguration);
        for (uint256 i; i < _config.length; i++) {
            if (i == 0)
                require(_config[i].weeksAmount > 0, "Wrong locked config 0");
            else
                require(
                    _config[i].weeksAmount > _config[i - 1].weeksAmount,
                    "Wrong locked config order"
                );
            lockedConfiguration.push(_config[i]);
        }
    }

    /** @dev Allows an admin to change levels
     * @param _levels an array of new level's values
     * @notice available for admin only
     */
    function changeLevels(LevelInfo[] memory _levels)
        external
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        delete (levels);
        for (uint256 i; i < _levels.length; i++) {
            if (i > 0)
                require(
                    _levels[i - 1].threshold < _levels[i].threshold,
                    "Wrong order"
                );
            levels.push(_levels[i]);
        }
    }

    /** @dev Allows an admin or link owner deactivate link
     * @param linkHash link to deactivate
     * @notice available for admin or link owner only
     */
    function deactivateLink(bytes32 linkHash) external {
        LinkInfo storage link = links[linkHash];
        require(
            link.owner == _msgSender() ||
                hasRole(DEFAULT_ADMIN_ROLE, _msgSender()),
            "Wrong sender"
        );
        require(link.enabled, "Already disabled");
        link.enabled = false;
        fathers[link.owner].linksEndbled.remove(linkHash);
        emit LinkDeactivated(linkHash, link.owner);
    }

    /** @dev Allows to buy BTCMT tokens and get bonuses
     * @notice if give is true, available for backend only
     * @param linkParams parameters of referral link (hash, owner, percent, etc.).
     * For more information, see LinkParameters structure.
     * @param purchaseParams parameters of purchase (payment token, amount to pay, amount to buy, etc.).
     * For more information, see PurchaseParameters structure.
     */
    function buyTokens(
        LinkParameters memory linkParams,
        PurchaseParameters memory purchaseParams
    ) external {
        require(purchaseParams.usdtAmount > 0, "Wrong amount");

        if (
            purchaseParams.give &&
            !purchaseParams.lockedPurchase &&
            dexInfo.manualPrice == 0
        ) {
            require(
                hasRole(BACKEND_ROLE, _msgSender()),
                "Only back provides give"
            );
            require(linkParams.linkSon != address(0), "Wrong son address");
            require(purchaseParams.btcmtAmount > 0, "Zero BTCMT amount");
            _checkLink(linkParams);
        } else {
            linkParams.linkSon = _msgSender();
            _checkLink(linkParams);
        }

        uint256 bonusPercent = (linkParams.linkHash == bytes32(0))
            ? 0
            : getUserBonusPercent(links[linkParams.linkHash].owner);

        if (purchaseParams.lockedPurchase) {
            require(
                lockedConfiguration.length > purchaseParams.lockIndex,
                "Wrong index"
            );

            _buy(
                purchaseParams.paymentToken,
                purchaseParams.usdtAmount,
                getPrice(
                    purchaseParams.usdtAmount,
                    true,
                    purchaseParams.lockIndex
                ),
                lockedConfiguration[purchaseParams.lockIndex].weeksAmount,
                bonusPercent,
                linkParams.linkHash
            );
        } else if (dexInfo.manualPrice > 0) {
            _buy(
                purchaseParams.paymentToken,
                purchaseParams.usdtAmount,
                getPrice(purchaseParams.usdtAmount, false, 0),
                0,
                bonusPercent,
                linkParams.linkHash
            );
        } else if (purchaseParams.give) {
            _give(
                linkParams.linkSon,
                purchaseParams.usdtAmount,
                purchaseParams.btcmtAmount,
                0,
                bonusPercent,
                linkParams.linkHash
            );
        } else {
            require(
                paymentsTokens.contains(purchaseParams.paymentToken),
                "Wrong paymentToken"
            );
            if (dexInfo.enabled) {
                _buyFromDex(
                    purchaseParams.paymentToken,
                    purchaseParams.usdtAmount,
                    bonusPercent,
                    linkParams.linkHash
                );
            } else {
                _buyFromCex(
                    purchaseParams.paymentToken,
                    purchaseParams.usdtAmount,
                    purchaseParams.btcmtAmount,
                    purchaseParams.expirationTime,
                    purchaseParams.buySignature,
                    bonusPercent,
                    linkParams.linkHash
                );
            }
        }
    }

    /** @dev View function to get the list of all payment tokens
     * @return list of all payment tokens
     */
    function getAllPaymentTokens() external view returns (address[] memory) {
        return paymentsTokens.values();
    }

    /** @dev Get stake amounts of @param user from STAKING and AUTOFARM contracts
     * @return sum of user's stake amounts
     */
    function getUserTotalStake(address user) public view returns (uint256) {
        (uint256 autofarmStake, , ) = AUTOFARM.userStake(user);
        return STAKING.userStakes(user).totalAmount + autofarmStake;
    }

    /** @dev Get user bonus percent according to his level (his stake amount)
     * @param user address
     * @return user bonus percent
     */
    function getUserBonusPercent(address user) public view returns (uint256) {
        uint256 totalStake = getUserTotalStake(user);
        for (uint256 i = levels.length - 1; ; i--) {
            if (totalStake >= levels[i].threshold) {
                return levels[i].bonusPercent;
            }
            if (i == 0) break;
        }
        return 0;
    }

    /** @dev Get price from BTCMT-USDT pair and calculate output BTCMT amount
     * @param payAmount USDT
     * @param locked purchase status
     * @param lockedIndex in lockedConfiguration array
     * @return BTCMT output amount (0 if empty reserves/payAmount == 0/ dexInfo.enabled == false)
     */
    function getPrice(
        uint256 payAmount,
        bool locked,
        uint256 lockedIndex
    ) public view returns (uint256) {
        if (payAmount == 0) return 0;
        if (locked) {
            if (lockedIndex >= lockedConfiguration.length) return 0;
            else {
                return
                    (payAmount * 10**IERC20Metadata(BTCMT).decimals()) /
                    lockedConfiguration[lockedIndex].lockedPrice;
            }
        } else if (dexInfo.manualPrice > 0) {
            return
                (payAmount * 10**IERC20Metadata(BTCMT).decimals()) /
                dexInfo.manualPrice;
        } else if (dexInfo.enabled) {
            (uint112 reserve0, uint112 reserve1, ) = IPair(dexInfo.pair)
                .getReserves();

            if (reserve0 == 0 || reserve1 == 0) return 0;

            uint256 reserveUsdt;
            uint256 reserveBtcmt;
            if (address(BTCMT) == dexInfo.token0) {
                reserveBtcmt = reserve0;
                reserveUsdt = reserve1;
            } else {
                reserveBtcmt = reserve1;
                reserveUsdt = reserve0;
            }

            return (payAmount * reserveBtcmt) / (reserveUsdt);
        } else return 0;
    }

    /** Get amount to pay from output BTCMT amount
     * @param receiveAmount BTCMT
     * @return USDT input amount (0 if empty reserves/receiveAmount == 0/ dexInfo.enabled == false)
     */
    function getAmountToPay(uint256 receiveAmount)
        public
        view
        returns (uint256)
    {
        if (receiveAmount == 0) return 0;
        if (dexInfo.enabled) {
            (uint112 reserve0, uint112 reserve1, ) = IPair(dexInfo.pair)
                .getReserves();

            if (reserve0 == 0 || reserve1 == 0) return 0;

            uint256 reserveUsdt;
            uint256 reserveBtcmt;
            if (address(BTCMT) == dexInfo.token0) {
                reserveBtcmt = reserve0;
                reserveUsdt = reserve1;
            } else {
                reserveBtcmt = reserve1;
                reserveUsdt = reserve0;
            }

            return (reserveUsdt * receiveAmount) / reserveBtcmt;
        } else return 0;
    }

    /** @dev Get available BTCMT amount to buy
     * @param user buyer address
     * @param linkHash user link
     * @return available BTCMT amount to buy (0 if wrong link/new user + disabled link;
     * contract balance if zero bonus percent/link doesn't exist in contract)
     */
    function availableTokensToBuy(address user, bytes32 linkHash)
        public
        view
        returns (uint256)
    {
        KidInfo memory kid = kids[user];
        uint256 bonusPercent;
        if (kid.registered) {
            if (kid.fatherLink != linkHash) return 0;
            bonusPercent = (kid.fatherLink == bytes32(0))
                ? 0
                : getUserBonusPercent(links[kid.fatherLink].owner);
        } else {
            if (!links[linkHash].enabled && links[linkHash].owner != address(0))
                return 0;
            bonusPercent = (links[linkHash].owner == address(0))
                ? 0
                : getUserBonusPercent(links[linkHash].owner);
        }
        return
            (IERC20(BTCMT).balanceOf(address(this)) * DENOMINATOR) /
            (DENOMINATOR + bonusPercent);
    }

    /** @dev Get detail info for purchasing (buyAmount, bonus amount, sum of these two params)
     * @param payAmount USDT input amount
     * @param locked purchase status
     * @param lockIndex in lockedConfiguration array
     * @param user address of buyer
     * @param linkHash link
     * @return buyAmount (BTCMT output amount)
     * @return bonus (BTCMT buyer bonus amount)
     * @return sum of these two params
     * @notice will return (0,0,0) if not enough BTCMT/buyAmount == 0/payAmount == 0
     * @notice will return (n,0,n) if zero bonus percent/link doesn't exist on the contract
     */
    function detailing(
        uint256 payAmount,
        bool locked,
        uint256 lockIndex,
        address user,
        bytes32 linkHash
    )
        external
        view
        returns (
            uint256 buyAmount,
            uint256 bonus,
            uint256 sum
        )
    {
        buyAmount = getPrice(payAmount, locked, lockIndex);
        if (
            ((availableTokensToBuy(user, linkHash) < buyAmount && !locked) ||
                payAmount == 0 ||
                buyAmount == 0)
        ) return (0, 0, 0);
        KidInfo memory kid = kids[user];
        uint256 bonusPercent;
        uint256 sonPercent;
        if (kid.registered) {
            if (kid.fatherLink == bytes32(0)) {
                bonusPercent = 0;
                sonPercent = 0;
            } else {
                bonusPercent = getUserBonusPercent(links[kid.fatherLink].owner);
                sonPercent = DENOMINATOR - links[kid.fatherLink].ownerPercent;
            }
        } else {
            //link not exists || zero link (no link means)
            if ((links[linkHash].owner == address(0))) {
                bonusPercent = 0;
                sonPercent = 0;
            } else {
                bonusPercent = getUserBonusPercent(links[linkHash].owner);
                sonPercent = DENOMINATOR - links[linkHash].ownerPercent;
            }
        }
        bonus =
            (((buyAmount * bonusPercent) / DENOMINATOR) * sonPercent) /
            DENOMINATOR;
        sum = buyAmount + bonus;
    }

    /** @dev Get all link's owner information
     * @param _father link's owner address
     * @return fatherBonus (see getUserBonusPercent())
     * @return activeLinks all enabled links list
     * @return allLinks list of all added links
     * @return allLinkInfo list of all added links information
     * @return allLinkStatistic list of all added links statistic information
     */
    function getAllFatherLinkStatistic(address _father)
        external
        view
        returns (
            uint256 fatherBonus,
            bytes32[] memory activeLinks,
            bytes32[] memory allLinks,
            LinkInfo[] memory allLinkInfo,
            LinkStatistic[] memory allLinkStatistic
        )
    {
        fatherBonus = getUserBonusPercent(_father);
        activeLinks = fathers[_father].linksEndbled.values();
        allLinks = fathers[_father].allLinks;
        allLinkInfo = new LinkInfo[](allLinks.length);
        allLinkStatistic = new LinkStatistic[](allLinks.length);
        for (uint256 i; i < allLinks.length; i++) {
            allLinkInfo[i] = links[allLinks[i]];
            allLinkStatistic[i] = linkStatistic[allLinks[i]];
        }
    }

    /** @dev Get all father kids
     * @param _father links' owner address
     * @return list of all his referrals
     */
    function getFatherKids(address _father)
        external
        view
        returns (address[] memory)
    {
        return fathers[_father].allKids;
    }

    /** @dev Get levels info
     * @return an array of current levels
     */
    function getLevels() external view returns (LevelInfo[] memory) {
        return levels;
    }

    /** @dev Get locked purchase configuration
     * @return an array of current locked purchase configuration
     */
    function getLockedConfiguration()
        external
        view
        returns (LockedPurchaseConfig[] memory)
    {
        return lockedConfiguration;
    }

    function _buyFromCex(
        address payToken,
        uint256 payAmount,
        uint256 buyAmount,
        uint256 expirationTime,
        bytes memory signature,
        uint256 bonusPercent,
        bytes32 link
    ) internal {
        require(
            hasRole(
                SIGNER_ROLE,
                ECDSA.recover(
                    ECDSA.toEthSignedMessageHash(
                        keccak256(
                            abi.encodePacked(
                                _msgSender(),
                                payAmount,
                                buyAmount,
                                expirationTime
                            )
                        )
                    ),
                    signature
                )
            ),
            "Wrong buy signature"
        );
        require(block.timestamp < expirationTime, "Time passed");
        require(buyAmount > 0, "Zero buyAmount");

        _buy(payToken, payAmount, buyAmount, 0, bonusPercent, link);
    }

    function _buyFromDex(
        address payToken,
        uint256 payAmount,
        uint256 bonusPercent,
        bytes32 link
    ) internal {
        _buy(
            payToken,
            payAmount,
            getPrice(payAmount, false, 0),
            0,
            bonusPercent,
            link
        );
    }

    function _buy(
        address payToken,
        uint256 payAmount,
        uint256 buyAmount,
        uint256 lockedDuration,
        uint256 bonusPercent,
        bytes32 link
    ) internal {
        if (lockedDuration == 0 && dexInfo.manualPrice == 0)
            require(
                (10**IERC20Metadata(BTCMT).decimals() * payAmount) /
                    buyAmount >=
                    dexInfo.floorPrice,
                "Under floor price"
            );

        _give(
            _msgSender(),
            payAmount,
            buyAmount,
            lockedDuration,
            bonusPercent,
            link
        );

        TransferHelper.safeTransferFrom(
            payToken,
            _msgSender(),
            address(this),
            payAmount
        );
    }

    function _give(
        address sender,
        uint256 payAmount,
        uint256 buyAmount,
        uint256 lockedDuration,
        uint256 bonusPercent,
        bytes32 link
    ) internal {
        uint256 bonusAmount = (buyAmount * bonusPercent) / DENOMINATOR;
        if (lockedDuration == 0)
            require(
                buyAmount + bonusAmount <=
                    IERC20(BTCMT).balanceOf(address(this)),
                "Not enough BTCMT"
            );
        uint256 fatherAmount = (bonusAmount * links[link].ownerPercent) /
            DENOMINATOR;

        linkStatistic[link].totalBought += buyAmount;
        linkStatistic[link].totalBonuses += bonusAmount;
        fatherStatistic[links[link].owner].btcmtKidBought += buyAmount;
        fatherStatistic[links[link].owner].usdtKidSpent += payAmount;
        fatherStatistic[links[link].owner].totalBonuses += fatherAmount;
        kidStatistic[sender].sumOfPurchases += buyAmount;
        kidStatistic[sender].sumOfBonuses += (bonusAmount - fatherAmount);

        if (fatherAmount > 0) {
            if (lockedDuration > 0)
                IToken(BTCMT).mintLocked(
                    links[link].owner,
                    fatherAmount,
                    lockedDuration
                );
            else
                TransferHelper.safeTransfer(
                    BTCMT,
                    links[link].owner,
                    fatherAmount
                );
        }
        if (lockedDuration > 0)
            IToken(BTCMT).mintLocked(
                sender,
                (bonusAmount - fatherAmount) + buyAmount,
                lockedDuration
            );
        else
            TransferHelper.safeTransfer(
                BTCMT,
                sender,
                (bonusAmount - fatherAmount) + buyAmount
            );

        emit PurchaseWithBonuses(
            link,
            buyAmount,
            fatherAmount,
            links[link].owner,
            bonusAmount - fatherAmount,
            sender,
            IERC20(BTCMT).balanceOf(address(this))
        );
    }

    function _checkLink(LinkParameters memory linkParams) internal {
        if (
            linkParams.linkHash == bytes32(0) ||
            links[linkParams.linkHash].owner != address(0)
        ) {
            require(
                links[linkParams.linkHash].owner != linkParams.linkSon,
                "Wrong sender"
            );
            if (kids[linkParams.linkSon].registered) {
                require(
                    kids[linkParams.linkSon].fatherLink == linkParams.linkHash,
                    "Wrong link"
                );
                if (!kids[linkParams.linkSon].comeSecondTime) {
                    kids[linkParams.linkSon].comeSecondTime = true;
                    linkStatistic[linkParams.linkHash].totalSonsTwice++;
                }
            } else {
                require(links[linkParams.linkHash].enabled, "Unactive link");
                _register(
                    links[linkParams.linkHash].owner,
                    linkParams.linkSon,
                    linkParams.linkHash
                );
            }
        } else {
            // create new link
            require(
                hasRole(
                    SIGNER_ROLE,
                    ECDSA.recover(
                        ECDSA.toEthSignedMessageHash(
                            keccak256(
                                abi.encodePacked(
                                    linkParams.linkHash,
                                    linkParams.linkFather,
                                    linkParams.fatherPercent
                                )
                            )
                        ),
                        linkParams.linkSignature
                    )
                ),
                "Wrong link signature"
            );

            require(
                linkParams.linkFather != address(0) &&
                    linkParams.linkFather != linkParams.linkSon,
                "Wrong father's address"
            );
            require(
                availableFatherPercents[linkParams.fatherPercent],
                "Wrong father's percent value"
            );
            require(!kids[linkParams.linkSon].registered, "Not new user");

            require(
                fathers[linkParams.linkFather].linksEndbled.length() <
                    MAX_ENABLED_LINKS,
                "Limit of active links"
            );
            fathers[linkParams.linkFather].linksEndbled.add(
                linkParams.linkHash
            );
            fathers[linkParams.linkFather].allLinks.push(linkParams.linkHash);

            links[linkParams.linkHash].enabled = true;
            links[linkParams.linkHash].owner = linkParams.linkFather;
            links[linkParams.linkHash].ownerPercent = linkParams.fatherPercent;

            _register(
                linkParams.linkFather,
                linkParams.linkSon,
                linkParams.linkHash
            );

            emit NewLinkCreated(
                linkParams.linkHash,
                linkParams.linkFather,
                linkParams.fatherPercent,
                DENOMINATOR - linkParams.fatherPercent
            );
        }

        kidStatistic[linkParams.linkSon].numOfPurchases++;
    }

    function _register(
        address _father,
        address _kid,
        bytes32 _link
    ) internal {
        kids[_kid].registered = true;
        kids[_kid].fatherLink = _link;

        linkStatistic[_link].totalSons++;
        fathers[_father].allKids.push(_kid);
        fatherStatistic[_father].totalKids++;
        kidStatistic[_kid].firstPurchaseDate = block.timestamp;

        emit NewUserRegistered(_kid, _father, _link);
    }
}