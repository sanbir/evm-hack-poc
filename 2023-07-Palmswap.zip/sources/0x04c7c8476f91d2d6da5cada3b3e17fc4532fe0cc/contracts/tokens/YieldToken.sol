// SPDX-License-Identifier: MIT

pragma solidity 0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import "./interfaces/IYieldTracker.sol";
import "./interfaces/IYieldToken.sol";

contract YieldToken is ERC20, IYieldToken {
    using SafeERC20 for IERC20;

    uint256 public nonStakingSupply;

    address public gov;

    address[] public yieldTrackers;
    mapping(address => bool) public nonStakingAccounts;
    mapping(address => bool) public admins;

    bool public inWhitelistMode;
    mapping(address => bool) public whitelistedHandlers;

    modifier onlyGov() {
        require(msg.sender == gov, "YieldToken: forbidden");
        _;
    }

    modifier onlyAdmin() {
        require(admins[msg.sender], "YieldToken: forbidden");
        _;
    }

    constructor(
        string memory _name,
        string memory _symbol,
        uint256 _initialSupply
    ) ERC20(_name, _symbol) {
        gov = msg.sender;
        admins[msg.sender] = true;
        _mint(msg.sender, _initialSupply);
    }

    function setGov(address _gov) external onlyGov {
        gov = _gov;
    }

    function setYieldTrackers(address[] memory _yieldTrackers)
        external
        onlyGov
    {
        yieldTrackers = _yieldTrackers;
    }

    function addAdmin(address _account) external onlyGov {
        admins[_account] = true;
    }

    function removeAdmin(address _account) external override onlyGov {
        admins[_account] = false;
    }

    // to help users who accidentally send their tokens to this contract
    function withdrawToken(
        address _token,
        address _account,
        uint256 _amount
    ) external onlyGov {
        IERC20(_token).safeTransfer(_account, _amount);
    }

    function setInWhitelistMode(bool _inWhitelistMode) external onlyGov {
        inWhitelistMode = _inWhitelistMode;
    }

    function setWhitelistedHandler(address _handler, bool _isWhitelisted)
        external
        onlyGov
    {
        whitelistedHandlers[_handler] = _isWhitelisted;
    }

    function addNonStakingAccount(address _account) external onlyAdmin {
        require(
            !nonStakingAccounts[_account],
            "YieldToken: _account already marked"
        );
        _updateRewards(_account);
        nonStakingAccounts[_account] = true;
        nonStakingSupply += balanceOf(_account);
    }

    function removeNonStakingAccount(address _account) external onlyAdmin {
        require(
            nonStakingAccounts[_account],
            "YieldToken: _account not marked"
        );
        _updateRewards(_account);
        nonStakingAccounts[_account] = false;
        nonStakingSupply -= balanceOf(_account);
    }

    function recoverClaim(address _account, address _receiver)
        external
        onlyAdmin
    {
        for (uint256 i = 0; i < yieldTrackers.length; i++) {
            address yieldTracker = yieldTrackers[i];
            IYieldTracker(yieldTracker).claim(_account, _receiver);
        }
    }

    function claim(address _receiver) external {
        for (uint256 i = 0; i < yieldTrackers.length; i++) {
            address yieldTracker = yieldTrackers[i];
            IYieldTracker(yieldTracker).claim(msg.sender, _receiver);
        }
    }

    function totalStaked() external view override returns (uint256) {
        return totalSupply() - nonStakingSupply;
    }

    function stakedBalance(address _account)
        external
        view
        override
        returns (uint256)
    {
        if (nonStakingAccounts[_account]) {
            return 0;
        }
        return balanceOf(_account);
    }

    function _transfer(
        address _sender,
        address _recipient,
        uint256 _amount
    ) internal override {
        if (inWhitelistMode) {
            require(
                whitelistedHandlers[msg.sender],
                "YieldToken: msg.sender not whitelisted"
            );
        }

        super._transfer(_sender, _recipient, _amount);

        _updateRewards(_sender);
        _updateRewards(_recipient);
    }

    function _updateRewards(address _account) private {
        for (uint256 i = 0; i < yieldTrackers.length; i++) {
            address yieldTracker = yieldTrackers[i];
            IYieldTracker(yieldTracker).updateRewards(_account);
        }
    }

    function _beforeTokenTransfer(
        address _sender,
        address _recipient,
        uint256 _amount
    ) internal override {
        super._beforeTokenTransfer(_sender, _recipient, _amount);

        if (_sender != address(0)) _updateRewards(_sender);
        if (_recipient != address(0)) _updateRewards(_recipient);
    }

    function _afterTokenTransfer(
        address _sender,
        address _recipient,
        uint256 _amount
    ) internal override {
        super._afterTokenTransfer(_sender, _recipient, _amount);

        if (_sender != address(0) && nonStakingAccounts[_sender])
            nonStakingSupply -= _amount;
        if (_recipient != address(0) && nonStakingAccounts[_recipient])
            nonStakingSupply += _amount;
    }
}
