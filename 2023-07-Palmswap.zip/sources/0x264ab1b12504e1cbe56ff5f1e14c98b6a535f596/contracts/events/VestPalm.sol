// SPDX-License-Identifier: MIT

pragma solidity 0.8.19;

import {ReentrancyGuardUpgradeable} from "@openzeppelin/contracts-upgradeable/security/ReentrancyGuardUpgradeable.sol";
import {IERC20Upgradeable, SafeERC20Upgradeable} from "@openzeppelin/contracts-upgradeable/token/ERC20/utils/SafeERC20Upgradeable.sol";

import {GovernableUpgradeable} from "../access/GovernableUpgradeable.sol";
import "./interfaces/ILiquidityEvent.sol";
import "./interfaces/IVestPalm.sol";

contract VestPalm is
    IVestPalm,
    ReentrancyGuardUpgradeable,
    GovernableUpgradeable
{
    using SafeERC20Upgradeable for IERC20Upgradeable;

    uint256 internal totalAvailable;
    uint256 public burnable;

    address public burnWallet;

    uint256 public CLIFF_PERIOD;
    uint256 public VEST_DURATION;
    address public token; // Reward Token
    ILiquidityEvent public lpe;

    mapping(address => mapping(uint256 => VestingSchedule)) public vestSchedule;
    mapping(address => uint256) public numberOfVesting;

    event Deposit(
        address indexed account,
        uint256 indexed index,
        uint256 tier,
        uint256 amountIn,
        uint256 plpAmount,
        uint256 rewardAmount
    );

    event Claim(address indexed claimer, uint256 amount);

    event ClaimWithIndex(
        address indexed claimer,
        uint256 indexed index,
        uint256 tier,
        uint256 amount
    );

    event Destroy(
        address indexed account,
        uint256 indexed index,
        uint256 tier,
        uint256 amount
    );
    event Burn(address indexed account, uint256 amount);

    event BurnWalletChanged(address _old, address _new);
    event LpeContractChanged(address _old, address _new);

    function initialize(
        address _token,
        address _burnTo,
        uint256 _cliffPeriod,
        uint256 _vestDuration
    ) public initializer {
        __ReentrancyGuard_init();
        __GovernableUpgradeable_init();

        require(_token != address(0), "!token");
        token = _token;

        require(_burnTo != address(0), "!burnWallet");
        burnWallet = _burnTo;

        CLIFF_PERIOD = _cliffPeriod;

        require(_vestDuration != 0, "!vestDuration");
        VEST_DURATION = _vestDuration;
    }

    modifier onlyLpe() {
        require(msg.sender == address(lpe), "!lpe");
        _;
    }

    function changeBurnWallet(address _to) external onlyGov {
        require(_to != address(0), "!burnWallet");

        address _old = burnWallet;
        require(_old != _to, "invalid: same burn wallet");

        burnWallet = _to;

        emit BurnWalletChanged(_old, _to);
    }

    function setLpeContract(address _lpe) external onlyGov {
        require(_lpe != address(0), "!lpe");

        address _old = address(lpe);
        require(_old != _lpe, "invalid: same Lpe address");

        lpe = ILiquidityEvent(_lpe);

        emit LpeContractChanged(_old, _lpe);
    }

    function sweep() external onlyGov {
        require(lpe.eventEnded() == true, "!end");

        uint256 _balance = IERC20Upgradeable(token).balanceOf(address(this));
        uint256 _burnable = _balance - totalAvailable;

        _burn(_burnable);
    }

    function burn(uint256 _amount) external onlyGov {
        require(_amount <= burnable, ">burnable");

        burnable -= _amount;
        totalAvailable -= _amount;

        _burn(_amount);
    }

    function _burn(uint256 _amount) internal {
        IERC20Upgradeable(token).safeTransfer(burnWallet, _amount);
        emit Burn(msg.sender, _amount);
    }

    function previewRewardsDestroy(
        address _account,
        uint256[] calldata _tiers,
        uint256 _length
    )
        external
        view
        override
        onlyLpe
        returns (VestingSchedule[] memory schedules, uint256 sLength)
    {
        uint256 _numberOfVesting = numberOfVesting[_account];
        schedules = new VestingSchedule[](_numberOfVesting);

        for (uint256 i; i < _numberOfVesting; ++i) {
            VestingSchedule memory _vestSchedule = vestSchedule[_account][i];

            for (uint256 j; j < _length; ++j) {
                if (
                    _vestSchedule.tier != _tiers[j] || _vestSchedule.isDestroyed
                ) continue;

                schedules[sLength] = _vestSchedule;
                schedules[sLength].isDestroyed = true;

                uint256 _vestedAmount = _getVestedAmount(schedules[sLength]);
                schedules[sLength].notClaimed =
                    _vestedAmount -
                    _vestSchedule.claimed;

                ++sLength;
            }
        }
    }

    function resetUserReward(
        address _account,
        uint256[] calldata _tiers,
        uint256 _length
    ) external override onlyLpe {
        uint256 _numberOfVesting = numberOfVesting[_account];
        VestingSchedule storage _vestSchedule;

        for (uint256 i; i < _numberOfVesting; ++i) {
            uint256 _vestedAmount;
            uint256 _destroyed;

            _vestSchedule = vestSchedule[_account][i];

            for (uint256 j; j < _length; ++j) {
                if (
                    _vestSchedule.tier != _tiers[j] || _vestSchedule.isDestroyed
                ) continue;

                _vestSchedule.isDestroyed = true;
                _vestedAmount = _getVestedAmount(_vestSchedule);
                _vestSchedule.notClaimed =
                    _vestedAmount -
                    _vestSchedule.claimed;

                _destroyed = _vestSchedule.allocated - _vestedAmount;
                burnable += _destroyed;

                emit Destroy(_account, i, _tiers[j], _destroyed);
            }
        }
    }

    function deposit(address _account, PurchaseInfo[] memory pInfo)
        external
        override
        nonReentrant
        onlyLpe
    {
        uint256 _currentIndex = numberOfVesting[_account];
        for (uint256 i; i < pInfo.length; ++i) {
            if (pInfo[i].rewards == 0) continue;

            vestSchedule[_account][_currentIndex] = VestingSchedule({
                isDestroyed: false,
                index: _currentIndex,
                tier: pInfo[i].tier,
                depositTime: block.timestamp,
                claimed: 0,
                notClaimed: 0,
                allocated: pInfo[i].rewards
            });

            totalAvailable += pInfo[i].rewards;

            emit Deposit(
                _account,
                _currentIndex,
                pInfo[i].tier,
                pInfo[i].amountIn,
                pInfo[i].amountOut,
                pInfo[i].rewards
            );

            ++_currentIndex;
        }
        numberOfVesting[_account] = _currentIndex;
    }

    function claim() external nonReentrant returns (uint256) {
        uint256 claimable;
        uint256 _numberOfVesting = numberOfVesting[msg.sender];

        for (uint256 i; i < _numberOfVesting; ++i)
            claimable += _updateClaimInfoWithIndex(i);

        return _claim(claimable);
    }

    function claimWithIndex(uint256 _index)
        external
        nonReentrant
        returns (uint256)
    {
        require(_index < numberOfVesting[msg.sender], "!exist");

        return _claim(_updateClaimInfoWithIndex(_index));
    }

    function _claim(uint256 _claimAmount) internal returns (uint256) {
        totalAvailable -= _claimAmount;

        IERC20Upgradeable(token).safeTransfer(msg.sender, _claimAmount);

        emit Claim(msg.sender, _claimAmount);
        return _claimAmount;
    }

    function _updateClaimInfoWithIndex(uint256 _index)
        internal
        returns (uint256 claimable)
    {
        VestingSchedule storage _vestSchedule = vestSchedule[msg.sender][
            _index
        ];

        if (!_vestSchedule.isDestroyed) {
            if (_vestSchedule.claimed == _vestSchedule.allocated) claimable = 0;
            else {
                uint256 _vestedAmount = _getVestedAmount(_vestSchedule);
                claimable = _vestedAmount - _vestSchedule.claimed;
                _vestSchedule.claimed = _vestedAmount;
            }
        } else if (_vestSchedule.notClaimed != 0) {
            claimable = _vestSchedule.notClaimed;

            _vestSchedule.claimed += _vestSchedule.notClaimed;
            _vestSchedule.notClaimed = 0;
        }

        emit ClaimWithIndex(msg.sender, _index, _vestSchedule.tier, claimable);

        return claimable;
    }

    function getClaimable(address _account)
        external
        view
        returns (uint256 claimable)
    {
        uint256 _numberOfVesting = numberOfVesting[_account];
        for (uint256 i; i < _numberOfVesting; ++i) {
            claimable += getClaimableWithIndex(_account, i);
        }
    }

    function getClaimableWithIndex(address _account, uint256 _index)
        public
        view
        returns (uint256 claimable)
    {
        require(_index < numberOfVesting[_account], "!exist");

        VestingSchedule memory _vestSchedule = vestSchedule[_account][_index];
        if (!_vestSchedule.isDestroyed) {
            if (_vestSchedule.claimed != _vestSchedule.allocated) {
                uint256 _vestedAmount = _getVestedAmount(_vestSchedule);
                claimable += _vestedAmount - _vestSchedule.claimed;
            }
        } else claimable += _vestSchedule.notClaimed;
    }

    function getClaimedRewards(address _account)
        external
        view
        returns (uint256 rewards)
    {
        uint256 _numberOfVesting = numberOfVesting[_account];
        for (uint256 i; i < _numberOfVesting; ++i) {
            VestingSchedule memory _vestSchedule = vestSchedule[_account][i];
            rewards += _vestSchedule.claimed;
        }
    }

    function getDestroyedRewards(address _account)
        external
        view
        returns (uint256 rewards)
    {
        uint256 _numberOfVesting = numberOfVesting[_account];
        for (uint256 i; i < _numberOfVesting; ++i) {
            VestingSchedule memory _vestSchedule = vestSchedule[_account][i];
            if (_vestSchedule.isDestroyed) {
                rewards +=
                    _vestSchedule.allocated -
                    _vestSchedule.claimed -
                    _vestSchedule.notClaimed;
            }
        }
    }

    function getAllocatedRewards(address _account)
        external
        view
        returns (uint256 rewards)
    {
        uint256 _numberOfVesting = numberOfVesting[_account];
        for (uint256 i; i < _numberOfVesting; ++i) {
            VestingSchedule memory _vestSchedule = vestSchedule[_account][i];
            rewards += _vestSchedule.allocated;
        }
    }

    function getDailyAmount(address _account, uint256 _index)
        external
        view
        returns (uint256)
    {
        VestingSchedule memory _vestSchedule = vestSchedule[_account][_index];

        if (block.timestamp <= _vestSchedule.depositTime + CLIFF_PERIOD)
            return 0;

        if (_vestSchedule.isDestroyed) return 0;

        return (_vestSchedule.allocated * 1 days) / VEST_DURATION;
    }

    function _getVestedAmount(VestingSchedule memory _vestSchedule)
        internal
        view
        returns (uint256)
    {
        if (block.timestamp <= _vestSchedule.depositTime + CLIFF_PERIOD)
            return 0;
        else if (
            block.timestamp >=
            _vestSchedule.depositTime + CLIFF_PERIOD + VEST_DURATION
        ) {
            return _vestSchedule.allocated;
        } else {
            uint256 _elapsedTime = block.timestamp -
                (_vestSchedule.depositTime + CLIFF_PERIOD);
            return (_vestSchedule.allocated * _elapsedTime) / VEST_DURATION;
        }
    }
}
