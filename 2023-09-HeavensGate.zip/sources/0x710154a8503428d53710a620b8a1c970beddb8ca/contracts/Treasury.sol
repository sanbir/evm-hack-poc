pragma solidity 0.8.19;

import "@openzeppelin/contracts/access/Ownable.sol";
import "./interface/IHATE.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/IERC721Enumerable.sol";
import "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";

/// @title   HATE TREASURY
/// @notice  HATE TREASURY
contract HateTreasury is Ownable, IERC721Receiver {
    /// EVENTS ///

    /// @notice Emitted ERC20 tokens are transferred
    /// @param token Address of token being withdrawn
    /// @param destination Address of where withdrawn token is sent
    /// @param amount Amount of tokens withdrawn
    event TransferredERC20(address token, address destination, uint amount);

    /// @notice Emitted when ERC721 tokens are transferred
    /// @param token Address of token being withdrawn
    /// @param destination Address of where withdrawn token is sent
    /// @param ids Array of ids that are being witdrawn
    event TransferredERC721(address token, address destination, uint[] ids);

    /// STATE VARIABLS ///

    /// @notice HATE token
    address public immutable HATE;

    /// @notice Stores approved HATE minter
    mapping(address => bool) public hateMinter;

    /// CONSTRUCTOR ///

    /// @param _HATE  Address of HATE
    constructor(address _HATE) {
        require(_HATE != address(0));
        HATE = _HATE;
    }

    /// MINTER FUNCTION ///

    function mintHATE(address to_, uint256 amount_) external {
        require(hateMinter[msg.sender], "msg.sender is not a hate minter");
        IHATE(HATE).mint(to_, amount_);
    }

    /// VIEW FUNCTION ///

    /// @notice                 Returns payout token valuation of principal
    /// @param _principalToken  Address of principal token
    /// @param _amount          Amount of `_principalToken` to value
    /// @return value_          Value of `_amount` of `_principalToken`
    function valueOfToken(address _principalToken, uint _amount) public view returns (uint value_) {
        // convert amount to match payout token decimals
        value_ =
            (_amount * (10 ** IERC20Metadata(HATE).decimals())) /
            (10 ** IERC20Metadata(_principalToken).decimals());
    }

    /// POLICY FUNCTIONS ///

    /// @notice              Withdraw ERC20 token to `_destination`
    /// @param _token        Address of token to withdraw
    /// @param _destination  Address of where to send `_token`
    /// @param _amount       Amount of `_token` to withdraw
    function transferERC20(address _token, address _destination, uint _amount) external onlyOwner {
        IERC20(_token).transfer(_destination, _amount);
        emit TransferredERC20(_token, _destination, _amount);
    }

    function transferERC721(address token_, address from, address to, uint256[] calldata nftIDs) external onlyOwner {
        for (uint256 i = 0; i < nftIDs.length; ++i) {
            IERC721(token_).safeTransferFrom(from, to, nftIDs[i]);
        }
        emit TransferredERC721(token_, to, nftIDs);
    }

    function addHateMinter(address _minter) external onlyOwner {
        hateMinter[_minter] = true;
    }

    function removeHateMinter(address _minter) external onlyOwner {
        hateMinter[_minter] = false;
    }

    /// PURE FUNCTIONS ///

    function onERC721Received(address, address, uint256, bytes calldata) external pure returns (bytes4) {
        return IERC721Receiver.onERC721Received.selector;
    }

}
