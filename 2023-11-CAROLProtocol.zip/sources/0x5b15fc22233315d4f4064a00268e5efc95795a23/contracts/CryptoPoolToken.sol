// SPDX-License-Identifier: MIT

pragma solidity ^0.8.3;

import "./interfaces/ICryptoPoolToken.sol";
import "./PoolToken.sol";

contract CryptoPoolToken is PoolToken, ICryptoPoolToken {
    constructor(string memory name_, string memory symbol_) PoolToken(name_, symbol_) {}

    /// @dev Increases supply by factor of (1 + frac/1e18) and mints it for _to
    function mintRelative(address to, uint256 frac) external onlyOwner returns (uint256) {
        uint256 supply = totalSupply();
        uint256 dSupply = (supply * frac) / 10 ** 18;
        if (dSupply > 0) {
            _mint(to, dSupply);
        }

        return dSupply;
    }
}
