// SPDX-License-Identifier: MIT

pragma solidity ^0.8.3;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/interfaces/IERC1271.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import "@openzeppelin/contracts/utils/Address.sol";

import "./interfaces/IPoolToken.sol";
import "./library/Ownable.sol";

abstract contract PoolToken is ERC20, Ownable, EIP712, IPoolToken {
    using Address for address;

    bytes32 private constant _PERMIT_TYPEHASH =
        keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");

    // bytes4(keccak256("isValidSignature(bytes32,bytes)")
    bytes4 internal constant _ERC1271_MAGIC_VALUE = 0x1626ba7e;

    mapping(address => uint256) public override nonces;

    constructor(string memory name_, string memory symbol_) ERC20(name_, symbol_) EIP712(name_, "1") {}

    function mint(address user, uint256 amount) public onlyOwner returns (bool) {
        _mint(user, amount);
        return true;
    }

    function burn(address user, uint256 value) public onlyOwner returns (bool) {
        _burn(user, value);
        return true;
    }

    function permit(
        address owner_,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external {
        require(owner_ != address(0), "zero address");
        require(block.timestamp <= deadline, "deadline");

        uint256 nonce = nonces[owner_];
        bytes32 structHash = keccak256(abi.encode(_PERMIT_TYPEHASH, owner_, spender, value, nonce, deadline));

        bytes32 hash = _hashTypedDataV4(structHash);

        if (owner_.isContract()) {
            bytes memory signature = abi.encodePacked(r, s, v);
            require(IERC1271(owner_).isValidSignature(hash, signature) == _ERC1271_MAGIC_VALUE, "invalid sig");
        } else {
            address signer = ECDSA.recover(hash, v, r, s);
            require(signer == owner_, "invalid sig");
        }
        ++nonces[owner_];
        _approve(owner_, spender, value);
    }

    function DOMAIN_SEPARATOR() external view returns (bytes32) {
        return _domainSeparatorV4();
    }
}
