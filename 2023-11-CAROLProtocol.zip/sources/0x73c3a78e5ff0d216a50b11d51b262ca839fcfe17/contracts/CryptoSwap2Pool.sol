// SPDX-License-Identifier: MIT

pragma solidity ^0.8.3;

import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";

import "./interfaces/ICryptoPoolToken.sol";
import "./interfaces/ICryptoSwap2Pool.sol";
import "./interfaces/IKokonutSwapExchangeCallback.sol";
import "./library/ReentrancyGuard.sol";
import "./utils/ZKokonutAccess.sol";
import "./interfaces/ICryptoSwapFactory.sol";

contract CryptoSwap2Pool is ICryptoSwap2Pool, ReentrancyGuard, ZKokonutAccess {
    using SafeERC20 for IERC20;

    uint256 internal constant _ADMIN_ACTIONS_DELAY = 3 * 86400;
    uint256 internal constant _MIN_RAMP_TIME = 86400;

    uint256 internal constant _MAX_ADMIN_FEE = 10 * 10 ** 9;
    uint256 internal constant _MIN_FEE = 5 * 10 ** 5; // 0.5 bps
    uint256 internal constant _MAX_FEE = 5 * 10 ** 9;
    uint256 internal constant _MAX_A_CHANGE = 10;
    uint256 internal constant _NOISE_FEE = 10 ** 5; // 0.1 bps

    uint256 internal constant _MIN_GAMMA = 10 ** 10;
    uint256 internal constant _MAX_GAMMA = 2 * 10 ** 16;

    uint256 internal constant _MIN_A = (N_COINS ** N_COINS * _A_MULTIPLIER) / 10;
    uint256 internal constant _MAX_A = N_COINS ** N_COINS * _A_MULTIPLIER * 100000;

    uint256 public constant override N_COINS = 2;
    uint256 internal constant _PRECISION_PRICE_SCALE = 10 ** 18; // The precision to convert to
    uint256 internal constant _PRECISION_EXP = 10 ** 10;
    uint256 internal constant _PRECISION_FEE = 10 ** 10;
    uint256 internal constant _A_MULTIPLIER = 10000;

    address internal immutable _factory;

    address public immutable override token;
    address internal immutable _coin0;
    address internal immutable _coin1;

    uint256 internal immutable _PRECISION_COIN0;
    uint256 internal immutable _PRECISION_COIN1;

    uint256 public override priceScale; // Internal price scale
    uint256 internal _PriceOracle; // Price target given by MA

    uint256 public override lastPrices;
    uint256 public override lastPricesTimestamp;

    uint32 public override initialA;
    uint32 public override futureA;
    uint64 public override initialGamma;
    uint64 public override futureGamma;
    uint32 public override initialAGammaTime;
    uint32 public override futureAGammaTime;

    uint256 public override allowedExtraProfit; // 2 * 10**12 - recommended value;
    uint256 public override futureAllowedExtraProfit;

    uint256 public override minRemainingPostRebalanceRatio;
    uint256 public override futureRebalancingThreshold;

    uint256 public override feeGamma;
    uint256 public override futureFeeGamma;

    uint256 public override adjustmentStep;
    uint256 public override futureAdjustmentStep;

    uint256 public override maHalfTime;
    uint256 public override futureMaHalfTime;

    uint256 public override midFee;
    uint256 public override outFee;
    uint256 public override adminFee;
    uint256 public override flashLoanFee;
    uint256 public override futureMidFee;
    uint256 public override futureOutFee;
    uint256 public override futureAdminFee;
    uint256 public override futureFlashLoanFee;

    uint256[N_COINS] public override balances;
    uint256 public override D;

    uint256 public override xcpProfit;
    uint256 public override xcpProfitA; // Full profit at last claim of admin fees
    uint256 public override virtualPrice; // Cached (fast to read) virtual price also used internally
    bool internal _notAdjusted;

    uint256 public override adminActionsDeadline;

    modifier readOnlyNonReentrant() {
        _checkReadOnlyNonReentrant();
        _;
    }

    function _checkReadOnlyNonReentrant() internal view {
        require(!reentrancyGuardEntered(), "Reentrant");
    }

    constructor(InitializeArgs memory args, address token_, address owner_, address factory_) {
        _initializeZKokonutAccess(owner_);
        _factory = factory_;

        // Pack A and gamma:
        // shifted A + gamma

        initialA = args.A;
        initialGamma = args.gamma;
        futureA = args.A;
        futureGamma = args.gamma;

        midFee = args.midFee;
        outFee = args.outFee;
        allowedExtraProfit = args.allowedExtraProfit;
        minRemainingPostRebalanceRatio = args.minRemainingPostRebalanceRatio;
        feeGamma = args.feeGamma;
        adjustmentStep = args.adjustmentStep;
        adminFee = args.adminFee;
        flashLoanFee = args.flashLoanFee;

        priceScale = args.initialPrice;
        _PriceOracle = args.initialPrice;
        lastPrices = args.initialPrice;
        lastPricesTimestamp = block.timestamp;
        maHalfTime = args.maHalfTime;

        xcpProfitA = 10 ** 18;

        token = token_;
        _coin0 = args.coins[0];
        _coin1 = args.coins[1];
        _PRECISION_COIN0 = 10 ** (18 - _getDecimals(args.coins[0]));
        _PRECISION_COIN1 = 10 ** (18 - _getDecimals(args.coins[1]));
    }

    function _getDecimals(address tokenAddress) internal view returns (uint256) {
        return IERC20Metadata(tokenAddress).decimals();
    }

    function _AGamma() internal view returns (uint256 mA, uint256 mGamma) {
        unchecked {
            uint256 t1 = futureAGammaTime;
            mA = futureA;
            mGamma = futureGamma;

            if (block.timestamp < t1) {
                // handle ramping up and down of A
                uint256 t0 = initialAGammaTime;

                // Less readable but more compact way of writing and converting to uint256
                // gamma0: uint256 = bitwise_and(AGamma0, 2**128-1)
                // A0: uint256 = shift(AGamma0, -128)
                // A1 = A0 + (A1 - A0) * (block.timestamp - t0) / (t1 - t0)
                // gamma1 = gamma0 + (gamma1 - gamma0) * (block.timestamp - t0) / (t1 - t0)

                t1 -= t0;
                t0 = block.timestamp - t0;
                uint256 t2 = t1 - t0;

                mA = (initialA * t2 + mA * t0) / t1;
                mGamma = (initialGamma * t2 + mGamma * t0) / t1;
            }
        }
    }

    function _standardize(uint256 x, uint256 y) internal view returns (uint256[N_COINS] memory result) {
        result[0] = x * _PRECISION_COIN0;
        result[1] = (y * _PRECISION_COIN1 * priceScale) / _PRECISION_PRICE_SCALE;
        return result;
    }

    function _unStandardize(uint256 standardizedAmount, uint256 i) internal view returns (uint256) {
        return
            i == 0
                ? standardizedAmount / _PRECISION_COIN0
                : (standardizedAmount * _PRECISION_PRICE_SCALE) / _PRECISION_COIN1 / priceScale;
    }

    function _feeRate(uint256[N_COINS] memory xp) internal view returns (uint256) {
        /*
        f = feeGamma / (feeGamma + (1 - K))
        where
        K = prod(x) / (sum(x) / N)**N
        (all normalized to 1e18)
        */

        uint256 feeGamma_ = feeGamma;
        uint256 f = xp[0] + xp[1]; // sum
        f =
            (feeGamma_ * 10 ** 18) /
            (feeGamma_ + 10 ** 18 - ((((10 ** 18 * N_COINS ** N_COINS) * xp[0]) / f) * xp[1]) / f);
        return (midFee * f + outFee * (10 ** 18 - f)) / 10 ** 18;
    }

    function _getXcp(uint256 _D) internal view returns (uint256) {
        uint256[N_COINS] memory x;
        unchecked {
            x[0] = _D / N_COINS;
            x[1] = (_D * _PRECISION_PRICE_SCALE) / (priceScale * N_COINS);
        }
        return _geometricMean(x, true);
    }

    function _halfpow(uint256 power) internal pure returns (uint256) {
        /*
        1e18 * 0.5 ** (power/1e18)
        Inspired by: https://github.com/balancer-labs/balancer-core/blob/master/contracts/BNum.sol#L128
        */
        uint256 intpow = power / 10 ** 18;
        uint256 otherpow = power - intpow * 10 ** 18;
        if (intpow > 59) {
            return 0;
        }
        uint256 result = 10 ** 18 / (2 ** intpow);
        if (otherpow == 0) {
            return result;
        }

        uint256 term = 10 ** 18;
        uint256 S = 10 ** 18;
        bool neg = false;

        for (uint256 i = 1; i < 256; ++i) {
            uint256 K = i * 10 ** 18;
            uint256 c = K - 10 ** 18;
            if (otherpow > c) {
                c = otherpow - c;
                neg = !neg;
            } else {
                c -= otherpow;
            }
            term = (term * (c / 2)) / K;
            if (neg) {
                S -= term;
            } else {
                S += term;
            }
            if (term < _PRECISION_EXP) {
                return (result * S) / 10 ** 18;
            }
        }

        revert("C");
    }

    function _sqrtInt(uint256 x) internal pure returns (uint256) {
        /*
        Originating from: https://github.com/vyperlang/vyper/issues/1266
        */
        if (x == 0) {
            return 0;
        }

        uint256 z = (x + 10 ** 18) / 2;
        uint256 y = x;

        for (uint256 i = 0; i < 256; ++i) {
            if (z == y) {
                return y;
            }
            y = z;
            z = ((x * 10 ** 18) / z + z) / 2;
        }

        revert("C");
    }

    function _calcTokenFeeRate(
        uint256[N_COINS] memory xp0,
        uint256[N_COINS] memory xp1
    ) internal view returns (uint256) {
        uint256 feeRate = _feeRate(xp1);
        uint256 sum = 0;
        uint256 diff = 0;
        uint256[N_COINS] memory amounts;
        unchecked {
            for (uint256 i = 0; i < N_COINS; ++i) {
                amounts[i] = xp1[i] - xp0[i]; // always xp1[i] > xp0[i]
                sum += amounts[i];
                require(sum >= amounts[i]);
            }
            uint256 avg = sum / N_COINS;
            for (uint256 i = 0; i < N_COINS; ++i) {
                diff += (amounts[i] > avg) ? amounts[i] - avg : avg - amounts[i];
            }
            feeRate = (feeRate * N_COINS) / (4 * (N_COINS - 1));
        }
        return (feeRate * diff) / sum + _NOISE_FEE;
    }

    function _calcWithdrawOneCoin(
        uint256 tokenAmount,
        uint256 i,
        uint256[N_COINS] memory xp0
    ) internal view returns (uint256 dy, uint256 lpFee, uint256 D1, uint256[N_COINS] memory xp1) {
        require(i < N_COINS); // dev: coin out of range

        uint256 tokenSupply = _lpTotalSupply();
        xp1 = _arrCopy(xp0);
        (uint256 mA, uint256 mGamma) = _AGamma();
        require(tokenAmount <= tokenSupply);
        uint256 D0 = futureAGammaTime > 0 ? _newtonD(mA, mGamma, xp1) : D;
        uint256 y;
        unchecked {
            lpFee = (_feeRate(xp1) * tokenAmount) / (2 * _PRECISION_FEE) + 1;
            D1 = D0 - (D0 * (tokenAmount - lpFee)) / tokenSupply;
            y = _newtonY(mA, mGamma, xp1[1 - i], D1);
        }
        dy = _unStandardize(xp1[i] - y, i);
        xp1[i] = y;
    }

    function _arrCopy(uint256[N_COINS] memory _input) internal pure returns (uint256[N_COINS] memory result) {
        unchecked {
            for (uint256 i = 0; i < N_COINS; ++i) {
                result[i] = _input[i];
            }
        }
    }

    // Internal Functions
    function _claimAdminFee() internal {
        (uint256 mA, uint256 mGamma) = _AGamma();

        uint256 _xcpProfit = xcpProfit;
        uint256 _xcpProfitA = xcpProfitA;
        uint256 _minRemainingPostRebalanceRatio = minRemainingPostRebalanceRatio;

        // Gulp here
        unchecked {
            for (uint256 i = 0; i < N_COINS; ++i) {
                balances[i] = _thisBalanceOf(_coins(i));
            }
        }

        uint256 vprice = virtualPrice;

        if (_xcpProfit > _xcpProfitA) {
            uint256 fees;
            unchecked {
                fees = ((_xcpProfit - _xcpProfitA) * adminFee) / _PRECISION_FEE;
            }
            if (fees > 0) {
                address receiver = ICryptoSwapFactory(_factory).getFeeReceiver();
                if (receiver != address(0)) {
                    uint256 frac = (vprice * 10 ** 18) /
                        (vprice - (fees * _minRemainingPostRebalanceRatio) / _PRECISION_FEE) -
                        10 ** 18;
                    uint256 claimed = ICryptoPoolToken(token).mintRelative(receiver, frac);
                    _xcpProfit -= fees;
                    xcpProfit = _xcpProfit;
                    emit ClaimAdminFee(receiver, claimed);
                }
            }
        }

        // Recalculate D b/c we gulped
        D = _newtonD(mA, mGamma, _standardize(balances[0], balances[1]));

        virtualPrice = (10 ** 18 * _getXcp(D)) / _lpTotalSupply();

        if (_xcpProfit > _xcpProfitA) {
            xcpProfitA = _xcpProfit;
        }
    }

    function _tweakPrice(uint256 mA, uint256 mGamma, uint256[N_COINS] memory xp, uint256 newD) internal {
        uint256 oldPriceScale = priceScale;
        uint256 newPriceOracle = _PriceOracle;
        uint256 lastPrices_ = lastPrices;
        {
            uint256 lastPricesTimestamp_ = lastPricesTimestamp;

            if (lastPricesTimestamp_ < block.timestamp) {
                // MA update required
                uint256 alpha = _halfpow(((block.timestamp - lastPricesTimestamp_) * 10 ** 18) / maHalfTime);
                uint256 price = Math.max(Math.min(lastPrices_, 2 * oldPriceScale), oldPriceScale / 2);
                newPriceOracle = (price * (10 ** 18 - alpha) + newPriceOracle * alpha) / 10 ** 18;
                _PriceOracle = newPriceOracle;
                lastPricesTimestamp = block.timestamp;
            }

            // Withdrawal methods know new D already
            if (newD == 0) {
                // We will need this a few times (35k gas)
                // @dev Reuse newD as DUnadjusted
                newD = _newtonD(mA, mGamma, xp);
            }

            lastPrices_ = _getPrice(1, mA, mGamma, xp, newD);
            lastPrices = lastPrices_;
        }

        uint256 oldVirtualPrice = virtualPrice;

        // Update profit numbers without price adjustment first
        uint256[N_COINS] memory mXp;
        mXp[0] = newD / N_COINS;
        mXp[1] = (newD * _PRECISION_PRICE_SCALE) / (N_COINS * oldPriceScale);
        uint256 newXcpProfit = 10 ** 18;
        uint256 newVirtualPrice = 10 ** 18;

        if (oldVirtualPrice > 0) {
            newVirtualPrice = (10 ** 18 * _geometricMean(mXp, true)) / _lpTotalSupply();
            newXcpProfit = (xcpProfit * newVirtualPrice) / oldVirtualPrice;

            uint256 t = futureAGammaTime;
            if (newVirtualPrice < oldVirtualPrice && t == 0) {
                revert("Loss");
            }
            if (t == 1) {
                futureAGammaTime = 0;
            }
        }

        xcpProfit = newXcpProfit;

        uint256 norm = (newPriceOracle * 10 ** 18) / oldPriceScale;
        unchecked {
            if (norm > 10 ** 18) {
                norm -= 10 ** 18;
            } else {
                norm = 10 ** 18 - norm;
            }
        }
        uint256 mAdjustmentStep = Math.max(adjustmentStep, norm / 5);

        bool needsAdjustment = _notAdjusted;
        // if not needsAdjustment and (virtualPrice-10**18 > (xcpProfit-10**18)*minRemainingPostRebalanceRatio + allowedExtraProfit):
        // (re-arrange for gas efficiency)
        if (
            !needsAdjustment &&
            (newVirtualPrice - 10 ** 18 >
                ((newXcpProfit - 10 ** 18) * minRemainingPostRebalanceRatio) / _PRECISION_FEE + allowedExtraProfit) &&
            (norm > mAdjustmentStep) &&
            (oldVirtualPrice > 0)
        ) {
            needsAdjustment = true;
            _notAdjusted = true;
        }

        if (needsAdjustment) {
            if (norm > mAdjustmentStep && oldVirtualPrice > 0) {
                // We reuse lastPrices_ as pNew
                lastPrices_ = (oldPriceScale * (norm - mAdjustmentStep) + mAdjustmentStep * newPriceOracle) / norm;

                // Calculate balances*prices
                mXp[0] = xp[0];
                mXp[1] = (xp[1] * lastPrices_) / oldPriceScale;

                // Calculate "extended constant product" invariant xCP and virtual price
                uint256 _D = _newtonD(mA, mGamma, mXp);
                mXp[0] = _D / N_COINS;
                mXp[1] = (_D * _PRECISION_PRICE_SCALE) / (N_COINS * lastPrices_);
                // We reuse oldVirtualPrice here but it's not old anymore
                oldVirtualPrice = (10 ** 18 * _geometricMean(mXp, true)) / _lpTotalSupply();

                // Proceed if we've got enough profit
                // if (oldVirtualPrice > 10**18) and (oldVirtualPrice - 10**18 > (xcpProfit - 10**18) * minRemainingPostRebalanceRatio):
                if (
                    (oldVirtualPrice > 10 ** 18) &&
                    (oldVirtualPrice - 10 ** 18 >
                        ((newXcpProfit - 10 ** 18) * minRemainingPostRebalanceRatio) / _PRECISION_FEE)
                ) {
                    priceScale = lastPrices_;
                    D = _D;
                    virtualPrice = oldVirtualPrice;

                    emit TweakPrice(lastPrices_, _D, oldVirtualPrice, newXcpProfit);
                    return;
                } else {
                    _notAdjusted = false;

                    // Can instead do another flag variable if we want to save bytespace
                    D = newD;
                    virtualPrice = newVirtualPrice;
                    _claimAdminFee();

                    return;
                }
            }
        }

        // If we are here, the priceScale adjustment did not happen
        // Still need to update the profit counter and D
        D = newD;
        virtualPrice = newVirtualPrice;

        // norm appeared < adjustmentStep after
        if (needsAdjustment) {
            _notAdjusted = false;
            _claimAdminFee();
        }
    }

    function _internalPriceOracle() internal view returns (uint256) {
        uint256 _lastPricesTimestamp = lastPricesTimestamp;

        if (_lastPricesTimestamp < block.timestamp) {
            uint256 alpha = _halfpow(((block.timestamp - _lastPricesTimestamp) * 10 ** 18) / maHalfTime);
            return (lastPrices * (10 ** 18 - alpha) + _PriceOracle * alpha) / 10 ** 18;
        } else {
            return _PriceOracle;
        }
    }

    /* External Functions */

    function exchange(
        uint256 i,
        uint256 j,
        uint256 dx,
        uint256 minDy,
        bytes calldata data
    ) external nonReentrant whenNotPaused returns (uint256 dy, uint256 dyFee) {
        require(i + j == 1); // dev: coin index out of range
        require(dx > 0); // dev: do not exchange 0 coins

        (uint256 mA, uint256 mGamma) = _AGamma();

        if (futureAGammaTime > 0) {
            D = _newtonD(mA, mGamma, _standardize(balances[0], balances[1]));
            if (block.timestamp >= futureAGammaTime) {
                futureAGammaTime = 1;
            }
        }
        uint256[N_COINS] memory xp0 = balances;
        uint256[N_COINS] memory xp1 = _arrCopy(xp0);
        xp1[i] = xp1[i] + dx;
        balances[i] = xp1[i];
        xp0 = _standardize(xp0[0], xp0[1]);
        xp1 = _standardize(xp1[0], xp1[1]);

        dy = xp1[j] - _newtonY(mA, mGamma, xp1[i], D);
        require(dy > 0);
        unchecked {
            xp1[j] -= dy;
            dy = _unStandardize(dy - 1, j);
            dyFee = (_feeRate(xp1) * dy) / _PRECISION_FEE;
            dy -= dyFee;
            require(dy >= minDy, "SP");
            balances[j] = balances[j] - dy;
        }

        // support flash swap
        _transfer(_coins(j), msg.sender, dy);

        // Do transfers in and out together
        if (data.length == 0) {
            _pullToken(_coins(i), msg.sender, dx);
        } else {
            address inCoin = _coins(i);
            // reuse minDy as balance
            minDy = _thisBalanceOf(inCoin);
            IKokonutSwapExchangeCallback(msg.sender).onExchange(i, j, dx, dy, data);
            require(_thisBalanceOf(inCoin) - minDy >= dx); // dev: callback didn't give us sufficient coins
        }

        xp1 = _standardize(balances[0], balances[1]);
        _tweakPrice(mA, mGamma, xp1, 0);

        emit TokenExchange(msg.sender, i, dx, j, dy, dyFee);
    }

    function addLiquidity(
        uint256[] calldata amounts,
        uint256 minMintAmount
    ) external nonReentrant whenNotPaused returns (uint256 dToken, uint256 lpFee) {
        require(amounts.length == N_COINS);
        require(amounts[0] > 0 || amounts[1] > 0); // dev: no coins to add

        (uint256 mA, uint256 mGamma) = _AGamma();

        uint256 D0;
        if (futureAGammaTime > 0) {
            D0 = _newtonD(mA, mGamma, _standardize(balances[0], balances[1]));
            if (block.timestamp >= futureAGammaTime) {
                futureAGammaTime = 1;
            }
        } else {
            D0 = D;
        }

        uint256[N_COINS] memory xp0 = balances;
        uint256[N_COINS] memory xp1 = _arrCopy(xp0);
        for (uint256 i = 0; i < N_COINS; ++i) {
            uint256 amount = amounts[i];
            if (amount > 0) {
                xp1[i] = xp1[i] + amount;
                _pullToken(_coins(i), msg.sender, amount);
            }
            balances[i] = xp1[i];
        }

        xp0 = _standardize(xp0[0], xp0[1]);
        xp1 = _standardize(xp1[0], xp1[1]);

        uint256 D1 = _newtonD(mA, mGamma, xp1);

        uint256 tokenSupply = _lpTotalSupply();
        if (D0 > 0) {
            dToken = (tokenSupply * D1) / D0 - tokenSupply;
        } else {
            dToken = _getXcp(D1); // making initial virtual price equal to 1
        }
        require(dToken > 0); // dev: nothing minted

        if (D0 > 0) {
            lpFee = (_calcTokenFeeRate(xp0, xp1) * dToken) / _PRECISION_FEE + 1;
            dToken -= lpFee;
            tokenSupply += dToken;
            _mintMsgSender(dToken);

            _tweakPrice(mA, mGamma, xp1, D1);
        } else {
            D = D1;
            virtualPrice = 10 ** 18;
            xcpProfit = 10 ** 18;
            _mintMsgSender(dToken);
            tokenSupply += dToken;
        }

        require(dToken >= minMintAmount, "SP");

        emit AddLiquidity(msg.sender, amounts, lpFee, D1, tokenSupply);
    }

    function removeLiquidity(
        uint256 amount,
        uint256[] calldata minAmounts
    ) external nonReentrant returns (uint256[] memory) {
        /*
        This withdrawal method is very safe, does no complex math
        */
        require(minAmounts.length == N_COINS);
        uint256 _totalSupply = _lpTotalSupply();
        _burnMsgSender(amount);
        uint256[] memory dBalances = new uint256[](N_COINS);
        uint256[] memory balances_ = new uint256[](N_COINS);

        unchecked {
            for (uint256 i = 0; i < N_COINS; ++i) {
                balances_[i] = balances[i];
                uint256 dBalance = (balances_[i] * amount) / _totalSupply;
                require(dBalance >= minAmounts[i]);
                balances[i] = balances_[i] - dBalance;
                balances_[i] = dBalance;
                // now it's the amounts going out
                address coin = _coins(i);
                _transfer(coin, msg.sender, dBalance);
                dBalances[i] = dBalance;
            }

            uint256 _D = D;
            D = _D - (_D * amount) / _totalSupply;

            emit RemoveLiquidity(msg.sender, balances_, _totalSupply - amount);
        }
        return dBalances;
    }

    function removeLiquidityOneCoin(
        uint256 tokenAmount,
        uint256 i,
        uint256 minAmount
    ) external nonReentrant whenNotPaused returns (uint256, uint256) {
        uint256[N_COINS] memory xp0 = _standardize(balances[0], balances[1]);
        (uint256 dy, uint256 lpFee, uint256 D1, uint256[N_COINS] memory xp1) = _calcWithdrawOneCoin(
            tokenAmount,
            i,
            xp0
        );
        require(dy >= minAmount, "SP");

        if (block.timestamp >= futureAGammaTime) {
            futureAGammaTime = 1;
        }

        balances[i] -= dy;
        _burnMsgSender(tokenAmount);
        _transfer(_coins(i), msg.sender, dy);

        (uint256 mA, uint256 mGamma) = _AGamma();
        _tweakPrice(mA, mGamma, xp1, D1);

        emit RemoveLiquidityOne(msg.sender, i, dy, lpFee, _lpTotalSupply());

        return (dy, lpFee);
    }

    function claimableAdminFee() external view readOnlyNonReentrant returns (uint256) {
        uint256 _xcpProfit = xcpProfit;
        uint256 _xcpProfitA = xcpProfitA;

        uint256 vprice = virtualPrice;

        if (_xcpProfit > _xcpProfitA) {
            uint256 fees = ((_xcpProfit - _xcpProfitA) * adminFee * minRemainingPostRebalanceRatio) /
                (_PRECISION_FEE * _PRECISION_FEE);
            if (fees > 0) {
                uint256 frac = (vprice * 10 ** 18) / (vprice - fees) - 10 ** 18;
                uint256 supply = _lpTotalSupply();
                return (supply * frac) / 10 ** 18;
            }
        }
        return 0;
    }

    function claimAdminFee() external nonReentrant {
        _claimAdminFee();
    }

    /* Admin parameters */
    function rampAGamma(uint32 futureA_, uint64 futureGamma_, uint32 futureTime_) external onlyOwner {
        unchecked {
            require(block.timestamp > initialAGammaTime + (_MIN_RAMP_TIME - 1));
            require(futureTime_ > block.timestamp + (_MIN_RAMP_TIME - 1)); // dev: insufficient time

            (uint256 mA, uint256 mGamma) = _AGamma();

            require(futureA_ > _MIN_A - 1);
            require(futureA_ < _MAX_A + 1);
            require(futureGamma_ > _MIN_GAMMA - 1);
            require(futureGamma_ < _MAX_GAMMA + 1);

            uint256 ratio = (10 ** 18 * uint256(futureA_)) / mA;
            require(ratio < 10 ** 18 * _MAX_A_CHANGE + 1);
            require(ratio > 10 ** 18 / _MAX_A_CHANGE - 1);

            ratio = (10 ** 18 * uint256(futureGamma_)) / mGamma;
            require(ratio < 10 ** 18 * _MAX_A_CHANGE + 1);
            require(ratio > 10 ** 18 / _MAX_A_CHANGE - 1);

            initialA = uint32(mA);
            initialGamma = uint64(mGamma);
            initialAGammaTime = uint32(block.timestamp);

            futureA = uint32(futureA_);
            futureGamma = uint64(futureGamma_);
            futureAGammaTime = uint32(futureTime_);

            emit RampAGamma(mA, futureA_, mGamma, futureGamma_, block.timestamp, futureTime_);
        }
    }

    function stopRampAGamma() external onlyOwner {
        (uint256 mA, uint256 mGamma) = _AGamma();
        initialA = uint32(mA);
        initialGamma = uint64(mGamma);
        futureA = uint32(mA);
        futureGamma = uint64(mGamma);
        initialAGammaTime = uint32(block.timestamp);
        futureAGammaTime = uint32(block.timestamp);
        // now (block.timestamp < t1) is always False, so we return saved A

        emit StopRampA(mA, mGamma, block.timestamp);
    }

    function commitNewParameters(
        uint256 _newMidFee,
        uint256 _newOutFee,
        uint256 _newAdminFee,
        uint256 _newFlashLoanFee,
        uint256 _newFeeGamma,
        uint256 _newAllowedExtraProfit,
        uint256 _newRebalancingThreshold,
        uint256 _newAdjustmentStep,
        uint256 _newMaHalfTime
    ) external onlyOwner {
        unchecked {
            require(adminActionsDeadline == 0); // dev: active action

            // Fees
            if (_newOutFee < _MAX_FEE + 1) {
                require(_newOutFee > _MIN_FEE - 1); // dev: fee is out of range
            } else {
                _newOutFee = outFee;
            }
            if (_newMidFee > _MAX_FEE) {
                _newMidFee = midFee;
            }
            require(_newMidFee <= _newOutFee); // dev: mid-fee is too high
            if (_newAdminFee > _MAX_ADMIN_FEE) {
                _newAdminFee = adminFee;
            }
            if (_newFlashLoanFee > _MAX_FEE) {
                _newFlashLoanFee = flashLoanFee;
            }

            // AMM parameters
            if (_newFeeGamma < 10 ** 18) {
                require(_newFeeGamma > 0); // dev: feeGamma out of range [1 .. 10**18]
            } else {
                _newFeeGamma = feeGamma;
            }
            if (_newAllowedExtraProfit > 10 ** 18) {
                _newAllowedExtraProfit = allowedExtraProfit;
            }
            if (_newAdjustmentStep > 10 ** 18) {
                _newAdjustmentStep = adjustmentStep;
            }
            if (_newRebalancingThreshold > _PRECISION_FEE) {
                _newRebalancingThreshold = minRemainingPostRebalanceRatio;
            } else {
                require(_newRebalancingThreshold >= 2 * 10 ** 9);
            }

            // MA
            if (_newMaHalfTime < 7 * 86400) {
                require(_newMaHalfTime > 0); // dev: MA time should be longer than 1 second
            } else {
                _newMaHalfTime = maHalfTime;
            }

            uint256 _deadline = block.timestamp + _ADMIN_ACTIONS_DELAY;
            adminActionsDeadline = _deadline;

            futureAdminFee = _newAdminFee;
            futureMidFee = _newMidFee;
            futureOutFee = _newOutFee;
            futureFlashLoanFee = _newFlashLoanFee;
            futureFeeGamma = _newFeeGamma;
            futureAllowedExtraProfit = _newAllowedExtraProfit;
            futureRebalancingThreshold = _newRebalancingThreshold;
            futureAdjustmentStep = _newAdjustmentStep;
            futureMaHalfTime = _newMaHalfTime;

            emit CommitNewParameters(
                _deadline,
                _newAdminFee,
                _newFlashLoanFee,
                _newMidFee,
                _newOutFee,
                _newFeeGamma,
                _newAllowedExtraProfit,
                _newRebalancingThreshold,
                _newAdjustmentStep,
                _newMaHalfTime
            );
        }
    }

    function applyNewParameters() external nonReentrant onlyOwner {
        require(block.timestamp >= adminActionsDeadline); // dev: insufficient time
        require(adminActionsDeadline != 0); // dev: no active action

        adminActionsDeadline = 0;

        uint256 adminFee_ = futureAdminFee;
        if (adminFee != adminFee_) {
            _claimAdminFee();
            adminFee = adminFee_;
        }

        uint256 flashLoanFee_ = futureFlashLoanFee;
        flashLoanFee = flashLoanFee_;
        uint256 midFee_ = futureMidFee;
        midFee = midFee_;
        uint256 outFee_ = futureOutFee;
        outFee = outFee_;
        uint256 feeGamma_ = futureFeeGamma;
        feeGamma = feeGamma_;
        uint256 allowedExtraProfit_ = futureAllowedExtraProfit;
        allowedExtraProfit = allowedExtraProfit_;
        uint256 minRemainingPostRebalanceRatio_ = futureRebalancingThreshold;
        minRemainingPostRebalanceRatio = minRemainingPostRebalanceRatio_;
        uint256 adjustmentStep_ = futureAdjustmentStep;
        adjustmentStep = adjustmentStep_;
        uint256 maHalfTime_ = futureMaHalfTime;
        maHalfTime = maHalfTime_;

        emit NewParameters(
            adminFee_,
            flashLoanFee_,
            midFee_,
            outFee_,
            feeGamma_,
            allowedExtraProfit_,
            minRemainingPostRebalanceRatio_,
            adjustmentStep_,
            maHalfTime_
        );
    }

    function revertNewParameters() external onlyOwner {
        adminActionsDeadline = 0;
    }

    function withdrawLostToken(address _target, uint256 _amount, address _to) external onlyOwner {
        address[N_COINS] memory coins_ = _coins();
        unchecked {
            for (uint256 i = 0; i < N_COINS; ++i) {
                require(coins_[i] != _target);
            }
        }
        _transfer(_target, _to, _amount);
    }

    function flashLoan(
        IKokonutSwapFlashCallback borrower,
        uint256[] calldata amounts,
        bytes calldata data
    ) external nonReentrant {
        require(amounts.length == N_COINS);

        address[N_COINS] memory coinsList = _coins();
        uint256[N_COINS] memory oldBalance;
        uint256[] memory fees = new uint256[](N_COINS);
        uint256 currentFee = flashLoanFee;
        for (uint256 i = 0; i < N_COINS; ++i) {
            address coin = coinsList[i];
            // rounding up
            fees[i] = (amounts[i] * currentFee + _PRECISION_FEE - 1) / _PRECISION_FEE;
            oldBalance[i] = _thisBalanceOf(coin);
            if (amounts[i] > 0) {
                _transfer(coin, address(borrower), amounts[i]);
            }
        }

        borrower.onFlashLoan(msg.sender, amounts, fees, data);

        for (uint256 i = 0; i < N_COINS; ++i) {
            uint256 newBalance = _thisBalanceOf(coinsList[i]);
            require(newBalance >= oldBalance[i] + fees[i], "flashLoan");
            unchecked {
                fees[i] = newBalance - oldBalance[i];
            }
            balances[i] += fees[i];
        }

        (uint256 mA, uint256 mGamma) = _AGamma();
        _tweakPrice(mA, mGamma, _standardize(balances[0], balances[1]), 0);

        emit FlashLoan(address(borrower), amounts, fees);
    }

    /* View Methods*/
    function getDy(
        uint256 i,
        uint256 j,
        uint256 dx
    ) external view readOnlyNonReentrant returns (uint256 dy, uint256 dyFee) {
        require(i + j == 1);

        (uint256 mA, uint256 mGamma) = _AGamma();
        uint256[N_COINS] memory xp = balances;
        uint256 D0 = (futureAGammaTime > 0) ? _newtonD(mA, mGamma, _standardize(xp[0], xp[1])) : D;

        xp[i] += dx;
        xp = _standardize(xp[0], xp[1]);

        dy = xp[j] - _newtonY(mA, mGamma, xp[i], D0);
        require(dy > 0);
        unchecked {
            xp[j] -= dy;
            dy = _unStandardize(dy - 1, j);
            dyFee = (_feeRate(xp) * dy) / _PRECISION_FEE;
            dy -= dyFee;
        }
    }

    function _getPrice(
        uint256 i,
        uint256 mA,
        uint256 mGamma,
        uint256[N_COINS] memory xp,
        uint256 D_
    ) internal view returns (uint256) {
        uint256 K0 = ((((10 ** 18 * N_COINS ** N_COINS) * xp[0]) / D_) * xp[1]) / D_;
        require(K0 <= 10 ** 18, "K0");
        uint256 _g1k0 = mGamma + 10 ** 18 - K0;

        uint256 K = (((mA * K0 * mGamma) / _g1k0) * mGamma) / _g1k0 / _A_MULTIPLIER / N_COINS ** N_COINS;
        uint256 S = xp[0] + xp[1];
        require(D_ <= S, "D");

        // mul = X / (K*D**(N-1))
        uint256 mul = ((S - D_) * (mGamma + 10 ** 18 + K0)) / _g1k0 + (D_ * K0) / K / N_COINS ** N_COINS;
        uint256 dxi = _PRECISION_PRICE_SCALE + (_PRECISION_PRICE_SCALE * mul) / xp[1 - i];
        uint256 dxj = _PRECISION_PRICE_SCALE + (_PRECISION_PRICE_SCALE * mul) / xp[i];
        if (i == 0) {
            return (((_PRECISION_PRICE_SCALE * dxj) / dxi) * _PRECISION_PRICE_SCALE) / priceScale;
        } else {
            return (((_PRECISION_PRICE_SCALE * dxj) / dxi) * priceScale) / _PRECISION_PRICE_SCALE;
        }
    }

    // the price of i for j
    function getPrice(uint256 i, uint256 j) public view readOnlyNonReentrant returns (uint256) {
        require(i + j == 1);

        uint256[N_COINS] memory xp = _standardize(balances[0], balances[1]);

        (uint256 mA, uint256 mGamma) = _AGamma(); // [A*N**N, gamma]
        uint256 D_ = futureAGammaTime > 0 ? _newtonD(mA, mGamma, xp) : D;

        return _getPrice(i, mA, mGamma, xp, D_);
    }

    function calcDeposit(
        uint256[] calldata amounts
    ) external view readOnlyNonReentrant returns (uint256 lpAmount, uint256 lpFee) {
        require(amounts.length == N_COINS);
        uint256 tokenSupply = _lpTotalSupply();
        (uint256 mA, uint256 mGamma) = _AGamma();

        uint256[N_COINS] memory xp0 = balances;
        uint256[N_COINS] memory xp1 = _arrCopy(xp0);
        xp1[0] = xp0[0] + amounts[0];
        xp1[1] = xp0[1] + amounts[1];

        xp0 = _standardize(xp0[0], xp0[1]);
        xp1 = _standardize(xp1[0], xp1[1]);
        uint256 D0 = (futureAGammaTime > 0) ? _newtonD(mA, mGamma, xp0) : D;
        uint256 D1 = _newtonD(mA, mGamma, xp1);
        lpAmount = (tokenSupply * D1) / D0 - tokenSupply;
        lpFee = (_calcTokenFeeRate(xp0, xp1) * lpAmount) / _PRECISION_FEE + 1;
        lpAmount -= lpFee;
    }

    function calcWithdraw(uint256 _amount) external view readOnlyNonReentrant returns (uint256[] memory amounts) {
        uint256 _totalSupply = _lpTotalSupply();
        uint256[N_COINS] memory balances_ = balances;
        amounts = new uint256[](N_COINS);
        for (uint256 i = 0; i < N_COINS; ++i) {
            amounts[i] = (balances_[i] * _amount) / _totalSupply;
        }
    }

    function calcWithdrawOneCoin(
        uint256 tokenAmount,
        uint256 i
    ) external view readOnlyNonReentrant returns (uint256 dy, uint256 lpFee) {
        (dy, lpFee, , ) = _calcWithdrawOneCoin(tokenAmount, i, _standardize(balances[0], balances[1]));
    }

    /// @return The rate of lpPrice/coin[0] with 1e18 precision
    function lpPrice() external view returns (uint256) {
        /*
        Approximate LP token price
        */
        return (2 * virtualPrice * _sqrtInt(_internalPriceOracle())) / 10 ** 18;
    }

    function A() external view returns (uint256 result) {
        (result, ) = _AGamma();
    }

    function gamma() external view returns (uint256 result) {
        (, result) = _AGamma();
    }

    function fee() external view readOnlyNonReentrant returns (uint256) {
        return _feeRate(_standardize(balances[0], balances[1]));
    }

    function getVirtualPrice() external view readOnlyNonReentrant returns (uint256) {
        return (10 ** 18 * _getXcp(D)) / _lpTotalSupply();
    }

    /// @return The rate of coin[1]/coin[0] with 1e18 precision
    function priceOracle() external view returns (uint256) {
        return _internalPriceOracle();
    }

    function coins(uint256 i) external view returns (address) {
        return _coins(i);
    }

    function _coins() internal view returns (address[N_COINS] memory) {
        return [_coin0, _coin1];
    }

    function _coins(uint256 i) internal view returns (address) {
        if (i == 0) {
            return _coin0;
        } else if (i == 1) {
            return _coin1;
        } else {
            revert();
        }
    }

    function _lpTotalSupply() internal view returns (uint256) {
        return ICryptoPoolToken(token).totalSupply();
    }

    function _thisBalanceOf(address coin) internal view returns (uint256) {
        return IERC20(coin).balanceOf(address(this));
    }

    function _pullToken(address coin, address from, uint256 amount) internal {
        IERC20(coin).safeTransferFrom(from, address(this), amount);
    }

    function _transfer(address coin, address to, uint256 amount) internal {
        IERC20(coin).safeTransfer(to, amount);
    }

    function _geometricMean(uint256[N_COINS] memory unsortedX, bool sort) internal pure returns (uint256) {
        /// (x[0] * x[1] * ...) ** (1/N)
        uint256[N_COINS] memory x = _arrCopy(unsortedX);
        if (sort && x[0] < x[1]) {
            x[0] = unsortedX[1];
            x[1] = unsortedX[0];
        }
        uint256 _D = x[0];
        uint256 diff = 0;
        for (uint256 i = 0; i < 255; ++i) {
            uint256 DPrev = _D;
            // tmp: uint256 = 10**18
            // for _x in x:
            //     tmp = tmp * _x / D
            // D = D * ((N_COINS - 1) * 10**18 + tmp) / (N_COINS * 10**18)
            // line below makes it for 2 coins
            _D = (_D + (x[0] * x[1]) / _D) / N_COINS;
            unchecked {
                if (_D > DPrev) {
                    diff = _D - DPrev;
                } else {
                    diff = DPrev - _D;
                }
            }
            if (diff <= 1 || diff * 10 ** 18 < _D) {
                return _D;
            }
        }
        revert("C");
    }

    function _newtonD(uint256 mA, uint256 mGamma, uint256[N_COINS] memory xUnsorted) internal pure returns (uint256) {
        /*
        Finding the invariant using Newton method.
        ANN is higher by the factor A_MULTIPLIER
        ANN is already A * N**N

        Currently uses 60k gas
        */
        // Safety checks
        unchecked {
            require(mA > _MIN_A - 1 && mA < _MAX_A + 1); // dev: unsafe values A
            require(mGamma > _MIN_GAMMA - 1 && mGamma < _MAX_GAMMA + 1); // dev: unsafe values gamma
        }
        // Initial value of invariant D is that for constant-product invariant
        uint256[N_COINS] memory x = _arrCopy(xUnsorted);
        if (x[0] < x[1]) {
            x[0] = xUnsorted[1];
            x[1] = xUnsorted[0];
        }

        require(x[0] > 10 ** 9 - 1 && x[0] < 10 ** 15 * 10 ** 18 + 1); // dev: unsafe values x[0]
        require((x[1] * 10 ** 18) / x[0] > 10 ** 14 - 1); // dev: unsafe values x[i] (input)

        uint256 _D = N_COINS * _geometricMean(x, false);
        uint256 S = x[0] + x[1];

        for (uint256 i = 0; i < 255; ++i) {
            uint256 DPrev = _D;

            // K0: uint256 = 10**18
            // for _x in x:
            //     K0 = K0 * _x * N_COINS / D
            // collapsed for 2 coins
            uint256 K0 = ((((10 ** 18 * N_COINS ** 2) * x[0]) / _D) * x[1]) / _D;

            uint256 _g1k0 = mGamma + 10 ** 18;
            unchecked {
                if (_g1k0 > K0) {
                    _g1k0 = _g1k0 - K0 + 1;
                } else {
                    _g1k0 = K0 - _g1k0 + 1;
                }
            }

            // D / (A * N**N) * _g1k0**2 / gamma**2
            uint256 mul1 = (((((10 ** 18 * _D) / mGamma) * _g1k0) / mGamma) * _g1k0 * _A_MULTIPLIER) / mA;

            // 2*N*K0 / _g1k0
            uint256 mul2 = ((2 * 10 ** 18) * N_COINS * K0) / _g1k0;

            uint256 negFprime = (S + (S * mul2) / 10 ** 18) + (mul1 * N_COINS) / K0 - (mul2 * _D) / 10 ** 18;

            // D -= f / fprime
            uint256 D_plus = (_D * (negFprime + S)) / negFprime;
            uint256 D_minus = (_D * _D) / negFprime;
            if (10 ** 18 > K0) {
                D_minus += (((_D * (mul1 / negFprime)) / 10 ** 18) * (10 ** 18 - K0)) / K0;
            } else {
                D_minus -= (((_D * (mul1 / negFprime)) / 10 ** 18) * (K0 - 10 ** 18)) / K0;
            }
            unchecked {
                if (D_plus > D_minus) {
                    _D = D_plus - D_minus;
                } else {
                    _D = (D_minus - D_plus) / 2;
                }
            }

            uint256 diff = 0;
            unchecked {
                if (_D > DPrev) {
                    diff = _D - DPrev;
                } else {
                    diff = DPrev - _D;
                }
            }
            if (diff * 10 ** 14 < Math.max(10 ** 16, _D)) {
                // Could reduce precision for gas efficiency here
                // Test that we are safe with the next newton_y
                for (uint256 j = 0; j < x.length; ++j) {
                    uint256 frac = (x[j] * 10 ** 18) / _D;
                    require((frac > 10 ** 16 - 1) && (frac < 10 ** 20 + 1)); // dev: unsafe values x[i]
                }
                return _D;
            }
        }
        revert("C");
    }

    function _newtonY(uint256 mA, uint256 mGamma, uint256 xJ, uint256 _D) internal pure returns (uint256 y) {
        /*
        Calculating x[i] given other balances x[0..N_COINS-1] and invariant D
        ANN = A * N**N
        */
        // Safety checks
        unchecked {
            require(mA > _MIN_A - 1 && mA < _MAX_A + 1); // dev: unsafe values A
            require(mGamma > _MIN_GAMMA - 1 && mGamma < _MAX_GAMMA + 1); // dev: unsafe values gamma
            require(_D > 10 ** 17 - 1 && _D < 10 ** 15 * 10 ** 18 + 1); // dev: unsafe values D
        }

        y = _D ** 2 / (xJ * N_COINS ** 2);
        uint256 K0I = ((10 ** 18 * N_COINS) * xJ) / _D;
        // S_i = xJ

        // frac = xJ * 1e18 / D => frac = K0I / N_COINS
        require((K0I > 10 ** 16 * N_COINS - 1) && (K0I < 10 ** 20 * N_COINS + 1)); // dev: unsafe values x[i]

        // x_sorted: uint256[N_COINS] = x
        // x_sorted[i] = 0
        // x_sorted = self.sort(x_sorted)  // From high to low
        // x[not i] instead of x_sorted since x_sorted has only 1 element

        uint256 convergenceLimit = Math.max(Math.max(xJ / 10 ** 14, _D / 10 ** 14), 100);

        for (uint256 j = 0; j < 255; ++j) {
            uint256 K0 = (K0I * y * N_COINS) / _D;

            uint256 mul1;
            uint256 mul2;
            {
                uint256 _g1k0 = mGamma + 10 ** 18;
                unchecked {
                    if (_g1k0 > K0) {
                        _g1k0 = _g1k0 - K0 + 1;
                    } else {
                        _g1k0 = K0 - _g1k0 + 1;
                    }
                }

                // D / (A * N**N) * _g1k0**2 / gamma**2
                mul1 = (((((10 ** 18 * _D) / mGamma) * _g1k0) / mGamma) * _g1k0 * _A_MULTIPLIER) / mA;

                // 2*K0 / _g1k0
                mul2 = 10 ** 18 + ((2 * 10 ** 18) * K0) / _g1k0;
            }

            uint256 S = xJ + y;
            uint256 yfprime = 10 ** 18 * y + S * mul2 + mul1;
            uint256 yPrev = y;
            {
                uint256 _dyfprime = _D * mul2;
                if (yfprime < _dyfprime) {
                    y = yPrev / 2;
                    continue;
                } else {
                    unchecked {
                        yfprime -= _dyfprime;
                    }
                }
            }
            {
                uint256 fprime = yfprime / y;

                // y -= f / f_prime;  y = (y * fprime - f) / fprime
                // y = (yfprime + 10**18 * D - 10**18 * S) // fprime + mul1 // fprime * (10**18 - K0) // K0
                uint256 yMinus = mul1 / fprime;
                uint256 yPlus = (yfprime + 10 ** 18 * _D) / fprime + (yMinus * 10 ** 18) / K0;
                yMinus += (10 ** 18 * S) / fprime;

                if (yPlus < yMinus) {
                    y = yPrev / 2;
                } else {
                    unchecked {
                        y = yPlus - yMinus;
                    }
                }
            }

            uint256 diff;
            unchecked {
                diff = y > yPrev ? y - yPrev : yPrev - y;
            }
            if (diff < Math.max(convergenceLimit, y / 10 ** 14)) {
                uint256 frac = (y * 10 ** 18) / _D;
                require((frac > 10 ** 16 - 1) && (frac < 10 ** 20 + 1)); // dev: unsafe value for y
                return y;
            }
        }
        revert("C");
    }

    function _burnMsgSender(uint256 amount) internal {
        ICryptoPoolToken(token).burn(msg.sender, amount);
    }

    function _mintMsgSender(uint256 amount) internal {
        ICryptoPoolToken(token).mint(msg.sender, amount);
    }
}
