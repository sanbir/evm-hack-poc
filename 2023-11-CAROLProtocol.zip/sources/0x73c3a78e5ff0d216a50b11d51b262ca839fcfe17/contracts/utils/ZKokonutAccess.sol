// SPDX-License-Identifier: MIT

pragma solidity ^0.8.3;

import "../library/Pausable.sol";
import "../library/Ownable.sol";

abstract contract ZKokonutAccess is Ownable, Pausable {
    function _initializeZKokonutAccess(address owner_) internal {
        _transferOwnership(owner_);
    }

    function pause() public onlyOwner {
        _pause();
    }

    function unpause() public onlyOwner {
        _unpause();
    }
}
