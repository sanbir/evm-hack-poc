// SPDX-License-Identifier: MIT
pragma solidity 0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IUniswapV2Factory} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "@uniswap/v2-periphery/contracts/interfaces/IUniswapV2Router02.sol";

contract Cryptensor is ERC20, Ownable {
    uint public constant minimumTokenToSwap = 10e18;
    uint public constant maximumTokenToSwap = 10000e18;
    uint public constant maxWalletSize = 25000e18;
    uint private buyCount;
    uint private contractLatestBlock;

    bool public isTradingOpen;
    bool public transferLimits = true;
    bool private contractSellLimit = true;
    bool private isSwapping;
    bool private swapEnabled = true;

    address private immutable WETH;
    IUniswapV2Router02 private constant uniswapV2Router =
        IUniswapV2Router02(0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D);
    address private uniswapV2Pair;
    address public taxAddress;

    mapping(address => bool) public isFeeExcluded;
    mapping(address => bool) public isStacker;
    mapping(address => uint256) private lastTransferTimestamp;

    constructor() ERC20("Cryptensor", "CRYPT") Ownable(msg.sender) {
        isFeeExcluded[address(this)] = true;
        isFeeExcluded[msg.sender] = true;

        WETH = uniswapV2Router.WETH();

        uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(
            address(this),
            WETH
        );

        taxAddress = msg.sender;

        _mint(msg.sender, 800_000e18);
    }

    modifier LockSwapping() {
        isSwapping = true;
        _;
        isSwapping = false;
    }

    modifier OnlyStacker() {
        require(isStacker[msg.sender]);
        _;
    }

    function activateTrading() external onlyOwner {
        require(!isTradingOpen);
        isTradingOpen = true;
    }

    function setSwapEnabled(bool _isEnabled) external onlyOwner {
        swapEnabled = _isEnabled;
    }

    function allowUnclog() external onlyOwner {
        require(contractSellLimit);
        contractSellLimit = false;
    }

    function removeLimits() external onlyOwner {
        require(transferLimits);
        transferLimits = false;
    }

    function setStackerContract(
        address _address,
        bool _isStacker
    ) external onlyOwner {
        isStacker[_address] = _isStacker;
    }

    function setFeesExcluded(
        address _address,
        bool _isExcluded
    ) external onlyOwner {
        isFeeExcluded[_address] = _isExcluded;
    }

    function setTaxAddress(address _address) external {
        require(taxAddress == msg.sender);
        taxAddress = _address;
    }

    // allow taxAddress to claim token fees that couldn't be sold
    function claimLostTokens() external {
        require(taxAddress == msg.sender);
        transfer(taxAddress, balanceOf(address(this)));
    }

    function sellContractFees(uint _percentage) external {
        require(taxAddress == msg.sender);
        _swapTokensForEth((balanceOf(address(this)) * _percentage) / 100);
    }

    function mintRewards(address _address, uint _amount) external OnlyStacker {
        _mint(_address, _amount);
    }

    function burnTokens(address _address, uint _amount) external OnlyStacker {
        _update(_address, address(0), _amount);
    }

    function getFees() public view returns (uint) {
        // 19% fees for the first 35 buys
        if (buyCount <= 35) return 19;
        return 5;
    }

    function _swapTokensForEth(uint _amount) private LockSwapping {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = WETH;

        _approve(
            address(this),
            address(uniswapV2Router),
            type(uint).max,
            false
        );
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            _amount,
            0,
            path,
            address(this),
            block.timestamp
        );

        contractLatestBlock = block.number;

        (bool result, ) = payable(taxAddress).call{
            value: address(this).balance
        }("");
        require(result);
    }

    function _update(
        address from,
        address to,
        uint256 amount
    ) internal override {
        if (isSwapping || isFeeExcluded[from] || isFeeExcluded[to]) {
            super._update(from, to, amount);
            return;
        }

        // limits
        require(isTradingOpen);
        if (
            transferLimits &&
            to != address(uniswapV2Router) &&
            to != uniswapV2Pair
        ) {
            require(
                lastTransferTimestamp[tx.origin] < block.number,
                "Limits : One transfer per block."
            );
            lastTransferTimestamp[tx.origin] = block.number;
        }

        // fees
        uint feesCharged = from == uniswapV2Pair || to == uniswapV2Pair
            ? (getFees() * amount) / 100
            : 0;
        if (feesCharged > 0) super._update(from, address(this), feesCharged);

        // increase buy amount
        if (
            from == uniswapV2Pair &&
            to != address(uniswapV2Router) &&
            !isFeeExcluded[to]
        ) {
            if (transferLimits)
                require(
                    balanceOf(to) + amount <= maxWalletSize,
                    "Limits : Exceeds the max wallet size."
                );

            buyCount++;
        }

        // sell contract fees
        if (
            from != uniswapV2Pair &&
            balanceOf(address(this)) >= minimumTokenToSwap &&
            swapEnabled &&
            buyCount >= 25
        ) {
            if (contractSellLimit && contractLatestBlock < block.number)
                _swapTokensForEth(
                    min(balanceOf(address(this)), maximumTokenToSwap)
                );
            else if (!contractSellLimit)
                _swapTokensForEth(balanceOf(address(this)));
        }

        return super._update(from, to, amount - feesCharged);
    }

    function min(uint a, uint b) private pure returns (uint) {
        return (a > b) ? b : a;
    }

    receive() external payable {}
}
