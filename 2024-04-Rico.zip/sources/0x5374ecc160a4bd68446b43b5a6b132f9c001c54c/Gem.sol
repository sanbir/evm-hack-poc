/// SPDX-License-Identifier: AGPL-3.0-only

// Copyright (C) 2021 kevin and his friends
// Copyright (C) 2017, 2018, 2019 dbrock, rain, mrchico

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as published by
// the Free Software Foundation, version 3.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

pragma solidity ^0.8.19;

contract Gem {
    bytes32 public name;
    bytes32 public symbol;
    uint256 public totalSupply;
    uint8   public constant decimals = 18;

    mapping (address => uint)                      public balanceOf;
    mapping (address => mapping (address => uint)) public allowance;
    mapping (address => uint)                      public nonces;
    mapping (address => bool)                      public wards;

    bytes32 constant DOMAIN_SUBHASH = keccak256(
        'EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)'
    );
    bytes32 constant PERMIT_TYPEHASH = keccak256(
        'Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)'
    );
    function DOMAIN_SEPARATOR() external view returns (bytes32) {
        return keccak256(abi.encode( DOMAIN_SUBHASH,
            keccak256("GemPermit"), keccak256("0"),
            block.chainid, address(this))
        );
    }

    event Approval(address indexed src, address indexed usr, uint256 wad);
    event Transfer(address indexed src, address indexed dst, uint256 wad);
    event Ward(address indexed setter, address indexed user, bool authed);

    error ErrPermitDeadline();
    error ErrPermitSignature();
    error ErrOverflow();
    error ErrUnderflow();
    error ErrZeroDst();
    error ErrWard();

    constructor(bytes32 name_, bytes32 symbol_)
      payable
    {
        name = name_;
        symbol = symbol_;

        wards[msg.sender] = true;
        emit Ward(msg.sender, msg.sender, true);
    }

    function ward(address usr, bool authed)
      payable external
    {
        if (!wards[msg.sender]) revert ErrWard();
        wards[usr] = authed;
        emit Ward(msg.sender, usr, authed);
    }

    function mint(address usr, uint wad)
      payable external
    {
        if (!wards[msg.sender]) revert ErrWard();
        unchecked {
            // only need to check totalSupply for overflow
            uint256 prev = totalSupply;
            if (prev + wad < prev) revert ErrOverflow();

            balanceOf[usr] += wad;
            totalSupply     = prev + wad;
            emit Transfer(address(0), usr, wad);

            if (usr == address(0)) revert ErrZeroDst();
        }
    }

    function burn(address usr, uint wad)
      payable external
    {
        if (!wards[msg.sender]) revert ErrWard();
        unchecked {
            // only need to check balanceOf[usr] for underflow
            uint256 prev = balanceOf[usr];
            balanceOf[usr] = prev - wad;
            totalSupply    -= wad;
            emit Transfer(usr, address(0), wad);

            if (prev < wad) revert ErrUnderflow();
        }
    }

    function transfer(address dst, uint wad)
      payable external returns (bool ok)
    {
        unchecked {
            ok = true;
            uint256 prev = balanceOf[msg.sender];
            balanceOf[msg.sender] = prev - wad;
            balanceOf[dst]       += wad;
            emit Transfer(msg.sender, dst, wad);

            if (prev < wad) revert ErrUnderflow();
            if (dst == address(0)) revert ErrZeroDst();
        }
    }

    function transferFrom(address src, address dst, uint wad)
      payable external returns (bool ok)
    {
        unchecked {
            ok              = true;
            uint256 prevB   = balanceOf[src];
            balanceOf[src]  = prevB - wad;
            balanceOf[dst] += wad;
            uint256 prevA   = allowance[src][msg.sender];

            if (prevA != type(uint256).max) {
                allowance[src][msg.sender] = prevA - wad;
                emit Approval(src, msg.sender, prevA - wad);

                if (prevA < wad) revert ErrUnderflow();
            }
            emit Transfer(src, dst, wad);

            if (prevB < wad) revert ErrUnderflow();
            if (dst == address(0)) revert ErrZeroDst();
        }
    }

    function approve(address usr, uint wad)
      payable external returns (bool ok)
    {
        ok = true;
        allowance[msg.sender][usr] = wad;
        emit Approval(msg.sender, usr, wad);
    }

    // EIP-2612
    function permit(address owner, address spender, uint256 value, uint256 deadline,
                    uint8 v, bytes32 r, bytes32 s)
      payable external
    {
        allowance[owner][spender] = value;
        emit Approval(owner, spender, value);

        address signer;
        unchecked {
            signer = ecrecover(
                keccak256(abi.encodePacked( "\x19\x01",
                    keccak256(abi.encode( DOMAIN_SUBHASH,
                        keccak256("GemPermit"), keccak256("0"),
                        block.chainid, address(this))),
                    keccak256(abi.encode( PERMIT_TYPEHASH, owner, spender,
                        value, nonces[owner]++, deadline )))),
                v, r, s
            );
        }

        if (signer == address(0)) revert ErrPermitSignature();
        if (owner != signer) revert ErrPermitSignature();
        if (block.timestamp > deadline) revert ErrPermitDeadline();
    }
}

contract GemFab {
    mapping(address=>bool) public built;

    event Build(address indexed caller, address indexed gem);

    function build(bytes32 name, bytes32 symbol)
      payable external returns (Gem gem)
    {
        gem = new Gem(name, symbol);
        built[address(gem)] = true;
        emit Build(msg.sender, address(gem));
        gem.ward(msg.sender, true);
        gem.ward(address(this), false);
        return gem;
    }
}