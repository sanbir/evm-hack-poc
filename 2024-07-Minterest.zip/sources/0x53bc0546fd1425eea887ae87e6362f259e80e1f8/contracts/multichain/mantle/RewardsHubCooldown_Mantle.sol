// SPDX-License-Identifier: BSD-3-Clause
pragma solidity 0.8.17;

import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC20/utils/SafeERC20Upgradeable.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";
import "@openzeppelin/contracts/utils/math/SafeCast.sol";

import "../../libraries/ErrorCodes.sol";
import "./interfaces/IRewardsHubCooldown_Mantle.sol";
import "./RewardsHubLight_Mantle.sol";

contract RewardsHubCooldown_Mantle is IRewardsHubCooldown_Mantle, RewardsHubLight_Mantle {
    using SafeCast for uint256;
    using SafeERC20Upgradeable for IMntMirror;

    // // // // // // Cooldown logic

    /// @dev Charge length
    uint256 public constant CHARGE_LENGTH = 30 days;
    /// @dev The number of charges that can be made by user. Length of cooldown period.
    uint256 public numberOfCharges;
    /// @dev The share of total available amount that can be charged during one period.
    uint256 public chargeShare;
    /// @dev The time when cooldown period starts.
    uint32 public cooldownStartTimestamp;

    /// @dev Contatins counters of charges made by user.
    mapping(address => uint256) public charges;

    // // // // // // Overrides

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function withdraw(uint256 amount)
        external
        virtual
        override(IRewardsHubCooldown_Mantle, IRewardsHubLight, RewardsHubLight)
        checkPaused(WITHDRAW_OP)
    {
        if (isCooldownActive()) {
            cooldownWithdraw(msg.sender);
        } else {
            uint256 balance = balances[msg.sender];
            if (amount == type(uint256).max) amount = balance;

            require(amount <= balance, ErrorCodes.INCORRECT_AMOUNT);
            balances[msg.sender] = balance - amount;

            emit Withdraw(msg.sender, amount);

            mnt.safeTransfer(msg.sender, amount);

            if (amount > 0) {
                buyback().updateBuybackAndVotingWeights(msg.sender);
            }
        }
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function availableBalanceOfCooldown(address account) external view virtual returns (uint256) {
        if (!isCooldownActive()) return 0;

        uint256 availableCharges = getAvailableCharges(account);
        return calculateAvailableBalanceOfCooldown(availableCharges, balances[account]);
    }

    // // // // Admin functions

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function setNumberOfCharges(uint256 newNumberOfCharges) external onlyRole(TIMELOCK) {
        require(newNumberOfCharges > numberOfCharges, ErrorCodes.RH_INCORRECT_NUMBER_OF_CHARGES);
        numberOfCharges = newNumberOfCharges;
        emit NumberOfChargesUpdated(newNumberOfCharges);
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function setChargeShare(uint256 newChargeShare) external onlyRole(TIMELOCK) {
        require(newChargeShare > 0 && newChargeShare <= 1e18, ErrorCodes.RH_INCORRECT_CHARGE_SHARE);
        chargeShare = newChargeShare;
        emit ChargeShareUpdated(newChargeShare);
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function setCooldownStartTimestamp(uint32 startTimestamp) external onlyRole(TIMELOCK) {
        require(cooldownStartTimestamp == 0, ErrorCodes.RH_COOLDOWN_START_ALREADY_SET);
        require(startTimestamp >= getTimestamp(), ErrorCodes.RH_INCORRECT_COOLDOWN_START);
        cooldownStartTimestamp = startTimestamp;
        emit CooldownStartTimestampSet(startTimestamp);
    }

    // // // // Cooldown logic

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function getCooldownEndTimestamp() public view virtual returns (uint32) {
        return cooldownStartTimestamp + (CHARGE_LENGTH * numberOfCharges).toUint32();
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function isCooldownFinished() public view virtual returns (bool) {
        return isCooldownConfigured() && getTimestamp() >= getCooldownEndTimestamp();
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function isCooldownConfigured() public view virtual returns (bool) {
        return numberOfCharges > 0 && chargeShare > 0 && cooldownStartTimestamp > 0;
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function isCooldownActive() public view virtual returns (bool) {
        return cooldownStartTimestamp <= getTimestamp() && getTimestamp() < getCooldownEndTimestamp();
    }

    /// @inheritdoc IRewardsHubCooldown_Mantle
    function getAvailableCharges(address account) public view virtual returns (uint256) {
        if (!isCooldownActive()) return 0;

        uint256 timeDelta = getTimestamp() - cooldownStartTimestamp;
        uint256 chargesUnlocked = timeDelta / CHARGE_LENGTH;
        return chargesUnlocked - charges[account];
    }

    function calculateAvailableBalanceOfCooldown(uint256 availableCharges, uint256 balance)
        internal
        view
        virtual
        returns (uint256)
    {
        if (availableCharges == 0) return 0;

        uint256 share = chargeShare;

        uint256 amount = 0;
        for (uint256 i = 0; i < availableCharges; i++) {
            uint256 chargeAmount = (balance * share) / EXP_SCALE;
            balance -= chargeAmount;
            amount += chargeAmount;
        }
        return amount;
    }

    function cooldownWithdraw(address account) internal virtual {
        uint256 balance = balances[account];

        uint256 availableCharges = getAvailableCharges(account);
        uint256 amount = calculateAvailableBalanceOfCooldown(availableCharges, balance);

        balances[account] -= amount;
        charges[account] += availableCharges;

        emit Withdraw(account, amount);

        mnt.safeTransfer(account, amount);

        if (amount > 0) {
            buyback().updateBuybackAndVotingWeights(account);
        }
    }

    function getTimestamp() internal view virtual returns (uint32) {
        return block.timestamp.toUint32();
    }
}
