// SPDX-License-Identifier: BSD-3-Clause
pragma solidity 0.8.17;

import "../../RewardsHubLight.sol";
import "./libraries/L1BlockProviderProxy.sol";
import "./interfaces/IRewardsHubLight_Mantle.sol";
import "./interfaces/iBVM_L1BlockNumber.sol";

contract RewardsHubLight_Mantle is IRewardsHubLight_Mantle, RewardsHubLight {
    using SafeCast for uint256;

    IIncentiveEmissionHub public incentiveEmissionHub;

    struct EmissionsDistributionVarsExtended {
        EmissionsDistributionVars basicEmission;
        IncentiveEmissionVars incentiveEmission;
    }

    struct IncentiveEmissionVars {
        uint256 mantleRewardTokenAmount;
    }

    /// @dev Returns block number from L1 network.
    ///      Note! Block number from L1 returns with the delay
    function getBlockNumber() internal view virtual override returns (uint32 bn) {
        return iBVM_L1BlockNumber(address(L1BlockProviderProxy.iBVM_L1BlockNumber)).getL1BlockNumber().toUint32();
    }

    /// @dev Basically EmissionsDistributionVarsExtended constructor
    function initDistributionExtended(address account)
        internal
        view
        virtual
        checkPaused(DISTRIBUTION_OP)
        returns (EmissionsDistributionVarsExtended memory vars)
    {
        vars.basicEmission = initDistribution(account);
    }

    /// @inheritdoc IRewardsHubLight
    function distributeSupplierMnt(IMToken mToken, address account)
        external
        virtual
        override(IRewardsHubLight, RewardsHubLight)
    {
        updateMntSupplyIndex(mToken);

        EmissionsDistributionVarsExtended memory vars = initDistributionExtended(account);

        uint256 supplyAmount = mToken.balanceOf(account);
        updateDistributionState(
            vars,
            mToken,
            supplyAmount,
            mntSupplyState[mToken].index,
            mntSupplierState[mToken][account],
            true
        );
        payoutDistributionState(vars.basicEmission, vars.incentiveEmission);
    }

    /// @inheritdoc IRewardsHubLight
    function distributeBorrowerMnt(IMToken mToken, address account)
        external
        virtual
        override(IRewardsHubLight, RewardsHubLight)
    {
        uint224 borrowIndex = mToken.borrowIndex().toUint224();
        updateMntBorrowIndex(mToken, borrowIndex);

        EmissionsDistributionVarsExtended memory vars = initDistributionExtended(account);

        uint256 borrowAmount = (mToken.borrowBalanceStored(account) * EXP_SCALE) / borrowIndex;
        updateDistributionState(
            vars,
            mToken,
            borrowAmount,
            mntBorrowState[mToken].index,
            mntBorrowerState[mToken][account],
            false
        );
        payoutDistributionState(vars.basicEmission, vars.incentiveEmission);
    }

    function distributeAccountMnt(
        address account,
        IMToken[] memory mTokens,
        bool borrowers,
        bool suppliers
    ) internal virtual override {
        EmissionsDistributionVarsExtended memory vars = initDistributionExtended(account);

        for (uint256 i = 0; i < mTokens.length; i++) {
            IMToken mToken = mTokens[i];
            if (borrowers) {
                uint256 accountBorrowUnderlying = mToken.borrowBalanceStored(account);
                if (accountBorrowUnderlying > 0) {
                    uint224 borrowIndex = mToken.borrowIndex().toUint224();
                    updateMntBorrowIndex(mToken, borrowIndex);
                    updateDistributionState(
                        vars,
                        mToken,
                        (accountBorrowUnderlying * EXP_SCALE) / borrowIndex,
                        mntBorrowState[mToken].index,
                        mntBorrowerState[mToken][account],
                        false
                    );
                }
            }
            if (suppliers) {
                uint256 accountSupplyWrap = mToken.balanceOf(account);
                if (accountSupplyWrap > 0) {
                    updateMntSupplyIndex(mToken);
                    updateDistributionState(
                        vars,
                        mToken,
                        accountSupplyWrap,
                        mntSupplyState[mToken].index,
                        mntSupplierState[mToken][account],
                        true
                    );
                }
            }
        }

        payoutDistributionState(vars.basicEmission, vars.incentiveEmission);
    }

    /// @dev This function is intentionally hard disabled to prevent the execution of an unexpected or outdated version.
    function updateDistributionState(
        EmissionsDistributionVars memory,
        IMToken,
        uint256,
        uint224,
        IndexState storage,
        bool
    ) internal pure virtual override {
        require(false, "UNEXPECTED VERSION OF FUNCTION USED");
    }

    function updateDistributionState(
        EmissionsDistributionVarsExtended memory vars,
        IMToken mToken,
        uint256 accountBalance,
        uint224 currentMntIndex,
        IndexState storage accountIndex,
        bool isSupply
    ) internal virtual {
        uint32 currentBlock = getBlockNumber();
        uint224 lastAccountIndex = accountIndex.index;
        uint32 lastUpdateBlock = accountIndex.block;

        if (lastAccountIndex == 0 && currentMntIndex >= MNT_INITIAL_INDEX) {
            // Covers the case where users interacted with market before its state index was set.
            // Rewards the user with MNT accrued from the start of when account rewards were first
            // set for the market.
            lastAccountIndex = MNT_INITIAL_INDEX;
            lastUpdateBlock = currentBlock;
        }

        // Update supplier's index and block to the current index and block since we are distributing accrued MNT
        accountIndex.index = currentMntIndex;
        accountIndex.block = currentBlock;

        if (currentMntIndex == lastAccountIndex) return;

        uint256 deltaIndex = currentMntIndex - lastAccountIndex;

        if (vars.basicEmission.representative != address(0)) {
            // Calc change in the cumulative sum of the MNT per mToken accrued (with considering BD system boosts)
            deltaIndex += (deltaIndex * vars.basicEmission.liquidityProviderBoost) / EXP_SCALE;
        } else {
            // Calc change in the cumulative sum of the MNT per mToken accrued (with considering NFT emission boost).
            // NFT emission boost doesn't work with liquidity provider emission boost at the same time.
            deltaIndex += emissionBooster.calculateEmissionBoost(
                mToken,
                vars.basicEmission.account,
                lastAccountIndex,
                lastUpdateBlock,
                currentMntIndex,
                isSupply
            );
        }

        uint256 accruedMnt = (accountBalance * deltaIndex) / DOUBLE_SCALE;
        vars.basicEmission.accruedMnt += accruedMnt;

        accrueAdditionalRewards(mToken, accruedMnt, isSupply, vars.incentiveEmission);

        if (isSupply) emit DistributedSupplierMnt(mToken, vars.basicEmission.account, accruedMnt, currentMntIndex);
        else emit DistributedBorrowerMnt(mToken, vars.basicEmission.account, accruedMnt, currentMntIndex);
    }

    /// @dev This function is intentionally hard disabled to prevent the execution of an unexpected or outdated version.
    function payoutDistributionState(EmissionsDistributionVars memory) internal pure virtual override {
        require(false, "UNEXPECTED VERSION OF FUNCTION USED");
    }

    function payoutDistributionState(
        EmissionsDistributionVars memory vars,
        IncentiveEmissionVars memory incentivizeVars
    ) internal virtual {
        if (vars.accruedMnt == 0) return;

        balances[vars.account] += vars.accruedMnt;
        emit EmissionRewardAccrued(vars.account, vars.accruedMnt);

        if (vars.representative != address(0)) {
            uint256 repReward = (vars.accruedMnt * vars.representativeBonus) / EXP_SCALE;
            balances[vars.representative] += repReward;
            emit RepresentativeRewardAccrued(vars.representative, vars.account, repReward);
        }

        assignAdditionalRewards(vars.account, incentivizeVars.mantleRewardTokenAmount);

        // Use relaxed update so it could skip if buyback update is paused
        buyback().updateBuybackAndVotingWeightsRelaxed(vars.account);
    }

    /// @dev Accrue incentive rewards with regards to amount of base reward tokens
    function accrueAdditionalRewards(
        IMToken market,
        uint256 baseRewardTokensAccrued,
        bool isSupply,
        IncentiveEmissionVars memory incentivizeVars
    ) internal view virtual {
        if (address(incentiveEmissionHub) != address(0) && baseRewardTokensAccrued > 0) {
            incentivizeVars.mantleRewardTokenAmount += incentiveEmissionHub.calculateIncentiveRewards(
                market,
                baseRewardTokensAccrued,
                isSupply
            );
        }
    }

    /// @dev Accumulate accrued incentive rewards to user balance
    function assignAdditionalRewards(address account, uint256 rewardsAmount) internal virtual {
        if (address(incentiveEmissionHub) != address(0) && rewardsAmount > 0) {
            incentiveEmissionHub.assignRewards(account, rewardsAmount);
        }
    }

    /// @inheritdoc IRewardsHubLight_Mantle
    function setIncentiveEmissionHub(IIncentiveEmissionHub newIncentiveEmissionHub)
        external
        virtual
        onlyRole(DEFAULT_ADMIN_ROLE)
    {
        incentiveEmissionHub = newIncentiveEmissionHub;
        emit IncentiveEmissionHubUpdated(newIncentiveEmissionHub);
    }
}
