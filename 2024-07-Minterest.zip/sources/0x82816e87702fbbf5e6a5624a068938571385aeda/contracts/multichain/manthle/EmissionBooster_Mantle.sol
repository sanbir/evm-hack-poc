// SPDX-License-Identifier: BSD-3-Clause
pragma solidity 0.8.17;

import "../../EmissionBooster.sol";
import "./libraries/L1BlockProviderProxy.sol";
import "./interfaces/iBVM_L1BlockNumber.sol";

contract EmissionBooster_Mantle is EmissionBooster {
    /// @dev Returns block number from L1 network.
    ///      Note! Block number from L1 returns with the delay
    function _getBlockNumber() internal view virtual override returns (uint256) {
        return iBVM_L1BlockNumber(L1BlockProviderProxy.iBVM_L1BlockNumber).getL1BlockNumber();
    }

    /// @inheritdoc IEmissionBooster
    function onMintToken(
        address to_,
        uint256[] memory ids_,
        uint256[] memory amounts_,
        uint256[] memory tiers_
    ) external override {
        require(msg.sender == minterestNFT, ErrorCodes.UNAUTHORIZED);

        uint256 transferredTiers = 0;
        for (uint256 i = 0; i < ids_.length; i++) {
            uint256 tier = tiers_[i];
            if (tier == 0) continue; // Process only positive tiers

            require(tierExists(tier), ErrorCodes.EB_TIER_DOES_NOT_EXIST);

            tokenTier[ids_[i]] = tier;
            accountToTierAmounts[to_][tier] += amounts_[i];
            transferredTiers |= _tierMask(tier);
        }

        // Update only if receiver has got new tiers
        uint256 tiersDiff = accountToTiers[to_] ^ transferredTiers;
        if (tiersDiff > 0) {
            // slither-disable-next-line reentrancy-no-eth
            rewardsHub().distributeAllMnt(to_);
            accountToTiers[to_] |= transferredTiers;
        }
    }
}
