// SPDX-License-Identifier: BSD-3-Clause
pragma solidity 0.8.17;

import "../../MToken.sol";
import "./libraries/L1BlockProviderProxy.sol";
import "./interfaces/iBVM_L1BlockNumber.sol";

/**
 * @title Minterest MToken Contract
 * @notice Abstract base for MTokens
 * @author Minterest
 */
contract MToken_Mantle is MToken {
    /// @dev Returns block number from L1 network.
    ///      Note! Block number from L1 returns with the delay
    function getBlockNumber() internal view virtual override returns (uint256) {
        return iBVM_L1BlockNumber(L1BlockProviderProxy.iBVM_L1BlockNumber).getL1BlockNumber();
    }
}
