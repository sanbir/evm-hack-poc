// File: @openzeppelin/contracts-upgradeable@4.9.3/utils/StorageSlotUpgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (utils/StorageSlot.sol)
// This file was procedurally generated from scripts/generate/templates/StorageSlot.js.

pragma solidity ^0.8.0;

// import "hardhat/console.sol";
/**
 * @dev Library for reading and writing primitive types to specific storage slots.
 *
 * Storage slots are often used to avoid storage conflict when dealing with upgradeable contracts.
 * This library helps with reading and writing to such slots without the need for inline assembly.
 *
 * The functions in this library return Slot structs that contain a `value` member that can be used to read or write.
 *
 * Example usage to set ERC1967 implementation slot:
 * ```solidity
 * contract ERC1967 {
 *     bytes32 internal constant _IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
 *
 *     function _getImplementation() internal view returns (address) {
 *         return StorageSlot.getAddressSlot(_IMPLEMENTATION_SLOT).value;
 *     }
 *
 *     function _setImplementation(address newImplementation) internal {
 *         require(Address.isContract(newImplementation), "ERC1967: new implementation is not a contract");
 *         StorageSlot.getAddressSlot(_IMPLEMENTATION_SLOT).value = newImplementation;
 *     }
 * }
 * ```
 *
 * _Available since v4.1 for `address`, `bool`, `bytes32`, `uint256`._
 * _Available since v4.9 for `string`, `bytes`._
 */
library StorageSlotUpgradeable {
    struct AddressSlot {
        address value;
    }

    struct BooleanSlot {
        bool value;
    }

    struct Bytes32Slot {
        bytes32 value;
    }

    struct Uint256Slot {
        uint256 value;
    }

    struct StringSlot {
        string value;
    }

    struct BytesSlot {
        bytes value;
    }

    /**
     * @dev Returns an `AddressSlot` with member `value` located at `slot`.
     */
    function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `BooleanSlot` with member `value` located at `slot`.
     */
    function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `Bytes32Slot` with member `value` located at `slot`.
     */
    function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `Uint256Slot` with member `value` located at `slot`.
     */
    function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `StringSlot` with member `value` located at `slot`.
     */
    function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `StringSlot` representation of the string storage pointer `store`.
     */
    function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := store.slot
        }
    }

    /**
     * @dev Returns an `BytesSlot` with member `value` located at `slot`.
     */
    function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := slot
        }
    }

    /**
     * @dev Returns an `BytesSlot` representation of the bytes storage pointer `store`.
     */
    function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
        /// @solidity memory-safe-assembly
        assembly {
            r.slot := store.slot
        }
    }
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/interfaces/IERC1967Upgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (interfaces/IERC1967.sol)

pragma solidity ^0.8.0;

/**
 * @dev ERC-1967: Proxy Storage Slots. This interface contains the events defined in the ERC.
 *
 * _Available since v4.8.3._
 */
interface IERC1967Upgradeable {
    /**
     * @dev Emitted when the implementation is upgraded.
     */
    event Upgraded(address indexed implementation);

    /**
     * @dev Emitted when the admin account has changed.
     */
    event AdminChanged(address previousAdmin, address newAdmin);

    /**
     * @dev Emitted when the beacon is changed.
     */
    event BeaconUpgraded(address indexed beacon);
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/proxy/beacon/IBeaconUpgradeable.sol


// OpenZeppelin Contracts v4.4.1 (proxy/beacon/IBeacon.sol)

pragma solidity ^0.8.0;

/**
 * @dev This is the interface that {BeaconProxy} expects of its beacon.
 */
interface IBeaconUpgradeable {
    /**
     * @dev Must return an address that can be used as a delegate call target.
     *
     * {BeaconProxy} will check that this address is a contract.
     */
    function implementation() external view returns (address);
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/interfaces/draft-IERC1822Upgradeable.sol


// OpenZeppelin Contracts (last updated v4.5.0) (interfaces/draft-IERC1822.sol)

pragma solidity ^0.8.0;

/**
 * @dev ERC1822: Universal Upgradeable Proxy Standard (UUPS) documents a method for upgradeability through a simplified
 * proxy whose upgrades are fully controlled by the current implementation.
 */
interface IERC1822ProxiableUpgradeable {
    /**
     * @dev Returns the storage slot that the proxiable contract assumes is being used to store the implementation
     * address.
     *
     * IMPORTANT: A proxy pointing at a proxiable contract should not be considered proxiable itself, because this risks
     * bricking a proxy that upgrades to it, by delegating to itself until out of gas. Thus it is critical that this
     * function revert if invoked through a proxy.
     */
    function proxiableUUID() external view returns (bytes32);
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/utils/AddressUpgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (utils/Address.sol)

pragma solidity ^0.8.1;

/**
 * @dev Collection of functions related to the address type
 */
library AddressUpgradeable {
    /**
     * @dev Returns true if `account` is a contract.
     *
     * [IMPORTANT]
     * ====
     * It is unsafe to assume that an address for which this function returns
     * false is an externally-owned account (EOA) and not a contract.
     *
     * Among others, `isContract` will return false for the following
     * types of addresses:
     *
     *  - an externally-owned account
     *  - a contract in construction
     *  - an address where a contract will be created
     *  - an address where a contract lived, but was destroyed
     *
     * Furthermore, `isContract` will also return true if the target contract within
     * the same transaction is already scheduled for destruction by `SELFDESTRUCT`,
     * which only has an effect at the end of a transaction.
     * ====
     *
     * [IMPORTANT]
     * ====
     * You shouldn't rely on `isContract` to protect against flash loan attacks!
     *
     * Preventing calls from contracts is highly discouraged. It breaks composability, breaks support for smart wallets
     * like Gnosis Safe, and does not provide security since it can be circumvented by calling from a contract
     * constructor.
     * ====
     */
    function isContract(address account) internal view returns (bool) {
        // This method relies on extcodesize/address.code.length, which returns 0
        // for contracts in construction, since the code is only stored at the end
        // of the constructor execution.

        return account.code.length > 0;
    }

    /**
     * @dev Replacement for Solidity's `transfer`: sends `amount` wei to
     * `recipient`, forwarding all available gas and reverting on errors.
     *
     * https://eips.ethereum.org/EIPS/eip-1884[EIP1884] increases the gas cost
     * of certain opcodes, possibly making contracts go over the 2300 gas limit
     * imposed by `transfer`, making them unable to receive funds via
     * `transfer`. {sendValue} removes this limitation.
     *
     * https://consensys.net/diligence/blog/2019/09/stop-using-soliditys-transfer-now/[Learn more].
     *
     * IMPORTANT: because control is transferred to `recipient`, care must be
     * taken to not create reentrancy vulnerabilities. Consider using
     * {ReentrancyGuard} or the
     * https://solidity.readthedocs.io/en/v0.8.0/security-considerations.html#use-the-checks-effects-interactions-pattern[checks-effects-interactions pattern].
     */
    function sendValue(address payable recipient, uint256 amount) internal {
        require(address(this).balance >= amount, "Address: insufficient balance");

        (bool success, ) = recipient.call{value: amount}("");
        require(success, "Address: unable to send value, recipient may have reverted");
    }

    /**
     * @dev Performs a Solidity function call using a low level `call`. A
     * plain `call` is an unsafe replacement for a function call: use this
     * function instead.
     *
     * If `target` reverts with a revert reason, it is bubbled up by this
     * function (like regular Solidity function calls).
     *
     * Returns the raw returned data. To convert to the expected return value,
     * use https://solidity.readthedocs.io/en/latest/units-and-global-variables.html?highlight=abi.decode#abi-encoding-and-decoding-functions[`abi.decode`].
     *
     * Requirements:
     *
     * - `target` must be a contract.
     * - calling `target` with `data` must not revert.
     *
     * _Available since v3.1._
     */
    function functionCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, "Address: low-level call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with
     * `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but also transferring `value` wei to `target`.
     *
     * Requirements:
     *
     * - the calling contract must have an ETH balance of at least `value`.
     * - the called Solidity function must be `payable`.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(address target, bytes memory data, uint256 value) internal returns (bytes memory) {
        return functionCallWithValue(target, data, value, "Address: low-level call with value failed");
    }

    /**
     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but
     * with `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value,
        string memory errorMessage
    ) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        (bool success, bytes memory returndata) = target.call{value: value}(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(address target, bytes memory data) internal view returns (bytes memory) {
        return functionStaticCall(target, data, "Address: low-level static call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a static call.
     *
     * _Available since v3.3._
     */
    function functionStaticCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        (bool success, bytes memory returndata) = target.staticcall(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
        return functionDelegateCall(target, data, "Address: low-level delegate call failed");
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-string-}[`functionCall`],
     * but performing a delegate call.
     *
     * _Available since v3.4._
     */
    function functionDelegateCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        (bool success, bytes memory returndata) = target.delegatecall(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Tool to verify that a low level call to smart-contract was successful, and revert (either by bubbling
     * the revert reason or using the provided one) in case of unsuccessful call or if target was not a contract.
     *
     * _Available since v4.8._
     */
    function verifyCallResultFromTarget(
        address target,
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        if (success) {
            if (returndata.length == 0) {
                // only check isContract if the call was successful and the return data is empty
                // otherwise we already know that it was a contract
                require(isContract(target), "Address: call to non-contract");
            }
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    /**
     * @dev Tool to verify that a low level call was successful, and revert if it wasn't, either by bubbling the
     * revert reason or using the provided one.
     *
     * _Available since v4.3._
     */
    function verifyCallResult(
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal pure returns (bytes memory) {
        if (success) {
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    function _revert(bytes memory returndata, string memory errorMessage) private pure {
        // Look for revert reason and bubble it up if present
        if (returndata.length > 0) {
            // The easiest way to bubble the revert reason is using memory via assembly
            /// @solidity memory-safe-assembly
            assembly {
                let returndata_size := mload(returndata)
                revert(add(32, returndata), returndata_size)
            }
        } else {
            revert(errorMessage);
        }
    }
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/proxy/utils/Initializable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (proxy/utils/Initializable.sol)

pragma solidity ^0.8.2;


/**
 * @dev This is a base contract to aid in writing upgradeable contracts, or any kind of contract that will be deployed
 * behind a proxy. Since proxied contracts do not make use of a constructor, it's common to move constructor logic to an
 * external initializer function, usually called `initialize`. It then becomes necessary to protect this initializer
 * function so it can only be called once. The {initializer} modifier provided by this contract will have this effect.
 *
 * The initialization functions use a version number. Once a version number is used, it is consumed and cannot be
 * reused. This mechanism prevents re-execution of each "step" but allows the creation of new initialization steps in
 * case an upgrade adds a module that needs to be initialized.
 *
 * For example:
 *
 * [.hljs-theme-light.nopadding]
 * ```solidity
 * contract MyToken is ERC20Upgradeable {
 *     function initialize() initializer public {
 *         __ERC20_init("MyToken", "MTK");
 *     }
 * }
 *
 * contract MyTokenV2 is MyToken, ERC20PermitUpgradeable {
 *     function initializeV2() reinitializer(2) public {
 *         __ERC20Permit_init("MyToken");
 *     }
 * }
 * ```
 *
 * TIP: To avoid leaving the proxy in an uninitialized state, the initializer function should be called as early as
 * possible by providing the encoded function call as the `_data` argument to {ERC1967Proxy-constructor}.
 *
 * CAUTION: When used with inheritance, manual care must be taken to not invoke a parent initializer twice, or to ensure
 * that all initializers are idempotent. This is not verified automatically as constructors are by Solidity.
 *
 * [CAUTION]
 * ====
 * Avoid leaving a contract uninitialized.
 *
 * An uninitialized contract can be taken over by an attacker. This applies to both a proxy and its implementation
 * contract, which may impact the proxy. To prevent the implementation contract from being used, you should invoke
 * the {_disableInitializers} function in the constructor to automatically lock it when it is deployed:
 *
 * [.hljs-theme-light.nopadding]
 * ```
 * /// @custom:oz-upgrades-unsafe-allow constructor
 * constructor() {
 *     _disableInitializers();
 * }
 * ```
 * ====
 */
abstract contract Initializable {
    /**
     * @dev Indicates that the contract has been initialized.
     * @custom:oz-retyped-from bool
     */
    uint8 private _initialized;

    /**
     * @dev Indicates that the contract is in the process of being initialized.
     */
    bool private _initializing;

    /**
     * @dev Triggered when the contract has been initialized or reinitialized.
     */
    event Initialized(uint8 version);

    /**
     * @dev A modifier that defines a protected initializer function that can be invoked at most once. In its scope,
     * `onlyInitializing` functions can be used to initialize parent contracts.
     *
     * Similar to `reinitializer(1)`, except that functions marked with `initializer` can be nested in the context of a
     * constructor.
     *
     * Emits an {Initialized} event.
     */
    modifier initializer() {
        bool isTopLevelCall = !_initializing;
        require(
            (isTopLevelCall && _initialized < 1) || (!AddressUpgradeable.isContract(address(this)) && _initialized == 1),
            "Initializable: contract is already initialized"
        );
        _initialized = 1;
        if (isTopLevelCall) {
            _initializing = true;
        }
        _;
        if (isTopLevelCall) {
            _initializing = false;
            emit Initialized(1);
        }
    }

    /**
     * @dev A modifier that defines a protected reinitializer function that can be invoked at most once, and only if the
     * contract hasn't been initialized to a greater version before. In its scope, `onlyInitializing` functions can be
     * used to initialize parent contracts.
     *
     * A reinitializer may be used after the original initialization step. This is essential to configure modules that
     * are added through upgrades and that require initialization.
     *
     * When `version` is 1, this modifier is similar to `initializer`, except that functions marked with `reinitializer`
     * cannot be nested. If one is invoked in the context of another, execution will revert.
     *
     * Note that versions can jump in increments greater than 1; this implies that if multiple reinitializers coexist in
     * a contract, executing them in the right order is up to the developer or operator.
     *
     * WARNING: setting the version to 255 will prevent any future reinitialization.
     *
     * Emits an {Initialized} event.
     */
    modifier reinitializer(uint8 version) {
        require(!_initializing && _initialized < version, "Initializable: contract is already initialized");
        _initialized = version;
        _initializing = true;
        _;
        _initializing = false;
        emit Initialized(version);
    }

    /**
     * @dev Modifier to protect an initialization function so that it can only be invoked by functions with the
     * {initializer} and {reinitializer} modifiers, directly or indirectly.
     */
    modifier onlyInitializing() {
        require(_initializing, "Initializable: contract is not initializing");
        _;
    }

    /**
     * @dev Locks the contract, preventing any future reinitialization. This cannot be part of an initializer call.
     * Calling this in the constructor of a contract will prevent that contract from being initialized or reinitialized
     * to any version. It is recommended to use this to lock implementation contracts that are designed to be called
     * through proxies.
     *
     * Emits an {Initialized} event the first time it is successfully executed.
     */
    function _disableInitializers() internal virtual {
        require(!_initializing, "Initializable: contract is initializing");
        if (_initialized != type(uint8).max) {
            _initialized = type(uint8).max;
            emit Initialized(type(uint8).max);
        }
    }

    /**
     * @dev Returns the highest version that has been initialized. See {reinitializer}.
     */
    function _getInitializedVersion() internal view returns (uint8) {
        return _initialized;
    }

    /**
     * @dev Returns `true` if the contract is currently initializing. See {onlyInitializing}.
     */
    function _isInitializing() internal view returns (bool) {
        return _initializing;
    }
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/proxy/ERC1967/ERC1967UpgradeUpgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (proxy/ERC1967/ERC1967Upgrade.sol)

pragma solidity ^0.8.2;







/**
 * @dev This abstract contract provides getters and event emitting update functions for
 * https://eips.ethereum.org/EIPS/eip-1967[EIP1967] slots.
 *
 * _Available since v4.1._
 */
abstract contract ERC1967UpgradeUpgradeable is Initializable, IERC1967Upgradeable {
    function __ERC1967Upgrade_init() internal onlyInitializing {
    }

    function __ERC1967Upgrade_init_unchained() internal onlyInitializing {
    }
    // This is the keccak-256 hash of "eip1967.proxy.rollback" subtracted by 1
    bytes32 private constant _ROLLBACK_SLOT = 0x4910fdfa16fed3260ed0e7147f7cc6da11a60208b5b9406d12a635614ffd9143;

    /**
     * @dev Storage slot with the address of the current implementation.
     * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1, and is
     * validated in the constructor.
     */
    bytes32 internal constant _IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;

    /**
     * @dev Returns the current implementation address.
     */
    function _getImplementation() internal view returns (address) {
        return StorageSlotUpgradeable.getAddressSlot(_IMPLEMENTATION_SLOT).value;
    }

    /**
     * @dev Stores a new address in the EIP1967 implementation slot.
     */
    function _setImplementation(address newImplementation) private {
        require(AddressUpgradeable.isContract(newImplementation), "ERC1967: new implementation is not a contract");
        StorageSlotUpgradeable.getAddressSlot(_IMPLEMENTATION_SLOT).value = newImplementation;
    }

    /**
     * @dev Perform implementation upgrade
     *
     * Emits an {Upgraded} event.
     */
    function _upgradeTo(address newImplementation) internal {
        _setImplementation(newImplementation);
        emit Upgraded(newImplementation);
    }

    /**
     * @dev Perform implementation upgrade with additional setup call.
     *
     * Emits an {Upgraded} event.
     */
    function _upgradeToAndCall(address newImplementation, bytes memory data, bool forceCall) internal {
        _upgradeTo(newImplementation);
        if (data.length > 0 || forceCall) {
            AddressUpgradeable.functionDelegateCall(newImplementation, data);
        }
    }

    /**
     * @dev Perform implementation upgrade with security checks for UUPS proxies, and additional setup call.
     *
     * Emits an {Upgraded} event.
     */
    function _upgradeToAndCallUUPS(address newImplementation, bytes memory data, bool forceCall) internal {
        // Upgrades from old implementations will perform a rollback test. This test requires the new
        // implementation to upgrade back to the old, non-ERC1822 compliant, implementation. Removing
        // this special case will break upgrade paths from old UUPS implementation to new ones.
        if (StorageSlotUpgradeable.getBooleanSlot(_ROLLBACK_SLOT).value) {
            _setImplementation(newImplementation);
        } else {
            try IERC1822ProxiableUpgradeable(newImplementation).proxiableUUID() returns (bytes32 slot) {
                require(slot == _IMPLEMENTATION_SLOT, "ERC1967Upgrade: unsupported proxiableUUID");
            } catch {
                revert("ERC1967Upgrade: new implementation is not UUPS");
            }
            _upgradeToAndCall(newImplementation, data, forceCall);
        }
    }

    /**
     * @dev Storage slot with the admin of the contract.
     * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1, and is
     * validated in the constructor.
     */
    bytes32 internal constant _ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;

    /**
     * @dev Returns the current admin.
     */
    function _getAdmin() internal view returns (address) {
        return StorageSlotUpgradeable.getAddressSlot(_ADMIN_SLOT).value;
    }

    /**
     * @dev Stores a new address in the EIP1967 admin slot.
     */
    function _setAdmin(address newAdmin) private {
        require(newAdmin != address(0), "ERC1967: new admin is the zero address");
        StorageSlotUpgradeable.getAddressSlot(_ADMIN_SLOT).value = newAdmin;
    }

    /**
     * @dev Changes the admin of the proxy.
     *
     * Emits an {AdminChanged} event.
     */
    function _changeAdmin(address newAdmin) internal {
        emit AdminChanged(_getAdmin(), newAdmin);
        _setAdmin(newAdmin);
    }

    /**
     * @dev The storage slot of the UpgradeableBeacon contract which defines the implementation for this proxy.
     * This is bytes32(uint256(keccak256('eip1967.proxy.beacon')) - 1)) and is validated in the constructor.
     */
    bytes32 internal constant _BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;

    /**
     * @dev Returns the current beacon.
     */
    function _getBeacon() internal view returns (address) {
        return StorageSlotUpgradeable.getAddressSlot(_BEACON_SLOT).value;
    }

    /**
     * @dev Stores a new beacon in the EIP1967 beacon slot.
     */
    function _setBeacon(address newBeacon) private {
        require(AddressUpgradeable.isContract(newBeacon), "ERC1967: new beacon is not a contract");
        require(
            AddressUpgradeable.isContract(IBeaconUpgradeable(newBeacon).implementation()),
            "ERC1967: beacon implementation is not a contract"
        );
        StorageSlotUpgradeable.getAddressSlot(_BEACON_SLOT).value = newBeacon;
    }

    /**
     * @dev Perform beacon upgrade with additional setup call. Note: This upgrades the address of the beacon, it does
     * not upgrade the implementation contained in the beacon (see {UpgradeableBeacon-_setImplementation} for that).
     *
     * Emits a {BeaconUpgraded} event.
     */
    function _upgradeBeaconToAndCall(address newBeacon, bytes memory data, bool forceCall) internal {
        _setBeacon(newBeacon);
        emit BeaconUpgraded(newBeacon);
        if (data.length > 0 || forceCall) {
            AddressUpgradeable.functionDelegateCall(IBeaconUpgradeable(newBeacon).implementation(), data);
        }
    }

    /**
     * @dev This empty reserved space is put in place to allow future versions to add new
     * variables without shifting down storage in the inheritance chain.
     * See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
     */
    uint256[50] private __gap;
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/proxy/utils/UUPSUpgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (proxy/utils/UUPSUpgradeable.sol)

pragma solidity ^0.8.0;




/**
 * @dev An upgradeability mechanism designed for UUPS proxies. The functions included here can perform an upgrade of an
 * {ERC1967Proxy}, when this contract is set as the implementation behind such a proxy.
 *
 * A security mechanism ensures that an upgrade does not turn off upgradeability accidentally, although this risk is
 * reinstated if the upgrade retains upgradeability but removes the security mechanism, e.g. by replacing
 * `UUPSUpgradeable` with a custom implementation of upgrades.
 *
 * The {_authorizeUpgrade} function must be overridden to include access restriction to the upgrade mechanism.
 *
 * _Available since v4.1._
 */
abstract contract UUPSUpgradeable is Initializable, IERC1822ProxiableUpgradeable, ERC1967UpgradeUpgradeable {
    function __UUPSUpgradeable_init() internal onlyInitializing {
    }

    function __UUPSUpgradeable_init_unchained() internal onlyInitializing {
    }
    /// @custom:oz-upgrades-unsafe-allow state-variable-immutable state-variable-assignment
    address private immutable __self = address(this);

    /**
     * @dev Check that the execution is being performed through a delegatecall call and that the execution context is
     * a proxy contract with an implementation (as defined in ERC1967) pointing to self. This should only be the case
     * for UUPS and transparent proxies that are using the current contract as their implementation. Execution of a
     * function through ERC1167 minimal proxies (clones) would not normally pass this test, but is not guaranteed to
     * fail.
     */
    modifier onlyProxy() {
        require(address(this) != __self, "Function must be called through delegatecall");
        require(_getImplementation() == __self, "Function must be called through active proxy");
        _;
    }

    /**
     * @dev Check that the execution is not being performed through a delegate call. This allows a function to be
     * callable on the implementing contract but not through proxies.
     */
    modifier notDelegated() {
        require(address(this) == __self, "UUPSUpgradeable: must not be called through delegatecall");
        _;
    }

    /**
     * @dev Implementation of the ERC1822 {proxiableUUID} function. This returns the storage slot used by the
     * implementation. It is used to validate the implementation's compatibility when performing an upgrade.
     *
     * IMPORTANT: A proxy pointing at a proxiable contract should not be considered proxiable itself, because this risks
     * bricking a proxy that upgrades to it, by delegating to itself until out of gas. Thus it is critical that this
     * function revert if invoked through a proxy. This is guaranteed by the `notDelegated` modifier.
     */
    function proxiableUUID() external view virtual override notDelegated returns (bytes32) {
        return _IMPLEMENTATION_SLOT;
    }

    /**
     * @dev Upgrade the implementation of the proxy to `newImplementation`.
     *
     * Calls {_authorizeUpgrade}.
     *
     * Emits an {Upgraded} event.
     *
     * @custom:oz-upgrades-unsafe-allow-reachable delegatecall
     */
    function upgradeTo(address newImplementation) public virtual onlyProxy {
        _authorizeUpgrade(newImplementation);
        _upgradeToAndCallUUPS(newImplementation, new bytes(0), false);
    }

    /**
     * @dev Upgrade the implementation of the proxy to `newImplementation`, and subsequently execute the function call
     * encoded in `data`.
     *
     * Calls {_authorizeUpgrade}.
     *
     * Emits an {Upgraded} event.
     *
     * @custom:oz-upgrades-unsafe-allow-reachable delegatecall
     */
    function upgradeToAndCall(address newImplementation, bytes memory data) public payable virtual onlyProxy {
        _authorizeUpgrade(newImplementation);
        _upgradeToAndCallUUPS(newImplementation, data, true);
    }

    /**
     * @dev Function that should revert when `msg.sender` is not authorized to upgrade the contract. Called by
     * {upgradeTo} and {upgradeToAndCall}.
     *
     * Normally, this function will use an xref:access.adoc[access control] modifier such as {Ownable-onlyOwner}.
     *
     * ```solidity
     * function _authorizeUpgrade(address) internal override onlyOwner {}
     * ```
     */
    function _authorizeUpgrade(address newImplementation) internal virtual;

    /**
     * @dev This empty reserved space is put in place to allow future versions to add new
     * variables without shifting down storage in the inheritance chain.
     * See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
     */
    uint256[50] private __gap;
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/utils/ContextUpgradeable.sol


// OpenZeppelin Contracts v4.4.1 (utils/Context.sol)

pragma solidity ^0.8.0;


/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract ContextUpgradeable is Initializable {
    function __Context_init() internal onlyInitializing {
    }

    function __Context_init_unchained() internal onlyInitializing {
    }
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    /**
     * @dev This empty reserved space is put in place to allow future versions to add new
     * variables without shifting down storage in the inheritance chain.
     * See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
     */
    uint256[50] private __gap;
}

// File: @openzeppelin/contracts-upgradeable@4.9.3/access/OwnableUpgradeable.sol


// OpenZeppelin Contracts (last updated v4.9.0) (access/Ownable.sol)

pragma solidity ^0.8.0;



/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * By default, the owner account will be the one that deploys the contract. This
 * can later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract OwnableUpgradeable is Initializable, ContextUpgradeable {
    address private _owner = msg.sender;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the deployer as the initial owner.
     */
    function __Ownable_init() internal onlyInitializing {
        __Ownable_init_unchained();
    }

    function __Ownable_init_unchained() internal onlyInitializing {
        _transferOwnership(_msgSender());
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby disabling any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }

    /**
     * @dev This empty reserved space is put in place to allow future versions to add new
     * variables without shifting down storage in the inheritance chain.
     * See https://docs.openzeppelin.com/contracts/4.x/upgradeable#storage_gaps
     */
    uint256[49] private __gap;
}

// File: vistaForce.sol


pragma solidity ^0.8.0;




interface IERC20 {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function balanceOf(address account) external returns (uint256); 
    function allowance(address owner, address spender) external returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function stakeTokens(address _wallet, uint256 _amount, uint256 lockDuration) external returns (bool);
    function burn(uint256 _amount) external;
    function getFreeBalance(address to) external returns (uint256);

}

interface IBUSD {
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function balanceOf(address account) external returns (uint256); 
    function allowance(address owner, address spender) external returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
}

interface IVista {
    function transfer(address to, uint256 value) external returns (bool);
    function stakeTokens(address _wallet, uint256 _amount, uint256 lockDuration) external returns (bool);
}

library SafeMath {
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "Addition overflow");
        return c;
    }

    function subtract(uint256 a, uint256 b) internal pure returns (uint256) {
        require(b <= a, "Subtraction overflow");
        uint256 c = a - b;
        return c;
    }

}

contract vistaForcePlan is Initializable, OwnableUpgradeable, UUPSUpgradeable {
    uint256 private day = 86400;
    uint256 private month = day * 30;
    uint256 private startmonth = 18 * (day * 30);
    uint256 public price = 8100000000000000000;
    // uint public price;
    address public usdt = 0x55d398326f99059fF775485246999027B3197955;
    address public vista = 0x493361D6164093936c86Dcb35Ad03b4C0D032076;
    struct User {
        address levelUpline;
        address[] levelDownlines;
        uint256 plan;
        uint256 earnings;
        uint256 withdrawn;
        uint256 registrationTime;
        uint256 rank;
        uint256 buyCount;
        uint256 lastCommissionCalculationTime;
        uint256 totalBusiness; // Total business count for the user
    }

    IBUSD private busdToken;
    IVista private token;


    mapping(address => uint256) private balances;
    mapping(address => User) public users;

    uint256 public tokenPriceInBusd;
    address public busd = 0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56;

    uint256 private constant dailyROI = 16666; // 0.16666%
    uint256 private constant oneDayInSeconds = 1 days;
    uint256 private constant oneWeekInSeconds = 7 days;

    event Registration(address indexed user, address indexed referrer, uint256 plan);
    event Upgraded(address indexed user, uint256 plan);
    event CommissionEarned(address indexed user, address indexed referrer, uint256 amount, uint256 level);
    event Payout(address indexed user, uint256 amount);
    event RankUpdated(address indexed user, uint256 rank);
    event RewardTransferred(address indexed user, uint256 amount);
    event RoyaltyTransferred(address indexed user, uint256 amount, uint256 week);
    event DebugLog(address indexed user, uint256 value1, uint256 value2, uint256 value3, uint256 value4, uint256 value5);
    event PriceUpdated(uint256 oldPrice, uint256 newPrice);

    mapping(uint256 => uint256) private levelIncomes;
    mapping(uint256 => uint256) private differenceIncomeTarget;
    mapping(uint256 => uint256) private rewardIncomes;
    mapping(uint256 => uint256) private royaltyIncomes;
    mapping(address => uint256) private royaltyPaidWeeks;
    uint256 public royaltyWeeks = 15;

    function buyPackage(uint256 plan, address referrer) external {
       
        uint256 amount = plan * 10 ** 18 / tokenPriceInBusd;
       

        busdToken.transferFrom(msg.sender, address(this), amount);
        token.transfer(msg.sender, amount);


        // Calculate staking return and update user's earnings
        users[msg.sender].plan = plan;
        users[msg.sender].registrationTime = block.timestamp;
        users[msg.sender].levelUpline = referrer;
        users[msg.sender].buyCount++;
        users[referrer].levelDownlines.push(msg.sender);
       
        // Update total business count for the user and their uplines
        if (users[msg.sender].levelUpline == address(0)) {
            users[msg.sender].levelUpline = referrer;
        }
        require(users[referrer].plan > 0, "Referrer must be upgraded to a level to refer others");
        users[msg.sender].buyCount++;

        address upline = referrer;
        address downline = msg.sender;
        for (uint256 i = 1; i <= 10; i++) {
            if (upline == address(0)) break;

            updateTotalBusiness(downline, plan);
            // Update user's rank
            updateRank(upline);

            downline = upline;
            upline = users[upline].levelUpline;
        }

        // Emit events accordingly
        emit Registration(msg.sender, referrer, plan);
    }

    function updateTotalBusiness(address user, uint256 plan) internal {
        uint256 totalBusiness = plan;
        for (uint256 i = 0; i < users[user].levelDownlines.length; i++) {
            address downline = users[user].levelDownlines[i];
            totalBusiness += users[downline].totalBusiness;
        }
        users[user].totalBusiness = totalBusiness;
    }

    function distributeCommission(address user, uint256 plan) internal {
        address upline = users[user].levelUpline;
        uint256 currentTime = block.timestamp;
        uint256 lastCalculationTime = users[user].lastCommissionCalculationTime;

        for (uint256 i = 1; i <= 20; i++) {
            if (upline == address(0)) break;

            uint256 timeSinceLastCalculation = currentTime - lastCalculationTime;
            uint256 commission = (plan * levelIncomes[i] * timeSinceLastCalculation) / (10000 * oneDayInSeconds); // Convert to daily percentage

            users[upline].earnings += commission;
            emit CommissionEarned(upline, user, commission, i);

            // Distribute 50% of direct referral's ROI to the user
            if (i == 1) {
                uint256 referralROI = (plan * dailyROI * timeSinceLastCalculation) / (10000 * oneDayInSeconds); // Convert to daily percentage
                uint256 referralIncome = (referralROI / tokenPriceInBusd) / 2;

                users[upline].earnings += referralIncome;
                emit CommissionEarned(upline, user, referralIncome, 0);
            }

            // Distribute 50% of level 1 referral's ROI to the user
            if (i == 2 && getTotalBusinessLevel1(upline) >= 5000) {
                uint256 referralROI = (plan * dailyROI * timeSinceLastCalculation) / (10000 * oneDayInSeconds); // Convert to daily percentage
                uint256 referralIncome = (referralROI / tokenPriceInBusd) / 2;

                users[upline].earnings += referralIncome;
                emit CommissionEarned(upline, user, referralIncome, 0);
            }

            // Apply rank bonus for higher ranked users
            if (users[upline].rank >= 1 && users[upline].rank <= 10 && users[upline].rank > users[user].rank) {
                uint256 rankBonus = ((users[upline].rank - users[user].rank) * plan * 10 * timeSinceLastCalculation) / (100 * oneDayInSeconds); // Convert to daily percentage
                users[upline].earnings += rankBonus;
                emit CommissionEarned(upline, user, rankBonus, 0);
            }

            upline = users[upline].levelUpline;
        }

        // Update last commission calculation time for the user
        users[user].lastCommissionCalculationTime = currentTime;
    }


    function payout() external {
        // Check if the user's total withdrawn amount is less than the allowed earnings for their current buying count
        uint256 maxEarnings = getMaxEarnings(users[msg.sender].buyCount);
        require(users[msg.sender].withdrawn < maxEarnings * users[msg.sender].plan, "Maximum earnings reached");

        // Calculate daily commissions for the user and their uplines
        distributeCommission(msg.sender, users[msg.sender].plan);
        updateRank(msg.sender);

        // Calculate user's ROI since last withdrawn
        uint256 roiAmount = (users[msg.sender].plan * dailyROI) / 10000; // Convert to percentage
        uint256 eligibleEarnings = roiAmount * ((block.timestamp - users[msg.sender].lastCommissionCalculationTime) / oneDayInSeconds);
        uint256 totalEarnings = eligibleEarnings + users[msg.sender].earnings - users[msg.sender].withdrawn;

        // Calculate royalty earnings
        if (users[msg.sender].rank > 0) {
            uint256 royaltyAmount = calculateRoyalty(msg.sender);
            totalEarnings += royaltyAmount;
        }

        if (totalEarnings > 0) {
            // Update user's earnings
            users[msg.sender].earnings += totalEarnings;

            // Transfer ROI tokens to the user
            bool success = token.transfer(msg.sender, totalEarnings * 10 ** 18 );
            require(success, "Token transfer failed");

            users[msg.sender].withdrawn += totalEarnings;
            emit Payout(msg.sender, totalEarnings);
        }
    }

    function getMaxEarnings(uint256 buyingCount) internal pure returns (uint256) {
        if (buyingCount == 1) {
            // First buying, maximum earnings allowed is 3x the plan amount
            return 3;
        } else if (buyingCount == 2) {
            // Second buying, maximum earnings allowed is 4x the plan amount
            return 4;
        } else if (buyingCount == 3) {
            // Third buying, maximum earnings allowed is 5x the plan amount
            return 5;
        } else {
            // Subsequent buying, no limit on earnings
            return type(uint256).max;
        }
    }

    function calculateRoyalty(address user) internal returns (uint256) {
        uint256 royaltyAmount = 0;
        uint256 lastPaidWeek = royaltyPaidWeeks[user];
        uint256 currentWeek = block.timestamp / oneWeekInSeconds;

        for (uint256 i = lastPaidWeek + 1; i <= currentWeek && royaltyWeeks > 0; i++) {
            royaltyAmount += royaltyIncomes[users[user].rank] / tokenPriceInBusd;
            royaltyPaidWeeks[user] = i;
            royaltyWeeks--;
        }

        return royaltyAmount;
    }

    function updateRank(address user) internal {
        uint256 userBusiness = getTotalBusinessCount(user);
        uint256 currentRank = users[user].rank;

        // Calculate the total business from the top two downlines
        uint256 totalBusinessFromTopTwo = 0;
        for (uint256 i = 0; i < users[user].levelDownlines.length && i < 2; i++) {
            address downline = users[user].levelDownlines[i];
            uint256 downlineBusiness = getTotalBusinessCount(downline);
            totalBusinessFromTopTwo += downlineBusiness;
        }

        // Calculate the total business from other downlines
        uint256 totalBusinessFromOthers = userBusiness - totalBusinessFromTopTwo;

        for (uint256 i = 1; i <= 10; i++) {
            uint256 targetBusinessTopTwo = differenceIncomeTarget[i] * 60 / 100;
            uint256 targetBusinessOthers = differenceIncomeTarget[i] * 40 / 100;

            if (totalBusinessFromTopTwo >= targetBusinessTopTwo && totalBusinessFromOthers >= targetBusinessOthers) {
                if (currentRank < i) {
                    users[user].rank = i;
                    emit RankUpdated(user, users[user].rank);

                    // Transfer reward income based on the user's rank
                    uint256 rewardAmount = rewardIncomes[users[user].rank] / tokenPriceInBusd;
                    bool success = token.transfer(user, rewardAmount * 10 ** 18 );
                    require(success, "Reward transfer failed");

                    emit RewardTransferred(user, rewardAmount);
                }

                break;
            }
        }
    }

    function getTotalBusinessCount(address user) internal view returns (uint256) {
        return users[user].totalBusiness;
    }

    function getTotalBusinessLevel1(address user) internal view returns (uint256) {
        uint256 totalBusinessLevel1 = 0;
        for (uint256 i = 0; i < users[user].levelDownlines.length; i++) {
            address downline = users[user].levelDownlines[i];
            totalBusinessLevel1 += users[downline].plan;
        }
        return totalBusinessLevel1;
    }

    // Only the contract owner can call this function
    function openLevelsAndIncomesForUser(address userAddress, uint256[] calldata levelNumbers) external onlyOwner {
        require(levelNumbers.length > 0, "At least one level must be specified");

        for (uint256 i = 0; i < levelNumbers.length; i++) {
            uint256 levelNumber = levelNumbers[i];
            require(levelNumber >= 1 && levelNumber <= 20, "Invalid level number");

            // Check if the level is already open for the user
            bool isLevelOpen = false;
            for (uint256 j = 0; j < users[userAddress].levelDownlines.length; j++) {
                if (users[userAddress].levelDownlines[j] == userAddress && users[userAddress].rank >= levelNumber) {
                    isLevelOpen = true;
                    break;
                }
            }
            require(!isLevelOpen, "Level is already open for the user");

            // Open the level and income for the user
            users[userAddress].rank = levelNumber; // Assuming rank represents the level user has access to.
        }
    }

    function getUserLevelUpline(address userAddress) external view returns (address) {
        return users[userAddress].levelUpline;
    }

    function getUserLevelDownlines(address userAddress) external view returns (address[] memory) {
        return users[userAddress].levelDownlines;
    }

    function getUserPlan(address userAddress) external view returns (uint256) {
        return users[userAddress].plan;
    }

    function getUserEarnings(address userAddress) external view returns (uint256) {
        return users[userAddress].earnings;
    }

    function getUserWithdrawn(address userAddress) external view returns (uint256) {
        return users[userAddress].withdrawn;
    }

    function getUserRegistrationTime(address userAddress) external view returns (uint256) {
        return users[userAddress].registrationTime;
    }

    function getUserRank(address userAddress) external view returns (uint256) {
        return users[userAddress].rank;
    }

    function getUserBuyCount(address userAddress) external view returns (uint256) {
        return users[userAddress].buyCount;
    }

    function getUserLastCommissionCalculationTime(address userAddress) external view returns (uint256) {
        return users[userAddress].lastCommissionCalculationTime;
    }

    function depositTokens(uint256 amount) external onlyOwner {
        require(amount > 0, "Amount must be greater than zero");

        // Increase the contract balance
        balances[address(this)] += amount;
    }

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    function initialize() initializer public {
        __Ownable_init();
        __UUPSUpgradeable_init();
        _transferOwnership(msg.sender);

        busdToken = IBUSD(busd);
        token = IVista(vista);
        // Initialize the Token contract
        tokenPriceInBusd = 490;

        // Initialize other variables if needed
        levelIncomes[1] = 25;
        levelIncomes[2] = 10;
        levelIncomes[3] = 10;
        levelIncomes[4] = 5;
        levelIncomes[5] = 5;
        levelIncomes[6] = 4;
        levelIncomes[7] = 4;
        levelIncomes[8] = 4;
        levelIncomes[9] = 4;
        levelIncomes[10] = 4;
        levelIncomes[11] = 3;
        levelIncomes[12] = 3;
        levelIncomes[13] = 3;
        levelIncomes[14] = 3;
        levelIncomes[15] = 3;
        levelIncomes[16] = 2;
        levelIncomes[17] = 2;
        levelIncomes[18] = 2;
        levelIncomes[19] = 2;
        levelIncomes[20] = 2;
        differenceIncomeTarget[1] = 2500;
        differenceIncomeTarget[2] = 7500;
        differenceIncomeTarget[3] = 22500;
        differenceIncomeTarget[4] = 72500;
        differenceIncomeTarget[5] = 172500;
        differenceIncomeTarget[6] = 472500;
        differenceIncomeTarget[7] = 1972500;
        differenceIncomeTarget[8] = 6972500;
        differenceIncomeTarget[9] = 14472500;
        differenceIncomeTarget[10] = 114472500;
        rewardIncomes[1] = 100;
        rewardIncomes[2] = 250;
        rewardIncomes[3] = 700;
        rewardIncomes[4] = 2500;
        rewardIncomes[5] = 5000;
        rewardIncomes[6] = 15000;
        rewardIncomes[7] = 75000;
        rewardIncomes[8] = 200000;
        rewardIncomes[9] = 350000;
        rewardIncomes[10] = 500000;
        royaltyIncomes[1] = 10;
        royaltyIncomes[2] = 25;
        royaltyIncomes[3] = 60;
        royaltyIncomes[4] = 150;
        royaltyIncomes[5] = 350;
        royaltyIncomes[6] = 1000;
        royaltyIncomes[7] = 5200;
        royaltyIncomes[8] = 17000;
        royaltyIncomes[9] = 30000;
        royaltyIncomes[10] = 50000;

        users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].levelUpline = address(0);
        users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].plan = 5000; 
        users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].registrationTime = block.timestamp;
        users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].buyCount = 1;
        users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].lastCommissionCalculationTime = block.timestamp;

        for (uint256 i = 1; i <= 10; i++) {
            users[0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E].levelDownlines.push(0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E);
        }

        // Emit events accordingly
        emit Registration(0xD79fe145D76e4a4468Bd27Ec3d435B15D00e921E, address(0), 100);
    }

    function _authorizeUpgrade(address newImplementation)
        internal
        onlyOwner
        override
    {}

    // Function to deposit ERC-20 tokens into the contract

    function updatePrice(uint256 _newPrice) public onlyOwner {
        require(_newPrice != price, "New price must be different.");

        uint256 oldPrice = price;
        price = _newPrice;
        

        emit PriceUpdated(oldPrice, _newPrice);
    }

    function burn() public onlyOwner {
        IERC20 vistaToken = IERC20(vista);
        uint256 _balance = vistaToken.balanceOf(address(this));
        vistaToken.burn(_balance);
    }


    // Function to stake ERC-20 tokens into the contract
    function stake(uint256 USDTAmount, address refer, address user) public {
        IERC20 vistaToken = IERC20(vista);
        IERC20 usdToken = IERC20(usdt);
        uint256 amount = (USDTAmount * 1 ether) / price;
        require(usdToken.transferFrom(user, address(this), USDTAmount), "USDT transferFrom failed");

        require(usdToken.transfer(0x415eF61e51f7D70f43569775E4a3D986cD02ed0c, USDTAmount), "USDT transfer to destination failed");
       
        require(vistaToken.transfer(user, amount), "VISTA transfer to sender failed");
       
        directStakingIncentive(refer, amount/10);

        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 1);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 2);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 3);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 4);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 5);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 6);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 7);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 8);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 9);
    }

    // Function to reStake ERC-20 tokens into the contract
    function reStake(uint256 amount, address user) public {
        IERC20 vistaToken = IERC20(vista);
        uint256 balance = vistaToken.getFreeBalance(msg.sender);
        require(balance > amount, "Tokens are still Staked");

        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 1);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 2);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 3);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 4);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 5);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 6);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 7);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 8);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 9);
        vistaToken.stakeTokens(user, amount * 10 / 100, startmonth + month * 10);
    }
   
    // Function to distribute direct staking incentive
    function directStakingIncentive(address refer, uint256 amount) internal {
        IERC20 vistaToken = IERC20(vista);

        require(vistaToken.transfer(refer, amount), "VISTA transfer to refer failed");
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 1);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 2);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 3);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 4);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 5);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 6);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 7);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 8);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 9);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 10);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 11);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 12);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 13);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 14);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 15);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 16);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 17);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 18);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 19);
        vistaToken.stakeTokens(refer, amount * 5 / 100, month * 20);
    }

}