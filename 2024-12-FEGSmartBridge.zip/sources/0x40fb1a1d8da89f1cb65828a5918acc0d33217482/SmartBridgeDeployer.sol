// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
// optimize 200
/// Standard IERC20 interface
interface IERC20 {
    function totalSupply() external view returns (uint256);
    function decimals() external view returns (uint8);
    function balanceOf(address account) external view returns (uint256);
    function owner() external view returns(address);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function symbol() external view returns(string memory);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

library Address {
    /**
     * @dev Returns true if `account` is a contract.
     *
     * [IMPORTANT]
     * ====
     * It is unsafe to assume that an address for which this function returns
     * false is an externally-owned account (EOA) and not a contract.
     *
     * Among others, `isContract` will return false for the following
     * types of addresses:
     *
     *  - an externally-owned account
     *  - a contract in construction
     *  - an address where a contract will be created
     *  - an address where a contract lived, but was destroyed
     * ====
     *
     * [IMPORTANT]
     * ====
     * You shouldn't rely on `isContract` to protect against flash loan attacks!
     *
     * Preventing calls from contracts is highly discouraged. It breaks composability, breaks support for smart wallets
     * like Gnosis Safe, and does not provide security since it can be circumvented by calling from a contract
     * constructor.
     * ====
     */
    function isContract(address account) internal view returns (bool) {
        // This method relies on extcodesize/address.code.length, which returns 0
        // for contracts in construction, since the code is only stored at the end
        // of the constructor execution.

        return account.code.length > 0;
    }

    /**
     * @dev Same as {xref-Address-functionCall-address-bytes-}[`functionCall`], but with
     * `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCall(
        address target,
        bytes memory data,
        string memory errorMessage
    ) internal returns (bytes memory) {
        return functionCallWithValue(target, data, 0, errorMessage);
    }

    /**
     * @dev Same as {xref-Address-functionCallWithValue-address-bytes-uint256-}[`functionCallWithValue`], but
     * with `errorMessage` as a fallback revert reason when `target` reverts.
     *
     * _Available since v3.1._
     */
    function functionCallWithValue(
        address target,
        bytes memory data,
        uint256 value,
        string memory errorMessage
    ) internal returns (bytes memory) {
        require(address(this).balance >= value, "Address: insufficient balance for call");
        (bool success, bytes memory returndata) = target.call{value: value}(data);
        return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    }

    /**
     * @dev Tool to verify that a low level call to smart-contract was successful, and revert (either by bubbling
     * the revert reason or using the provided one) in case of unsuccessful call or if target was not a contract.
     *
     * _Available since v4.8._
     */
    function verifyCallResultFromTarget(
        address target,
        bool success,
        bytes memory returndata,
        string memory errorMessage
    ) internal view returns (bytes memory) {
        if (success) {
            if (returndata.length == 0) {
                // only check isContract if the call was successful and the return data is empty
                // otherwise we already know that it was a contract
                require(isContract(target), "Address: call to non-contract");
            }
            return returndata;
        } else {
            _revert(returndata, errorMessage);
        }
    }

    function _revert(bytes memory returndata, string memory errorMessage) private pure {
        // Look for revert reason and bubble it up if present
        if (returndata.length > 0) {
            // The easiest way to bubble the revert reason is using memory via assembly
            /// @solidity memory-safe-assembly
            assembly {
                let returndata_size := mload(returndata)
                revert(add(32, returndata), returndata_size)
            }
        } else {
            revert(errorMessage);
        }
    }
}

/// Transfer Helper to ensure the correct transfer of the tokens or ETH
library SafeTransfer {
    using Address for address;
    function safeApprove(IERC20 token, address spender, uint256 value) 
    internal {
    // safeApprove should only be called when setting an initial allowance,
    // or when resetting it to zero. To increase and decrease it, use
    // 'safeIncreaseAllowance' and 'safeDecreaseAllowance'
    require(
        (value == 0) || (token.allowance(address(this), spender) == 0),
        "SafeERC20: approve from non-zero to non-zero allowance"
    );
    _callOptionalReturn(token, 
    abi.encodeWithSelector(token.approve.selector, spender, value));
}
    /** Safe Transfer asset from one wallet with approval of the wallet
    * @param erc20: the contract address of the erc20 token
    * @param from: the wallet to take from
    * @param amount: the amount to take from the wallet
    **/
    function _pullUnderlying(IERC20 erc20, address from, uint amount) internal
    {
        safeTransferFrom(erc20,from,address(this),amount);
    }

    function safeTransfer(
        IERC20 token,
        address to,
        uint256 value
    ) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transfer.selector, to, value));
    }

    function safeTransferFrom(
        IERC20 token,
        address from,
        address to,
        uint256 value
    ) internal {
        _callOptionalReturn(token, abi.encodeWithSelector(token.transferFrom.selector, from, to, value));
    }

    /** Safe Transfer asset to one wallet from within the contract
    * @param erc20: the contract address of the erc20 token
    * @param to: the wallet to send to
    * @param amount: the amount to send from the contract
    **/
    function _pushUnderlying(IERC20 erc20, address to, uint amount) internal
    {
        safeTransfer(erc20,to,amount);
    }

    /** Safe Transfer ETH to one wallet from within the contract
    * @param to: the wallet to send to
    * @param value: the amount to send from the contract
    **/
    function safeTransferETH(address to, uint256 value) internal {
        (bool success,) = to.call{value : value}(new bytes(0));
        require(success, 'TransferHelper::safeTransferETH: ETH transfer failed');
    }

    function _callOptionalReturn(IERC20 token, bytes memory data) private {
        // We need to perform a low level call here, to bypass Solidity's return data size checking mechanism, since
        // we're implementing it ourselves. We use {Address-functionCall} to perform this call, which verifies that
        // the target address contains contract code and also asserts for success in the low-level call.

        bytes memory returndata = address(token).functionCall(data, "SafeERC20: low-level call failed");
        if (returndata.length > 0) {
            // Return data is optional
            require(abi.decode(returndata, (bool)), "SafeERC20: ERC20 operation did not succeed");
        }
    }
}

interface dr {
    function superAdmin(address addy) external view returns(bool);
    function isAdmin(address addy) external view returns(bool);
    function bridgeDep() external view returns(address);
    function isBridge(address addy) external view returns(bool);
    function setBridgeSD(address who, address addy) external;
    function wETH() external view returns(address);
    function bridgeSD(address sd) external view returns(address);
    function sdDepAddy() external view returns(address);
    function creatorOfSD(address creator) external view returns(address);
    function SDOfCreator(address sd) external view returns(address);

}

interface warp {    
    function sendPayloadToEvm(uint16 targetChain,address targetAddress,bytes memory payload,uint256 receiverValue,uint256 gasLimit,uint16 refundChain,address refundAddress) external payable returns (uint64 sequence);
}

interface dep {
    function relayDeposit(uint256 cost, uint16 toChain, bytes calldata payload, uint16 toChain0, address fund) external payable;
    function relayWithdrawal(uint256 cost, uint16 toChain, bytes calldata payload, uint16 toChain0, address fund) external payable;
    function registerWithdraw(address ad, uint256 amount, uint16 sourceChain, uint256 depositID) external;
    function registerBridge(uint256 depositID) external;
    function fund() external view returns(address);
    function gas0() external view returns(uint256);
    function gas1() external view returns(uint256);
    function recoveryFee() external view returns(uint256);
    function donation() external view returns(uint256);
    function quoteEVMDeliveryPrice(uint16 targetChain, uint256 receiverValue, uint256 gasLimit) external view returns (uint256 nativePriceQuote, uint256);
    function quoteDeposit(uint16 target, uint256 rv) external view returns (uint256 npq);
    function quoteWithdraw(uint16 target, uint256 rv) external view returns (uint256 npq);
    function deposit() external payable;
    function deploy(address sd, address owner) external returns(address bridge);
    function tokenOnChain(address sd, uint16 chain) external view returns(address);
    function coolDown() external view returns(uint256);
}

contract SmartBridgeDeployer {
    mapping(address => bool) public isBridge;
    address[] public allBridges;
    address public dataread = 0xdAE383661587232FBd254b05a395CB8e35E6e7B6;
    address public logic = 0x190BE53720e7313d5615d46326cCacE59F1Cc822;
    address public fund = 0x46B6dF78388284088e07aA8F5dda4B5A3Ef3f861;
    uint256 public donation = 300000000000000; //donation
    uint256 public recoveryFee = 10; // 10 = 10%
    uint256 public coolDown = 5 minutes; 
    bool public on = true;
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;
    uint256 private _status;

    constructor() {        
        _status = _NOT_ENTERED;
    }

    modifier nonReentrant() {
        require(_status != _ENTERED, "ReentrancyGuard");
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }

    function setLogic(address addy) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        logic = addy;
    }

    function setOn(bool _bool) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        on = _bool;
    }

    function setDonation(uint256 amt) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        donation = amt;
    }
    
    function setCooldown(uint256 amt) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        coolDown = amt;
    }

    function setFund(address addy) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        fund = addy;
    }

    function setRecoveryFee(uint256 fee) external {
        require(dr(dataread).superAdmin(msg.sender), "not admin");
        require(fee <= 10, "10%max");
        recoveryFee = fee;
    }
    
    function deploy(address sd, bool originChain) external nonReentrant returns(address bridge){
        require(on, "deploy paused");
        require(msg.sender == IERC20(sd).owner(), "not owner");
        bridge = dep(logic).deploy(sd,msg.sender);
        require(!isBridge[bridge], "already bridge");
        dr(dataread).setBridgeSD(sd,bridge);
        if(!originChain) {
        SafeTransfer.safeTransferFrom(IERC20(sd), msg.sender, bridge, IERC20(sd).totalSupply());        
        }
        isBridge[bridge] = true;
        allBridges.push(bridge);
    }
}