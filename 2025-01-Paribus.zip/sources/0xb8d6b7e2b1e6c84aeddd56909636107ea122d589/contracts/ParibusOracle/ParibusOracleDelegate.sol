// SPDX-License-Identifier: BSD-3-Clause
pragma solidity ^0.8.10;

import "./ParibusOracleInterfaces.sol";

// TODO PBX fee ??

/**
 * @title Paribus NFT Oracle contract
 * @notice This contract is separable and independent from the rest of the Paribus protocol
 * @author Paribus
 */
contract ParibusOracleDelegate is ParibusOracleInterface {
    modifier onlyOwner() {
        require(msg.sender == admin, "ParibusOracle: admin only");
        _;
    }

    modifier onlyUpdater() {
        require(msg.sender == updater || (msg.sender == admin && updater == address(0)), "ParibusOracle: caller is not the updater");
        _;
    }

    function _setUpdater(address _updater) override external onlyOwner {
        emit NewUpdater(updater, _updater);
        updater = _updater;
    }

    function _setCollectionWhitelisted(address[] calldata nfts, bool whitelisted) override external onlyOwner {
        requestWhitelistedOnly = true;

        for (uint i = 0; i < nfts.length; i++) {
            collectionWhitelist[nfts[i]] = whitelisted;
        }
    }

    function getOrRequestTokenPriceWei(address nft, uint tokenId) override virtual external returns (uint, uint) {
        TokenPrice memory price = tokenPrices[nft][tokenId];

        if (price.priceWei == 0 || price.updatedAt + heartbeat < getBlockTimestamp()) { // price not available or stale
            if (!requestWhitelistedOnly || collectionWhitelist[nft]) {
                // request token price only if collection is whitelisted
                emit PriceRequested(nft, tokenId);
            }
        }

        return (price.priceWei, price.updatedAt);
    }

    function getTokenPriceWei(address nft, uint tokenId) override external view returns (uint, uint) {
        TokenPrice memory price = tokenPrices[nft][tokenId];
        return (price.priceWei, price.updatedAt);
    }

    function setCollectionPricesWei(address nft, uint[] calldata tokenIds, uint[] calldata pricesWei) override external onlyUpdater {
        require(tokenIds.length == pricesWei.length, "ParibusOracle: invalid data");

        uint dataLen = tokenIds.length;
        mapping(uint => TokenPrice) storage collectionPrices = tokenPrices[nft];

        for (uint i = 0; i < dataLen; i++) {
            TokenPrice storage tokenPrice = collectionPrices[tokenIds[i]];
            tokenPrice.priceWei = pricesWei[i];
            tokenPrice.updatedAt = getBlockTimestamp();
        }
    }

    function setPricesWei(address[] calldata nfts, uint[] calldata tokenIds, uint[] calldata pricesWei) override external onlyUpdater {
        require(tokenIds.length == pricesWei.length && pricesWei.length == nfts.length, "ParibusOracle: invalid data");
        uint dataLen = nfts.length;

        for (uint i = 0; i < dataLen; i++) {
            TokenPrice storage tokenPrice = tokenPrices[nfts[i]][tokenIds[i]];
            tokenPrice.priceWei = pricesWei[i];
            tokenPrice.updatedAt = getBlockTimestamp();
        }
    }

    function getBlockTimestamp() override public virtual view returns (uint) {
        return block.timestamp;
    }

    /**
      * @notice Begins transfer of admin rights. The newPendingAdmin must call `_acceptAdmin` to finalize the transfer.
      * @dev Admin function to begin change of admin. The newPendingAdmin must call `_acceptAdmin` to finalize the transfer.
      * @param newPendingAdmin New pending admin.
      */
    function _setPendingAdmin(address newPendingAdmin) external override {
        require(msg.sender == admin, "ParibusOracle::_setPendingAdmin: admin only");
        require(newPendingAdmin != address(0), "ParibusOracleDelegator::_setPendingAdmin: admin cannot be zero address");

        emit NewPendingAdmin(pendingAdmin, newPendingAdmin);
        pendingAdmin = newPendingAdmin;
    }

    /**
      * @notice Accepts transfer of admin rights. msg.sender must be pendingAdmin
      * @dev Admin function for pending admin to accept role and update admin
      */
    function _acceptAdmin() external override {
        require(msg.sender == pendingAdmin, "ParibusOracleDelegator::_acceptAdmin: pending admin only");

        emit NewAdmin(admin, pendingAdmin);
        emit NewPendingAdmin(pendingAdmin, address(0));
        admin = pendingAdmin;
        pendingAdmin = address(0);
    }
}
