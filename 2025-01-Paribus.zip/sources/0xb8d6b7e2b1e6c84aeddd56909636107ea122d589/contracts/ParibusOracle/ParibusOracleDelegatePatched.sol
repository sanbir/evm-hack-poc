// SPDX-License-Identifier: BSD-3-Clause
pragma solidity ^0.8.10;

import "./ParibusOracleDelegate.sol";

interface IComptroller {
    function oracle() external view returns (address);
    function isComptroller() external view returns (bool);
}
/**
 * @title Paribus NFT Oracle contract
 * @notice This contract is separable and independent from the rest of the Paribus protocol
 * @author Paribus
 */
contract ParibusOracleDelegatePatched is ParibusOracleDelegate {

    IComptroller public comptroller;

    function getOrRequestTokenPriceWei(address nft, uint tokenId) override external returns (uint, uint) {
       
        if (getPositionPriceWei(nft, tokenId) > 0) {
            return (getPositionPriceWei(nft, tokenId), getBlockTimestamp());
        }
        else {
            TokenPrice memory price = tokenPrices[nft][tokenId];

            if (price.priceWei == 0 || price.updatedAt + heartbeat < getBlockTimestamp()) { // price not available or stale
                if (!requestWhitelistedOnly || collectionWhitelist[nft]) {
                    // request token price only if collection is whitelisted
                    emit PriceRequested(nft, tokenId);
                }
            }

            return (price.priceWei, price.updatedAt);
        }
    }

    function getPositionPriceWei(address nft, uint tokenId) internal view returns (uint) {
        AggregatorOracleInterface aggregatorOracleContract = AggregatorOracleInterface(comptroller.oracle());
        NFPOracleInterface camelotV2Oracle = NFPOracleInterface(aggregatorOracleContract.camelotV2Oracle());
        NFPOracleInterface univ3PriceOracle = NFPOracleInterface(aggregatorOracleContract.uniV3PriceOracle());
        if (nft == camelotV2Oracle.nfpManager()) {
            return (camelotV2Oracle.getPositionPrice(tokenId) * 1e18) / aggregatorOracleContract.getTokenPrice(address(0), 18);
        }
        else if (nft == univ3PriceOracle.nfpManager()) {
            return (univ3PriceOracle.getPositionPrice(tokenId) *1e18) / aggregatorOracleContract.getTokenPrice(address(0), 18);
        }
        else {
            return 0;
        }
    }

    function setComptroller(address _comptroller) public onlyOwner{
        (bool success, ) = _comptroller.staticcall(abi.encodeWithSignature("isComptroller()"));
        require(success, "not valid comptroller address");
        comptroller = IComptroller(_comptroller);
    }
}