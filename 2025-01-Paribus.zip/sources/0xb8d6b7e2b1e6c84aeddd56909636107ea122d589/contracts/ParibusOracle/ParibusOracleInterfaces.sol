// SPDX-License-Identifier: BSD-3-Clause
pragma solidity ^0.8.10;

contract ParibusOracleDelegationStorage {
    /// @notice Administrator for this contract
    address public admin;

    /// @notice Pending administrator for this contract
    address public pendingAdmin;

    /// @notice Active brain of ParibusOracle
    address public implementation;
}

contract ParibusOracleDelegatorInterface is ParibusOracleDelegationStorage {
    /// @notice Emitted when implementation is changed
    event NewImplementation(address oldImplementation, address newImplementation);
}

contract ParibusOracleStorage is ParibusOracleDelegationStorage {
    /// @dev Guard variable for reentrancy checks
    bool internal _notEntered;

    struct TokenPrice {
        uint priceWei;

        /// @dev timestamp
        uint updatedAt;
    }

    /// @notice { nftAddress => { tokenId => TokenPrice } } mapping of token prices
    mapping(address => mapping(uint => TokenPrice)) internal tokenPrices;

    /// @notice Feature flag on/off to request token prices only for whitelisted collections
    bool public requestWhitelistedOnly = false;

    /// @notice { nftAddress => whitelisted } mapping of whitelisted collections
    mapping(address => bool) public collectionWhitelist;

    /// @notice The maximum time a token price is considered fresh
    uint public constant heartbeat = 86400; // 24 hours

    /// @notice The address allowed to update token prices
    address public updater;
}

abstract contract ParibusOracleInterface is ParibusOracleStorage {
    /// @notice Emitted when pendingAdmin is changed
    event NewPendingAdmin(address oldPendingAdmin, address newPendingAdmin);

    /// @notice Emitted when pendingAdmin is accepted, which means admin is updated
    event NewAdmin(address oldAdmin, address newAdmin);

    /// @notice Emitted when token price is requested. Assuming this event will be listened for by the oracle backend price update service
    event PriceRequested(address nft, uint tokenId);

    /// @notice Emitted when updater address is changed
    event NewUpdater(address oldUpdater, address newUpdater);

    function _setUpdater(address _updater) virtual external;

    function _setCollectionWhitelisted(address[] calldata nfts, bool whitelisted) virtual external;

    /// @dev returns 0 if price not available
    function getOrRequestTokenPriceWei(address nft, uint tokenId) virtual external returns (uint, uint);

    /// @dev returns 0 if price not available
    function getTokenPriceWei(address nft, uint tokenId) virtual external view returns (uint, uint);

    function setCollectionPricesWei(address nft, uint[] calldata tokenIds, uint[] calldata pricesWei) virtual external;

    function setPricesWei(address[] calldata nfts, uint[] calldata tokenIds, uint[] calldata pricesWei) virtual external;

    function getBlockTimestamp() virtual public view returns (uint);

    function _setPendingAdmin(address newPendingAdmin) virtual external;
    function _acceptAdmin() virtual external;
}


interface AggregatorOracleInterface {
    function camelotV2Oracle() external view returns (address);
    function uniV3PriceOracle() external view returns (address);

    function getTokenPrice(address token, uint decimals) external view returns (uint);
}

interface NFPOracleInterface {
    function nfpManager() external view returns (address);
    function getPositionPrice(uint tokenId) external view returns (uint);
}