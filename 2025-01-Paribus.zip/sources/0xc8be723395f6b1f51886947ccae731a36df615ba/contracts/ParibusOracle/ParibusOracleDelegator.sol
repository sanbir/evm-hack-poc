// SPDX-License-Identifier: BSD-3-Clause
pragma solidity ^0.8.10;

import "./ParibusOracleInterfaces.sol";

contract ParibusOracleDelegator is ParibusOracleDelegatorInterface {
    constructor(address admin_, address implementation_) {
        // Admin set to msg.sender for initialization
        admin = msg.sender;

        _setImplementation(implementation_);

        require(admin_ != address(0), "invalid argument");
        admin = admin_;
    }

	/**
     * @notice Called by the admin to update the implementation of the delegator
     * @param implementation_ The address of the new implementation for delegation
     */
    function _setImplementation(address implementation_) public {
        require(msg.sender == admin, "ParibusOracleDelegator::_setImplementation: admin only");
        require(implementation_ != address(0), "ParibusOracleDelegator::_setImplementation: invalid implementation address");

        emit NewImplementation(implementation, implementation_);

        implementation = implementation_;
    }

    /**
     * @dev Delegates execution to an implementation contract.
     * It returns to the external caller whatever the implementation returns
     * or forwards reverts.
     */
    fallback() external {
        // delegate all other functions to current implementation
        (bool success, ) = implementation.delegatecall(msg.data);

        assembly {
            let free_mem_ptr := mload(0x40)
            returndatacopy(free_mem_ptr, 0, returndatasize())

            switch success
            case 0 { revert(free_mem_ptr, returndatasize()) }
            default { return (free_mem_ptr, returndatasize()) }
        }
    }
}
