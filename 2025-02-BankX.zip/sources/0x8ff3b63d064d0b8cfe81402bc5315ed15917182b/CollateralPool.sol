// Sources flattened with hardhat v2.22.5 https://hardhat.org

// SPDX-License-Identifier: GPL-2.0-or-later AND GPL-3.0-or-later AND MIT

// File @openzeppelin/contracts/utils/Context.sol@v4.9.6

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v4.9.4) (utils/Context.sol)

pragma solidity ^0.8.0;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}


// File @openzeppelin/contracts/utils/math/SafeMath.sol@v4.9.6

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v4.9.0) (utils/math/SafeMath.sol)



// CAUTION
// This version of SafeMath should only be used with Solidity 0.8 or later,
// because it relies on the compiler's built in overflow checks.

/**
 * @dev Wrappers over Solidity's arithmetic operations.
 *
 * NOTE: `SafeMath` is generally not needed starting with Solidity 0.8, since the compiler
 * now has built in overflow checking.
 */
library SafeMath {
    /**
     * @dev Returns the addition of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryAdd(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        unchecked {
            uint256 c = a + b;
            if (c < a) return (false, 0);
            return (true, c);
        }
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function trySub(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        unchecked {
            if (b > a) return (false, 0);
            return (true, a - b);
        }
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, with an overflow flag.
     *
     * _Available since v3.4._
     */
    function tryMul(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        unchecked {
            // Gas optimization: this is cheaper than requiring 'a' not being zero, but the
            // benefit is lost if 'b' is also tested.
            // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522
            if (a == 0) return (true, 0);
            uint256 c = a * b;
            if (c / a != b) return (false, 0);
            return (true, c);
        }
    }

    /**
     * @dev Returns the division of two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryDiv(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        unchecked {
            if (b == 0) return (false, 0);
            return (true, a / b);
        }
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers, with a division by zero flag.
     *
     * _Available since v3.4._
     */
    function tryMod(uint256 a, uint256 b) internal pure returns (bool, uint256) {
        unchecked {
            if (b == 0) return (false, 0);
            return (true, a % b);
        }
    }

    /**
     * @dev Returns the addition of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `+` operator.
     *
     * Requirements:
     *
     * - Addition cannot overflow.
     */
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        return a + b;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting on
     * overflow (when the result is negative).
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return a - b;
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, reverting on
     * overflow.
     *
     * Counterpart to Solidity's `*` operator.
     *
     * Requirements:
     *
     * - Multiplication cannot overflow.
     */
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        return a * b;
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting on
     * division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator.
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return a / b;
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting when dividing by zero.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        return a % b;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting with custom message on
     * overflow (when the result is negative).
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {trySub}.
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     *
     * - Subtraction cannot overflow.
     */
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        unchecked {
            require(b <= a, errorMessage);
            return a - b;
        }
    }

    /**
     * @dev Returns the integer division of two unsigned integers, reverting with custom message on
     * division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        unchecked {
            require(b > 0, errorMessage);
            return a / b;
        }
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * reverting with custom message when dividing by zero.
     *
     * CAUTION: This function is deprecated because it requires allocating memory for the error
     * message unnecessarily. For custom revert reasons use {tryMod}.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     *
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        unchecked {
            require(b > 0, errorMessage);
            return a % b;
        }
    }
}


// File contracts/BEP20/IBEP20.sol

// Original license: SPDX_License_Identifier: MIT



interface IBEP20 {
  /**
   * @dev Returns the amount of tokens in existence.
   */
  function totalSupply() external view returns (uint256);

  /**
   * @dev Returns the amount of tokens owned by `account`.
   */
  function balanceOf(address account) external view returns (uint256);

  /**
   * @dev Moves `amount` tokens from the caller's account to `recipient`.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * Emits a {Transfer} event.
   */
  function transfer(address recipient, uint256 amount) external returns (bool);

  /**
   * @dev Returns the remaining number of tokens that `spender` will be
   * allowed to spend on behalf of `owner` through {transferFrom}. This is
   * zero by default.
   *
   * This value changes when {approve} or {transferFrom} are called.
   */
  function allowance(address _owner, address spender) external view returns (uint256);

  /**
   * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * IMPORTANT: Beware that changing an allowance with this method brings the risk
   * that someone may use both the old and the new allowance by unfortunate
   * transaction ordering. One possible solution to mitigate this race
   * condition is to first reduce the spender's allowance to 0 and set the
   * desired value afterwards:
   * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
   *
   * Emits an {Approval} event.
   */
  function approve(address spender, uint256 amount) external returns (bool);

  /**
   * @dev Moves `amount` tokens from `sender` to `recipient` using the
   * allowance mechanism. `amount` is then deducted from the caller's
   * allowance.
   *
   * Returns a boolean value indicating whether the operation succeeded.
   *
   * Emits a {Transfer} event.
   */
  function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);

  /**
   * @dev Emitted when `value` tokens are moved from one account (`from`) to
   * another (`to`).
   *
   * Note that `value` may be zero.
   */
  event Transfer(address indexed from, address indexed to, uint256 value);

  /**
   * @dev Emitted when the allowance of a `spender` for an `owner` is set by
   * a call to {approve}. `value` is the new allowance.
   */
  event Approval(address indexed owner, address indexed spender, uint256 value);
}


// File contracts/BEP20/BEP20Custom.sol

// Original license: SPDX_License_Identifier: MIT




// Due to compiling issues, _name, _symbol, and _decimals were removed


/**
 * @dev Implementation of the {IBEP20} interface.
 *
 * This implementation is agnostic to the way tokens are created. This means
 * that a supply mechanism has to be added in a derived contract using {_mint}.
 * For a generic mechanism see {BEP20Mintable}.
 *
 * TIP: For a detailed writeup see our guide
 * https://forum.zeppelin.solutions/t/how-to-implement-BEP20-supply-mechanisms/226[How
 * to implement supply mechanisms].
 *
 * We have followed general OpenZeppelin guidelines: functions revert instead
 * of returning `false` on failure. This behavior is nonetheless conventional
 * and does not conflict with the expectations of BEP20 applications.
 *
 * Additionally, an {Approval} event is emitted on calls to {transferFrom}.
 * This allows applications to reconstruct the allowance for all accounts just
 * by listening to said events. Other implementations of the EIP may not emit
 * these events, as it isn't required by the specification.
 *
 * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
 * functions have been added to mitigate the well-known issues around setting
 * allowances. See {IBEP20-approve}.
 */
contract BEP20Custom is Context, IBEP20 {
    using SafeMath for uint256;

    mapping (address => uint256) internal _balances;

    mapping (address => mapping (address => uint256)) internal _allowances;

    uint256 private _totalSupply;
    /**
     * @dev See {IBEP20-totalSupply}.
     */
    function totalSupply() public view override returns (uint256) {
        return _totalSupply;
    }

    /**
     * @dev See {IBEP20-balanceOf}.
     */
    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }

    /**
     * @dev See {IBEP20-transfer}.
     *
     * Requirements:
     *
     * - `recipient` cannot be the zero address.
     * - the caller must have a balance of at least `amount`.
     */
    function transfer(address to, uint256 amount) public virtual override returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, amount);
        return true;
    }

    /**
     * @dev See {IBEP20-allowance}.
     */
    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }

    /**
     * @dev See {IBEP20-approve}.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.approve(address spender, uint256 amount)
     */
    function approve(address spender, uint256 amount) public virtual override returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, amount);
        return true;
    }

    /**
     * @dev See {IBEP20-transferFrom}.
     *
     * Emits an {Approval} event indicating the updated allowance. This is not
     * required by the EIP. See the note at the beginning of {BEP20}.
     *
     * NOTE: Does not update the allowance if the current allowance
     * is the maximum `uint256`.
     *
     * Requirements:
     *
     * - `from` and `to` cannot be the zero address.
     * - `from` must have a balance of at least `amount`.
     * - the caller must have allowance for ``from``'s tokens of at least
     * `amount`.
     */
    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) public virtual override returns (bool) {
        address spender = _msgSender();
        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }

    /**
     * @dev Updates `owner` s allowance for `spender` based on spent `amount`.
     *
     * Does not update the allowance amount in case of infinite allowance.
     * Revert if not enough allowance is available.
     *
     * Might emit an {Approval} event.
     */
    function _spendAllowance(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= amount, "BEP20: insufficient allowance");
            unchecked {
                _approve(owner, spender, currentAllowance - amount);
            }
        }
    }

    /**
     * @dev Atomically increases the allowance granted to `spender` by the caller.
     *
     * This is an alternative to {approve} that can be used as a mitigation for
     * problems described in {IBEP20-approve}.
     *
     * Emits an {Approval} event indicating the updated allowance.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.
     */
    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, allowance(owner, spender) + addedValue);
        return true;
    }

    /**
     * @dev Atomically decreases the allowance granted to `spender` by the caller.
     *
     * This is an alternative to {approve} that can be used as a mitigation for
     * problems described in {IBEP20-approve}.
     *
     * Emits an {Approval} event indicating the updated allowance.
     *
     * Requirements:
     *
     * - `spender` cannot be the zero address.
     * - `spender` must have allowance for the caller of at least
     * `subtractedValue`.
     */
    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        address owner = _msgSender();
        uint256 currentAllowance = allowance(owner, spender);
        require(currentAllowance >= subtractedValue, "BEP20: decreased allowance below zero");
        unchecked {
            _approve(owner, spender, currentAllowance - subtractedValue);
        }

        return true;
    }

    /**
     * @dev Moves tokens `amount` from `sender` to `recipient`.
     *
     * This is internal function is equivalent to {transfer}, and can be used to
     * e.g. implement automatic token fees, slashing mechanisms, etc.
     *
     * Emits a {Transfer} event.
     *
     * Requirements:
     *
     * - `sender` cannot be the zero address.
     * - `recipient` cannot be the zero address.
     * - `sender` must have a balance of at least `amount`.
     */
    function _transfer(address from, address to, uint256 amount) internal virtual {
        require(from != address(0), "BEP20: transfer from the zero address");
        require(to != address(0), "BEP20: transfer to the zero address");

        _beforeTokenTransfer(from, to, amount);

        uint256 fromBalance = _balances[from];
        require(fromBalance >= amount, "BEP20: transfer amount exceeds balance");
        unchecked {
            _balances[from] = fromBalance - amount;
        }
        _balances[to] += amount;

        emit Transfer(from, to, amount);

        _afterTokenTransfer(from, to, amount);
    }

    /** @dev Creates `amount` tokens and assigns them to `account`, increasing
     * the total supply.
     *
     * Emits a {Transfer} event with `from` set to the zero address.
     *
     * Requirements
     *
     * - `to` cannot be the zero address.
     */
    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "BEP20: mint to the zero address");

        _beforeTokenTransfer(address(0), account, amount);

        _totalSupply += amount;
        _balances[account] += amount;
        emit Transfer(address(0), account, amount);

        _afterTokenTransfer(address(0), account, amount);
    }

    /**
     * @dev Destroys `amount` tokens from the caller.
     *
     * See {BEP20-_burn}.
     */
    function burn(uint256 amount) public virtual {
        _burn(_msgSender(), amount);
    }

    /**
     * @dev Destroys `amount` tokens from `account`, deducting from the caller's
     * allowance.
     *
     * See {BEP20-_burn} and {BEP20-allowance}.
     *
     * Requirements:
     *
     * - the caller must have allowance for `accounts`'s tokens of at least
     * `amount`.
     */
    function burnFrom(address account, uint256 amount) public virtual {
        uint256 decreasedAllowance = allowance(account, _msgSender()).sub(amount, "BEP20: burn amount exceeds allowance");

        _approve(account, _msgSender(), decreasedAllowance);
        _burn(account, amount);
    }


    /**
     * @dev Transfers 'tokens' from 'account' to origin address, reducing the
     * total supply.
     *
     * Emits a {Transfer} event with `to` set to the zero address.
     *
     * Requirements
     *
     * - `account` cannot be the zero address.
     * - `account` must have at least `amount` tokens.
     */
    function _burn(address account, uint256 amount) internal virtual {
       require(account != address(0), "BEP20: burn from the zero address");

        _beforeTokenTransfer(account, address(0), amount);

        uint256 accountBalance = _balances[account];
        require(accountBalance >= amount, "BEP20: burn amount exceeds balance");
        unchecked {
            _balances[account] = accountBalance - amount;
        }
        _totalSupply -= amount;

        emit Transfer(account, address(0), amount);

        _afterTokenTransfer(account, address(0), amount);
        
    }

    /**
     * @dev Sets `amount` as the allowance of `spender` over the `owner`s tokens.
     *
     * This is internal function is equivalent to `approve`, and can be used to
     * e.g. set automatic allowances for certain subsystems, etc.
     *
     * Emits an {Approval} event.
     *
     * Requirements:
     *
     * - `owner` cannot be the zero address.
     * - `spender` cannot be the zero address.
     */
    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        require(owner != address(0), "BEP20: approve from the zero address");
        require(spender != address(0), "BEP20: approve to the zero address");

        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    /**
     * @dev Destroys `amount` tokens from `account`.`amount` is then deducted
     * from the caller's allowance.
     *
     * See {_burn} and {_approve}.
     */
    function _burnFrom(address account, uint256 amount) internal virtual {
        _burn(account, amount);
        _approve(account, _msgSender(), _allowances[account][_msgSender()].sub(amount, "BEP20: burn amount exceeds allowance"));
    }

    /**
     * @dev Hook that is called before any transfer of tokens. This includes
     * minting and burning.
     *
     * Calling conditions:
     *
     * - when `from` and `to` are both non-zero, `amount` of `from`'s tokens
     * will be to transferred to `to`.
     * - when `from` is zero, `amount` tokens will be minted for `to`.
     * - when `to` is zero, `amount` of `from`'s tokens will be burned.
     * - `from` and `to` are never both zero.
     *
     * To learn more about hooks, head to xref:ROOT:using-hooks.adoc[Using Hooks].
     */
    function _beforeTokenTransfer(address from, address to, uint256 amount) internal virtual { }
    /**
     * @dev Hook that is called after any transfer of tokens. This includes
     * minting and burning.
     *
     * Calling conditions:
     *
     * - when `from` and `to` are both non-zero, `amount` of ``from``'s tokens
     * has been transferred to `to`.
     * - when `from` is zero, `amount` tokens have been minted for `to`.
     * - when `to` is zero, `amount` of ``from``'s tokens have been burned.
     * - `from` and `to` are never both zero.
     *
     * To learn more about hooks, head to xref:ROOT:extending-contracts.adoc#using-hooks[Using Hooks].
     */
    function _afterTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}
}


// File @openzeppelin/contracts/token/ERC20/IERC20.sol@v4.9.6

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v4.9.0) (token/ERC20/IERC20.sol)



/**
 * @dev Interface of the ERC20 standard as defined in the EIP.
 */
interface IERC20 {
    /**
     * @dev Emitted when `value` tokens are moved from one account (`from`) to
     * another (`to`).
     *
     * Note that `value` may be zero.
     */
    event Transfer(address indexed from, address indexed to, uint256 value);

    /**
     * @dev Emitted when the allowance of a `spender` for an `owner` is set by
     * a call to {approve}. `value` is the new allowance.
     */
    event Approval(address indexed owner, address indexed spender, uint256 value);

    /**
     * @dev Returns the amount of tokens in existence.
     */
    function totalSupply() external view returns (uint256);

    /**
     * @dev Returns the amount of tokens owned by `account`.
     */
    function balanceOf(address account) external view returns (uint256);

    /**
     * @dev Moves `amount` tokens from the caller's account to `to`.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transfer(address to, uint256 amount) external returns (bool);

    /**
     * @dev Returns the remaining number of tokens that `spender` will be
     * allowed to spend on behalf of `owner` through {transferFrom}. This is
     * zero by default.
     *
     * This value changes when {approve} or {transferFrom} are called.
     */
    function allowance(address owner, address spender) external view returns (uint256);

    /**
     * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * IMPORTANT: Beware that changing an allowance with this method brings the risk
     * that someone may use both the old and the new allowance by unfortunate
     * transaction ordering. One possible solution to mitigate this race
     * condition is to first reduce the spender's allowance to 0 and set the
     * desired value afterwards:
     * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
     *
     * Emits an {Approval} event.
     */
    function approve(address spender, uint256 amount) external returns (bool);

    /**
     * @dev Moves `amount` tokens from `from` to `to` using the
     * allowance mechanism. `amount` is then deducted from the caller's
     * allowance.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}


// File contracts/Oracle/AggregatorV3Interface.sol

// Original license: SPDX_License_Identifier: MIT


interface AggregatorV3Interface {

  function decimals() external view returns (uint8);
  function description() external view returns (string memory);
  function version() external view returns (uint256);

  // getRoundData and latestRoundData should both raise "No data present"
  // if they do not have data to report, instead of returning unset values
  // which could be misinterpreted as actual reported values.
  function getRoundData(uint80 _roundId)
    external
    view
    returns (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    );
  function latestRoundData()
    external
    view
    returns (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    );

}


// File contracts/Oracle/ChainlinkETHUSDPriceConsumer.sol

// Original license: SPDX_License_Identifier: MIT


contract ChainlinkETHUSDPriceConsumer {

    AggregatorV3Interface internal priceFeed;
    constructor() {
        priceFeed = AggregatorV3Interface(0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419);
    }

    /**
     * Returns the latest price
     */
    function getLatestPrice() public view returns (int) {
        (
            uint80 roundID
            , 
            int price,
            ,
            ,
            uint80 answeredInRound
        ) = priceFeed.latestRoundData();
        require(answeredInRound >= roundID);
        return price;
    }

    function getDecimals() public view returns (uint8) {
        return priceFeed.decimals();
    }
}


// File contracts/Oracle/ChainlinkXAGUSDPriceConsumer.sol

// Original license: SPDX_License_Identifier: MIT


contract ChainlinkXAGUSDPriceConsumer {

    AggregatorV3Interface internal priceFeed;
    constructor() {
        priceFeed = AggregatorV3Interface(0x379589227b15F1a12195D3f2d90bBc9F31f95235);
    }

    /**
     * Returns the latest price
     */
    function getLatestPrice() public view returns (int) {
        (
            uint80 roundID
            , 
            int price,
            ,
            ,
            uint80 answeredInRound
        ) = priceFeed.latestRoundData();
        require(answeredInRound >= roundID);
        return price;
    }

    function getDecimals() public view returns (uint8) {
        return priceFeed.decimals();
    }
}


// File contracts/XSD/Pools/Interfaces/IBankXWETHpool.sol

// Original license: SPDX_License_Identifier: MIT


interface IBankXWETHpool {
    function PERMIT_TYPEHASH() external pure returns (bytes32);
    function nonces(address owner) external view returns (uint);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function price0CumulativeLast() external view returns (uint);
    function price1CumulativeLast() external view returns (uint);
    function kLast() external view returns (uint);
    function collatDollarBalance() external returns(uint);
    function swap(uint amount0Out, uint amount1Out, address to) external;
    //function flush() external;
    function skim(address to) external;
    function sync() external;
}


// File contracts/XSD/Pools/Interfaces/ICollateralPool.sol

// Original license: SPDX_License_Identifier: MIT


interface ICollateralPool{
    function userProvideLiquidity(address to, uint amount1) external;
    function collat_XSD() external returns(uint);
    function mintAlgorithmicXSD(uint256 bankx_amount_d18, uint256 XSD_out_min) external;
    function collatDollarBalance() external returns(uint);
}


// File contracts/XSD/Pools/Interfaces/IXSDWETHpool.sol

// Original license: SPDX_License_Identifier: MIT


interface IXSDWETHpool {
    function PERMIT_TYPEHASH() external pure returns (bytes32);
    function nonces(address owner) external view returns (uint);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function price0CumulativeLast() external view returns (uint);
    function price1CumulativeLast() external view returns (uint);
    function kLast() external view returns (uint);
    function collatDollarBalance() external returns (uint);
    function swap(uint amount0Out, uint amount1Out, address to) external;
    //function flush() external;
    function skim(address to) external;
    function sync() external;
}


// File contracts/XSD/XSDStablecoin.sol

// Original license: SPDX_License_Identifier: GPL-2.0-or-later









contract XSDStablecoin is BEP20Custom {

    /* ========== STATE VARIABLES ========== */
    enum PriceChoice { XSD, BankX }
    ChainlinkETHUSDPriceConsumer private eth_usd_pricer;
    ChainlinkXAGUSDPriceConsumer private xag_usd_pricer;
    uint8 private eth_usd_pricer_decimals;
    uint8 private xag_usd_pricer_decimals;
    string public symbol;
    string public name;
    uint8 public constant decimals = 18;
    address public treasury; 
    address public collateral_pool_address;
    address public router;
    address public eth_usd_oracle_address;
    address public xag_usd_oracle_address;
    address public smartcontract_owner;
    IBankXWETHpool private bankxEthPool;
    IXSDWETHpool private xsdEthPool;
    uint256 public cap_rate;
    uint256 public genesis_supply; 

    // The addresses in this array are added by the oracle and these contracts are able to mint xsd
    address[] public xsd_pools_array;

    // Mapping is also used for faster verification
    mapping(address => bool) public xsd_pools; 

    // Constants for various precisions
    uint256 private constant PRICE_PRECISION = 1e6;

    /* ========== MODIFIERS ========== */

    modifier onlyPools() {
       require(xsd_pools[msg.sender] == true, "Only xsd pools can call this function");
        _;//check happens before the function is executed 
    } 

    modifier onlyByOwner(){
        require(msg.sender == smartcontract_owner, "You are not the owner");
        _;
    }

    modifier onlyByOwnerOrPool() {
        require(
            msg.sender == smartcontract_owner  
            || xsd_pools[msg.sender] == true, 
            "You are not the owner or a pool");
        _;
    }

    /* ========== CONSTRUCTOR ========== */

    constructor(
        string memory _name,
        string memory _symbol,
        uint256 _pool_amount,
        uint256 _genesis_supply,
        address _smartcontract_owner,
        address _treasury,
        uint256 _cap_rate
    ) {
        require((_smartcontract_owner != address(0))
                && (_treasury != address(0)), "Zero address detected"); 
        name = _name;
        symbol = _symbol;
        genesis_supply = _genesis_supply + _pool_amount;
        treasury = _treasury;
        _mint(_smartcontract_owner, _pool_amount);
        _mint(treasury, _genesis_supply);
        smartcontract_owner = _smartcontract_owner;
        cap_rate = _cap_rate;// Maximum mint amount
    }
    /* ========== VIEWS ========== */

    function eth_usd_price() public view returns (uint256) {
        return (uint256(eth_usd_pricer.getLatestPrice())*PRICE_PRECISION)/(uint256(10) ** eth_usd_pricer_decimals);
    }
    //silver price
    //hard coded value for testing on goerli
    function xag_usd_price() public view returns (uint256) {
        return (uint256(xag_usd_pricer.getLatestPrice())*PRICE_PRECISION)/(uint256(10) ** xag_usd_pricer_decimals);
    }

    /* ========== PUBLIC FUNCTIONS ========== */

    function creatorMint(uint256 amount) public onlyByOwner{
        require(genesis_supply+amount<cap_rate,"cap limit reached");
        super._mint(treasury,amount);
    }

    /* ========== RESTRICTED FUNCTIONS ========== */

    // Used by pools when user redeems
    function pool_burn_from(address b_address, uint256 b_amount) public onlyPools {
        super._burnFrom(b_address, b_amount);
        emit XSDBurned(b_address, msg.sender, b_amount);
    }

    // This function is what other xsd pools will call to mint new XSD 
    function pool_mint(address m_address, uint256 m_amount) public onlyPools {
        super._mint(m_address, m_amount);
        emit XSDMinted(msg.sender, m_address, m_amount);
    }
    

    // Adds collateral addresses supported, such as tether and busd, must be ERC20 
    function addPool(address pool_address) public onlyByOwner {
        require(pool_address != address(0), "Zero address detected");

        require(xsd_pools[pool_address] == false, "Address already exists");
        xsd_pools[pool_address] = true; 
        xsd_pools_array.push(pool_address);

        emit PoolAdded(pool_address);
    }

    // Remove a pool 
    function removePool(address pool_address) public onlyByOwner {
        require(pool_address != address(0), "Zero address detected");

        require(xsd_pools[pool_address] == true, "Address nonexistant");
        
        // Delete from the mapping
        delete xsd_pools[pool_address];

        // 'Delete' from the array by setting the address to 0x0
        for (uint i = 0; i < xsd_pools_array.length; i++){ 
            if (xsd_pools_array[i] == pool_address) {
                xsd_pools_array[i] = address(0); // This will leave a null in the array and keep the indices the same
                break;
            }
        }

        emit PoolRemoved(pool_address);
    }
// create a seperate function for users and the pool
    function burnpoolXSD(uint _xsdamount) public {
        require(msg.sender == router, "Only the router can access this function");
        require(totalSupply()-ICollateralPool(payable(collateral_pool_address)).collat_XSD()>_xsdamount, "uXSD has to be positive");
        super._burn(address(xsdEthPool),_xsdamount);
        xsdEthPool.sync();
        emit XSDBurned(msg.sender, address(this), _xsdamount);
    }
    // add burn function for users
    function burnUserXSD(uint _xsdamount) public {
        require(totalSupply()-ICollateralPool(payable(collateral_pool_address)).collat_XSD()>_xsdamount, "uXSD has to be positive");
        super._burn(msg.sender, _xsdamount);
        emit XSDBurned(msg.sender, address(this), _xsdamount);
    }

    function setTreasury(address _new_treasury) public onlyByOwner {
        require(_new_treasury != address(0), "Zero address detected");
        treasury = _new_treasury;
    }

    function setETHUSDOracle(address _eth_usd_oracle_address) public onlyByOwner {
        require(_eth_usd_oracle_address != address(0), "Zero address detected");

        eth_usd_oracle_address = _eth_usd_oracle_address;
        eth_usd_pricer = ChainlinkETHUSDPriceConsumer(eth_usd_oracle_address);
        eth_usd_pricer_decimals = eth_usd_pricer.getDecimals();

        emit ETHUSDOracleSet(_eth_usd_oracle_address);
    }
    
    function setXAGUSDOracle(address _xag_usd_oracle_address) public onlyByOwner {
        require(_xag_usd_oracle_address != address(0), "Zero address detected");

        xag_usd_oracle_address = _xag_usd_oracle_address;
        xag_usd_pricer = ChainlinkXAGUSDPriceConsumer(xag_usd_oracle_address);
        xag_usd_pricer_decimals = xag_usd_pricer.getDecimals();

        emit XAGUSDOracleSet(_xag_usd_oracle_address);
    }

    function setRouterAddress(address _router) external onlyByOwner {
        require(_router != address(0), "Zero address detected");
        router = _router;
    }

    // Sets the XSD_ETH Uniswap oracle address 
    function setXSDEthPool(address _xsd_pool_addr) public onlyByOwner {
        require(_xsd_pool_addr != address(0), "Zero address detected");
        xsdEthPool = IXSDWETHpool(_xsd_pool_addr); 

        emit XSDETHPoolSet(_xsd_pool_addr);
    }

    // Sets the BankX_ETH Uniswap oracle address 
    function setBankXEthPool(address _bankx_pool_addr) public onlyByOwner {
        require(_bankx_pool_addr != address(0), "Zero address detected");
        bankxEthPool = IBankXWETHpool(_bankx_pool_addr);

        emit BankXEthPoolSet(_bankx_pool_addr);
    }

    //sets the collateral pool address
    function setCollateralEthPool(address _collateral_pool_address) public onlyByOwner {
        require(_collateral_pool_address != address(0), "Zero address detected");
        collateral_pool_address = payable(_collateral_pool_address);
    }

    function setSmartContractOwner(address _smartcontract_owner) external{
        require(msg.sender == smartcontract_owner, "Only the smart contract owner can access this function");
        require(_smartcontract_owner != address(0), "Zero address detected");
        smartcontract_owner = _smartcontract_owner;
    }

    function renounceOwnership() external{
        require(msg.sender == smartcontract_owner, "Only the smart contract owner can access this function");
        smartcontract_owner = address(0);
    }

    
    /* ========== EVENTS ========== */

    // Track XSD burned
    event XSDBurned(address indexed from, address indexed to, uint256 amount);
    // Track XSD minted
    event XSDMinted(address indexed from, address indexed to, uint256 amount);
    event PoolAdded(address pool_address);
    event PoolRemoved(address pool_address);
    event RedemptionFeeSet(uint256 red_fee);
    event MintingFeeSet(uint256 min_fee);
    event ETHUSDOracleSet(address eth_usd_oracle_address);
    event XAGUSDOracleSet(address xag_usd_oracle_address);
    event PIDControllerSet(address _pid_controller);
    event XSDETHPoolSet(address xsd_pool_addr);
    event BankXEthPoolSet(address bankx_pool_addr);
}


// File contracts/BankX/BankXToken.sol

// Original license: SPDX_License_Identifier: MIT




contract BankXToken is BEP20Custom {

    /* ========== STATE VARIABLES ========== */

    string public name; 
    string public symbol;
    address public router;
    address public treasury;
    XSDStablecoin private XSD; 
    address public pool_address;
    uint256 public genesis_supply; 
    address public smartcontract_owner;
    uint8 public constant decimals = 18;
    /* ========== MODIFIERS ========== */

    modifier onlyPools() {
       require(XSD.xsd_pools(msg.sender) == true, "Only xsd pools can mint new BankX");
        _;
    } 
    
    modifier onlyByOwner() {
        require(msg.sender == smartcontract_owner, "You are not an owner");
        _;
    }

    /* ========== CONSTRUCTOR ========== */

    constructor(
        string memory _name,
        string memory _symbol,
        uint256 _pool_amount, 
        uint256 _genesis_supply,
        address _treasury,
        address _smartcontract_owner
    ) {
        require((_treasury != address(0)), "Zero address detected"); 
        name = _name;
        symbol = _symbol;
        genesis_supply = _genesis_supply + _pool_amount;
        treasury = _treasury;
        _mint(_msgSender(), _pool_amount);
        _mint(treasury, _genesis_supply);
        smartcontract_owner = _smartcontract_owner;

    
    }

    /* ========== RESTRICTED FUNCTIONS ========== */

    function setPool(address new_pool) external onlyByOwner {
        require(new_pool != address(0), "Zero address detected");

        pool_address = new_pool;
    }

    function setTreasury(address new_treasury) external onlyByOwner {
        require(new_treasury != address(0), "Treasury address cannot be 0");
        treasury = new_treasury;
    }

    function setRouterAddress(address _router) external onlyByOwner {
        require(_router != address(0), "Zero address detected");
        router = _router;
    }
    
    function setXSDAddress(address xsd_contract_address) external onlyByOwner {
        require(xsd_contract_address != address(0), "Zero address detected");

        XSD = XSDStablecoin(xsd_contract_address);

        emit XSDAddressSet(xsd_contract_address);
    }
    
    function mint(address to, uint256 amount) public onlyPools {
        _mint(to, amount);
        emit BankXMinted(address(this), to, amount);
    }
    
    function genesisSupply() public view returns(uint256){
        return genesis_supply;
    }

    // This function is what other xsd pools will call to mint new BankX (similar to the XSD mint) 
    function pool_mint(address m_address, uint256 m_amount) external onlyPools  {        
        super._mint(m_address, m_amount);
        emit BankXMinted(address(this), m_address, m_amount);
    }

    // This function is what other xsd pools will call to burn BankX 
    function pool_burn_from(address b_address, uint256 b_amount) external onlyPools {

        super._burnFrom(b_address, b_amount);
        emit BankXBurned(b_address, address(this), b_amount);
    }
    //burn bankx from the pool when bankx is inflationary
    function burnpoolBankX(uint _bankx_amount) public {
        require(msg.sender == router, "Only Router can access this function");
        require(totalSupply()>genesis_supply,"BankX must be deflationary");
        super._burn(pool_address, _bankx_amount);
        IBankXWETHpool(pool_address).sync();
        emit BankXBurned(msg.sender, address(this), _bankx_amount);
    }

    function setSmartContractOwner(address _smartcontract_owner) external{
        require(msg.sender == smartcontract_owner, "Only the smart contract owner can access this function");
        require(_smartcontract_owner != address(0), "Zero address detected");
        smartcontract_owner = _smartcontract_owner;
    }

    function renounceOwnership() external{
        require(msg.sender == smartcontract_owner, "Only the smart contract owner can access this function");
        smartcontract_owner = address(0);
    }
    /* ========== EVENTS ========== */

    // Track BankX burned
    event BankXBurned(address indexed from, address indexed to, uint256 amount);

    // Track BankX minted
    event BankXMinted(address indexed from, address indexed to, uint256 amount);
    event XSDAddressSet(address addr);
}


// File @openzeppelin/contracts/security/ReentrancyGuard.sol@v4.9.6

// Original license: SPDX_License_Identifier: MIT
// OpenZeppelin Contracts (last updated v4.9.0) (security/ReentrancyGuard.sol)



/**
 * @dev Contract module that helps prevent reentrant calls to a function.
 *
 * Inheriting from `ReentrancyGuard` will make the {nonReentrant} modifier
 * available, which can be applied to functions to make sure there are no nested
 * (reentrant) calls to them.
 *
 * Note that because there is a single `nonReentrant` guard, functions marked as
 * `nonReentrant` may not call one another. This can be worked around by making
 * those functions `private`, and then adding `external` `nonReentrant` entry
 * points to them.
 *
 * TIP: If you would like to learn more about reentrancy and alternative ways
 * to protect against it, check out our blog post
 * https://blog.openzeppelin.com/reentrancy-after-istanbul/[Reentrancy After Istanbul].
 */
abstract contract ReentrancyGuard {
    // Booleans are more expensive than uint256 or any type that takes up a full
    // word because each write operation emits an extra SLOAD to first read the
    // slot's contents, replace the bits taken up by the boolean, and then write
    // back. This is the compiler's defense against contract upgrades and
    // pointer aliasing, and it cannot be disabled.

    // The values being non-zero value makes deployment a bit more expensive,
    // but in exchange the refund on every call to nonReentrant will be lower in
    // amount. Since refunds are capped to a percentage of the total
    // transaction's gas, it is best to keep them low in cases like this one, to
    // increase the likelihood of the full refund coming into effect.
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;

    uint256 private _status;

    constructor() {
        _status = _NOT_ENTERED;
    }

    /**
     * @dev Prevents a contract from calling itself, directly or indirectly.
     * Calling a `nonReentrant` function from another `nonReentrant`
     * function is not supported. It is possible to prevent this from happening
     * by making the `nonReentrant` function external, and making it call a
     * `private` function that does the actual work.
     */
    modifier nonReentrant() {
        _nonReentrantBefore();
        _;
        _nonReentrantAfter();
    }

    function _nonReentrantBefore() private {
        // On the first call to nonReentrant, _status will be _NOT_ENTERED
        require(_status != _ENTERED, "ReentrancyGuard: reentrant call");

        // Any calls to nonReentrant after this point will fail
        _status = _ENTERED;
    }

    function _nonReentrantAfter() private {
        // By storing the original value once again, a refund is triggered (see
        // https://eips.ethereum.org/EIPS/eip-2200)
        _status = _NOT_ENTERED;
    }

    /**
     * @dev Returns true if the reentrancy guard is currently set to "entered", which indicates there is a
     * `nonReentrant` function in the call stack.
     */
    function _reentrancyGuardEntered() internal view returns (bool) {
        return _status == _ENTERED;
    }
}


// File @uniswap/lib/contracts/libraries/TransferHelper.sol@v4.0.1-alpha

// Original license: SPDX_License_Identifier: GPL-3.0-or-later

pragma solidity >=0.6.0;

// helper methods for interacting with ERC20 tokens and sending ETH that do not consistently return true/false
library TransferHelper {
    function safeApprove(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('approve(address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            'TransferHelper::safeApprove: approve failed'
        );
    }

    function safeTransfer(
        address token,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transfer(address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            'TransferHelper::safeTransfer: transfer failed'
        );
    }

    function safeTransferFrom(
        address token,
        address from,
        address to,
        uint256 value
    ) internal {
        // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
        (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
        require(
            success && (data.length == 0 || abi.decode(data, (bool))),
            'TransferHelper::transferFrom: transferFrom failed'
        );
    }

    function safeTransferETH(address to, uint256 value) internal {
        (bool success, ) = to.call{value: value}(new bytes(0));
        require(success, 'TransferHelper::safeTransferETH: ETH transfer failed');
    }
}


// File contracts/BEP20/IWBNB.sol

// Original license: SPDX_License_Identifier: MIT


interface IWBNB {
    function deposit() external payable;
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address src, address dst, uint wad) external returns (bool);
    function balanceOf(address account) external view returns (uint256);
    function withdraw(uint) external;
}


// File contracts/Oracle/Interfaces/IPIDController.sol

// Original license: SPDX_License_Identifier: MIT


interface IPIDController{
    function bucket1() external view returns (bool);
    function bucket2() external view returns (bool);
    function bucket3() external view returns (bool);
    function diff1() external view returns (uint);
    function diff2() external view returns (uint);
    function diff3() external view returns (uint);
    function amountpaid1() external view returns (uint);
    function amountpaid2() external view returns (uint);
    function amountpaid3() external view returns (uint);
    function bankx_updated_price() external view returns (uint);
    function xsd_updated_price() external view returns (uint);
    function global_collateral_ratio() external view returns(uint);
    function interest_rate() external view returns(uint);
    function systemCalculations(bytes[] calldata priceUpdateData) external;
    struct PriceCheck{
        uint256 lastpricecheck;
        bool pricecheck;
    }
    function neededWETH() external view returns(uint);
    function neededBankX() external view returns(uint);
    function lastPriceCheck(address user) external view returns (PriceCheck memory info);
    function setPriceCheck(address sender) external;
    function amountPaidBankXWETH(uint ethvalue) external;
    function amountPaidXSDWETH(uint ethvalue) external;
    function amountPaidCollateralPool(uint ethvalue) external;
}


// File contracts/Utils/Initializable.sol

// Original license: SPDX_License_Identifier: MIT

pragma solidity >=0.4.24;


/**
 * @title Initializable
 *
 * @dev Helper contract to support initializer functions. To use it, replace
 * the constructor with a function that has the `initializer` modifier.
 * WARNING: Unlike constructors, initializer functions must be manually
 * invoked. This applies both to deploying an Initializable contract, as well
 * as extending an Initializable contract via inheritance.
 * WARNING: When used with inheritance, manual care must be taken to not invoke
 * a parent initializer twice, or ensure that all initializers are idempotent,
 * because this is not dealt with automatically as with constructors.
 */
contract Initializable {

  /**
   * @dev Indicates that the contract has been initialized.
   */
  bool private initialized;

  /**
   * @dev Indicates that the contract is in the process of being initialized.
   */
  bool private initializing;

  /**
   * @dev Modifier to use in the initializer function of a contract.
   */
  modifier initializer() {
    require(initializing || isConstructor() || !initialized, "Contract instance has already been initialized");

    bool isTopLevelCall = !initializing;
    if (isTopLevelCall) {
      initializing = true;
      initialized = true;
    }

    _;

    if (isTopLevelCall) {
      initializing = false;
    }
  }

  /// @dev Returns true if and only if the function is running in the constructor
  function isConstructor() private view returns (bool) {
    // extcodesize checks the size of the code stored in an address, and
    // address returns the current address. Since the code is still not
    // deployed when running a constructor, any checks on its code size will
    // yield zero, making it an effective way to detect if a contract is
    // under construction or not.
    address self = address(this);
    uint256 cs;
    assembly { cs := extcodesize(self) }
    return cs == 0;
  }

  // Reserved storage space to allow for layout changes in the future.
  uint256[50] private ______gap;
}


// File contracts/XSD/Pools/CollateralPoolLibrary.sol

// Original license: SPDX_License_Identifier: MIT


library CollateralPoolLibrary {
    // ================ Structs ================
    // Needed to lower stack size
    /**
     * @dev Parameters for the BankX buyback process.
     * @param excess_collateral_dollar_value_d18 Excess collateral in dollar value (scaled by 1e18).
     * @param bankx_price_usd Price of BankX in USD.
     * @param col_price_usd Price of collateral in USD.
     * @param BankX_amount Amount of BankX to be bought back.
     */
    struct BuybackBankX_Params {
        uint256 excess_collateral_dollar_value_d18;
        uint256 bankx_price_usd;
        uint256 col_price_usd;
        uint256 BankX_amount;
    }

    /**
     * @dev Parameters for the XSD buyback process.
     * @param excess_collateral_dollar_value_d18 Excess collateral in dollar value (scaled by 1e18).
     * @param xsd_price_usd Price of XSD in USD.
     * @param col_price_usd Price of collateral in USD.
     * @param XSD_amount Amount of XSD to be bought back.
     */
    struct BuybackXSD_Params {
        uint256 excess_collateral_dollar_value_d18;
        uint256 xsd_price_usd;
        uint256 col_price_usd;
        uint256 XSD_amount;
    }

    // ================ Functions ================

    /**
     * @dev Calculates the interest accumulated over time for a given XSD amount.
     * @param XSD_amount Amount of XSD.
     * @param silver_price Price of silver in USD.
     * @param rate Base rate of interest.
     * @param accum_interest Accumulated interest.
     * @param interest_rate Current interest rate.
     * @param time Timestamp of the last update.
     * @param amount Principal amount.
     * @return Updated accumulated interest, interest rate, timestamp, and amount.
     */
    function calcMintInterest(uint256 XSD_amount,uint256 silver_price,uint256 rate, uint256 accum_interest, uint256 interest_rate, uint256 time, uint256 amount) public view returns(uint256, uint256, uint256, uint256) {
        uint256 gram_price = (silver_price*(1e4))/(311035);
        if(time == 0){
            interest_rate = rate;
            amount = XSD_amount;
            time = block.timestamp;
        }
        else{
            uint delta_t = block.timestamp - time;
            delta_t = delta_t/(86400); 
            accum_interest = accum_interest+((amount*gram_price*interest_rate*delta_t)/(365*(1e12)));
        
            interest_rate = (amount*interest_rate) + (XSD_amount*rate);
            amount = amount+XSD_amount;
            interest_rate = interest_rate/amount;
            time = block.timestamp;
        }
        return (
            accum_interest,
            interest_rate,
            time, 
            amount
        );
    }

    /**
     * @dev Calculates the redemption interest for a given XSD amount.
     * @param XSD_amount Amount of XSD.
     * @param silver_price Price of silver in USD.
     * @param accum_interest Accumulated interest.
     * @param interest_rate Current interest rate.
     * @param time Timestamp of the last update.
     * @param amount Principal amount.
     * @return Updated accumulated interest, interest rate, timestamp, and amount.
     */
    function calcRedemptionInterest(uint256 XSD_amount,uint256 silver_price, uint256 accum_interest, uint256 interest_rate, uint256 time, uint256 amount) public view returns(uint256, uint256, uint256, uint256){
        uint256 gram_price = (silver_price*(1e4))/(311035);
        uint delta_t = block.timestamp - time;
        delta_t = delta_t/(86400);
        accum_interest = accum_interest+((amount*gram_price*interest_rate*delta_t)/(365*(1e12)));
        amount = amount - XSD_amount;
        time = block.timestamp;
        return (
            accum_interest,
            interest_rate,
            time, 
            amount
        );
    }

    /**
     * @dev Calculates the amount of collateral equivalent to the buyback of BankX.
     * @param params Struct containing parameters for BankX buyback.
     * @return Amount of collateral equivalent.
     */
    function calcBuyBackBankX(BuybackBankX_Params memory params) public pure returns (uint256) {
        // If the total collateral value is higher than the amount required at the current collateral ratio then buy back up to the possible BankX with the desired collateral
        require(params.excess_collateral_dollar_value_d18 > 0, "No excess collateral to buy back!");

        // Make sure not to take more than is available
        uint256 bankx_dollar_value_d18 = (params.BankX_amount*params.bankx_price_usd);
        require((bankx_dollar_value_d18/1e6) <= params.excess_collateral_dollar_value_d18, "You are trying to buy back more than the excess!");

        // Get the equivalent amount of collateral based on the market value of BankX provided 
        uint256 collateral_equivalent_d18 = (bankx_dollar_value_d18)/(params.col_price_usd);

        return (
            collateral_equivalent_d18
        );
    }

    /**
     * @dev Calculates the amount of collateral equivalent to the buyback of XSD.
     * @param params Struct containing parameters for XSD buyback.
     * @return Amount of collateral equivalent.
     */
    function calcBuyBackXSD(BuybackXSD_Params memory params) public pure returns (uint256) {
        require(params.excess_collateral_dollar_value_d18 > 0, "No excess collateral to buy back!");

        uint256 xsd_dollar_value_d18 = params.XSD_amount*(params.xsd_price_usd);
        require((xsd_dollar_value_d18/1e6) <= params.excess_collateral_dollar_value_d18, "You are trying to buy more than the excess!");

        uint256 collateral_equivalent_d18 = (xsd_dollar_value_d18)/(params.col_price_usd);

        return (
            collateral_equivalent_d18
        );
    }
}


// File contracts/XSD/Pools/CollateralPool.sol

// Original license: SPDX_License_Identifier: MIT
/*
BBBBBBBBBBBBBBBBB                                       kkkkkkkk        XXXXXXX       XXXXXXX
B::::::::::::::::B                                      k::::::k        X:::::X       X:::::X
B::::::BBBBBB:::::B                                     k::::::k        X:::::X       X:::::X
BB:::::B     B:::::B                                    k::::::k        X::::::X     X::::::X
  B::::B     B:::::B  aaaaaaaaaaaaa  nnnn  nnnnnnnnn    k:::::k kkkkkkk XXX:::::X   X:::::XXX
  B::::B     B:::::B  a::::::::::::a n:::nn::::::::nn   k:::::k k:::::k     X:::::X X:::::X
  B::::BBBBBB:::::B   aaaaaaaaa:::::an::::::::::::::nn  k:::::k k:::::k      X:::::X:::::X
  B:::::::::::::BB             a::::ann:::::::::::::::n k:::::k k:::::k       X:::::::::X
  B::::BBBBBB:::::B    aaaaaaa:::::a  n:::::nnnn:::::n k::::::k:::::k         X:::::::::X
  B::::B     B:::::B  aa::::::::::::a  n::::n    n::::n k:::::::::::k        X:::::X:::::X
  B::::B     B:::::B a::::aaaa::::::a  n::::n    n::::n k:::::::::::k       X:::::X X:::::X
  B::::B     B:::::Ba::::a    a:::::a  n::::n    n::::n k::::::k:::::k   XXX:::::X   X:::::XXX
BB:::::BBBBBB::::::Ba::::a    a:::::a  n::::n    n::::nk::::::k k:::::k  X::::::X     X::::::X
B:::::::::::::::::B a:::::aaaa::::::a  n::::n    n::::nk::::::k k:::::k  X:::::X       X:::::X
B::::::::::::::::B   a::::::::::aa:::a n::::n    n::::nk::::::k k:::::k  X:::::X       X:::::X
BBBBBBBBBBBBBBBBB     aaaaaaaaaa  aaaa nnnnnn    nnnnnnkkkkkkkk kkkkkkk  XXXXXXX       XXXXXXX


                                          Currency Creators Manifesto

Our world faces an urgent crisis of currency manipulation, theft and inflation.  Under the current system, currency is controlled by and benefits elite families, governments and large banking institutions.  We believe currencies should be minted by and benefit the individual, not the establishment.  It is time to take back the control of and the freedom that money can provide.

BankX is rebuilding the legacy banking system from the ground up by providing you with the capability to create currency and be in complete control of wealth creation with a concept we call ‘Individual Created Digital Currency’ (ICDC). You own the collateral.  You mint currency.  You earn interest.  You leverage without the risk of liquidation.  You stake to earn even more returns.  All of this is done with complete autonomy and decentralization.  BankX has built a stablecoin for Individual Freedom.

BankX is the antidote for the malevolent financial system bringing in a new future of freedom where you are in complete control with no middlemen, bank or central bank between you and your finances. This capability to create currency and be in complete control of wealth creation will be in the hands of every individual that uses BankX.

By 2030, we will rid the world of the corrupt, tyrannical and incompetent banking system replacing it with a system where billions of people will be in complete control of their financial future.  Everyone will be given ultimate freedom to use their assets to create currency, earn interest and multiply returns to accomplish their individual goals.  The mission of BankX is to be the first to mint $1 trillion in stablecoin. 

We will bring about this transformation by attracting people that believe what we believe.  We will partner with other blockchain protocols and build decentralized applications that drive even more usage.  Finally, we will deploy a private network that is never connected to the Internet to communicate between counterparties, that allows for blockchain-to-blockchain interoperability and stores private keys and cryptocurrency wallets.  Our ecosystem, network and platform has never been seen in the market and provides us with a long term sustainable competitive advantage.

We value individual freedom.
We believe in financial autonomy.
We are anti-establishment.
We envision a future of self-empowerment.

*/











/**
 * @title CollateralPool
 * @dev This contract manages the collateral for the XSD stablecoin. It handles minting and redemption of XSD, both 1:1 and fractional.
 * It also controls the interest calculation for minting and redemption processes.
 */
contract CollateralPool is Initializable,ReentrancyGuard {
    /* ========== STATE VARIABLES ========== */

    /// @notice Address of the WETH contract
    address public WETH;

    /// @notice Address of the smart contract owner
    address public smartcontract_owner;

    /// @notice Address of the XSD contract
    address public xsd_contract_address;

    /// @notice Address of the BankX contract
    address public bankx_contract_address;

    /// @notice Address of the XSD-WETH pool
    address public xsdweth_pool;

    /// @notice Address of the BankX-WETH pool
    address public bankxweth_pool;

    /// @notice Address of the PID controller contract
    address public pid_address;

    /// @notice Instance of the BankX token
    BankXToken private BankX;

    /// @notice Instance of the XSD stablecoin
    XSDStablecoin private XSD;

    /// @notice Instance of the PID controller
    IPIDController private pid_controller;

    /// @notice Collateralized XSD in the pool
    uint256 public collat_XSD;

    /// @notice Flag indicating if minting is paused
    bool public mint_paused;

    /// @notice Flag indicating if redeeming is paused
    bool public redeem_paused;

    /// @notice Flag indicating if buybacks are paused
    bool public buyback_paused;

    /// @notice Structure to store minting information
    struct MintInfo {
        uint256 accum_interest; // accumulated interest from previous mints
        uint256 interest_rate; // interest rate at that particular timestamp
        uint256 time; // last timestamp
        uint256 amount; // XSD amount minted
    }

    /// @notice Mapping to store mint information for each address
    mapping(address => MintInfo) public mintMapping; 

    /// @notice Mapping to store BankX token balances for redemption
    mapping(address => uint256) public redeemBankXTokenBalances;

    /// @notice Mapping to store BankX balances for redemption
    mapping(address => uint256) public redeemBankXBalances;

    /// @notice Mapping to store collateral balances for redemption
    mapping(address => uint256) public redeemCollateralBalances;

    /// @notice Mapping to store vesting timestamps
    mapping(address => uint256) public vestingtimestamp;

    /// @notice Unclaimed collateral in the pool
    uint256 public unclaimedPoolCollateral;

    /// @notice Unclaimed BankX in the pool
    uint256 public unclaimedPoolBankX;

    /// @notice Equivalent collateral value in d18
    uint256 public collateral_equivalent_d18;

    /// @notice Count of minted BankX
    uint256 public bankx_minted_count;

    /// @notice Mapping to store the last redeemed block for each address
    mapping(address => uint256) public lastRedeemed;

    /// @notice Block delay to prevent flash mint attacks
    uint256 public block_delay;

    /* ========== MODIFIERS ========== */

    /**
     * @dev Ensures the transaction is executed before the specified deadline
     * @param deadline The time by which the transaction must be completed
     */
    modifier ensure(uint deadline) {
        require(deadline >= block.timestamp, 'COLLATERALPOOL:EXPIRED');
        _;
    }

    /**
     * @dev Ensures the function is only called by the contract owner
     */
    modifier onlyByOwner() {
        require(msg.sender == smartcontract_owner, "COLLATERALPOOL:FORBIDDEN");
        _;
    }

    /**
     * @dev Ensures minting is not paused
     */
    modifier mintPaused() {
        require(!mint_paused, "COLLATERALPOOL:PAUSED");
        _;
    }

    /**
     * @dev Ensures redeeming is not paused
     */
    modifier redeemPaused() {
        require(!redeem_paused, "COLLATERALPOOL:PAUSED");
        _;
    }

    /**
     * @dev Ensures a block delay is maintained between mint and redeem actions
     */
    modifier blockDelay(){
        require(((pid_controller.lastPriceCheck(msg.sender).lastpricecheck + block_delay) <= block.number) && (pid_controller.lastPriceCheck(msg.sender).pricecheck), "COLLATERALPOOL:BLOCKDELAY");
        _;
        pid_controller.setPriceCheck(msg.sender);
    }
 
    /* ========== FUNCTIONS ========== */

    /**
     * @notice Initialize the CollateralPool contract
     * @dev This function sets the initial state variables
     * @param _weth Address of the WETH contract
     * @param _smartcontract_owner Address of the contract owner
     * @param _xsd_contract_address Address of the XSD contract
     * @param _bankx_contract_address Address of the BankX contract
     * @param _xsdweth_pool Address of the XSD-WETH pool
     * @param _bankxweth_pool Address of the BankX-WETH pool
     * @param _pid_address Address of the PID controller contract
     */
    function initialize(
        address _weth,
        address _smartcontract_owner,
        address _xsd_contract_address,
        address _bankx_contract_address,
        address _xsdweth_pool,
        address _bankxweth_pool,
        address _pid_address
    ) public initializer{
        WETH = _weth;
        smartcontract_owner = _smartcontract_owner;
        xsd_contract_address = _xsd_contract_address;
        bankx_contract_address = _bankx_contract_address;
        xsdweth_pool = _xsdweth_pool;
        bankxweth_pool = _bankxweth_pool;
        pid_address = _pid_address;

        BankX = BankXToken(bankx_contract_address);
        XSD = XSDStablecoin(xsd_contract_address);
        pid_controller = IPIDController(pid_address);
        block_delay = 2;
    }

    /* ========== VIEWS ========== */
/**
 * @dev This function is used to receive ETH from the WETH contract.
 * It ensures that only the WETH contract can send ETH to this contract.
 */
receive() external payable {
    assert(msg.sender == WETH);
}

/**
 * @dev Returns the dollar value of collateral held in this XSD pool.
 * @return uint256 The dollar value of the collateral in the pool.
 */
function collatDollarBalance() public view returns (uint256) {
    return ((IWBNB(WETH).balanceOf(address(this)) * XSD.eth_usd_price()) / (1e6));
}

/**
 * @dev Returns the value of excess collateral held in this XSD pool,
 * compared to what is needed to maintain the global collateral ratio.
 * @return uint256 The value of excess collateral in the pool.
 */
function availableExcessCollatDV() public view returns (uint256) {
    uint256 global_collateral_ratio = pid_controller.global_collateral_ratio();
    uint256 global_collat_value = collatDollarBalance();

    if (global_collateral_ratio > (1e6)) global_collateral_ratio = (1e6); // Handles an overcollateralized contract with CR > 1
    uint256 required_collat_dollar_value_d18 = ((collat_XSD) * global_collateral_ratio * (XSD.xag_usd_price() * (1e4)) / (311035)) / (1e12); // Calculates collateral needed to back each 1 XSD with $1 of collateral at current collat ratio
    if ((global_collat_value - unclaimedPoolCollateral) > required_collat_dollar_value_d18) return (global_collat_value - unclaimedPoolCollateral - required_collat_dollar_value_d18);
    else return 0;
}

/* ========== INTERNAL FUNCTIONS ======== */

/**
 * @dev Calculates and updates the interest for minting XSD.
 * @param xsd_amount The amount of XSD minted.
 * @param sender The address of the sender who minted XSD.
 */
function mintInterestCalc(uint xsd_amount, address sender) internal {
    (mintMapping[sender].accum_interest, mintMapping[sender].interest_rate, mintMapping[sender].time, mintMapping[sender].amount) = CollateralPoolLibrary.calcMintInterest(xsd_amount, XSD.xag_usd_price(), pid_controller.interest_rate(), mintMapping[sender].accum_interest, mintMapping[sender].interest_rate, mintMapping[sender].time, mintMapping[sender].amount);
}

/**
 * @dev Calculates and updates the interest for redeeming XSD.
 * @param xsd_amount The amount of XSD redeemed.
 * @param sender The address of the sender who redeemed XSD.
 */
function redeemInterestCalc(uint xsd_amount, address sender) internal {
    (mintMapping[sender].accum_interest, mintMapping[sender].interest_rate, mintMapping[sender].time, mintMapping[sender].amount) = CollateralPoolLibrary.calcRedemptionInterest(xsd_amount, XSD.xag_usd_price(), mintMapping[sender].accum_interest, mintMapping[sender].interest_rate, mintMapping[sender].time, mintMapping[sender].amount);
}


    /* ========== PUBLIC FUNCTIONS ========== */
    /**
     * @notice Mints XSD tokens by providing collateral in ETH.
     * @param XSD_amount Minimum amount of XSD tokens expected.
     * @param deadline The deadline timestamp by which the transaction should be confirmed.
     * @dev Requires ETH collateral to be greater than 0 and global collateral ratio to be at least 1.
     */
    function mint1t1XSD(uint256 XSD_amount, uint256 deadline) external ensure(deadline) payable nonReentrant mintPaused{
        require(msg.value>0, "Invalid collateral amount");
        require(pid_controller.global_collateral_ratio() >= (1e6), "Collateral ratio must be >= 1");
        uint neededWETH = (XSD_amount * pid_controller.neededWETH())/(1e6); // precision of 1e18
        require(msg.value >= neededWETH,"INSUFFICIENT INPUT: WETH");
        mintInterestCalc(XSD_amount,msg.sender);
        IWBNB(WETH).deposit{value: msg.value}();
        assert(IWBNB(WETH).transfer(address(this), msg.value));
        collat_XSD = collat_XSD + XSD_amount;
        XSD.pool_mint(msg.sender, XSD_amount);
    }
/**
     * @notice Mints XSD tokens algorithmically using BankX tokens.
     * @param bankx_amount_d18 Amount of BankX tokens to be used for minting.
     * @param XSD_amount Minimum amount of XSD tokens expected.
     * @param deadline The deadline timestamp by which the transaction should be confirmed.
     * @dev Requires global collateral ratio to be 0.
     */
    function mintAlgorithmicXSD(uint256 bankx_amount_d18, uint256 XSD_amount, uint256 deadline) external ensure(deadline) nonReentrant mintPaused blockDelay{
        require(pid_controller.global_collateral_ratio() == 0, "Collateral ratio must be 0");
        uint neededBankX = (XSD_amount * pid_controller.neededBankX())/(1e6); // precision of 1e18
        require(bankx_amount_d18 >= neededBankX,"INSUFFICIENT INPUT: BankX");
        mintInterestCalc(XSD_amount,msg.sender);
        collat_XSD = collat_XSD + XSD_amount;
        bankx_minted_count = bankx_minted_count + bankx_amount_d18;
        BankX.pool_burn_from(msg.sender, bankx_amount_d18);
        XSD.pool_mint(msg.sender, XSD_amount);
    }
    /**
     * @notice Mints XSD tokens fractionally using both BankX tokens and ETH collateral.
     * @param XSD_amount Minimum amount of XSD tokens expected.
     * @param bankx_amount amount of bankx tokens required for mint
     * @param deadline The deadline timestamp by which the transaction should be confirmed.
     * @dev Requires collateral ratio to be greater than 0% and less than 100%.
     */
    function mintFractionalXSD(uint256 XSD_amount,uint bankx_amount, uint256 deadline) external ensure(deadline) payable nonReentrant mintPaused blockDelay{
        uint256 global_collateral_ratio = pid_controller.global_collateral_ratio();
        require(global_collateral_ratio < (1e6) && global_collateral_ratio > 0, "Collateral ratio needs to be between .000001 and .999999");
        uint neededWETH = (XSD_amount * pid_controller.neededWETH())/(1e6); // precision of 1e18
        uint neededBankX = (XSD_amount * pid_controller.neededBankX())/(1e6); // precision of 1e18
        require(bankx_amount >= neededBankX,"INSUFFICIENT INPUT: BankX");
        require(msg.value >= neededWETH,"INSUFFICIENT INPUT: WETH");
        mintInterestCalc(XSD_amount,msg.sender);
        bankx_minted_count = bankx_minted_count + neededBankX;
        BankX.pool_burn_from(msg.sender, neededBankX);
        IWBNB(WETH).deposit{value: msg.value}();
        assert(IWBNB(WETH).transfer(address(this), msg.value));
        collat_XSD = collat_XSD + XSD_amount;
        XSD.pool_mint(msg.sender, XSD_amount);
    }
        /**
     * @dev Redeem XSD for collateral with 1:1 backing.
     * @param XSD_amount The amount of XSD to redeem.
     * @param COLLATERAL_out_min The minimum amount of collateral to receive.
     * @param deadline The timestamp by which the redemption must be completed.
     */
    function redeem1t1XSD(uint256 XSD_amount, uint256 COLLATERAL_out_min, uint256 deadline) external ensure(deadline) nonReentrant redeemPaused blockDelay{
        require(!pid_controller.bucket3(), "Cannot withdraw in times of deficit");
        require(pid_controller.global_collateral_ratio() == (1e6), "Collateral ratio must be == 1");
        require(XSD_amount<=mintMapping[msg.sender].amount, "OVERREDEMPTION ERROR");
        uint neededWETH = (XSD_amount * pid_controller.neededWETH())/(1e6); // precision of 1e18
        uint weth_dollar_value = (neededWETH * XSD.eth_usd_price())/1e6; // precision of 1e18
        // convert xsd to $ and then to collateral value
        uint total_xsd_amount = mintMapping[msg.sender].amount;
        uint CollateralAmount = (unclaimedPoolCollateral*1e6)/XSD.eth_usd_price();
        require(neededWETH <= (IWBNB(WETH).balanceOf(address(this))-CollateralAmount), "Not enough collateral in pool");
        require(COLLATERAL_out_min <= neededWETH, "INSUFFICIENT OUTPUT [collateral]");
        redeemInterestCalc(XSD_amount, msg.sender);
        uint current_accum_interest = (XSD_amount*mintMapping[msg.sender].accum_interest)/total_xsd_amount;
        redeemBankXBalances[msg.sender] = (redeemBankXBalances[msg.sender]+current_accum_interest);
        redeemCollateralBalances[msg.sender] = redeemCollateralBalances[msg.sender]+weth_dollar_value;
        unclaimedPoolCollateral = unclaimedPoolCollateral+weth_dollar_value;
        lastRedeemed[msg.sender] = block.number;
        uint256 neededBankX = (current_accum_interest*1e6)/pid_controller.bankx_updated_price();
        unclaimedPoolBankX = (unclaimedPoolBankX+neededBankX);
        redeemBankXTokenBalances[msg.sender] = (redeemBankXTokenBalances[msg.sender]+neededBankX);
        collat_XSD -= XSD_amount;
        mintMapping[msg.sender].accum_interest = (mintMapping[msg.sender].accum_interest - current_accum_interest);
        XSD.pool_burn_from(msg.sender, XSD_amount);
        BankX.pool_mint(address(this), neededBankX);
    }

    /**
     * @dev Redeem fractional XSD for collateral and BankX.
     * @param XSD_amount The amount of XSD to redeem.
     * @param BankX_out_min The minimum amount of BankX to receive.
     * @param COLLATERAL_out_min The minimum amount of collateral to receive.
     * @param deadline The timestamp by which the redemption must be completed.
     */
    function redeemFractionalXSD(uint256 XSD_amount, uint256 BankX_out_min, uint256 COLLATERAL_out_min, uint256 deadline) external ensure(deadline) nonReentrant redeemPaused blockDelay{
        require(!pid_controller.bucket3(), "Cannot withdraw in times of deficit");
        require(XSD_amount<=mintMapping[msg.sender].amount, "OVERREDEMPTION ERROR");
        uint neededWETH = (XSD_amount * pid_controller.neededWETH())/(1e6); // precision of 1e18
        uint neededBankX = (XSD_amount * pid_controller.neededBankX())/(1e6); // precision of 1e18
        uint weth_dollar_value = (neededWETH * XSD.eth_usd_price())/1e6; // precision of 1e18
        uint bankx_dollar_value = (neededBankX * pid_controller.bankx_updated_price())/1e6; //precision of 1e18
        uint CollateralAmount = (unclaimedPoolCollateral*1e6)/XSD.eth_usd_price();
        require(neededWETH <= (IWBNB(WETH).balanceOf(address(this))-CollateralAmount), "Not enough collateral in pool");
        require(COLLATERAL_out_min <= neededWETH, "INSUFFICIENT OUTPUT [collateral]");
        require(BankX_out_min <= neededBankX, "INSUFFICIENT OUTPUT [BankX]");
        redeemCollateralBalances[msg.sender] = redeemCollateralBalances[msg.sender]+weth_dollar_value;
        unclaimedPoolCollateral = unclaimedPoolCollateral+weth_dollar_value;
        lastRedeemed[msg.sender] = block.number;
        uint total_xsd_amount = mintMapping[msg.sender].amount;
        redeemInterestCalc(XSD_amount, msg.sender);
        uint current_accum_interest = (XSD_amount*mintMapping[msg.sender].accum_interest)/total_xsd_amount;
        redeemBankXBalances[msg.sender] = redeemBankXBalances[msg.sender]+current_accum_interest;
        neededBankX = neededBankX + ((current_accum_interest*1e6)/pid_controller.bankx_updated_price());
        mintMapping[msg.sender].accum_interest = mintMapping[msg.sender].accum_interest - current_accum_interest;
        redeemBankXBalances[msg.sender] = redeemBankXBalances[msg.sender]+bankx_dollar_value;
        unclaimedPoolBankX = unclaimedPoolBankX+neededBankX;
        redeemBankXTokenBalances[msg.sender] = (redeemBankXTokenBalances[msg.sender]+neededBankX);
        collat_XSD -= XSD_amount;    
        XSD.pool_burn_from(msg.sender, XSD_amount);
        BankX.pool_mint(address(this), neededBankX);
    }

    /**
     * @dev Redeem XSD for BankX with 0% collateral backing.
     * @param XSD_amount The amount of XSD to redeem.
     * @param BankX_out_min The minimum amount of BankX to receive.
     * @param deadline The timestamp by which the redemption must be completed.
     */
    function redeemAlgorithmicXSD(uint256 XSD_amount, uint256 BankX_out_min, uint256 deadline) external ensure(deadline) nonReentrant redeemPaused blockDelay{
        require(!pid_controller.bucket3(), "Cannot withdraw in times of deficit");
        require(XSD_amount<=mintMapping[msg.sender].amount, "OVERREDEMPTION ERROR");
        require(pid_controller.global_collateral_ratio() == 0, "Collateral ratio must be 0"); 
        uint neededBankX = (XSD_amount * pid_controller.neededBankX())/(1e6); // precision of 1e18
        uint bankx_dollar_value = (neededBankX * pid_controller.bankx_updated_price())/1e6; //precision of 1e18
        lastRedeemed[msg.sender] = block.number;
        uint total_xsd_amount = mintMapping[msg.sender].amount;
        require(BankX_out_min <= neededBankX, "INSUFFICIENT OUTPUT [BankX]");
        redeemInterestCalc(XSD_amount, msg.sender);
        uint current_accum_interest = XSD_amount*mintMapping[msg.sender].accum_interest/total_xsd_amount; //precision of 6
        redeemBankXBalances[msg.sender] = (redeemBankXBalances[msg.sender]+current_accum_interest);
        neededBankX = neededBankX + ((current_accum_interest*1e6)/pid_controller.bankx_updated_price());
        mintMapping[msg.sender].accum_interest = (mintMapping[msg.sender].accum_interest - current_accum_interest);
        redeemBankXBalances[msg.sender] = redeemBankXBalances[msg.sender]+bankx_dollar_value;
        unclaimedPoolBankX = (unclaimedPoolBankX+neededBankX);
        redeemBankXTokenBalances[msg.sender] = (redeemBankXTokenBalances[msg.sender]+neededBankX);
        collat_XSD -= XSD_amount;
        XSD.pool_burn_from(msg.sender, XSD_amount);
        BankX.pool_mint(address(this), neededBankX);
    }


        /**
     * @notice After a redemption happens, this function transfers the newly minted BankX and owed collateral 
     *         from this pool contract to the user. Redemption is split into two functions to prevent flash loans 
     *         from being able to take out XSD/collateral from the system, use an AMM to trade the new price, and 
     *         then mint back into the system.
     * @dev Uses Checks-Effects-Interactions pattern to prevent reentrancy attacks.
     */
    function collectRedemption() external nonReentrant redeemPaused blockDelay {
        require(!pid_controller.bucket3(), "Cannot withdraw in times of deficit");
        require(((lastRedeemed[msg.sender] + (block_delay)) <= block.number), "Must wait for redeem specific block_delay");
        uint CollateralDollarAmount;
        uint BankXAmount;
        uint CollateralAmount;

        // Use Checks-Effects-Interactions pattern
        if (redeemBankXBalances[msg.sender] > 0) {
            BankXAmount = redeemBankXTokenBalances[msg.sender];
            redeemBankXBalances[msg.sender] = 0;
            redeemBankXTokenBalances[msg.sender] = 0;
            unclaimedPoolBankX = unclaimedPoolBankX - BankXAmount;
            TransferHelper.safeTransfer(address(BankX), msg.sender, BankXAmount);
        }
        
        if (redeemCollateralBalances[msg.sender] > 0) {
            CollateralDollarAmount = redeemCollateralBalances[msg.sender];
            CollateralAmount = (CollateralDollarAmount * 1e6) / XSD.eth_usd_price();
            redeemCollateralBalances[msg.sender] = 0;
            unclaimedPoolCollateral = unclaimedPoolCollateral - CollateralDollarAmount;
            IWBNB(WETH).withdraw(CollateralAmount); // try to unwrap eth in the redeem
            TransferHelper.safeTransferETH(msg.sender, CollateralAmount);
        }
    }

    /**
     * @notice Allows a BankX holder to have the protocol buy back BankX with excess collateral value from a 
     *         desired collateral pool. This can also happen if the collateral ratio > 1.
     *         Adds XSD as a burn option while uXSD value is positive.
     * @param BankX_amount The amount of BankX to be burned.
     * @param COLLATERAL_out_min The minimum amount of collateral to be received.
     * @param deadline The time by which the transaction must be confirmed.
     * @dev Requires that the buyback is not paused. Uses CollateralPoolLibrary to calculate the collateral equivalent.
     */
    function buyBackBankX(uint256 BankX_amount, uint256 COLLATERAL_out_min, uint256 deadline) external blockDelay ensure(deadline) {
        require(!buyback_paused, "Buyback Paused");
        CollateralPoolLibrary.BuybackBankX_Params memory input_params = CollateralPoolLibrary.BuybackBankX_Params(
            availableExcessCollatDV(),
            pid_controller.bankx_updated_price(),
            XSD.eth_usd_price(),
            BankX_amount
        );

        (collateral_equivalent_d18) = (CollateralPoolLibrary.calcBuyBackBankX(input_params));

        require(COLLATERAL_out_min <= collateral_equivalent_d18, "INSUFFICIENT OUTPUT");
        // Give the sender their desired collateral and burn the BankX
        BankX.pool_burn_from(msg.sender, BankX_amount);
        TransferHelper.safeTransfer(address(WETH), address(this), collateral_equivalent_d18);
        IWBNB(WETH).withdraw(collateral_equivalent_d18);
        TransferHelper.safeTransferETH(msg.sender, collateral_equivalent_d18);
    }

    /**
     * @notice Allows a user to buy back XSD with excess collateral value from a desired collateral pool.
     *         This can happen if the collateral ratio > 1.
     * @param XSD_amount The amount of XSD to be burned.
     * @param collateral_out_min The minimum amount of collateral to be received.
     * @param deadline The time by which the transaction must be confirmed.
     * @dev Requires that the buyback is not paused. Uses CollateralPoolLibrary to calculate the collateral equivalent.
     */
    function buyBackXSD(uint256 XSD_amount, uint256 collateral_out_min, uint256 deadline) external blockDelay ensure(deadline) {
        require(!buyback_paused, "Buyback Paused");
        if (XSD_amount != 0) require((XSD.totalSupply() + XSD_amount) > collat_XSD, "uXSD MUST BE POSITIVE");

        CollateralPoolLibrary.BuybackXSD_Params memory input_params = CollateralPoolLibrary.BuybackXSD_Params(
            availableExcessCollatDV(),
            pid_controller.xsd_updated_price(),
            XSD.eth_usd_price(),
            XSD_amount
        );

        (collateral_equivalent_d18) = (CollateralPoolLibrary.calcBuyBackXSD(input_params));

        require(collateral_out_min <= collateral_equivalent_d18, "INSUFFICIENT OUTPUT");
        XSD.pool_burn_from(msg.sender, XSD_amount);
        TransferHelper.safeTransfer(address(WETH), address(this), collateral_equivalent_d18);
        IWBNB(WETH).withdraw(collateral_equivalent_d18);
        TransferHelper.safeTransferETH(msg.sender, collateral_equivalent_d18);
    }

    /**
     * @notice Sets pool parameters such as block delay and pause statuses.
     * @param new_block_delay The new block delay value.
     * @param _mint_paused Boolean indicating whether minting is paused.
     * @param _redeem_paused Boolean indicating whether redeeming is paused.
     * @param _buyback_paused Boolean indicating whether buyback is paused.
     */
    function setPoolParameters(uint256 new_block_delay, bool _mint_paused, bool _redeem_paused, bool _buyback_paused) external onlyByOwner {
        block_delay = new_block_delay;
        mint_paused = _mint_paused;
        redeem_paused = _redeem_paused;
        buyback_paused = _buyback_paused;
        emit PoolParametersSet(new_block_delay,_mint_paused, _redeem_paused, _buyback_paused);
    }

    /**
     * @notice Sets a new PID controller address.
     * @param new_pid_address The address of the new PID controller.
     */
    function setPIDController(address new_pid_address) external onlyByOwner {
        pid_controller = IPIDController(new_pid_address);
        pid_address = new_pid_address;
    }

    /**
     * @notice Sets the address of the smart contract owner.
     * @param _smartcontract_owner The address of the new smart contract owner.
     * @dev The new owner address cannot be zero.
     */
    function setSmartContractOwner(address _smartcontract_owner) external onlyByOwner {
        require(_smartcontract_owner != address(0), "COLLATERALPOOL:ZEROCHECK");
        smartcontract_owner = _smartcontract_owner;
    }

    /**
     * @notice Renounces ownership of the contract.
     */
    function renounceOwnership() external onlyByOwner {
        smartcontract_owner = address(0);
    }

    /**
     * @notice Resets various contract addresses.
     * @param _xsd_contract_address The address of the XSD contract.
     * @param _bankx_contract_address The address of the BankX contract.
     * @param _bankxweth_pool The address of the BankX/WETH pool.
     * @param _xsdweth_pool The address of the XSD/WETH pool.
     * @param _WETH The address of the WETH contract.
     * @dev Ensures that none of the provided addresses are zero.
     */
    function resetAddresses(address _xsd_contract_address,
        address _bankx_contract_address,
        address _bankxweth_pool,
        address _xsdweth_pool,
        address _WETH) external onlyByOwner {
        require(
            (_xsd_contract_address != address(0))
            && (_bankx_contract_address != address(0))
            && (_WETH != address(0))
            && (_bankxweth_pool != address(0))
            && (_xsdweth_pool != address(0))
        , "COLLATERALPOOL:ZEROCHECK"); 
        XSD = XSDStablecoin(_xsd_contract_address);
        BankX = BankXToken(_bankx_contract_address);
        xsd_contract_address = _xsd_contract_address;
        bankx_contract_address = _bankx_contract_address;
        xsdweth_pool = _xsdweth_pool;
        bankxweth_pool = _bankxweth_pool;
        WETH = _WETH;
    }

    /* ========== EVENTS ========== */

    /**
     * @notice Emitted when pool parameters are set.
     * @param new_block_delay The new block delay value.
     */
    event PoolParametersSet(uint256 new_block_delay, bool _mint_paused, bool _redeem_paused, bool _buyback_paused);
}