// SPDX-License-Identifier: MIT
pragma solidity >=0.6.0 <0.8.0;

import "@openzeppelin/contracts-upgradeable/math/SafeMathUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";

import "../interface/ICommunity.sol";
import "../lib/AddressLib.sol";
import "hardhat/console.sol";

contract Community is ICommunity, AccessControlUpgradeable {
    using AddressLib for address;
    using SafeMathUpgradeable for uint256;

    mapping(address => MemberInfo) public members;
    bytes32 public constant ADMIN = keccak256("ADMIN");
    bytes32 public constant OPERATORS = keccak256("OPERATORS");
    address public constant ORIGIN = address(0x1);
    address public commRoot;

    modifier onlyRole(bytes32 role) {
        require(hasRole(role, msg.sender), string(abi.encodePacked("Require role ", role)));
        _;
    }

    event Joined(address indexed member, address indexed referrer, uint256 level);
    event Imported(address indexed member, address indexed referrer, address indexed operator);

    function initialize(address relationImporter, address _commRoot) external initializer {
        console.log("initialize", msg.sender);

        _setupRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _setRoleAdmin(ADMIN, ADMIN);
        _setRoleAdmin(OPERATORS, ADMIN);

        _setupRole(ADMIN, msg.sender);
        // _setupRole(OPERATORS, msg.sender);
        _setupRole(OPERATORS, relationImporter);

        // init comm root
        commRoot = _commRoot;
        members[_commRoot].referrer = ORIGIN;
        members[_commRoot].level = 1;
        emit Joined(_commRoot, ORIGIN, 1);
    }

    function importRelations(address[] calldata _referrers, address[] calldata _members) external onlyRole(OPERATORS) {
        require(_referrers.length == _members.length, "Length not match");
        address operator = msg.sender;
        for (uint256 idx = 0; idx < _referrers.length; idx++) {
            _importRelation(_referrers[idx], _members[idx], operator);
        }
    }

    function importRelation(address _referer, address _member) external onlyRole(OPERATORS) {
        _importRelation(_referer, _member, msg.sender);
    }

    function _importRelation(address _referer, address _member, address _operator) internal {
        _join(_referer, _member);
        emit Imported(_member, _referer, _operator);
    }

    function join(address _referer) external {
        address user = msg.sender;
        _join(_referer, user);
    }

    function _join(address _referer, address _member) internal {
        if (_referer == address(0)) {
            _referer = commRoot;
        }
        require(!_referer.isContract() && (!_member.isContract()), "Forbidden contract");

        require(_referer != _member, "Illegal relation");
        require(_member != address(0) && _member != ORIGIN, "Illegal member");
        require(_referer != address(0) && _referer != ORIGIN, "Illegal referrer");

        require(members[_member].referrer == address(0), "Already joined");
        require(members[_referer].referrer != address(0), "Referrer is not member");
        //        require(members[_referer].referrer != _member, "Relation exists");

        uint256 level = members[_referer].level.add(1);

        members[_member].referrer = _referer;
        members[_member].level = level;
        members[_referer].referrals.push(_member);
        emit Joined(_member, _referer, level);
    }

    function referrals(address _member, uint256 _start, uint256 _offset)
        external
        view
        returns (uint256 length, address[] memory referrals_)
    {
        length = members[_member].referrals.length;
        require(_start + _offset <= length, "Exceeds length");

        referrals_ = new address[](_offset);
        for (uint256 index = 0; index < referrals_.length; index++) {
            referrals_[index] = members[_member].referrals[index + _start];
        }
    }

    function referrerOf(address member) external view override returns (address) {
        return members[member].referrer;
    }
    function getCredit(address member) external view override returns (uint256) {
        return members[member].credit;
    }

    function batchGetCredit(address[] calldata members_) external view returns (uint256[] memory credits_) {
        credits_ = new uint256[](members_.length);
        for (uint256 idx = 0; idx < members_.length; idx++) {
            credits_[idx] = members[members_[idx]].credit;
        }
    }
    
    function updateCredit(address member, uint256 credit) external onlyRole(OPERATORS) {
        members[member].credit = credit;
    }

    function batchUpdateCredit(address[] calldata members_, uint256[] calldata credits_) external onlyRole(OPERATORS) {
        require(members_.length == credits_.length, "Length not match");
        for (uint256 idx = 0; idx < members_.length; idx++) {
            members[members_[idx]].credit = credits_[idx];
        }
    }
}
