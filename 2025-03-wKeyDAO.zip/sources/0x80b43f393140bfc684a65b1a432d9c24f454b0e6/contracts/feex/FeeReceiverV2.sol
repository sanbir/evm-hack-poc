// SPDX-License-Identifier: MIT
pragma solidity >=0.6.0 <0.8.0;

import "@openzeppelin/contracts-upgradeable/math/SafeMathUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC20/IERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC20/SafeERC20Upgradeable.sol";
import "../lib/AddressLib.sol";

interface IPancakePair {
    function token0() external view returns (address);

    function token1() external view returns (address);

    function getReserves()
        external
        view
        returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);

    function skim(address to) external;

    function sync() external;
}

interface IPancakeRouter02 {
    function factory() external pure returns (address);

    function quote(
        uint256 amountA,
        uint256 reserveA,
        uint256 reserveB
    ) external pure returns (uint256 amountB);

     function addLiquidity(
        address tokenA,
        address tokenB,
        uint amountADesired,
        uint amountBDesired,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB, uint liquidity);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;
}

interface IPancakeFactory {
    function getPair(
        address tokenA,
        address tokenB
    ) external view returns (address pair);

    function createPair(
        address tokenA,
        address tokenB
    ) external returns (address pair);
}

interface IBurnable {
    function burn(uint256 amount) external;
}

interface IMint {
    function mint(address recipient, uint256 amount) external;
}

interface IERC20Metadata is IERC20Upgradeable {
    /**
     * @dev Returns the name of the token.
     */
    function name() external view returns (string memory);

    /**
     * @dev Returns the symbol of the token.
     */
    function symbol() external view returns (string memory);

    /**
     * @dev Returns the decimals places of the token.
     */
    function decimals() external view returns (uint8);
}

interface ILotteryPool {
    function onReceivedFunds(uint256 _amount) external;

    function participateLottery(address _user, uint256 _tickets) external;
}

contract FeeReceiverV2 is OwnableUpgradeable {
    using SafeERC20Upgradeable for IERC20Upgradeable;
    using SafeMathUpgradeable for uint256;
    using AddressLib for address;

    uint256 public constant PRECISION = 100e3;

    // 60% of fee to recipient
    uint256 public partFeeRatio;

    // divide 30% fee to 5 parts

    // 20%
    uint256 public lampFundRatio;
    // 30%
    uint256 public discipleFundRatio;
    // 20%
    uint256 public investmentRatio;
    // 30%
    uint256 public marketRatio;

    address public lampFundRecipient;
    address public discipleFundRecipient;
    address public investmentRecipient;
    address public marketRecipient;

    address public tao;
    address public usdt;

    address public turbine;

    address public router;
    address public pair;

    uint256 public rewardThresholdInUsdt;
    mapping(address => uint8) public bridges;

    enum RatioType {
        PartFee,
        LampFund,
        DiscipleFund,
        Investment,
        Market,
        StableCoinFund
    }

    enum RecipientType {
        LampFund,
        DiscipleFund,
        Investment,
        Market,
        StableCoinFund
    }

    event SwapError(string errorMessage);
    event SwapErrorBytes(bytes errorBytes);

    event RatioChanged(RatioType ratioType, uint256 ratio);
    event RecipientChanged(RecipientType recipientType, address recipient);

    function initialize(
        address _router,
        address _tao,
        address _usdt,
        address _turbine,
        address _lampFundRecipient,
        address _discipleFundRecipient,
        address _investmentRecipient,
        address _marketRecipient
    ) external initializer {
        __Ownable_init();
        tao = _tao;
        usdt = _usdt;
        router = _router;
        pair = IPancakeFactory(IPancakeRouter02(_router).factory()).getPair(
            _tao,
            _usdt
        );
        turbine = _turbine;

        lampFundRecipient = _lampFundRecipient;
        discipleFundRecipient = _discipleFundRecipient;
        investmentRecipient = _investmentRecipient;
        marketRecipient = _marketRecipient;

        rewardThresholdInUsdt = (10 ** IERC20Metadata(usdt).decimals()).mul(97);

        // 60% of fee to recipient
        partFeeRatio = (PRECISION * 6) / 10;

        // divide 30% fee to 5 parts
        // 20%
        lampFundRatio = (PRECISION * 2) / 10;
        // 30%
        discipleFundRatio = (PRECISION * 3) / 10;
        // 20%
        investmentRatio = (PRECISION * 2) / 10;
        // 30%
        marketRatio = (PRECISION * 3) / 10;
    }

    function _onlyToken() internal view {
        require(msg.sender == tao, "Only tao");
    }

    function _onlyPortal() internal view {
        require(msg.sender == turbine || msg.sender == tao, "Only portal");
    }

    function setRatio(RatioType ratioType, uint256 ratio) external onlyOwner {
        require(ratio <= PRECISION, "FeeReceiver: exceeds precision");
        if (ratioType == RatioType.PartFee) {
            partFeeRatio = ratio;
        } else if (ratioType == RatioType.LampFund) {
            lampFundRatio = ratio;
        } else if (ratioType == RatioType.DiscipleFund) {
            discipleFundRatio = ratio;
        } else if (ratioType == RatioType.Investment) {
            investmentRatio = ratio;
        } else if (ratioType == RatioType.Market) {
            marketRatio = ratio;
        }

        emit RatioChanged(ratioType, ratio);
    }

    function setRecipient(
        RecipientType recipientType,
        address recipient
    ) external onlyOwner {
        require(recipient != address(0), "FeeReceiver: zero address");
        if (recipientType == RecipientType.LampFund) {
            lampFundRecipient = recipient;
        } else if (recipientType == RecipientType.DiscipleFund) {
            discipleFundRecipient = recipient;
        } else if (recipientType == RecipientType.Investment) {
            investmentRecipient = recipient;
        } else if (recipientType == RecipientType.Market) {
            marketRecipient = recipient;
        }

        emit RecipientChanged(recipientType, recipient);
    }

    function setRewardThresholdInUsdt(
        uint256 _rewardThresholdInUsdt
    ) external onlyOwner {
        rewardThresholdInUsdt = _rewardThresholdInUsdt;
    }

    function triggerSwapFeeForLottery(uint256 amount) external {
        _onlyToken();

        uint256 balOfTao = IERC20Upgradeable(tao).balanceOf(address(this));
        uint256 toSwap = amount >= balOfTao ? balOfTao : amount;
        _doSwapForLottery(toSwap);
    }

    function _doSwapForLottery(uint256 toSwap) private {
        if (toSwap > 0) {
            address[] memory path = new address[](2);
            path[0] = tao;
            path[1] = usdt;

            IERC20Upgradeable uToken = IERC20Upgradeable(usdt);
            IERC20Upgradeable(tao).safeIncreaseAllowance(router, toSwap);

            try
                IPancakeRouter02(router)
                    .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                        toSwap,
                        0,
                        path,
                        address(this),
                        block.timestamp
                    )
            {
                uint256 usdtAmount = uToken.balanceOf(address(this));
                if (usdtAmount > 0) {
                    uint256 lampFund = usdtAmount.mul(lampFundRatio).div(
                        PRECISION
                    );
                    if (lampFund > 0) {
                        uToken.safeTransfer(lampFundRecipient, lampFund);
                    }

                    uint256 discipleFund = usdtAmount
                        .mul(discipleFundRatio)
                        .div(PRECISION);
                    if (discipleFund > 0) {
                        uToken.safeTransfer(
                            discipleFundRecipient,
                            discipleFund
                        );
                    }

                    uint256 investmentFund = usdtAmount
                        .mul(investmentRatio)
                        .div(PRECISION);
                    if (investmentFund > 0) {
                        uToken.safeTransfer(
                            investmentRecipient,
                            investmentFund
                        );
                    }
                    uint256 marketFund = usdtAmount.mul(marketRatio).div(
                        PRECISION
                    );
                    if (marketFund > 0) {
                        uToken.safeTransfer(marketRecipient, marketFund);
                    }
                }
            } catch Error(string memory errorMessage) {
                emit SwapError(errorMessage);
            } catch (bytes memory errorData) {
                emit SwapErrorBytes(errorData);
            }
        }
    }

    function participate(address user, uint256 qualifiedPaid) external {}

    function beyondLotteryThreshold(
        uint256 usdtValue
    ) internal view returns (bool) {
        return usdtValue >= rewardThresholdInUsdt;
    }

    function usdtValueOfTao(uint256 amount) public view returns (uint256) {
        if (amount == 0) return 0;

        IPancakePair iPair = IPancakePair(pair);
        (uint112 reserve0, uint112 reserve1, ) = iPair.getReserves();
        if (iPair.token0() == tao) {
            return IPancakeRouter02(router).quote(amount, reserve0, reserve1);
        } else {
            return IPancakeRouter02(router).quote(amount, reserve1, reserve0);
        }
    }

    function bridge(uint ohmAmount, uint usdtAmount) external returns (uint lp) {
        require(canBridge(msg.sender),"FeeReceiver: can't bridge");

        IERC20Upgradeable(tao).transferFrom(msg.sender, address(this), ohmAmount);
        IERC20Upgradeable(usdt).transferFrom(msg.sender, address(this), usdtAmount);

        IERC20Upgradeable(tao  ).approve(router, ohmAmount);
        IERC20Upgradeable(usdt).approve(router, usdtAmount);

        IPancakeRouter02(router).addLiquidity(tao, usdt, ohmAmount, usdtAmount, 0, 0, address(this), block.timestamp);
        lp = IERC20Upgradeable(pair).balanceOf(address(this));
        IERC20Upgradeable(pair).transfer(msg.sender, lp);
    }

    function canBridge(address _addr) public view returns (bool) {
        return bridges[_addr]==1;
    }

    function setBridge(address _addr, uint8 _status) external onlyOwner {
        bridges[_addr] = _status;
    }
}
