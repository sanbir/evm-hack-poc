// File: contracts\extensions\interfaces\IV3Oracle.sol

pragma solidity >=0.5.0;
pragma experimental ABIEncoderV2;

interface IV3Oracle {
	function oraclePriceSqrtX96(address token0, address token1) external returns (uint256);
}

// File: contracts\extensions\interfaces\AggregatorInterface.sol

pragma solidity >=0.5.0;

interface AggregatorInterface {
  function decimals() external view returns (uint8);
  function latestAnswer() external view returns (int256);
  function latestTimestamp() external view returns (uint256);
  function latestRound() external view returns (uint256);
  function description() external view returns (string memory);
}

// File: contracts\interfaces\IERC20.sol

pragma solidity >=0.5.0;

interface IERC20 {
    event Approval(address indexed owner, address indexed spender, uint value);
    event Transfer(address indexed from, address indexed to, uint value);

    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
    function totalSupply() external view returns (uint);
    function balanceOf(address owner) external view returns (uint);
    function allowance(address owner, address spender) external view returns (uint);

    function approve(address spender, uint value) external returns (bool);
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address from, address to, uint value) external returns (bool);
}

// File: contracts\libraries\SafeMath.sol

pragma solidity =0.5.16;

// From https://github.com/OpenZeppelin/openzeppelin-contracts/blob/master/contracts/math/Math.sol
// Subject to the MIT license.

/**
 * @dev Wrappers over Solidity's arithmetic operations with added overflow
 * checks.
 *
 * Arithmetic operations in Solidity wrap on overflow. This can easily result
 * in bugs, because programmers usually assume that an overflow raises an
 * error, which is the standard behavior in high level programming languages.
 * `SafeMath` restores this intuition by reverting the transaction when an
 * operation overflows.
 *
 * Using this library instead of the unchecked operations eliminates an entire
 * class of bugs, so it's recommended to use it always.
 */
library SafeMath {
    /**
     * @dev Returns the addition of two unsigned integers, reverting on overflow.
     *
     * Counterpart to Solidity's `+` operator.
     *
     * Requirements:
     * - Addition cannot overflow.
     */
    function add(uint256 a, uint256 b) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, "SafeMath: addition overflow");

        return c;
    }

    /**
     * @dev Returns the addition of two unsigned integers, reverting with custom message on overflow.
     *
     * Counterpart to Solidity's `+` operator.
     *
     * Requirements:
     * - Addition cannot overflow.
     */
    function add(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        uint256 c = a + b;
        require(c >= a, errorMessage);

        return c;
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting on underflow (when the result is negative).
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     * - Subtraction cannot underflow.
     */
    function sub(uint256 a, uint256 b) internal pure returns (uint256) {
        return sub(a, b, "SafeMath: subtraction underflow");
    }

    /**
     * @dev Returns the subtraction of two unsigned integers, reverting with custom message on underflow (when the result is negative).
     *
     * Counterpart to Solidity's `-` operator.
     *
     * Requirements:
     * - Subtraction cannot underflow.
     */
    function sub(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b <= a, errorMessage);
        uint256 c = a - b;

        return c;
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, reverting on overflow.
     *
     * Counterpart to Solidity's `*` operator.
     *
     * Requirements:
     * - Multiplication cannot overflow.
     */
    function mul(uint256 a, uint256 b) internal pure returns (uint256) {
        // Gas optimization: this is cheaper than requiring 'a' not being zero, but the
        // benefit is lost if 'b' is also tested.
        // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522
        if (a == 0) {
            return 0;
        }

        uint256 c = a * b;
        require(c / a == b, "SafeMath: multiplication overflow");

        return c;
    }

    /**
     * @dev Returns the multiplication of two unsigned integers, reverting on overflow.
     *
     * Counterpart to Solidity's `*` operator.
     *
     * Requirements:
     * - Multiplication cannot overflow.
     */
    function mul(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        // Gas optimization: this is cheaper than requiring 'a' not being zero, but the
        // benefit is lost if 'b' is also tested.
        // See: https://github.com/OpenZeppelin/openzeppelin-contracts/pull/522
        if (a == 0) {
            return 0;
        }

        uint256 c = a * b;
        require(c / a == b, errorMessage);

        return c;
    }

    /**
     * @dev Returns the integer division of two unsigned integers.
     * Reverts on division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b) internal pure returns (uint256) {
        return div(a, b, "SafeMath: division by zero");
    }

    /**
     * @dev Returns the integer division of two unsigned integers.
     * Reverts with custom message on division by zero. The result is rounded towards zero.
     *
     * Counterpart to Solidity's `/` operator. Note: this function uses a
     * `revert` opcode (which leaves remaining gas untouched) while Solidity
     * uses an invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     * - The divisor cannot be zero.
     */
    function div(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        // Solidity only automatically asserts when dividing by 0
        require(b > 0, errorMessage);
        uint256 c = a / b;
        // assert(a == b * c + a % b); // There is no case in which this doesn't hold

        return c;
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * Reverts when dividing by zero.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b) internal pure returns (uint256) {
        return mod(a, b, "SafeMath: modulo by zero");
    }

    /**
     * @dev Returns the remainder of dividing two unsigned integers. (unsigned integer modulo),
     * Reverts with custom message when dividing by zero.
     *
     * Counterpart to Solidity's `%` operator. This function uses a `revert`
     * opcode (which leaves remaining gas untouched) while Solidity uses an
     * invalid opcode to revert (consuming all remaining gas).
     *
     * Requirements:
     * - The divisor cannot be zero.
     */
    function mod(uint256 a, uint256 b, string memory errorMessage) internal pure returns (uint256) {
        require(b != 0, errorMessage);
        return a % b;
    }
}

// File: contracts\libraries\Math.sol

pragma solidity =0.5.16;

// a library for performing various math operations
// forked from: https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/libraries/Math.sol

library Math {
    function min(uint x, uint y) internal pure returns (uint z) {
        z = x < y ? x : y;
    }
	
    function max(uint x, uint y) internal pure returns (uint z) {
        z = x > y ? x : y;
    }

    // babylonian method (https://en.wikipedia.org/wiki/Methods_of_computing_square_roots#Babylonian_method)
    function sqrt(uint y) internal pure returns (uint z) {
        if (y > 3) {
            z = y;
            uint x = y / 2 + 1;
            while (x < z) {
                z = x;
                x = (y / x + x) / 2;
            }
        } else if (y != 0) {
            z = 1;
        }
    }
}

// File: contracts\extensions\libraries\StringHelpers.sol

pragma solidity =0.5.16;

library StringHelpers {
    function append(string memory a, string memory b) internal pure returns (string memory) {
        return string(abi.encodePacked(a, b));
    }

    /**
     * Returns the first string if it is not-empty, otherwise the second.
     */
    function orElse(string memory a, string memory b) internal pure returns (string memory) {
        if (bytes(a).length > 0) {
            return a;
        }
        return b;
    }
	
    function equals(string memory a, string memory b) internal pure returns (bool) {
        return (keccak256(abi.encodePacked((a))) == keccak256(abi.encodePacked((b))));
    }
}

// File: contracts\extensions\ImpermaxV3OracleChainlink.sol

pragma solidity =0.5.16;
contract ImpermaxV3OracleChainlink is IV3Oracle {
	using SafeMath for uint256;
	using StringHelpers for string;

	uint constant Q128 = 2**128;
	uint constant Q96 = 2**96;
	uint constant Q48 = 2**48;
	uint constant Q32 = 2**32;

	address public admin;
	address public pendingAdmin;
	
	address public fallbackOracle;

	// Once created, token sources are immutable
	// All sources should be USD denominated
	mapping(address => address) public tokenSources;
	
	// If this is true, it prevents the admin to add the wrong source for a token by mistake
	// The admin could still add malicious sources for new tokens -> always double check a source before adding it
	bool public verifyTokenSource;
	
	event NewPendingAdmin(address oldPendingAdmin, address newPendingAdmin);
	event NewAdmin(address oldAdmin, address newAdmin);
	event NewFallbackOracle(address oldFallbackOracle, address newFallbackOracle);
	event SetVerifyTokenSource(bool enable);
	event TokenSourceCreated(address token, address source);
	
	constructor(address _admin) public {
		admin = _admin;
		verifyTokenSource = true;
		emit NewAdmin(address(0), _admin);
		emit SetVerifyTokenSource(true);
	}
	
	function oraclePriceSqrtX96(address token0, address token1) external returns (uint256 priceSqrtX96) {
		// 1. get latest prices
		address source0 = tokenSources[token0];
		address source1 = tokenSources[token1];
		if (source0 == address(0) || source1 == address(0)) {
			// fallback would be unsafe
			revert("ImpermaxV3OracleChainlink: UNSUPPORTED_PAIR");
		}
		int256 price0 = AggregatorInterface(source0).latestAnswer();
		int256 price1 = AggregatorInterface(source1).latestAnswer();
		if (price0 <= 0 || price1 <= 0) {
			require(fallbackOracle != address(0), "ImpermaxV3OracleChainlink: PRICE_CALCULATION_ERROR");
			return IV3Oracle(fallbackOracle).oraclePriceSqrtX96(token0, token1);
		}
		
		// 2. calculate delta decimals
		int256 totalDecimals0 = int256(IERC20(token0).decimals()) + AggregatorInterface(source0).decimals();
		int256 totalDecimals1 = int256(IERC20(token1).decimals()) + AggregatorInterface(source1).decimals();
		int256 deltaDecimals = totalDecimals0 - totalDecimals1;
		
		// 3. calculate the price and scale it based on delta decimals
		priceSqrtX96 = Math.sqrt(uint256(price0).mul(Q128).div(uint256(price1))).mul(Q32);
		uint scaleX96 = Q96;
		uint deltaDecimalsAbs = uint(deltaDecimals > 0 ? deltaDecimals : -deltaDecimals);
		for (uint i = 0; i < deltaDecimalsAbs; i++) {
			scaleX96 = scaleX96.mul(10);
		}
		scaleX96 = Math.sqrt(scaleX96).mul(Q48);
		if (deltaDecimals > 0) {
			priceSqrtX96 = priceSqrtX96.mul(Q96).div(scaleX96);
		} else {
			priceSqrtX96 = priceSqrtX96.mul(scaleX96).div(Q96);
		}
	}
	
	/*** Admin ***/
	
	function _addTokenSources(address[] calldata tokens, address[] calldata sources) external {
		require(msg.sender == admin, "ImpermaxV3OracleChainlink: UNAUTHORIZED");
		require(tokens.length == sources.length, "ImpermaxV3OracleChainlink: INCONSISTENT_PARAMS_LENGTH");
		for (uint i = 0; i < tokens.length; i++) {
			require(tokenSources[tokens[i]] == address(0), "ImpermaxV3OracleChainlink: TOKEN_INITIALIZED");
			if (verifyTokenSource) {
				int256 price = AggregatorInterface(sources[i]).latestAnswer();
				require(price > 100 && price < 2**112, "ImpermaxV3OracleChainlink: PRICE_OUT_OF_RANGE");
				int256 totalDecimals = int256(IERC20(tokens[i]).decimals()) + AggregatorInterface(sources[i]).decimals();
				require(totalDecimals >= 8 && totalDecimals <= 48, "ImpermaxV3OracleChainlink: DECIMALS_OUT_OF_RANGE");
				string memory symbol = IERC20(tokens[i]).symbol();
				string memory description = AggregatorInterface(sources[i]).description();
				require(description.equals(symbol.append(" / USD")), "ImpermaxV3OracleChainlink: INCONSISTENT_DESCRIPTION");
			}
			tokenSources[tokens[i]] = sources[i];
			emit TokenSourceCreated(tokens[i], sources[i]);
		}
	}

	function _setFallbackOracle(address newFallbackOracle) external {
		require(msg.sender == admin, "ImpermaxV3OracleChainlink: UNAUTHORIZED");
		address oldFallbackOracle = fallbackOracle;
		fallbackOracle = newFallbackOracle;
		emit NewFallbackOracle(oldFallbackOracle, newFallbackOracle);
	}
	
	function _setVerifyTokenSource(bool enable) external {
		require(msg.sender == admin, "ImpermaxV3OracleChainlink: UNAUTHORIZED");
		verifyTokenSource = enable;
		emit SetVerifyTokenSource(enable);
	}
	
	function _setPendingAdmin(address newPendingAdmin) external {
		require(msg.sender == admin, "ImpermaxV3OracleChainlink: UNAUTHORIZED");
		address oldPendingAdmin = pendingAdmin;
		pendingAdmin = newPendingAdmin;
		emit NewPendingAdmin(oldPendingAdmin, newPendingAdmin);
	}

	function _acceptAdmin() external {
		require(msg.sender == pendingAdmin, "ImpermaxV3OracleChainlink: UNAUTHORIZED");
		address oldAdmin = admin;
		address oldPendingAdmin = pendingAdmin;
		admin = pendingAdmin;
		pendingAdmin = address(0);
		emit NewAdmin(oldAdmin, admin);
		emit NewPendingAdmin(oldPendingAdmin, address(0));
	}
}