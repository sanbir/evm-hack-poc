// File: contracts\extensions\interfaces\ITokenizedUniswapV3Factory.sol

pragma solidity >=0.5.0;
pragma experimental ABIEncoderV2;

interface ITokenizedUniswapV3Factory {
	event NFTLPCreated(address indexed token0, address indexed token1, address NFTLP, uint);
	event NewPendingAdmin(address oldPendingAdmin, address newPendingAdmin);
	event NewAdmin(address oldAdmin, address newAdmin);
	event NewAcModule(address oldAcModule, address newAcModule);
	
	function admin() external view returns (address);
	function pendingAdmin() external view returns (address);
	
	function uniswapV3Factory() external view returns (address);
	function deployer() external view returns (address);
	function oracle() external view returns (address);
	function acModule() external view returns (address);
	
	function getNFTLP(address tokenA, address tokenB) external view returns (address);
	function allNFTLP(uint) external view returns (address);
	function allNFTLPLength() external view returns (uint);
	
	function createNFTLP(address tokenA, address tokenB) external returns (address NFTLP);
	
	function _setPendingAdmin(address newPendingAdmin) external;
	function _acceptAdmin() external;
	function _setAcModule(address newAcModule) external;
}

// File: contracts\extensions\interfaces\ITokenizedUniswapV3Deployer.sol

pragma solidity >=0.5.0;

interface ITokenizedUniswapV3Deployer {
	function deployNFTLP(address token0, address token1) external returns (address NFTLP);
}

// File: contracts\interfaces\INFTLP.sol

pragma solidity >=0.5.0;

interface INFTLP {
	struct RealXY {
		uint256 realX;
		uint256 realY;
	}
	
	struct RealXYs {
		RealXY lowestPrice;
		RealXY currentPrice;
		RealXY highestPrice;
	}
	
	// ERC-721
	function ownerOf(uint256 _tokenId) external view returns (address);
	function safeTransferFrom(address from, address to, uint256 tokenId, bytes calldata data) external;
	function safeTransferFrom(address from, address to, uint256 tokenId) external;
	function transferFrom(address from, address to, uint256 tokenId) external;
	
	// Global state
	function token0() external view returns (address);
	function token1() external view returns (address);
	
	// Position state
	function getPositionData(uint256 _tokenId, uint256 _safetyMarginSqrt) external returns (
		uint256 priceSqrtX96,
		RealXYs memory realXYs
	);
	
	// Interactions
	
	function split(uint256 tokenId, uint256 percentage) external returns (uint256 newTokenId);
	function join(uint256 tokenId, uint256 tokenToJoin) external;
}

// File: contracts\extensions\interfaces\ITokenizedUniswapV3Position.sol

pragma solidity >=0.5.0;

interface ITokenizedUniswapV3Position {
	
	// ERC-721
	
	function name() external view returns (string memory);
	function symbol() external view returns (string memory);
	function balanceOf(address owner) external view returns (uint256 balance);
	function ownerOf(uint256 tokenId) external view returns (address owner);
	function getApproved(uint256 tokenId) external view returns (address operator);
	function isApprovedForAll(address owner, address operator) external view returns (bool);
	
	function DOMAIN_SEPARATOR() external view returns (bytes32);
	function nonces(uint256 tokenId) external view returns (uint256);
	
	function safeTransferFrom(address from, address to, uint256 tokenId, bytes calldata data) external;
	function safeTransferFrom(address from, address to, uint256 tokenId) external;
	function transferFrom(address from, address to, uint256 tokenId) external;
	function approve(address to, uint256 tokenId) external;
	function setApprovalForAll(address operator, bool approved) external;
	function permit(address spender, uint tokenId, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
	
	// INFTLP
	
	function token0() external view returns (address);
	function token1() external view returns (address);
	function getPositionData(uint256 _tokenId, uint256 _safetyMarginSqrt) external returns (
		uint256 priceSqrtX96,
		INFTLP.RealXYs memory realXYs
	);
	
	function join(uint256 tokenId, uint256 tokenToJoin) external;
	function split(uint256 tokenId, uint256 percentage) external returns (uint256 newTokenId);
	
	// ITokenizedUniswapV3Position
	
	struct Position {
		uint24 fee;
		int24 tickLower;
		int24 tickUpper;
		uint128 liquidity;
		uint256 feeGrowthInside0LastX128;
		uint256 feeGrowthInside1LastX128;
		uint256 unclaimedFees0;	
		uint256 unclaimedFees1;	
	}
	
	function factory() external view returns (address);
	function uniswapV3Factory() external view returns (address);
	
	function totalBalance(uint24 fee, int24 tickLower, int24 tickUpper) external view returns (uint256);
	
	function positions(uint256 tokenId) external view returns (
		uint24 fee,
		int24 tickLower,
		int24 tickUpper,
		uint128 liquidity,
		uint256 feeGrowthInside0LastX128,
		uint256 feeGrowthInside1LastX128,
		uint256 unclaimedFees0,
		uint256 unclaimedFees1
	);
	function positionsLength() external view returns (uint256);
	
	function getPool(uint24 fee) external view returns (address pool);
	
	function oraclePriceSqrtX96() external returns (uint256);
	
	event MintPosition(uint256 indexed tokenId, uint24 fee, int24 tickLower, int24 tickUpper);
	event UpdatePositionLiquidity(uint256 indexed tokenId, uint256 liquidity);
	event UpdatePositionFeeGrowthInside(uint256 indexed tokenId, uint256 feeGrowthInside0LastX128, uint256 feeGrowthInside1LastX128);
	event UpdatePositionUnclaimedFees(uint256 indexed tokenId, uint256 unclaimedFees0, uint256 unclaimedFees1);

	function _initialize (
		address _uniswapV3Factory, 
		address _oracle, 
		address _token0, 
		address _token1
	) external;
	
	function mint(address to, uint24 fee, int24 tickLower, int24 tickUpper) external  returns (uint256 newTokenId);
	function redeem(address to, uint256 tokenId) external  returns (uint256 amount0, uint256 amount1);

}

// File: contracts\extensions\TokenizedUniswapV3Factory.sol

pragma solidity =0.5.16;
contract TokenizedUniswapV3Factory is ITokenizedUniswapV3Factory {
	address public admin;
	address public pendingAdmin;
	
	address public uniswapV3Factory;
	address public oracle;
	address public acModule;
	
	ITokenizedUniswapV3Deployer public deployer;

	mapping(address => mapping(address => address)) public getNFTLP;
	address[] public allNFTLP;

	constructor(address _admin, address _uniswapV3Factory, ITokenizedUniswapV3Deployer _deployer, address _oracle) public {
		admin = _admin;
		uniswapV3Factory = _uniswapV3Factory;
		deployer = _deployer;
		oracle = _oracle;
		emit NewAdmin(address(0), _admin);
	}

	function allNFTLPLength() external view returns (uint) {
		return allNFTLP.length;
	}

	function createNFTLP(address tokenA, address tokenB) external returns (address NFTLP) {
		require(tokenA != tokenB);
		(address token0, address token1) = tokenA < tokenB ? (tokenA, tokenB) : (tokenB, tokenA);
		require(token0 != address(0));
		require(getNFTLP[token0][token1] == address(0), "TokenizedUniswapV3Factory: PAIR_EXISTS");
		NFTLP = deployer.deployNFTLP(token0, token1);
		ITokenizedUniswapV3Position(NFTLP)._initialize(uniswapV3Factory, oracle, token0, token1);
		getNFTLP[token0][token1] = NFTLP;
		getNFTLP[token1][token0] = NFTLP;
		allNFTLP.push(NFTLP);
		emit NFTLPCreated(token0, token1, NFTLP, allNFTLP.length);
	}
	
	/***  acModule ***/
	
	function _setPendingAdmin(address newPendingAdmin) external {
		require(msg.sender == admin, "TokenizedUniswapV3Factory: UNAUTHORIZED");
		address oldPendingAdmin = pendingAdmin;
		pendingAdmin = newPendingAdmin;
		emit NewPendingAdmin(oldPendingAdmin, newPendingAdmin);
	}

	function _acceptAdmin() external {
		require(msg.sender == pendingAdmin, "TokenizedUniswapV3Factory: UNAUTHORIZED");
		address oldAdmin = admin;
		address oldPendingAdmin = pendingAdmin;
		admin = pendingAdmin;
		pendingAdmin = address(0);
		emit NewAdmin(oldAdmin, admin);
		emit NewPendingAdmin(oldPendingAdmin, address(0));
	}
	
	function _setAcModule(address newAcModule) external {
		require(msg.sender == admin, "TokenizedUniswapV3Factory: UNAUTHORIZED");
		address oldAcModule = acModule;
		acModule = newAcModule;
		emit NewAcModule(oldAcModule, newAcModule);
	}
}