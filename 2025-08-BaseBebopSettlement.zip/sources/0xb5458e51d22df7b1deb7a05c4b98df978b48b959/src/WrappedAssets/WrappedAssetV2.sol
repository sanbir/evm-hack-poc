// SPDX-License-Identifier: GNU GPLv3
pragma solidity 0.8.25;

import {Initializable} from "openzeppelin-contracts-upgradeable/proxy/utils/Initializable.sol";
import {
    ERC20PermitUpgradeable,
    ERC20Upgradeable
} from "openzeppelin-contracts-upgradeable/token/ERC20/extensions/ERC20PermitUpgradeable.sol";
import {AccessControlDefaultAdminRulesUpgradeable} from
    "openzeppelin-contracts-upgradeable/access/extensions/AccessControlDefaultAdminRulesUpgradeable.sol";

/// @title Wrapped Asset Contract
/// @author Alongside
contract WrappedAssetV2 is Initializable, ERC20PermitUpgradeable, AccessControlDefaultAdminRulesUpgradeable {
    /// @custom:storage-location erc7201:universal.storage.WrappedAsset.v2
    struct WrappedAssetV2Storage {
        mapping(address => bool) userBlacklist;
    }

    error BlacklistedAddress();
    error InvalidRole();
    error ZeroAddress();

    // keccak256(abi.encode(uint256(keccak256("universal.storage.WrappedAsset.v2")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant WrappedAssetV2StorageLocation =
        0xf943d94857efdc1384947cd4368e46d6f4e48c77d9e53052434f984225127300;

    uint48 internal constant ADMIN_TRANSFER_DELAY = 1 days;
    bytes32 public constant RESPONDER_ROLE = keccak256("RESPONDER_ROLE");

    // By making it immutable in the beacon we ensure it is the same across all uAssets
    address public immutable MERCHANT_CONTROLLER;

    modifier onlyMerchantController() {
        if (msg.sender != MERCHANT_CONTROLLER) revert InvalidRole();
        _;
    }

    constructor(address merchantController) {
        if (merchantController == address(0)) revert ZeroAddress();
        MERCHANT_CONTROLLER = merchantController;
        _disableInitializers();
    }

    function initialize(string memory _name, string memory _symbol, address multisig) external initializer {
        __ERC20_init(_name, _symbol);
        __ERC20Permit_init(_name);

        __AccessControlDefaultAdminRules_init(ADMIN_TRANSFER_DELAY, multisig);
    }

    /*
        - EXTERNAL FUNCTIONS -
    */

    /// @notice Mint wrapped asset tokens to a minter
    /// @dev This function can only be called by the MerchantController contract
    /// @param account The address of the account to mint to
    /// @param amount The amount of tokens to mint
    function mint(address account, uint256 amount) external onlyMerchantController {
        _mint(account, amount);
    }

    /// @notice Burn wrapped asset tokens from a minter
    /// @dev This function can only be called by the MerchantController contract
    /// @param account The address of the account to burn from
    /// @param amount The amount of tokens to burn
    function burn(address account, uint256 amount) external onlyMerchantController {
        _burn(account, amount);
    }

    /// @notice Get the blacklist status of a user
    /// @dev This function can only be called by the admin
    /// @param user The user to get the blacklist status of
    function getUserBlacklist(address user) external view returns (bool) {
        return _getWrappedAssetV2Storage().userBlacklist[user];
    }

    /*
        - ONLY ADMIN EXTERNAL FUNCTIONS -
    */

    /// @notice Blacklist/Whitelist a user from transfering the tokens.
    /// @dev This function can only be called by the admin, by default all users are whitelisted
    /// @param user The chain to blacklist/whitelist
    /// @param blacklist Whether to blacklist or whitelist the user
    function setUserBlacklist(address user, bool blacklist) external onlyRole(RESPONDER_ROLE) {
        if (user == address(0)) revert ZeroAddress();

        _getWrappedAssetV2Storage().userBlacklist[user] = blacklist;
    }
    
    /*
        - INTERNAL FUNCTIONS -
    */
    function _update(address from, address to, uint256 value) internal override {
        WrappedAssetV2Storage storage $ = _getWrappedAssetV2Storage();

        if ($.userBlacklist[msg.sender] || $.userBlacklist[from] || $.userBlacklist[to]) revert BlacklistedAddress();
        super._update(from, to, value);
    }

    function _getWrappedAssetV2Storage() private pure returns (WrappedAssetV2Storage storage $) {
        assembly {
            $.slot := WrappedAssetV2StorageLocation
        }
    }
}
