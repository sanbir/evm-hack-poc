pragma solidity 0.8.20;

contract TradeRouterEventsStorage {
    event SettlePositions(uint marginAccountID);
    event IncreaseLongPosition(uint marginAccountID, address token, uint amount);
    event IncreaseShortPosition(uint marginAccountID, address token, uint amount);
    event DecreaseLongPosition(uint marginAccountID, address token, uint amount);
    event DecreaseShortPosition(uint marginAccountID, address token, uint amount);

    function emitSettlePositions(uint marginAccountID) external {
        emit SettlePositions(marginAccountID);
    }

    function emitIncreaseLongPosition(uint marginAccountID, address token, uint amount) external {
        emit IncreaseLongPosition(marginAccountID, token, amount);
    }
    
    function emitIncreaseShortPosition(uint marginAccountID, address token, uint amount) external {
        emit IncreaseShortPosition(marginAccountID, token, amount);
    }

    function emitDecreaseLongPosition(uint marginAccountID, address token, uint amount) external {
        emit DecreaseLongPosition(marginAccountID, token, amount);
    }
    
    function emitDecreaseShortPosition(uint marginAccountID, address token, uint amount) external {
        emit DecreaseShortPosition(marginAccountID, token, amount);
    }
}