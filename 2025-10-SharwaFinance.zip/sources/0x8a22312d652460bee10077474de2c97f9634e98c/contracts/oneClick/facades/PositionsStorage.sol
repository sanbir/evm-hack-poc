pragma solidity 0.8.20;

import {IPositionsStorage} from "../../interfaces/oneClick/IPositionsStorage.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

contract PositionsStorage is IPositionsStorage, AccessControl {
    constructor() {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    }

    bytes32 public constant ONE_CLICK_PROXY_ROLE =
        keccak256("ONE_CLICK_PROXY_ROLE");

    mapping(uint => mapping(address => Position)) public position;
    mapping(address => mapping(uint => uint)) public erc721Owner;
    mapping(address => uint[]) public activeOptions;

    // VIEW FUNCTIONS

    function getPosition(
        uint marginAccountID,
        address token
    ) external view returns (Position memory) {
        return position[marginAccountID][token];
    }

    function getOptionOwner(
        uint collateralTokenID,
        address token
    ) external view returns (uint) {
        return erc721Owner[token][collateralTokenID];
    }

    function getActiveOptions(
        address token
    ) external view returns (uint[] memory) {
        return activeOptions[token];
    }

    // ONLY ONE_CLICK_PROXY_ROLE FUNCTIONS

    function setPosition(
        uint marginAccountID,
        address token,
        Position memory positionData
    ) external onlyRole(ONE_CLICK_PROXY_ROLE) {
        position[marginAccountID][token] = positionData;
    }

    function setOptionOwner(
        uint marginAccountID,
        address token,
        uint collateralTokenID
    ) external onlyRole(ONE_CLICK_PROXY_ROLE) {
        erc721Owner[token][collateralTokenID] = marginAccountID;
    }

    function addActiveOption(
        address token,
        uint optionID
    ) external onlyRole(ONE_CLICK_PROXY_ROLE) {
        activeOptions[token].push(optionID);
    }

    function removeActiveOption(
        address token,
        uint optionID
    ) external onlyRole(ONE_CLICK_PROXY_ROLE) {
        uint[] memory options = activeOptions[token];
        for (uint i = 0; i < options.length; i++) {
            if (options[i] == optionID) {
                activeOptions[token][i] = activeOptions[token][
                    activeOptions[token].length - 1
                ];
                activeOptions[token].pop();
                break;
            }
        }
    }
}
