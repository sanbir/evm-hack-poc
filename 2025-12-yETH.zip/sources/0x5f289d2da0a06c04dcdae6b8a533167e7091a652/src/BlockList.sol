// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IBlockList} from "src/interfaces/IBlockList.sol";
import {AccessControlEnumerable} from "openzeppelin/access/AccessControlEnumerable.sol";

contract BlockList is IBlockList, AccessControlEnumerable {
    bytes32 public constant ADD_TO_BLOCK_LIST_ROLE = keccak256("ADD_TO_BLOCK_LIST_ROLE");
    bytes32 public constant REMOVE_FROM_BLOCK_LIST_ROLE = keccak256("REMOVE_FROM_BLOCK_LIST_ROLE");

    mapping(address => bool) public blockedAddresses;

    constructor(address admin) {
        if (admin == address(0)){
            admin = msg.sender;
        }
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    function addToBlockList(address[] calldata accounts) external onlyRole(ADD_TO_BLOCK_LIST_ROLE) {
        for (uint256 i; i < accounts.length; ++i) {
            blockedAddresses[accounts[i]] = true;
        }
        emit BlockedAddressesAdded(accounts);
    }

    function removeFromBlockList(address[] calldata accounts) external onlyRole(REMOVE_FROM_BLOCK_LIST_ROLE) {
        for (uint256 i; i < accounts.length; ++i) {
            delete blockedAddresses[accounts[i]];
        }
        emit BlockedAddressesRemoved(accounts);
    }

    function isBlocked(address user) external view returns (bool) {
        return blockedAddresses[user];
    }

    function isAnyoneBlocked(address[] calldata accounts) external view returns (bool) {
        for (uint256 i; i < accounts.length; ++i) {
            if (blockedAddresses[accounts[i]]) {
                return true;
            }
        }
        return false;
    }
}
