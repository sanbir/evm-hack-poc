// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";

contract TermMaxCheckIn is Ownable {
    event UserCheckedIn(address indexed user);
    bool public paused;

    // Mapping to store the last check-in day for each user
    mapping(address => uint256) public lastCheckInDay;

    constructor() Ownable(msg.sender) {}

    function checkIn() external {
        require(!paused, "Paused");

        uint256 currentDay = getCurrentDay();
        require(lastCheckInDay[msg.sender] < currentDay, "Already checked in today");

        lastCheckInDay[msg.sender] = currentDay;
        emit UserCheckedIn(msg.sender);
    }

    // Returns the current day number based on UTC+0 (00:00:00)
    // Day 0 = 1970-01-01, increments every 86400 seconds
    function getCurrentDay() public view returns (uint256) {
        return block.timestamp / 86400;
    }

    // Check if a user has checked in on the current day
    function hasCheckedInToday(address user) public view returns (bool) {
        return lastCheckInDay[user] == getCurrentDay();
    }

    function pause() public onlyOwner {
        paused = true;
    }

    function unpause() public onlyOwner {
        paused = false;
    }
}