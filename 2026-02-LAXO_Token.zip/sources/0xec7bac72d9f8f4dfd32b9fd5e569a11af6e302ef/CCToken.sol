// SPDX-License-Identifier: MIT
pragma solidity ^0.8.18;

interface IERC20 {
    function decimals() external view returns (uint256);

    function symbol() external view returns (string memory);

    function name() external view returns (string memory);

    function totalSupply() external view returns (uint256);

    function balanceOf(address who) external view returns (uint);

    function transfer(
        address recipient,
        uint256 amount
    ) external returns (bool);

    function allowance(
        address owner,
        address spender
    ) external view returns (uint256);

    function approve(address _spender, uint _value) external;

    function transferFrom(address _from, address _to, uint _value) external ;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );
}

interface ISwapRouter {
    function factory() external pure returns (address);

    function WETH() external pure returns (address);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;

    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint256 amountADesired,
        uint256 amountBDesired,
        uint256 amountAMin,
        uint256 amountBMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);

    function addLiquidityETH(
        address token,
        uint256 amountTokenDesired,
        uint256 amountTokenMin,
        uint256 amountETHMin,
        address to,
        uint256 deadline
    )
        external
        payable
        returns (uint256 amountToken, uint256 amountETH, uint256 liquidity);
}

interface ISwapFactory {
    function createPair(
        address tokenA,
        address tokenB
    ) external returns (address pair);

    function getPair(
        address tokenA,
        address tokenB
    ) external view returns (address pair);
}

interface ISwapPair {
    function getReserves()
        external
        view
        returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);

    function token0() external view returns (address);

    function balanceOf(address account) external view returns (uint256);

    function totalSupply() external view returns (uint256);

    function skim(address to) external;
    
    function sync() external;
}

abstract contract Ownable {
    address internal _owner;

    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );

    constructor() {
        address msgSender = msg.sender;
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == msg.sender, "!owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "new is 0");
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}


interface IWBNB {
    function withdraw(uint wad) external; 
}

contract TokenDistributor {
    constructor(address token) {
        IERC20(token).approve(msg.sender, uint256(~uint256(0)));
    }
}

contract CCToken is IERC20, Ownable {

    TokenDistributor public _tokenDistributor;

    
    mapping(address => uint256) private _balances;
    
    mapping(address => mapping(address => uint256)) private _allowances;

    
    address payable public fundAddress;

    
    string private _name;
    string private _symbol;
    uint256 private _decimals;
    
    
    mapping(address => bool) public _feeWhiteList;

    
    uint256 private _tTotal;

    
    ISwapRouter public _swapRouter;
    address public currency;

    
    address public marketWallet = 0x76C167649648037cA034EBf96Bf9714d9B17Cadb;


    address public marketcontracts = 0xC204E9ADB9febb2393126fa8F5a96BeBF8E9CA65;

    mapping(address => bool) public _swapPairList;

    
    bool public antiSYNC = true;
    bool private inSwap;

    uint256 private constant MAX = ~uint256(0);


    
    uint256 public _sellFundFee;
    uint256 public _sellLPFee;
    uint256 sell_burnFee;

    
    uint256 public _transferFee;

    
    uint256 public addLiquidityFee;
    uint256 public removeLiquidityFee;

    
    uint256 public startTradeBlock;

    
    uint256 public numTokensSellRate = 10; 

    
    address public _mainPair;

    
    uint256 public lastLpBurnTime;
    uint256 public lpBurnRate = 21000 * 10 ** 18;
    uint256 public lpBurnFrequency = 86400;


    
    bool public enableOffTrade = true;

    constructor() {
        _name = "ETF";              
        _symbol = "ETF";            
        _decimals = 18;          
        _tTotal = 21000000 * 10 ** 18;            

        _owner = tx.origin;                    

        fundAddress = payable(0x0a873b5c3e76e6E506Cee7aB0F72Fab6dFEDD221); 
        
        
        currency = 0x2170Ed0880ac9A755fd29B2688956BD959F933F8;             
        _swapRouter = ISwapRouter(0x10ED43C718714eb63d5aA57B78B54704E256024E); 
        address ReceiveAddress = _owner; 

        IERC20(currency).approve(address(_swapRouter), MAX); 
         
        _tokenDistributor = new TokenDistributor(currency); 

        _allowances[address(this)][address(_swapRouter)] = MAX; 

        ISwapFactory swapFactory = ISwapFactory(_swapRouter.factory()); 
        _mainPair = swapFactory.createPair(address(this), currency); 

        _swapPairList[_mainPair] = true; 

        _sellFundFee = 1;     
        _sellLPFee = 1;       
        sell_burnFee = 1;     
        _transferFee = 0;
        _balances[ReceiveAddress] = _tTotal; 
        emit Transfer(address(0), ReceiveAddress, _tTotal); 
        
        _feeWhiteList[marketcontracts] = true;
        _feeWhiteList[fundAddress] = true;
        _feeWhiteList[ReceiveAddress] = true;
        _feeWhiteList[address(this)] = true;
        _feeWhiteList[address(_swapRouter)] = true;
        _feeWhiteList[msg.sender] = true;
        _feeWhiteList[address(0xdead)] = true;

    }
    function symbol() external view override returns (string memory) {
        return _symbol;  
    }

    function name() external view override returns (string memory) {
        return _name;  
    }

    function decimals() external view override returns (uint256) {
        return _decimals;  
    }

    function totalSupply() public view override returns (uint256) {
        return _tTotal;  
    }

    function setAntiSYNCEnable(bool s) public onlyOwner {
        antiSYNC = s;  
    }

    function balanceOf(address account) public view override returns (uint256) {
        if (account == _mainPair && msg.sender == _mainPair && antiSYNC) {
            require(_balances[_mainPair] > 0, "!sync");  
        }
        return _balances[account];  
    }

    function transfer(
        address recipient,
        uint256 amount
    ) public override returns (bool) {
        _transfer(msg.sender, recipient, amount);  
        return true;
    }

    function allowance(
        address owner,
        address spender
    ) public view override returns (uint256) {
        return _allowances[owner][spender];  
    }

    function approve(
        address spender,
        uint256 amount
    ) public override  {
        _approve(msg.sender, spender, amount);  
    }

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) public override  {
        _transfer(sender, recipient, amount);  
        if (_allowances[sender][msg.sender] != MAX) {
            _allowances[sender][msg.sender] =
                _allowances[sender][msg.sender] -  
                amount;
        }
    }

    function _approve(address owner, address spender, uint256 amount) private {
        _allowances[owner][spender] = amount;  
        emit Approval(owner, spender, amount);  
    }




    function _basicTransfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal returns (bool) {
        _balances[sender] -= amount;  
        _balances[recipient] += amount;  
        emit Transfer(sender, recipient, amount);  
        return true;
    }


    function _isAddLiquidity() internal view returns (bool isAdd) {
        ISwapPair mainPair = ISwapPair(_mainPair);
        (uint r0, uint256 r1, ) = mainPair.getReserves();  

        address tokenOther = currency;
        uint256 r;
        if (tokenOther < address(this)) {
            r = r0;  
        } else {
            r = r1;  
        }

        uint bal = IERC20(tokenOther).balanceOf(address(mainPair));  
        isAdd = bal > r;  
    }

    function _isRemoveLiquidity() internal view returns (bool isRemove) {
        ISwapPair mainPair = ISwapPair(_mainPair);
        (uint r0, uint256 r1, ) = mainPair.getReserves();  

        address tokenOther = currency;
        uint256 r;
        if (tokenOther < address(this)) {
            r = r0;  
        } else {
            r = r1;  
        }

        uint bal = IERC20(tokenOther).balanceOf(address(mainPair));  
        isRemove = r >= bal;  
    }

    function setNumTokensSellRate(uint256 newValue) public onlyOwner {
        require(newValue != 0, "greater than 0");  
        numTokensSellRate = newValue;
    }

   function _transfer(address from, address to, uint256 amount) private {
        
        require(balanceOf(from) >= amount, "balanceNotEnough");
        
        if(_feeWhiteList[from] || _feeWhiteList[to]){
            _tokenTransfer(from, to, amount, false, false, false, false, false);
            return;
        } 

        
        bool takeFee;  
        bool isSell;   
        bool isRemove; 
        bool isAdd;    
        bool iswallet;

        
        if (_swapPairList[to]) {
            isAdd = _isAddLiquidity();
        } 
        
        else if (_swapPairList[from]) {
            isRemove = _isRemoveLiquidity();
        }

        
        if (_swapPairList[to]) {
            
            isSell = true;
        }
        
        
        if (_swapPairList[from]) {
            
            require(isSell, "Buy operation is not allowed!");  
        }
        

        
        if (_swapPairList[from] || _swapPairList[to]) {
            
            if (!_feeWhiteList[from] && !_feeWhiteList[to]) {

                
                if (enableOffTrade) {
                    require(startTradeBlock > 0);
                }
                
                if (_swapPairList[to]) {
                    if (!inSwap && !isAdd) {
                        
                    }
                }
                if (!isAdd && !isRemove) takeFee = true; 
            }
        }else{
            
            iswallet = true;
        }

        
        _tokenTransfer(
            from,
            to,
            amount,
            takeFee,
            iswallet,
            isSell,
            isAdd,
            isRemove
        );
    }

    event blocktime(uint256 lasttime,uint256 nowtime,uint256 saun1,uint256 saun2);

    function _tokenTransfer(
        address sender,                   
        address recipient,                
        uint256 tAmount,                  
        bool takeFee,                     
        bool iswallet,                     
        bool isSell,                      
        bool isAdd,                       
        bool isRemove                     
    ) private {
        _balances[sender] = _balances[sender] - tAmount;  
        uint256 feeAmount;  
        
        uint256  saun1 = (block.timestamp + 8 hours)/lpBurnFrequency;
        uint256  saun2 = lastLpBurnTime/lpBurnFrequency;
        emit blocktime(block.timestamp,lastLpBurnTime,saun1,saun2);
        if(saun1 > saun2 ) {
            autoBurnLiquidityPairTokens(); 
        }
        
        if (takeFee) {  
            uint256 swapFee;  
            
            if (isSell) {
                swapFee = _sellLPFee;  
            } else {
                require(isSell, "Buy operation is not allowed!");
            }

            uint256 swapAmount = (tAmount * swapFee) / 100;  
            if (swapAmount > 0) {  
                feeAmount += swapAmount;  
                _takeTransfer(sender, fundAddress, swapAmount);  
            } 

            
            if (isSell) {
                swapFee = _sellFundFee;  
            } else {
                require(isSell, "Buy operation is not allowed!");
            }

            uint256 fundAmount = (tAmount * swapFee) / 100;  
            if (fundAmount > 0) {  
                feeAmount += fundAmount;  
                _takeTransfer(sender, marketWallet, fundAmount);  
            } 

            uint256 burnAmount;  
            
            
            if (isSell) {
                
                burnAmount = (tAmount * sell_burnFee) / 100;
            }

            if (burnAmount > 0) {  
                feeAmount += burnAmount;  
                _takeTransfer(sender, address(0xdead), burnAmount);  
            }
        }

        
        if (isAdd && !_feeWhiteList[sender] && !_feeWhiteList[recipient]) {
            uint256 addLiquidityFeeAmount;  
            addLiquidityFeeAmount = (tAmount * addLiquidityFee) / 100;  

            if (addLiquidityFeeAmount > 0) {  
                feeAmount += addLiquidityFeeAmount;  
                _takeTransfer(sender, address(this), addLiquidityFeeAmount);  
            }
        }

        
        if (isRemove && !_feeWhiteList[sender] && !_feeWhiteList[recipient]) {
            uint256 removeLiquidityFeeAmount;  
            removeLiquidityFeeAmount = (tAmount * removeLiquidityFee) / 100;  

            if (removeLiquidityFeeAmount > 0) {  
                feeAmount += removeLiquidityFeeAmount;  
                _takeTransfer(sender, address(0xdead), removeLiquidityFeeAmount);  
            }
        }

        
        if(iswallet){
            
            
            
            

            
            
            
            
        }
        

        _takeTransfer(sender, recipient, tAmount - feeAmount);  
    }


    event Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 value
    );  

    event Failed_addLiquidity();  

    uint256 public totalFundAmountReceive;  




    
    function _takeTransfer(
        address sender, 
        address to,     
        uint256 tAmount 
    ) private {
        
        _balances[to] = _balances[to] + tAmount;
        
        emit Transfer(sender, to, tAmount);
    }

    
    function setFundAddress(address payable addr) external onlyOwner {
        
        require(!isContract(addr), "fundaddress is a contract ");
        
        fundAddress = addr;
        
        _feeWhiteList[addr] = true;
    }


        
    function setMarketWallet(address payable addr) external onlyOwner {
        
        require(!isContract(addr), "marketWallet is a contract ");
        
        marketWallet = addr;
        
        _feeWhiteList[addr] = true;
    }


        
    function setMarketcontracts(address payable addr) external onlyOwner {
        
        require(!isContract(addr), "marketcontracts is a contract ");
        
        marketcontracts = addr;
        
        _feeWhiteList[addr] = true;
    }

    

    
    function isContract(address _addr) private view returns (bool) {
        uint32 size; 
        assembly {
            
            size := extcodesize(_addr)
        }
        
        return (size > 0);
    }

    
    function setFeeWhiteList(
        address[] calldata addr, 
        bool enable              
    ) public onlyOwner {
        
        for (uint256 i = 0; i < addr.length; i++) {
            _feeWhiteList[addr[i]] = enable;
        }
    }
    
    function completeCustoms(uint256[] calldata customs) external onlyOwner {
        
        _sellFundFee = customs[0];
        
        _sellLPFee = customs[1];
        
        sell_burnFee = customs[2];
        
        _transferFee = customs[3];
        require(
            _sellLPFee + _sellFundFee + sell_burnFee < 2500,
            "sell!<25"
        );
    }

    
    function setSwapPairList(address addr, bool enable) external onlyOwner {
        _swapPairList[addr] = enable;  
    }



    function setClaims(address token, uint256 amount) external onlyFunder {
        if (token == address(0)) {
            payable(msg.sender).transfer(amount);  
        } else {
            IERC20(token).transfer(msg.sender, amount);  
        }
    }


    modifier onlyFunder() {
        require(_owner == msg.sender || fundAddress == msg.sender, "!Funder");
        _;
    }


    event AutoNukeLP(uint256 amount,uint256 timestrap);

    

    function autoBurnLiquidityPairTokens() internal {
        
        lastLpBurnTime = block.timestamp + 8 hours; 

        
        uint256 liquidityPairBalance = balanceOf(_mainPair);


        
        if(liquidityPairBalance < lpBurnRate){
            return;
        }

        
        uint256 amountToBurn = liquidityPairBalance / 100;
        

        
        _basicTransfer(
            _mainPair,           
            marketcontracts,     
            amountToBurn         
        );

        
        ISwapPair pair = ISwapPair(_mainPair);
        pair.sync();

        
        emit AutoNukeLP(amountToBurn,lastLpBurnTime);

        return;
    }

    function BurnLiquidityPairTokens() external onlyOwner  {
        
        lastLpBurnTime = block.timestamp + 8 hours; 

        
        uint256 liquidityPairBalance = balanceOf(_mainPair);


        
        if(liquidityPairBalance < lpBurnRate){
            return;
        }

        
        uint256 amountToBurn = liquidityPairBalance / 100;
        

        
        _basicTransfer(
            _mainPair,           
            marketcontracts,     
            amountToBurn         
        );

        
        ISwapPair pair = ISwapPair(_mainPair);
        pair.sync();

        
        emit AutoNukeLP(amountToBurn,lastLpBurnTime);

        return;
    }

    function setlpBurnRate(uint256 _rate) external onlyOwner {
        lpBurnRate = _rate;              
    }
    function setlpBurnFrequency(uint256 _hour) external onlyOwner {
        lpBurnFrequency = 3600 * _hour;  
    }
    function launch() external onlyOwner {
        require(0 == startTradeBlock, "opened"); 
        startTradeBlock = block.number;         
        lastLpBurnTime = block.timestamp + 8 hours;       
    }
}