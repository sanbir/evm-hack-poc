// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

interface IPancakePair {
    event Approval(address indexed owner, address indexed spender, uint value);
    event Transfer(address indexed from, address indexed to, uint value);

    function name() external pure returns (string memory);
    function symbol() external pure returns (string memory);
    function decimals() external pure returns (uint8);
    function totalSupply() external view returns (uint);
    function balanceOf(address owner) external view returns (uint);
    function allowance(address owner, address spender) external view returns (uint);

    function approve(address spender, uint value) external returns (bool);
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address from, address to, uint value) external returns (bool);

    function DOMAIN_SEPARATOR() external view returns (bytes32);
    function PERMIT_TYPEHASH() external pure returns (bytes32);
    function nonces(address owner) external view returns (uint);

    function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;

    event Mint(address indexed sender, uint amount0, uint amount1);
    event Burn(address indexed sender, uint amount0, uint amount1, address indexed to);
    event Swap(
        address indexed sender,
        uint amount0In,
        uint amount1In,
        uint amount0Out,
        uint amount1Out,
        address indexed to
    );
    event Sync(uint112 reserve0, uint112 reserve1);

    function MINIMUM_LIQUIDITY() external pure returns (uint);
    function factory() external view returns (address);
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function price0CumulativeLast() external view returns (uint);
    function price1CumulativeLast() external view returns (uint);
    function kLast() external view returns (uint);

    function mint(address to) external returns (uint liquidity);
    function burn(address to) external returns (uint amount0, uint amount1);
    function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    function skim(address to) external;
    function sync() external;

    function initialize(address, address) external;
}

interface IPancakeRouter01 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint amountADesired,
        uint amountBDesired,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB, uint liquidity);

    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);

    function removeLiquidity(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB);

    function removeLiquidityETH(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountToken, uint amountETH);

    function removeLiquidityWithPermit(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountA, uint amountB);

    function removeLiquidityETHWithPermit(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountToken, uint amountETH);

    function swapExactTokensForTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);

    function swapTokensForExactTokens(
        uint amountOut,
        uint amountInMax,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);

    function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline)
        external
        payable
        returns (uint[] memory amounts);

    function swapTokensForExactETH(uint amountOut, uint amountInMax, address[] calldata path, address to, uint deadline)
        external
        returns (uint[] memory amounts);

    function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline)
        external
        returns (uint[] memory amounts);

    function swapETHForExactTokens(uint amountOut, address[] calldata path, address to, uint deadline)
        external
        payable
        returns (uint[] memory amounts);

    function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
}

interface IPancakeFactory {
    function getPair(address tokenA, address tokenB) external view returns (address pair);
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IPancakeRouter02 is IPancakeRouter01 {
    function removeLiquidityETHSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountETH);

    function removeLiquidityETHWithPermitSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountETH);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;

    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable;

    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
}

contract PolarxToken is IERC20 {
    string public constant VERSION = "6.1.0-token-genesis";
    bytes32 private constant _DEPLOYMENT_SALT = 0xf6f7f8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5bb06;

    event TokenInitialized(address indexed minter, uint256 supply, bytes32 tokenHash);

    function _validateTokenParams(uint256 supply, uint256 maxSupply) internal pure returns (bool) {
        return supply <= maxSupply && maxSupply < 2**128;
    }

    string public constant name = "PSTAR Token";
    string public constant symbol = "PSTAR";
    uint8 public constant decimals = 18;
    uint256 private constant TOTAL_SUPPLY = 100_000_000 * 10**18;

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;

    address public immutable router;
    address public immutable usdt;
    address public constant dead = 0x000000000000000000000000000000000000dEaD;

    address public owner;
    address public immutable pair;

    uint256 public todayHighestPoolValue;
    uint256 public previousDayHighestValue;
    uint256 public lastValueUpdateDay;

    uint16 public growthThresholdBps = 100;

    int256 public timezoneOffset = 8 hours;
    address public dayContract;
    address public monthContract;
    address public quarterContract;
    address public yearContract;
    address public vaultContract;
    address public nodeTokenContract;

    uint16 public baseTaxBps = 250;

    struct TaxTier {
        uint256 thresholdUSDT;
        uint16 taxBps;
    }
    TaxTier[] public taxTiers;

    bool private inSwap;

    uint256 private _pendingBaseSwap;
    uint256 private _pendingDynamicSwap;
    uint256 public swapThreshold = 100 * 10**18;
    uint256 public maxSwapAmount = 50_000 * 10**18;
    uint256 public swapCooldown;
    uint256 public lastSwapTime;

    uint16 public distributeVaultBps = 9000;
    uint16 public distributeQuarterBps = 750;
    uint16 public distributeNodeBps = 250;

    mapping(address => bool) public isFeeExempt;
    mapping(address => bool) public isTradeBypass;

    uint256 public openThresholdUsdt = 100_000 * 10**18;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event NodeContractsUpdated(address day, address month, address quarter, address year, address vault);
    event FeeExemptUpdated(address indexed account, bool enabled);
    event TradeBypassUpdated(address indexed account, bool enabled);
    event TaxTiersUpdated(uint256 tiersCount);
    event BaseTaxUpdated(uint16 oldBps, uint16 newBps);
    event DistributionRatioUpdated(uint16 monthBps, uint16 quarterBps, uint16 yearBps);
    event OpenThresholdUpdated(uint256 oldThreshold, uint256 newThreshold);
    event GrowthThresholdUpdated(uint16 oldBps, uint16 newBps);
    event TimezoneOffsetUpdated(int256 oldOffset, int256 newOffset);
    event PoolValueUpdated(uint256 currentValue, uint256 todayHighest, uint256 previousDayHighest, bool isNewDay);
    event PoolValueReset(address indexed admin);

    event TaxCollected(
        address indexed from,
        address indexed to,
        uint256 amount,
        uint16 baseTaxBps,
        uint16 dynamicTaxBps,
        uint256 baseTax,
        uint256 dynamicTax
    );
    event TokensBurned(address indexed from, uint256 amount);
    event SwapExecuted(uint256 tokenAmount, uint256 usdtReceived, bool isBaseTax);
    event DistributionExecuted(uint256 toMonth, uint256 toQuarter, uint256 toYear);
    event SwapConfigUpdated(uint256 swapThreshold, uint256 maxSwapAmount, uint256 swapCooldown);
    event PendingTaxSwapped(uint256 baseAmount, uint256 dynamicAmount, uint256 usdtReceived);

    modifier onlyOwner() {
        require(msg.sender == owner, "PSTAR: caller is not the owner");
        _;
    }

    modifier lockSwap() {
        inSwap = true;
        _;
        inSwap = false;
    }

    constructor(
        address _router,
        address _usdt,
        address _mainReceiver,
        address _incentiveReceiver
    ) {
        require(_router != address(0), "PSTAR: router is zero address");
        require(_usdt != address(0), "PSTAR: usdt is zero address");
        require(_mainReceiver != address(0), "PSTAR: mainReceiver is zero address");
        require(_incentiveReceiver != address(0), "PSTAR: incentiveReceiver is zero address");

        router = _router;
        usdt = _usdt;
        owner = msg.sender;

        uint256 mainAmount = (TOTAL_SUPPLY * 8500) / 10000;
        uint256 incentiveAmount = TOTAL_SUPPLY - mainAmount;

        _totalSupply = TOTAL_SUPPLY;
        _balances[_mainReceiver] += mainAmount;
        _balances[_incentiveReceiver] += incentiveAmount;

        emit Transfer(address(0), _mainReceiver, mainAmount);
        emit Transfer(address(0), _incentiveReceiver, incentiveAmount);

        address factory = IPancakeRouter02(_router).factory();
        address _pair = IPancakeFactory(factory).getPair(address(this), _usdt);

        if (_pair == address(0)) {
            _pair = IPancakeFactory(factory).createPair(address(this), _usdt);
        }
        pair = _pair;

        lastValueUpdateDay = _getCurrentDay();

        isFeeExempt[address(this)] = true;
        isTradeBypass[address(this)] = true;

        isTradeBypass[msg.sender] = true;
        isTradeBypass[_mainReceiver] = true;

        _initDefaultTaxTiers();
    }

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address recipient, uint256 amount) external override returns (bool) {
        _transfer(msg.sender, recipient, amount);
        return true;
    }

    function allowance(address _owner, address spender) external view override returns (uint256) {
        return _allowances[_owner][spender];
    }

    function approve(address spender, uint256 amount) external override returns (bool) {
        _approve(msg.sender, spender, amount);
        return true;
    }

    function transferFrom(address sender, address recipient, uint256 amount) external override returns (bool) {
        uint256 currentAllowance = _allowances[sender][msg.sender];
        require(currentAllowance >= amount, "PSTAR: transfer amount exceeds allowance");
        unchecked {
            _approve(sender, msg.sender, currentAllowance - amount);
        }
        _transfer(sender, recipient, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        require(from != address(0), "PSTAR: transfer from zero address");
        require(to != address(0), "PSTAR: transfer to zero address");
        require(amount > 0, "PSTAR: transfer amount must be greater than zero");
        require(_balances[from] >= amount, "PSTAR: transfer amount exceeds balance");

        bool isAMMTrade = (from == pair || to == pair);

        if (isAMMTrade) {
            bool tradingOpen = isOpen();
            if (!tradingOpen) {
                require(
                    _isBypassAddress(from) || _isBypassAddress(to),
                    "PSTAR: TRADING_CLOSED"
                );
            }
        }

        if (
            to == pair &&
            !inSwap &&
            (_pendingBaseSwap + _pendingDynamicSwap) >= swapThreshold &&
            (swapCooldown == 0 || block.timestamp >= lastSwapTime + swapCooldown)
        ) {
            _processPendingSwap();
        }

        uint256 transferAmount = amount;

        bool isFirstLiquidity = false;
        if (to == pair && pair != address(0)) {
            uint256 lpSupply = IPancakePair(pair).totalSupply();
            isFirstLiquidity = (lpSupply == 0);
        }

        if (isAMMTrade && !_isExemptFromFee(from, to) && !inSwap && !isFirstLiquidity) {
            uint16 dynamicBps = getDynamicTaxBps();

            uint256 baseTax = (amount * baseTaxBps) / 10000;
            uint256 dynamicTax = (amount * dynamicBps) / 10000;

            if (baseTax > 0 || dynamicTax > 0) {
                uint256 baseBurn = baseTax / 2;
                uint256 baseSwap = baseTax - baseBurn;

                if (baseBurn > 0) {
                    _balances[from] -= baseBurn;
                    _balances[dead] += baseBurn;
                    emit Transfer(from, dead, baseBurn);
                    emit TokensBurned(from, baseBurn);
                }

                uint256 toContract = baseSwap + dynamicTax;
                if (toContract > 0) {
                    _balances[from] -= toContract;
                    _balances[address(this)] += toContract;
                    emit Transfer(from, address(this), toContract);

                    _pendingBaseSwap += baseSwap;
                    _pendingDynamicSwap += dynamicTax;
                }

                transferAmount = amount - baseTax - dynamicTax;

                emit TaxCollected(from, to, amount, baseTaxBps, dynamicBps, baseTax, dynamicTax);
            }
        }

        _balances[from] -= transferAmount;
        _balances[to] += transferAmount;
        emit Transfer(from, to, transferAmount);

        if (isAMMTrade && !inSwap) {
            _updatePoolValueTracking();
        }
    }

    function _processPendingSwap() internal {
        uint256 baseAmount = _pendingBaseSwap;
        uint256 dynamicAmount = _pendingDynamicSwap;
        uint256 totalAmount = baseAmount + dynamicAmount;

        if (totalAmount == 0) return;

        if (maxSwapAmount > 0 && totalAmount > maxSwapAmount) {
            baseAmount = (baseAmount * maxSwapAmount) / totalAmount;
            dynamicAmount = maxSwapAmount - baseAmount;
            _pendingBaseSwap -= baseAmount;
            _pendingDynamicSwap -= dynamicAmount;
        } else {
            _pendingBaseSwap = 0;
            _pendingDynamicSwap = 0;
        }

        totalAmount = baseAmount + dynamicAmount;
        bool success = _swapAndDistribute(baseAmount, dynamicAmount, totalAmount);

        if (!success) {
            _pendingBaseSwap += baseAmount;
            _pendingDynamicSwap += dynamicAmount;
            return;
        }

        lastSwapTime = block.timestamp;

        emit PendingTaxSwapped(baseAmount, dynamicAmount, totalAmount);
    }

    function _updatePoolValueTracking() internal {
        uint256 today = _getCurrentDay();
        uint256 currentValue = _getVaultLPValueInternal();

        if (today > lastValueUpdateDay) {
            previousDayHighestValue = todayHighestPoolValue;
            todayHighestPoolValue = currentValue;
            lastValueUpdateDay = today;
            emit PoolValueUpdated(currentValue, currentValue, previousDayHighestValue, true);
        } else {
            if (currentValue > todayHighestPoolValue) {
                todayHighestPoolValue = currentValue;
                emit PoolValueUpdated(currentValue, currentValue, previousDayHighestValue, false);
            }
        }
    }

    function _getVaultLPValueInternal() internal view returns (uint256) {
        if (pair == address(0) || vaultContract == address(0)) {
            return 0;
        }

        IPancakePair pairContract = IPancakePair(pair);
        uint256 lpTotalSupply = pairContract.totalSupply();
        if (lpTotalSupply == 0) {
            return 0;
        }

        uint256 lpBalanceVault = pairContract.balanceOf(vaultContract);
        uint256 reserveUSDT = _getUSDTReserve();

        return _mulDiv(lpBalanceVault * 2, reserveUSDT, lpTotalSupply);
    }

    function _getCurrentDay() internal view returns (uint256) {
        int256 adjustedTime = int256(block.timestamp) + timezoneOffset;
        require(adjustedTime >= 0, "PSTAR: invalid timezone offset");
        return uint256(adjustedTime) / 1 days;
    }

    function _approve(address _owner, address spender, uint256 amount) internal {
        require(_owner != address(0), "PSTAR: approve from zero address");
        require(spender != address(0), "PSTAR: approve to zero address");
        _allowances[_owner][spender] = amount;
        emit Approval(_owner, spender, amount);
    }

    function _swapAndDistribute(uint256 baseSwapAmount, uint256 dynamicTaxAmount, uint256 totalSwapAmount) internal lockSwap returns (bool) {
        require(vaultContract != address(0), "PSTAR: vaultContract not set");
        require(quarterContract != address(0), "PSTAR: quarterContract not set");
        require(nodeTokenContract != address(0), "PSTAR: nodeTokenContract not set");

        if (totalSwapAmount == 0) return false;

        uint256 totalUSDT = _swapTokensForUSDT(totalSwapAmount);
        if (totalUSDT == 0) return false;

        uint256 usdtFromBase = (totalUSDT * baseSwapAmount) / totalSwapAmount;
        uint256 usdtFromDynamic = totalUSDT - usdtFromBase;

        uint256 totalToVault = usdtFromBase;

        if (usdtFromBase > 0) {
            emit SwapExecuted(baseSwapAmount, usdtFromBase, true);
            emit DistributionExecuted(usdtFromBase, 0, 0);
        }

        uint256 toQuarter = 0;
        uint256 toNode = 0;
        if (usdtFromDynamic > 0) {
            uint256 dynamicToVault = (usdtFromDynamic * distributeVaultBps) / 10000;
            toQuarter = (usdtFromDynamic * distributeQuarterBps) / 10000;
            toNode = usdtFromDynamic - dynamicToVault - toQuarter;

            totalToVault += dynamicToVault;

            emit SwapExecuted(dynamicTaxAmount, usdtFromDynamic, false);
            emit DistributionExecuted(dynamicToVault, toQuarter, toNode);
        }

        if (totalToVault > 0) {
            _safeTransfer(usdt, vaultContract, totalToVault);
        }
        if (toQuarter > 0) {
            _safeTransfer(usdt, quarterContract, toQuarter);
        }
        if (toNode > 0) {
            _safeTransfer(usdt, nodeTokenContract, toNode);
        }

        return true;
    }

    function _swapTokensForUSDT(uint256 tokenAmount) internal returns (uint256) {
        if (tokenAmount == 0) return 0;

        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = usdt;

        _approve(address(this), router, tokenAmount);

        uint256 usdtBalanceBefore = IERC20(usdt).balanceOf(address(this));

        try IPancakeRouter02(router).swapExactTokensForTokensSupportingFeeOnTransferTokens(
            tokenAmount,
            0,
            path,
            address(this),
            block.timestamp
        ) {
            uint256 usdtBalanceAfter = IERC20(usdt).balanceOf(address(this));
            return usdtBalanceAfter - usdtBalanceBefore;
        } catch {
            return 0;
        }
    }

    function isOpen() public view returns (bool) {
        if (pair == address(0) || vaultContract == address(0)) {
            return false;
        }

        IPancakePair pairContract = IPancakePair(pair);

        uint256 lpTotalSupply = pairContract.totalSupply();
        if (lpTotalSupply == 0) {
            return false;
        }

        uint256 lpBalanceVault = pairContract.balanceOf(vaultContract);

        uint256 reserveUSDT = _getUSDTReserve();
        if (reserveUSDT == 0) {
            return false;
        }

        uint256 lpValue = _mulDiv(lpBalanceVault * 2, reserveUSDT, lpTotalSupply);

        return lpValue >= openThresholdUsdt;
    }

    function getDynamicTaxBps() public view returns (uint16) {
        if (pair == address(0)) {
            return 0;
        }

        uint256 reserveUSDT = _getUSDTReserve();

        uint256 poolMarketValue = reserveUSDT * 2;

        uint16 dynamicBps = 0;
        for (uint256 i = 0; i < taxTiers.length; i++) {
            if (poolMarketValue >= taxTiers[i].thresholdUSDT) {
                dynamicBps = taxTiers[i].taxBps;
            } else {
                break;
            }
        }

        return dynamicBps;
    }

    function _getUSDTReserve() internal view returns (uint256) {
        if (pair == address(0)) {
            return 0;
        }

        IPancakePair pairContract = IPancakePair(pair);
        (uint112 reserve0, uint112 reserve1, ) = pairContract.getReserves();

        address token0 = pairContract.token0();

        if (token0 == usdt) {
            return uint256(reserve0);
        } else {
            return uint256(reserve1);
        }
    }

    function _isBypassAddress(address account) internal view returns (bool) {
        return isTradeBypass[account];
    }

    function _isExemptFromFee(address from, address to) internal view returns (bool) {
        return isFeeExempt[from] || isFeeExempt[to];
    }

    function _mulDiv(uint256 a, uint256 b, uint256 denominator) internal pure returns (uint256) {
        require(denominator > 0, "PSTAR: division by zero");

        uint256 prod0;
        uint256 prod1;
        assembly {
            let mm := mulmod(a, b, not(0))
            prod0 := mul(a, b)
            prod1 := sub(sub(mm, prod0), lt(mm, prod0))
        }

        if (prod1 == 0) {
            return prod0 / denominator;
        }

        require(prod1 < denominator, "PSTAR: mulDiv overflow");

        uint256 remainder;
        assembly {
            remainder := mulmod(a, b, denominator)
            prod1 := sub(prod1, gt(remainder, prod0))
            prod0 := sub(prod0, remainder)
        }

        uint256 twos = denominator & (0 - denominator);
        assembly {
            denominator := div(denominator, twos)
            prod0 := div(prod0, twos)
            twos := add(div(sub(0, twos), twos), 1)
        }
        prod0 |= prod1 * twos;

        uint256 inverse = (3 * denominator) ^ 2;
        inverse *= 2 - denominator * inverse;
        inverse *= 2 - denominator * inverse;
        inverse *= 2 - denominator * inverse;
        inverse *= 2 - denominator * inverse;
        inverse *= 2 - denominator * inverse;
        inverse *= 2 - denominator * inverse;

        return prod0 * inverse;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "PSTAR: new owner is zero address");
        address oldOwner = owner;
        owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }

    function setNodeContracts(
        address _day,
        address _month,
        address _quarter,
        address _year,
        address _vault
    ) external onlyOwner {
        require(_vault != address(0), "PSTAR: vault is zero address");
        require(_month != address(0), "PSTAR: month is zero address");
        require(_quarter != address(0), "PSTAR: quarter is zero address");
        require(_year != address(0), "PSTAR: year is zero address");

        if (dayContract != address(0)) {
            isTradeBypass[dayContract] = false;
            isFeeExempt[dayContract] = false;
        }
        if (monthContract != address(0)) {
            isTradeBypass[monthContract] = false;
            isFeeExempt[monthContract] = false;
        }
        if (quarterContract != address(0)) {
            isTradeBypass[quarterContract] = false;
            isFeeExempt[quarterContract] = false;
        }
        if (yearContract != address(0)) {
            isTradeBypass[yearContract] = false;
            isFeeExempt[yearContract] = false;
        }
        if (vaultContract != address(0)) {
            isTradeBypass[vaultContract] = false;
            isFeeExempt[vaultContract] = false;
        }

        dayContract = _day;
        monthContract = _month;
        quarterContract = _quarter;
        yearContract = _year;
        vaultContract = _vault;

        if (_day != address(0)) {
            isTradeBypass[_day] = true;
            isFeeExempt[_day] = true;
        }
        isTradeBypass[_month] = true;
        isTradeBypass[_quarter] = true;
        isTradeBypass[_year] = true;
        isTradeBypass[_vault] = true;

        isFeeExempt[_vault] = true;
        isFeeExempt[_month] = true;
        isFeeExempt[_quarter] = true;
        isFeeExempt[_year] = true;

        emit NodeContractsUpdated(_day, _month, _quarter, _year, _vault);
    }

    function setNodeTokenContract(address _nodeToken) external onlyOwner {
        require(_nodeToken != address(0), "PSTAR: zero address");
        nodeTokenContract = _nodeToken;
    }

    function setFeeExempt(address account, bool enabled) external onlyOwner {
        isFeeExempt[account] = enabled;
        emit FeeExemptUpdated(account, enabled);
    }

    function setTradeBypass(address account, bool enabled) external onlyOwner {
        isTradeBypass[account] = enabled;
        emit TradeBypassUpdated(account, enabled);
    }

    function setBaseTaxBps(uint16 bps) external onlyOwner {
        require(bps <= 10000, "PSTAR: tax exceeds 100%");
        uint16 oldBps = baseTaxBps;
        baseTaxBps = bps;
        emit BaseTaxUpdated(oldBps, bps);
    }

    function setDistributionRatio(uint16 vaultBps, uint16 quarterBps, uint16 nodeBps) external onlyOwner {
        require(vaultBps + quarterBps + nodeBps == 10000, "PSTAR: ratios must sum to 10000");

        distributeVaultBps = vaultBps;
        distributeQuarterBps = quarterBps;
        distributeNodeBps = nodeBps;

        emit DistributionRatioUpdated(vaultBps, quarterBps, nodeBps);
    }

    function setOpenThreshold(uint256 threshold) external onlyOwner {
        require(threshold > 0, "PSTAR: threshold must be > 0");
        uint256 oldThreshold = openThresholdUsdt;
        openThresholdUsdt = threshold;
        emit OpenThresholdUpdated(oldThreshold, threshold);
    }

    function setTaxTiers(TaxTier[] calldata _tiers) external onlyOwner {
        require(_tiers.length <= 10, "PSTAR: too many tiers, max 10");

        for (uint256 i = 1; i < _tiers.length; i++) {
            require(
                _tiers[i].thresholdUSDT > _tiers[i - 1].thresholdUSDT,
                "PSTAR: tiers must be sorted ascending"
            );
        }

        delete taxTiers;
        for (uint256 i = 0; i < _tiers.length; i++) {
            taxTiers.push(_tiers[i]);
        }

        emit TaxTiersUpdated(_tiers.length);
    }

    function setGrowthThreshold(uint16 bps) external onlyOwner {
        require(bps <= 10000, "PSTAR: bps cannot exceed 100%");
        uint16 oldBps = growthThresholdBps;
        growthThresholdBps = bps;
        emit GrowthThresholdUpdated(oldBps, bps);
    }

    function resetPoolValueTracking() external onlyOwner {
        previousDayHighestValue = 0;
        todayHighestPoolValue = 0;
        lastValueUpdateDay = 0;
        emit PoolValueReset(msg.sender);
    }

    function setTimezoneOffset(int256 offset) external onlyOwner {
        require(offset >= -12 hours && offset <= 14 hours, "PSTAR: invalid timezone offset");
        int256 oldOffset = timezoneOffset;
        timezoneOffset = offset;
        emit TimezoneOffsetUpdated(oldOffset, offset);
    }

    function setSwapConfig(uint256 _threshold, uint256 _maxAmount, uint256 _cooldown) external onlyOwner {
        require(_threshold > 0, "PSTAR: threshold must be > 0");
        swapThreshold = _threshold;
        maxSwapAmount = _maxAmount;
        swapCooldown = _cooldown;
        emit SwapConfigUpdated(_threshold, _maxAmount, _cooldown);
    }

    function getTaxTiersCount() external view returns (uint256) {
        return taxTiers.length;
    }

    function getTaxTier(uint256 index) external view returns (uint256 threshold, uint16 taxBps) {
        require(index < taxTiers.length, "PSTAR: index out of bounds");
        TaxTier memory tier = taxTiers[index];
        return (tier.thresholdUSDT, tier.taxBps);
    }

    function getAllTaxTiers() external view returns (TaxTier[] memory) {
        return taxTiers;
    }

    function getPendingTaxInfo() external view returns (
        uint256 pendingBase,
        uint256 pendingDynamic,
        uint256 total
    ) {
        pendingBase = _pendingBaseSwap;
        pendingDynamic = _pendingDynamicSwap;
        total = _pendingBaseSwap + _pendingDynamicSwap;
    }

    function getPoolMarketValue() public view returns (uint256) {
        return _getUSDTReserve() * 2;
    }

    function getPoolValueTracking() external view returns (
        uint256 currentValue,
        uint256 todayHighest,
        uint256 previousDayHighest,
        uint256 lastUpdateDay
    ) {
        uint256 today = _getCurrentDay();
        currentValue = _getVaultLPValueInternal();

        if (today > lastValueUpdateDay) {
            todayHighest = currentValue;
            previousDayHighest = todayHighestPoolValue;
        } else {
            todayHighest = todayHighestPoolValue > currentValue ? todayHighestPoolValue : currentValue;
            previousDayHighest = previousDayHighestValue;
        }
        lastUpdateDay = lastValueUpdateDay;
    }

    function checkGrowthThreshold() external view returns (
        bool canClaim,
        uint256 currentValue,
        uint256 requiredValue
    ) {
        uint256 today = _getCurrentDay();
        currentValue = _getVaultLPValueInternal();

        uint256 previousDayHighest;
        if (today > lastValueUpdateDay) {
            previousDayHighest = todayHighestPoolValue;
        } else {
            previousDayHighest = previousDayHighestValue;
        }

        if (growthThresholdBps == 0 || previousDayHighest == 0) {
            return (true, currentValue, 0);
        }

        requiredValue = previousDayHighest * (10000 + growthThresholdBps) / 10000;
        canClaim = currentValue >= requiredValue;
    }

    function getVaultLPValue() external view returns (uint256) {
        if (pair == address(0) || vaultContract == address(0)) {
            return 0;
        }

        IPancakePair pairContract = IPancakePair(pair);
        uint256 lpTotalSupply = pairContract.totalSupply();
        if (lpTotalSupply == 0) {
            return 0;
        }

        uint256 lpBalanceVault = pairContract.balanceOf(vaultContract);
        uint256 reserveUSDT = _getUSDTReserve();

        return _mulDiv(lpBalanceVault * 2, reserveUSDT, lpTotalSupply);
    }

    function getCurrentTaxInfo() external view returns (
        uint16 baseBps,
        uint16 dynamicBps,
        uint16 totalBps,
        uint256 poolValue,
        bool tradingOpen
    ) {
        baseBps = baseTaxBps;
        dynamicBps = getDynamicTaxBps();
        totalBps = baseBps + dynamicBps;
        poolValue = _getUSDTReserve() * 2;
        tradingOpen = isOpen();
    }

    function _initDefaultTaxTiers() internal {
        taxTiers.push(TaxTier({
            thresholdUSDT: 10_000_000 * 10**18,
            taxBps: 3500
        }));

        taxTiers.push(TaxTier({
            thresholdUSDT: 20_000_000 * 10**18,
            taxBps: 3000
        }));

        taxTiers.push(TaxTier({
            thresholdUSDT: 40_000_000 * 10**18,
            taxBps: 2500
        }));

        taxTiers.push(TaxTier({
            thresholdUSDT: 60_000_000 * 10**18,
            taxBps: 1500
        }));

        taxTiers.push(TaxTier({
            thresholdUSDT: 100_000_000 * 10**18,
            taxBps: 500
        }));

        taxTiers.push(TaxTier({
            thresholdUSDT: 200_000_000 * 10**18,
            taxBps: 0
        }));
    }

    function rescueTokens(address token, uint256 amount) external onlyOwner {
        require(token != address(this), "PSTAR: cannot rescue PSTAR");
        _safeTransfer(token, owner, amount);
    }

    function rescueBNB(uint256 amount) external onlyOwner {
        uint256 balance = address(this).balance;
        require(balance > 0, "PSTAR: no BNB to rescue");
        uint256 toSend = amount == 0 ? balance : amount;
        require(toSend <= balance, "PSTAR: insufficient BNB balance");
        (bool success, ) = owner.call{value: toSend}("");
        require(success, "PSTAR: BNB transfer failed");
    }

    function _safeTransfer(address token, address to, uint256 amount) internal {
        (bool success, bytes memory data) = token.call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, amount)
        );
        require(success && (data.length == 0 || abi.decode(data, (bool))), "PSTAR: safe transfer failed");
    }
}
