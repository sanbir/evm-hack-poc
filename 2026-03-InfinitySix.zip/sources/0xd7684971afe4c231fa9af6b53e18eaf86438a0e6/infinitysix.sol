// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract InfinitySix is ERC20, ERC20Burnable, Ownable {
    uint256 public constant BURN_RATE = 1;
    address public dexPair;
    
    uint256 public buyingEnabledTime;

    mapping(address => bool) public allowedContracts;

    constructor(address initialOwner) 
        ERC20("Infinity Six", "i6") 
        Ownable(initialOwner) 
    {
        _mint(msg.sender, 6000000 * 10 ** decimals());
        
        buyingEnabledTime = block.timestamp + 365 days;
    }

    function setDexPair(address _dexPair) external onlyOwner {
        dexPair = _dexPair;
    }

    function setAllowedContract(address contractAddress, bool allowed) external onlyOwner {
        allowedContracts[contractAddress] = allowed;
    }

    function _update(address from, address to, uint256 value) internal override(ERC20) {
        if (from == address(0) || to == address(0)) {
            super._update(from, to, value);
            return;
        }

        if (block.timestamp < buyingEnabledTime) {
            if (from == dexPair && !allowedContracts[to]) {
                revert("i6: Buying is locked for 12 months");
            }
        }

        uint256 burnAmount = 0;

        if (from == dexPair || to == dexPair) {
            burnAmount = (value * BURN_RATE) / 100;
        }

        if (burnAmount > 0) {
            super._update(from, address(0), burnAmount);
        }
        
        super._update(from, to, value - burnAmount);
    }
}