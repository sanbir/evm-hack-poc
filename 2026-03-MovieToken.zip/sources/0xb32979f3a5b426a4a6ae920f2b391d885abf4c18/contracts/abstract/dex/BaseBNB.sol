// SPDX-License-Identifier: MIT
pragma solidity ^0.8.4;

import {IUniswapV2Factory} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "@uniswap/v2-periphery/contracts/interfaces/IUniswapV2Router02.sol";
import {IUniswapV2Pair} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Distributor} from "../../lib/Distributor.sol";

abstract contract BaseBNB {
    address public immutable WBNB;
    IUniswapV2Router02 public immutable uniswapV2Router;
    address public immutable uniswapV2Pair;
    Distributor public immutable distributor;
    bool public inSwapAndLiquidity;

    modifier lockTheSwap() {
        inSwapAndLiquidity = true;
        _;
        inSwapAndLiquidity = false;
    }

    constructor(address _WBNB, address _ROUTER) {
        WBNB = _WBNB;
        uniswapV2Router = IUniswapV2Router02(_ROUTER);
        // Check if pair exists first, if not create it
        IUniswapV2Factory factory = IUniswapV2Factory(uniswapV2Router.factory());
        address existingPair = factory.getPair(address(this), WBNB);
        if (existingPair == address(0)) {
            existingPair = factory.createPair(address(this), WBNB);
        }
        uniswapV2Pair = existingPair;
        distributor = new Distributor(WBNB);
    }
}

