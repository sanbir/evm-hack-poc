	// SPDX-License-Identifier: UNLICENSED
	pragma solidity ^0.8.20;

	import {FirstLaunch} from "../abstract/FirstLaunch.sol";
	import {Owned} from "solmate/src/auth/Owned.sol";
	import {IUniswapV2Pair} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol";
	import {IUniswapV2Factory} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Factory.sol";
	import {ERC20} from "../abstract/token/ERC20.sol";
	import {ExcludedFromFeeList} from "../abstract/ExcludedFromFeeList.sol";
	import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
	import {BaseBNB} from "../abstract/dex/BaseBNB.sol";
	import {IMTManager} from "../interfaces/IMTManager.sol";
	import {IMTLpMining} from "../interfaces/IMTLpMining.sol";
	import {IMTReferral} from "../interfaces/IMTReferral.sol";

	// Interface for MTDeposit to update super NFT holder cache

	/**
	 * @title MT Token (Movie Token)
	 * @notice MT Token with LP mining, referral system, and deflationary mechanics
	 * @dev 
	 * Total Supply: 21,000,000
	 * - 20,000,000 -> LP Pool
	 * - 1,000,000 -> Community Incentives
	 * 
	 * Tax: Sell 10% (Buy 0%)
	 *   - 5% -> Back to Pool
	 *   - 5% -> Film Ecosystem
	 * 
	 * Features:
	 * - LP Mining: Daily 1% output (0.5% LP dividend, 0.1% dynamic, 0.4% burn)
	 * - Triple Burn: Daily 0.8% from pool, all tokens on LP withdrawal, all tokens on sell (via tax/LP)
	 * - Referral Binding: Transfer 0.2 token, get back 0.1 token to confirm referral
	 */
	contract MT is ExcludedFromFeeList, BaseBNB, FirstLaunch, ERC20 {
		// ===========================
		// Constants & Config
		// ===========================
		uint256 public constant FEE_DENOMINATOR = 10000;
		uint256 public constant POOL_BACK_RATE = 500; // 5%
		uint256 public constant ECO_RATE = 500; // 5%
		
		uint256 public constant MIN_LP_SUPPLY = 21000 * 1e18; // 2.1万枚（LP流动池通缩至2.1万枚时开放买单、停止通缩、取消买卖税）
		uint256 public constant BINDING_AMOUNT = 2 * 1e17; // 0.2枚用于绑定
		uint256 public constant BINDING_RETURN = 1 * 1e17; // 0.1枚返还
		
		// 黑洞地址（用于销毁代币）
		address public constant DEAD_ADDRESS = address(0xdead);
		
		// ===========================
		// State Variables
		// ===========================
		bool public presale;
		bool public tradingEnabled;
		bool public deflationStopped; // 当LP流动池余额 <= 2.1万枚时停止通缩
		
		// Accumulated Fees
		uint256 public accumulatedToPool;   // 5% 回流底池
		uint256 public accumulatedToEco;    // 5% 影视生态
		uint256 public feeProcessingThreshold = 1000 * 1e18; // 手续费处理阈值
		
		// Contracts
		IMTManager public mtManager;
		address public mtManagerAddr;
		IMTLpMining public lpMining;
		address public lpMiningAddr;
		IMTReferral public referral;
		address public referralAddr;
		
		// Deposit Contract
		address public depositContract;
		
		// LP Pool for extraction (can be different from uniswapV2Pair)
		address public lpPoolForExtraction;
		
		// Mapping for pairs
		mapping(address => bool) public swapV2Pairs;
		
		// Binding mechanism: user => referral (confirmed by transfer)
		mapping(address => address) public confirmedReferral;
		
		// Pending binding requests: user => referral (waiting for recipient to confirm)
		mapping(address => address) public pendingBinding;
		
		// Pending burn amount: accumulated tokens to be burned when extracting from pool
		uint256 public pendingBurnAmount;
		
		// ===========================
		// Events
		// ===========================
		event PresaleOpened();
		event TradingEnabled();
		event TradingDisabled();
		event DeflationStopped();
		event ReferralPending(address indexed user, address indexed referral);
		event ReferralConfirmed(address indexed user, address indexed referral);
		event LpWithdrawn(address indexed user, uint256 lpAmount, uint256 tokensBurned);
		event PendingBurnRecorded(address indexed user, uint256 amount);
		event PendingBurnExecuted(uint256 amount);
		event FeesProcessed(uint256 poolFee, uint256 ecoFee);

		constructor(
			address _wbnb,
			address _router
		)
			Owned(msg.sender)
			ERC20("Movie Token", "MT", 18, 0)
			BaseBNB(_wbnb, _router)
		{
			// 只执行必要的初始化操作以节省 gas
			// 其他操作（approve、excludeFromFee）可以在部署后通过初始化函数完成
			
			// Mint initial supply: 20M to deployer (for LP), 1M for community
			// Total: 21,000,000 MT
			_mint(msg.sender, 21000000 * 1e18);
			
			// 延迟以下操作到部署后（通过初始化函数）：
			// - allowance[address(this)][address(uniswapV2Router)] = type(uint256).max;
			// - IERC20(WBNB).approve(address(uniswapV2Router), type(uint256).max);
			// - excludeFromFee(msg.sender);
			// - excludeFromFee(address(this));
		}

	  
		/**
		 * @notice 初始化函数，在部署后调用以完成设置（节省构造函数 gas）
		 * @dev 必须在部署后立即调用此函数
		 */
		function initialize() external onlyOwner {
			// 设置 allowance
			allowance[address(this)][address(uniswapV2Router)] = type(uint256).max;
			IERC20(WBNB).approve(address(uniswapV2Router), type(uint256).max);
			
			// 设置 fee exclusion
			excludeFromFee(msg.sender);
			excludeFromFee(address(this));
		}
		
		function setPresale() external onlyOwner {
			presale = true;
			launch();
			emit PresaleOpened();
		}

		function setMTManagerAddr(address _addr) public onlyOwner {
			require(_addr != address(0), "Zero address");
			mtManager = IMTManager(_addr);
			mtManagerAddr = _addr;
			allowance[address(this)][_addr] = type(uint256).max;
			excludeFromFee(_addr);
		}

		function setLpMiningAddr(address _addr) external onlyOwner {
			require(_addr != address(0), "Zero address");
			lpMining = IMTLpMining(_addr);
			lpMiningAddr = _addr;
			excludeFromFee(_addr);
		}

		function setReferralAddr(address _addr) external onlyOwner {
			require(_addr != address(0), "Zero address");
			referral = IMTReferral(_addr);
			referralAddr = _addr;
			excludeFromFee(_addr);
		}

		function setDepositContract(address _addr) external onlyOwner {
			require(_addr != address(0), "Zero address");
			depositContract = _addr;
			excludeFromFee(_addr);
		}
		
		function setLpPoolForExtraction(address _pair) external onlyOwner {
			require(_pair != address(0), "Zero address");
			lpPoolForExtraction = _pair;
		}

		function setPair(address _pair, bool _value) external onlyOwner {
			swapV2Pairs[_pair] = _value;
		}
		
		function setFeeProcessingThreshold(uint256 _threshold) external onlyOwner {
			feeProcessingThreshold = _threshold;
		}

		function enableTrading() external onlyOwner {
			require(presale, "Presale not started");
			tradingEnabled = true;
			emit TradingEnabled();
		}

		function disableTrading() external onlyOwner {
			tradingEnabled = false;
			emit TradingDisabled();
		}

		/**
		 * @notice Reset deflation status (only when LP pool balance > MIN_LP_SUPPLY)
		 * @dev This allows manually resuming deflation if LP pool balance increases above 2.1万枚
		 *      Note: Once deflation stops, it will not automatically resume
		 */
		function resetDeflation() external onlyOwner {
			require(uniswapV2Pair != address(0), "Pair not set");
			uint256 lpBalance = balanceOf[uniswapV2Pair];
			require(lpBalance > MIN_LP_SUPPLY, "LP pool balance must be > MIN_LP_SUPPLY");
			deflationStopped = false;
		}

		// Daily pool extraction tracking (借鉴BTdaoToken)
		uint256 public constant DAY_IN_SECONDS = 86400; // 测试用：1秒；生产环境应改为 86400 (24小时)
		uint256 public lastPoolExtractionTime; // Last time pool was extracted
		
		/**
		 * @notice Extract tokens from pool for LP mining (called by MTLpMining)
		 * @dev 从底池（Pair）中提取代币用于LP挖矿分配（借鉴BTdaoToken）
		 *      每天只能抽一次
		 *      同时销毁记录的卖出代币数量
		 * @param amount Amount to extract from pool
		 * @return Extracted amount
		 */
		function extractFromPoolForLpMining(uint256 amount) external returns (uint256) {
			require(msg.sender == lpMiningAddr, "Only LP mining");
			require(!deflationStopped, "Deflation stopped");
			
			// 使用 lpPoolForExtraction 如果设置了，否则使用 uniswapV2Pair
			address extractionPool = lpPoolForExtraction != address(0) ? lpPoolForExtraction : uniswapV2Pair;
			require(extractionPool != address(0), "Pool not set");
			
			// 每天只能抽一次（借鉴BTdaoToken的todayMidnight逻辑）
			uint256 todayMidnight = (block.timestamp / DAY_IN_SECONDS) * DAY_IN_SECONDS;
			require(todayMidnight > lastPoolExtractionTime, "Already extracted today");
			
			uint256 poolBalance = balanceOf[extractionPool];
			if (poolBalance == 0 || amount == 0) {
				// 即使不提取，也要处理待销毁的代币
				_executePendingBurn(extractionPool);
				lastPoolExtractionTime = todayMidnight; // Mark as extracted even if amount is 0
				return 0;
			}
			
			// 先处理待销毁的代币
			_executePendingBurn(extractionPool);
			
			// Limit extraction to available pool balance (after burn)
			poolBalance = balanceOf[extractionPool];
			if (amount > poolBalance) {
				amount = poolBalance;
			}
			
			// 边界检查：确保抽取后LP流动池余额不会低于 MIN_LP_SUPPLY (2.1万枚)
			// 如果抽取后会导致LP流动池余额 < 2.1万枚，则只抽取到 2.1万枚为止
			if (poolBalance - amount < MIN_LP_SUPPLY) {
				if (poolBalance > MIN_LP_SUPPLY) {
					// 只抽取到 2.1万枚为止
					amount = poolBalance - MIN_LP_SUPPLY;
				} else {
					// LP流动池余额已经 <= 2.1万枚，不能抽取
					amount = 0;
				}
			}
			
			// 如果调整后的 amount 为 0，不执行抽取
			if (amount == 0) {
				lastPoolExtractionTime = todayMidnight; // Mark as extracted even if amount is 0
				return 0;
			}
			
			// Extract from pool balance (similar to BTdaoToken)
			balanceOf[extractionPool] -= amount;
			balanceOf[address(this)] += amount;
			emit Transfer(extractionPool, address(this), amount);
			
			// Transfer to LP mining contract
			balanceOf[address(this)] -= amount;
			balanceOf[lpMiningAddr] += amount;
			emit Transfer(address(this), lpMiningAddr, amount);
			
			// Sync pair reserves
			try IUniswapV2Pair(extractionPool).sync() {} catch {}
			
			// Mark as extracted for today
			lastPoolExtractionTime = todayMidnight;
			
			return amount;
		}
		
		/**
		 * @notice Execute pending burn from pool
		 * @dev 从底池中销毁记录的待销毁代币数量
		 *      当底池达到2.1万枚时，不再执行销毁
		 * @param extractionPool The pool address to burn from
		 */
		function _executePendingBurn(address extractionPool) internal {
			if (pendingBurnAmount == 0) return;
			
			uint256 poolBalance = balanceOf[extractionPool];
			if (poolBalance == 0) {
				// 如果池子没有余额，清空待销毁数量
				pendingBurnAmount = 0;
				return;
			}
			
			// 限制销毁数量不超过池子余额，且确保销毁后LP流动池余额不会低于2.1万枚
			uint256 burnAmount = pendingBurnAmount;
			if (burnAmount > poolBalance) {
				burnAmount = poolBalance;
			}
			
			// 确保销毁后LP流动池余额不会低于2.1万枚
			if (poolBalance - burnAmount < MIN_LP_SUPPLY) {
				burnAmount = poolBalance > MIN_LP_SUPPLY ? poolBalance - MIN_LP_SUPPLY : 0;
			}
			
			if (burnAmount == 0) {
				// 如果不需要销毁，清空待销毁数量
				pendingBurnAmount = 0;
				return;
			}
			
			// 从池子中销毁代币
			balanceOf[extractionPool] -= burnAmount;
			balanceOf[DEAD_ADDRESS] += burnAmount;
			emit Transfer(extractionPool, DEAD_ADDRESS, burnAmount);
			emit PendingBurnExecuted(burnAmount);
			
			// 更新待销毁数量
			pendingBurnAmount -= burnAmount;
			
			// Sync pair reserves
			try IUniswapV2Pair(extractionPool).sync() {} catch {}
		}

		// ===========================
		// Core Logic
		// ===========================

		function _transfer(
			address sender,
			address recipient,
			uint256 amount
		) internal virtual override {
			// 0. Referral Binding Mechanism: Two-step confirmation
			// 绑定逻辑必须在白名单检查之前，确保绑定功能对所有地址都有效
			// Step 1: Referral transfers 0.2 MT to user (creates pending binding)
			if (amount == BINDING_AMOUNT && 
				confirmedReferral[recipient] == address(0) && 
				pendingBinding[recipient] == address(0) &&
				referralAddr != address(0)) {
					// Record pending binding request (referral -> user)
					pendingBinding[recipient] = sender;
					super._transfer(sender, recipient, amount);
					emit ReferralPending(recipient, sender);
					return;
			}
			
			// Step 2: User transfers 0.1 MT back to referral (confirms binding)
			if (amount == BINDING_RETURN && 
				pendingBinding[sender] == recipient &&
				confirmedReferral[sender] == address(0)) {
				// Confirm the binding (user -> referral)
				confirmedReferral[sender] = recipient;
				delete pendingBinding[sender];
				
				// Automatically bind referral relationship in MTReferral after confirmation
				// if (referralAddr != address(0)) {
				//     try referral.bindReferral(recipient, sender) {} catch {}
				// }

				// 转账确认绑定时，自动绑定超级NFT持有者到 MTReferral 映射中
				if (referralAddr != address(0)) {
					try referral.bindReferral(recipient, sender) {
						// ✅ 绑定成功后，自动绑定超级NFT持有者到 MTReferral 映射中
						// 如果接收方（推荐人）的映射中已经有超级NFT持有者，直接同步更新发送方的映射
						address recipientSuperNft = referral.getSuperNftHolder(recipient);
						
						if (recipientSuperNft != address(0)) {
							// 接收方已经有超级NFT映射，直接同步给发送方
							// 只更新发送方的映射，不更新下级用户
							try referral.setSuperNftHolder(sender, recipientSuperNft) {} catch {}
						} 
					} catch {}
				}
				
				super._transfer(sender, recipient, amount);
				emit ReferralConfirmed(sender, recipient);
				return;
			}
			
			// 1. 优先检查白名单：白名单地址跳过所有限制和税费
			// 白名单地址包括：合约本身、MTManager、LP挖矿合约、推荐合约、入金合约等
			// 注意：绑定逻辑已在上面处理，这里只处理非绑定转账
			if (_isExcludedFromFee[sender] && _isExcludedFromFee[recipient]) {
				// 白名单地址直接转账，跳过所有限制、税费和特殊处理
				super._transfer(sender, recipient, amount);
				return;
			}
			
			// 2. 先判断交易类型，以便正确处理添加/移除流动性的情况
			(bool isAdd, bool isRm) = addOrRemove(sender, recipient, amount);
			
			// 检查通缩状态（基于LP流动池余额）
			// 通缩停止条件：LP流动池余额 <= 2.1万枚（MIN_LP_SUPPLY）：开放买单、停止通缩、取消买卖税
			// 通缩状态：一旦停止就不再恢复
			if (!isAdd) {
				// 只有非添加流动性的交易才检查通缩状态
			if (uniswapV2Pair != address(0)) {
				uint256 lpBalance = balanceOf[uniswapV2Pair];
				if (lpBalance <= MIN_LP_SUPPLY && !deflationStopped) {
					deflationStopped = true;
					emit DeflationStopped();
					}
				}
			}

			// 2. Identify Transaction Type (借鉴 F Token 的精确判断逻辑)
			// 注意：isAdd 和 isRm 已经在上面计算过了，这里不需要重新计算
			// 但为了代码清晰，我们保留这个注释
			
			// 判断买入：Pair 转出 MT 给用户，且不是移除流动性（借鉴 F Token）
			// 双重保护：检查 swapV2Pairs 映射或直接检查 uniswapV2Pair
			// 如果 sender 是 Pair 且 msg.sender 是 Router，需要区分是移除流动性还是 swap
			// 移除流动性：recipient 是 depositContract 或用户地址，且是移除流动性操作
			// swap：recipient 是 depositContract（MTDeposit 在 swap 时买入 MT）
			bool isRouterRemoveLP = (sender == uniswapV2Pair && msg.sender == address(uniswapV2Router) && isRm);
			bool isBuy = (swapV2Pairs[sender] || sender == uniswapV2Pair) && !isRm && !isRouterRemoveLP;
			// 判断卖出：用户转 MT 给 Pair，且不是添加流动性（借鉴 F Token）
			// 双重保护：检查 swapV2Pairs 映射或直接检查 uniswapV2Pair
			bool isSell = (swapV2Pairs[recipient] || recipient == uniswapV2Pair) && !isAdd;
			
			// 3. Handle Add Liquidity (移除流动性由 MTDeposit 合约处理)
			// 参考 RWAToken: if (isAdd) { if (to != centerContractAddress) { require(false, "not add"); } }
			if (isAdd) {
				// 添加流动性时，只允许 depositContract 添加（参考 RWAToken 的严格限制）
				// 检查 recipient 是否是 Pair，且 sender 或 tx.origin 是否是 depositContract
				// 添加流动性时，Router 会从用户或 depositContract 转移代币到 Pair
				// 如果 sender 是 Router，需要检查 tx.origin 是否是 depositContract
				// 如果 sender 不是 Router，需要检查 sender 是否是 depositContract
				bool isFromDeposit = (sender == depositContract || tx.origin == depositContract);
				if (!isFromDeposit) {
					revert("Adding liquidity not allowed: only deposit contract can add liquidity");
				}
				
				// 添加流动性时，直接转账，不处理费用和销毁
				super._transfer(sender, recipient, amount);
				
				// 自动注册 LP 提供者
				if (lpMiningAddr != address(0)) {
					// 添加流动性时，sender 是 Router，recipient 是 Pair
					// 实际的用户地址需要通过 tx.origin 或其他方式获取
					address user = (sender == address(uniswapV2Router)) ? tx.origin : sender;
					if (user != address(0) && user != address(this) && user != mtManagerAddr && user != depositContract) {
						_autoRegisterLpProvider(user);
					}
				}
				
				// 添加流动性不会改变总供应量（除黑洞地址外），所以不需要检查通缩状态
				// 代币只是从用户地址转移到 Pair 地址，总供应量不变
				
				return;
			}
			
	 
			// MT 合约逻辑（通缩期间 = CSDToken 的 preLPAmount 情况，通缩停止后 = CSDToken 的正常 LP 情况）：
			//   - 通缩期间（!deflationStopped）：销毁代币 super._transfer(sender, DEAD_ADDRESS, amount)
			//   - 通缩停止后（deflationStopped）：正常转账 super._transfer(sender, recipient, amount)
			// 移除流动性时，转账方向是 Pair -> MTDeposit（Router 会从 Pair 转移 MT tokens 到 MTDeposit）
			if (isRm) {
				// 根据通缩状态决定是否销毁
				if (!deflationStopped) {
					// 代币总量还未达到阈值，且通缩期间：销毁代币（参考 CSDToken: super._transfer(from, address(0xDead), amount)）
					// 但是，如果销毁会导致底池代币数低于2.1万枚，则只销毁到2.1万枚，剩余的代币正常转账
					uint256 burnAmount = amount;
					uint256 transferAmount = 0;
					
					if (uniswapV2Pair != address(0) && sender == uniswapV2Pair) {
						// 检查移除流动性后，底池余额是否会低于2.1万枚
						uint256 currentLpBalance = balanceOf[uniswapV2Pair];
						// 注意：此时 balanceOf[sender] 还是移除前的余额，amount 是要移除的数量
						// 移除后底池余额 = currentLpBalance - amount
						if (currentLpBalance > amount) {
							uint256 lpBalanceAfter = currentLpBalance - amount;
							if (lpBalanceAfter < MIN_LP_SUPPLY) {
								// 如果移除后底池余额会低于2.1万枚，只销毁到2.1万枚
								// 需要保留 MIN_LP_SUPPLY 在底池，所以最多销毁 currentLpBalance - MIN_LP_SUPPLY
								if (currentLpBalance > MIN_LP_SUPPLY) {
									burnAmount = currentLpBalance - MIN_LP_SUPPLY;
									transferAmount = amount - burnAmount;
								} else {
									// 底池余额已经 <= 2.1万枚，不销毁，全部正常转账
									burnAmount = 0;
									transferAmount = amount;
								}
							}
						} else {
							// 底池余额不足，不销毁，全部正常转账
							burnAmount = 0;
							transferAmount = amount;
						}
					}
					
					// 销毁代币到 DEAD_ADDRESS
					if (burnAmount > 0) {
						super._transfer(sender, DEAD_ADDRESS, burnAmount);
					}
					
					// 如果有剩余代币，正常转账给 recipient
					if (transferAmount > 0) {
						super._transfer(sender, recipient, transferAmount);
					}


                    // 清除推荐关系和移除 LP 提供者（通缩期间移除流动性时）
					// recipient 是用户地址（通过 Router 移除流动性时）
					address user = recipient;
					if (user != address(0)) {
						// 清除推荐关系
						if (referralAddr != address(0)) {
							try referral.clearReferralOnLpWithdrawal(user) {} catch {}
						}
						// 移除 LP 提供者
						if (lpMiningAddr != address(0)) {
							try lpMining.removeLpProvider(user) {} catch {}
						}
					}
					
					
				} else {
					// 代币总量还未达到阈值，但通缩已停止：正常转账（参考 CSDToken: super._transfer(from, to, amount)）
					super._transfer(sender, recipient, amount);
				 
					// 清除推荐关系和移除 LP 提供者（通缩停止后移除流动性时）
					// recipient 是用户地址（通过 Router 移除流动性时）
					address user = recipient;
					if (user != address(0)) {
						// 清除推荐关系
						if (referralAddr != address(0)) {
							try referral.clearReferralOnLpWithdrawal(user) {} catch {}
						}
						// 移除 LP 提供者
						if (lpMiningAddr != address(0)) {
							try lpMining.removeLpProvider(user) {} catch {}
						}
					}
				}
				
				// 检查通缩状态（转账后，LP流动池余额已变化）
				if (!isAdd && uniswapV2Pair != address(0)) {
					uint256 lpBalanceAfter = balanceOf[uniswapV2Pair];
					if (lpBalanceAfter <= MIN_LP_SUPPLY && !deflationStopped) {
						deflationStopped = true;
						emit DeflationStopped();
					}
				}
				
				return;
			}
			
			// 特殊处理：如果 sender 是 Pair 且 msg.sender 是 Router（用户通过 Router 直接移除流动性），且不是 isRm
			// 这可能是移除流动性时 Router 的转账（isRm 可能没有被正确识别）
			// 在这种情况下，也应该允许转账，并根据通缩状态决定是否销毁
			if (sender == uniswapV2Pair && msg.sender == address(uniswapV2Router) && !isRm && !isAdd) {
				// 这很可能是用户通过 Router 直接移除流动性操作
				if (!deflationStopped) {
					// 代币总量还未达到阈值，且通缩期间：销毁代币
					// 但是，如果销毁会导致底池代币数低于2.1万枚，则只销毁到2.1万枚，剩余的代币正常转账
					uint256 burnAmount = amount;
					uint256 transferAmount = 0;
					
					// 检查移除流动性后，底池余额是否会低于2.1万枚
					uint256 currentLpBalance = balanceOf[uniswapV2Pair];
					// 注意：此时 balanceOf[sender] 还是移除前的余额，amount 是要移除的数量
					// 移除后底池余额 = currentLpBalance - amount
					if (currentLpBalance > amount) {
						uint256 lpBalanceAfter = currentLpBalance - amount;
						if (lpBalanceAfter < MIN_LP_SUPPLY) {
							// 如果移除后底池余额会低于2.1万枚，只销毁到2.1万枚
							// 需要保留 MIN_LP_SUPPLY 在底池，所以最多销毁 currentLpBalance - MIN_LP_SUPPLY
							if (currentLpBalance > MIN_LP_SUPPLY) {
								burnAmount = currentLpBalance - MIN_LP_SUPPLY;
								transferAmount = amount - burnAmount;
							} else {
								// 底池余额已经 <= 2.1万枚，不销毁，全部正常转账
								burnAmount = 0;
								transferAmount = amount;
							}
						}
					} else {
						// 底池余额不足，不销毁，全部正常转账
						burnAmount = 0;
						transferAmount = amount;
					}
					
					// 销毁代币到 DEAD_ADDRESS
					if (burnAmount > 0) {
						super._transfer(sender, DEAD_ADDRESS, burnAmount);
					}
					
					// 如果有剩余代币，正常转账给 recipient（用户）
					if (transferAmount > 0) {
						super._transfer(sender, recipient, transferAmount);
					}
					
					
				} else {
					// 通缩已停止：正常转账
					super._transfer(sender, recipient, amount);
					
					// 清除推荐关系和移除 LP 提供者（通缩停止后移除流动性时）
					// recipient 是用户地址（通过 Router 移除流动性时）
					address user = recipient;
					if (user != address(0)) {
						// 清除推荐关系
						if (referralAddr != address(0)) {
							try referral.clearReferralOnLpWithdrawal(user) {} catch {}
						}
						// 移除 LP 提供者
						if (lpMiningAddr != address(0)) {
							try lpMining.removeLpProvider(user) {} catch {}
						}
					}
				}
				return;
			}
			
		   
		   
			// 4. Check Trading
			// 获取方式：只能通过LP流动性挖矿获得，可自由卖出
			// - 通缩阶段：禁止买入（只能通过LP挖矿获得），允许卖出（10%税）
			// - 通缩停止后：开放买单（0%税），允许卖出（0%税，取消买卖税），停止所有销毁
			//   当LP流动池 <= 2.1万枚时，自动开放买单、停止通缩、取消买卖税（不需要手动开启tradingEnabled）
			// 例外：MTDeposit 合约在添加流动性时可以买入（用于组成 LP）
			// 注意：swap 时 sender  is Pair，recipient 是 MTDeposit，所以需要检查 recipient
			
			// 检查LP流动池余额，判断是否应该开放交易
			bool lpPoolAtThreshold = false;
			if (uniswapV2Pair != address(0)) {
				uint256 lpBalance = balanceOf[uniswapV2Pair];
				lpPoolAtThreshold = lpBalance <= MIN_LP_SUPPLY;
			}
			
			if (isBuy) {
				if (!deflationStopped) {
					// 通缩阶段：只允许 MTDeposit 合约买入（参考 RWAToken 的严格限制）
					// 参考 RWAToken: if (pairs[from]) { if (to != centerContractAddress) { require(false, "not buy"); } }
					// MT 合约: 如果 sender 是 Pair，只允许 recipient 是 depositContract
					if (sender == uniswapV2Pair || swapV2Pairs[sender]) {
						// 买入操作：从 Pair 转出 MT tokens
						// 只允许转给 depositContract（MTDeposit 在 swap 时买入 MT）
						if (recipient != depositContract) {
						// 通缩阶段完全禁止买入，只能通过LP挖矿获得代币
						revert("Buying not allowed: tokens can only be obtained through LP mining");
						}
					}
				} else {
					// 通缩停止后：检查是否允许买入
					// 如果LP流动池 <= 2.1万枚，自动允许买入（开放买单）
					// 否则需要检查总供应量或tradingEnabled
					if (lpPoolAtThreshold) {
						// LP流动池 <= 2.1万枚，自动允许买入（开放买单，不需要tradingEnabled）
						// 继续执行，不 revert
					} else {
						// 通缩已停止但LP流动池余额 > 2.1万枚，需要手动开启tradingEnabled
						if (!tradingEnabled) {
						revert("Trading not enabled");
					}
					}
				}
			}
			// 卖出：通缩阶段允许（可自由卖出，10%税）
			// 通缩停止后：如果LP流动池 <= 2.1万枚，自动允许交易（取消买卖税）；否则需要tradingEnabled
			if (isSell && deflationStopped) {
				// 检查LP流动池：如果 <= 2.1万枚，自动允许交易（取消买卖税）
				if (!lpPoolAtThreshold && !tradingEnabled) {
					// LP流动池 > 2.1万枚但通缩已停止，需要手动开启tradingEnabled
					revert("Trading not enabled");
				}
			}

			// 5. Handle Sell - Process fees and record burn amount (通缩阶段)
			// 卖出流程：user -> pair
			// 1. 扣除10%手续费（5%回流底池，5%影视生态）
			// 2. 通缩阶段：记录待销毁数量（扣除手续费后的净额），等抽底池时一起销毁
			// 3. 当LP流动池 <= 2.1万枚时，取消买卖税（不再扣税）
			// 注意：白名单地址已经在函数开头处理，这里不需要再检查
			// 检查LP流动池余额，判断是否应该取消买卖税
			bool shouldCancelTax = false;
			if (uniswapV2Pair != address(0)) {
				uint256 lpBalanceForTax = balanceOf[uniswapV2Pair];
				shouldCancelTax = lpBalanceForTax <= MIN_LP_SUPPLY;
			}
			
			if (isSell && !deflationStopped && !shouldCancelTax) {
				// 用户转 MT 给 Pair（卖出）
				if (sender != uniswapV2Pair && recipient == uniswapV2Pair) {
					// 计算手续费：10% 卖出税
					// 5% 回流底池，5% 影视生态（基于amount计算，不是基于feeAmount）
					uint256 poolFee = (amount * POOL_BACK_RATE) / FEE_DENOMINATOR; // 5% of amount
					uint256 ecoFee = (amount * ECO_RATE) / FEE_DENOMINATOR; // 5% of amount
					uint256 feeAmount = poolFee + ecoFee; // 总手续费 = 10% of amount
					uint256 netAmount = amount - feeAmount; // 扣除手续费后的净额
					
					// 累积手续费
					accumulatedToPool += poolFee;
					accumulatedToEco += ecoFee;
					
					// 手续费转给合约地址
					if (feeAmount > 0) {
						super._transfer(sender, address(this), feeAmount);
					}
					
						// 记录待销毁数量（扣除手续费后的净额，等抽底池时一起销毁）
						pendingBurnAmount += netAmount;
						emit PendingBurnRecorded(sender, netAmount);
					
					// 净额转账给Pair（让swap能成功）
					super._transfer(sender, recipient, netAmount);
					
					// 如果累积的手续费达到阈值，处理手续费
					if (accumulatedToPool + accumulatedToEco >= feeProcessingThreshold && mtManagerAddr != address(0)) {
						bool wasInSwap = inSwapAndLiquidity;
						_processFees();
						inSwapAndLiquidity = wasInSwap;
					}
					
					return;
				}
			}
			
			// 5.1 Handle Sell (通缩停止后)
			// 通缩停止后：取消买卖税，停止所有销毁，正常交易
			// 注意：通缩停止后不再处理手续费，直接正常转账
			// 代码继续执行到后续的正常转账逻辑
			
			// 注意：白名单地址已经在函数开头处理，这里不再需要检查
			// 如果是在 swap 过程中（inSwapAndLiquidity），直接转账
			if (inSwapAndLiquidity) {
				super._transfer(sender, recipient, amount);
				return;
			}

			// 6. Transfer Remainder
			// When deflationStopped:
			// - 开放买单（0%税）
			// - 取消买卖税（买入0%，卖出0%）
			// - 停止所有销毁机制
			// - 所有转账正常进行
			// When !deflationStopped:
			// - 买入：禁止（只能通过LP挖矿获得）
			// - 卖出：10%税（5%回流底池，5%影视生态）+ 记录待销毁
			super._transfer(sender, recipient, amount);
			
			// 8. Check deflation status after transfer (LP pool balance may change)
			// 在转账后再次检查通缩状态，确保LP流动池余额变化后能正确更新状态
			// 通缩状态：一旦停止就不再恢复
			// - LP流动池余额 > 2.1万枚：通缩进行中（deflationStopped = false）
			// - LP流动池余额 <= 2.1万枚：通缩停止（deflationStopped = true，永久停止）
			if (!isAdd && uniswapV2Pair != address(0)) {
				// 只有非添加流动性的交易才检查通缩状态
				uint256 lpBalanceAfter = balanceOf[uniswapV2Pair];
				if (lpBalanceAfter <= MIN_LP_SUPPLY && !deflationStopped) {
					// 转账后LP流动池余额 <= 2.1万枚，停止通缩（一旦停止，不再恢复）
					deflationStopped = true;
					emit DeflationStopped();
				}
			}

			// 9. Auto Register LP Providers
			// When adding liquidity, recipient is Pair, but LP tokens go to the user (msg.sender from Router's perspective)
			// We need to find the actual LP token recipient
			if (isAdd && lpMiningAddr != address(0)) {
				address router = address(uniswapV2Router);
				address user = address(0);
				
				if (sender == router) {
					// When Router adds liquidity, the LP tokens are minted to the 'to' parameter of addLiquidity
					// If tx.origin is depositContract, we need to find the actual user
					// For MTDeposit: tx.origin is MTDeposit, but we can check if depositContract is set
					if (depositContract != address(0) && tx.origin == depositContract) {
						// When called from MTDeposit, the user is passed as 'to' parameter in addLiquidity
						// We can't directly access it, but we can try to get it from the call data
						// For now, we'll check if we can get the user from the deposit contract
						// Note: This is a limitation - we can't directly get the 'to' parameter
						// The best solution is to have MTDeposit call registerLpProvider after adding liquidity
						// For now, we'll skip auto-registration when called from depositContract
						// and rely on MTDeposit to call registerLpProvider manually
					} else {
						// Direct call from user to Router
						user = tx.origin;
						if (user != address(0) && user != address(this) && user != router) {
							_autoRegisterLpProvider(user);
						}
					}
				}
			}
		}

		function _autoRegisterLpProvider(address account) internal {
			if (lpMiningAddr == address(0)) return;
			if (account == address(0) || account == address(this)) return;
			
			if (uniswapV2Pair == address(0)) return;
			IERC20 pair = IERC20(uniswapV2Pair);
			uint256 lpBalance = pair.balanceOf(account);
			if (lpBalance == 0) return;

			try lpMining.addLpProvider(account, lpBalance) {} catch {}
		}
		
		/**
		 * @notice Register LP provider from deposit contract
		 * @dev Called by depositContract after adding liquidity to auto-register LP providers
		 */
		function registerLpProviderFromDeposit(address account, uint256 lpAmount) external {
			require(msg.sender == depositContract, "Only deposit contract");
			require(account != address(0), "Invalid account");
			require(lpAmount > 0, "Invalid amount");
			require(lpMiningAddr != address(0), "LP mining not set");
			
			try lpMining.addLpProvider(account, lpAmount) {} catch {}
		}

		/**
		 * @notice Clear referral relationship and remove LP provider on LP withdrawal from deposit contract
		 * @dev Called by depositContract when user withdraws LP, clears referral relationship and removes LP provider
		 */
		function clearReferralOnLpWithdrawalFromDeposit(address user) external {
			require(msg.sender == depositContract, "Only deposit contract");
			require(user != address(0), "Invalid user");
			
			// 清除推荐关系
			if (referralAddr != address(0)) {
				try referral.clearReferralOnLpWithdrawal(user) {} catch {}
			}
			
			// 移除 LP 提供者
			if (lpMiningAddr != address(0)) {
				try lpMining.removeLpProvider(user) {} catch {}
			}
		}

		function _processFees() internal lockTheSwap {
			if (accumulatedToPool + accumulatedToEco == 0) return;
			
			uint256 poolFee = accumulatedToPool;
			uint256 ecoFee = accumulatedToEco;
			uint256 total = poolFee + ecoFee;
			
			// 检查合约余额是否足够
			uint256 contractBalance = balanceOf[address(this)];
			if (contractBalance < total) {
				// 余额不足，可能是之前已经转过了，清零累积值
				accumulatedToPool = 0;
				accumulatedToEco = 0;
				emit FeesProcessed(0, 0); // 记录余额不足
				return;
			}
			
			super._transfer(address(this), mtManagerAddr, total);

			try mtManager.distributeFees(poolFee, ecoFee) {
				accumulatedToPool = 0;
				accumulatedToEco = 0;
				emit FeesProcessed(poolFee, ecoFee);
			} catch {
				// 如果处理失败，保留累积的手续费，下次再试
				// 注意：余额已经转给MTManager了，但累积值未清零
				// 这会导致下次调用时余额不足，所以需要清零累积值
				accumulatedToPool = 0;
				accumulatedToEco = 0;
				emit FeesProcessed(0, 0); // 记录失败
			}
		}
		
		/**
		 * @notice 手动触发手续费处理
		 * @dev 允许任何人调用，但只有当累积的手续费达到阈值时才能处理
		 *      这可以防止恶意用户频繁调用或提前触发手续费处理
		 */
		function processFees() external {
			require(mtManagerAddr != address(0), "MTManager not set");
			uint256 totalAccumulated = accumulatedToPool + accumulatedToEco;
			require(totalAccumulated > 0, "No fees to process");
			require(totalAccumulated >= feeProcessingThreshold, "Fees below threshold");
			
			_processFees();
		}
		
		/**
		 * @notice 精确判断添加/移除流动性
		 * @dev 借鉴 Token2026 的逻辑：先判断移除流动性，再判断添加流动性，确保买卖判断的准确性
		 *      添加流动性有两种情况：
		 *      1. Router 转账到 Pair（添加流动性的第二步）
		 *      2. 用户转账到 Pair，且 msg.sender 是 Router（添加流动性的直接情况）
		 */
		function addOrRemove(
			address from,
			address to,
			uint256 amount
		) internal view returns (bool isAddLP, bool isRemoveLP) {
			// 检查移除流动性 - 借鉴 Token2026 的逻辑
			uint256 removeLPLiquidity;
			if (swapV2Pairs[from]) {
				removeLPLiquidity = _isRemoveLiquidity(from, amount);
			}
			if (removeLPLiquidity > 0) {
				isRemoveLP = true;
				return (false, true);
			}
			
			// 检查添加流动性 - 借鉴 Token2026 的逻辑
			// 情况1: Router 转账到 Pair（添加流动性的第二步）
			if (from == address(uniswapV2Router) && to == uniswapV2Pair) {
				uint256 addLPLiquidity = _isAddLiquidity(to, amount);
				if (addLPLiquidity > 0) {
					isAddLP = true;
				} else {
					(uint256 rOther, , uint256 balanceOther) = _getReserves(to);
					if (balanceOther > rOther) {
						isAddLP = true;
					}
				}
			}
			// 情况2: 用户转账到 Pair，且 msg.sender 是 Router（添加流动性的直接情况）
			else if (to == uniswapV2Pair && msg.sender == address(uniswapV2Router) && !swapV2Pairs[from]) {
				uint256 addAmount = amount;
				uint256 addLPLiquidity = _isAddLiquidity(to, addAmount);
				if (addLPLiquidity > 0) {
					isAddLP = true;
				} else {
					(uint256 rOther, , uint256 balanceOther) = _getReserves(to);
					if (balanceOther > rOther) {
						isAddLP = true;
					}
				}
			}
			
			return (isAddLP, isRemoveLP);
		}
		
		/**
		 * @notice 判断是否添加流动性
		 */
		function _isAddLiquidity(
			address pair,
			uint256 amount
		) internal view returns (uint256 liquidity) {
			(uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves(pair);
			
			if (rOther == 0 || rThis == 0) {
				return 1;
			}
			
			uint256 amountOther;
			if (rOther > 0 && rThis > 0) {
				amountOther = (amount * rOther) / rThis;
			}
			
			if (balanceOther > rOther) {
				if (balanceOther >= rOther + amountOther) {
					(liquidity, ) = calLiquidity(
						pair,
						balanceOther,
						amount,
						rOther,
						rThis
					);
				} else {
					liquidity = 1;
				}
			}
		}
		
		/**
		 * @notice 判断是否移除流动性
		 * @dev 参考 F Token 的逻辑：如果其他代币的余额 <= 储备量，说明正在移除流动性
		 *      移除流动性时，Pair 中的代币会被移除，导致 balanceOther <= rOther
		 *      参考 F Token: if (balanceOther <= rOther) { liquidity = (amount * totalSupply) / (balanceOf(pair) - amount); }
		 */
		function _isRemoveLiquidity(
			address pair,
			uint256 amount
		) internal view returns (uint256 liquidity) {
			(uint256 rOther, , uint256 balanceOther) = _getReserves(pair);
			
			// 关键判断：如果其他代币的余额 <= 储备量，说明正在移除流动性（完全参考 F Token）
			// 移除流动性时，Pair 中的代币会被移除，导致 balanceOther <= rOther
			if (balanceOther <= rOther) {
				// 计算移除的流动性数量（参考 F Token 的计算方式）
				liquidity =
					(amount * IUniswapV2Pair(pair).totalSupply()) /
					(balanceOf[pair] - amount);
			}
		}
		
		/**
		 * @notice 获取储备量
		 * @dev 借鉴 Token2026 的逻辑：通过比较 token0 和当前代币地址来确定哪个是 tokenOther
		 *      - tokenOther: 配对代币（WBNB）
		 *      - rThis: 当前代币（MT）的储备量
		 *      - balanceOther: 配对代币（WBNB）的当前余额
		 */
		function _getReserves(
			address pair
		)
			public
			view
			returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
		{
			IUniswapV2Pair mainPair = IUniswapV2Pair(pair);
			(uint r0, uint256 r1, ) = mainPair.getReserves();
			
			// 获取 token0 和 token1 的地址
			address token0 = mainPair.token0();
			address tokenOther = token0 == address(this) ? mainPair.token1() : token0;
			
			if (tokenOther < address(this)) {
				// tokenOther 地址小于当前代币地址，tokenOther 是 token0
				rOther = r0;
				rThis = r1;
			} else {
				// tokenOther 地址大于当前代币地址，tokenOther 是 token1
				rOther = r1;
				rThis = r0;
			}
			
			// 获取配对代币的当前余额
			balanceOther = IERC20(tokenOther).balanceOf(pair);
		}
		
		/**
		 * @notice 计算流动性
		 */
		function sqrt(uint256 y) internal pure returns (uint256 z) {
			if (y > 3) {
				z = y;
				uint256 x = y / 2 + 1;
				while (x < z) {
					z = x;
					x = (y / x + x) / 2;
				}
			} else if (y != 0) {
				z = 1;
			}
		}
		
		function calLiquidity(
			address pair,
			uint256 balanceA,
			uint256 amount,
			uint256 r0,
			uint256 r1
		) private view returns (uint256 liquidity, uint256 feeToLiquidity) {
			uint256 pairTotalSupply = IUniswapV2Pair(pair).totalSupply();
			address feeTo = IUniswapV2Factory(uniswapV2Router.factory()).feeTo();
			bool feeOn = feeTo != address(0);
			uint256 _kLast = IUniswapV2Pair(pair).kLast();
			if (feeOn) {
				if (_kLast != 0) {
					uint256 rootK = sqrt(r0 * r1);
					uint256 rootKLast = sqrt(_kLast);
					if (rootK > rootKLast) {
						uint256 numerator = pairTotalSupply * (rootK - rootKLast);
						uint256 denominator = rootK * 5 + rootKLast;
						feeToLiquidity = numerator / denominator;
						if (feeToLiquidity > 0) pairTotalSupply += feeToLiquidity;
					}
				}
			}
			uint256 amount0 = balanceA - r0;
			if (pairTotalSupply == 0) {
				if (amount0 > 0) {
					liquidity = sqrt(amount0 * amount) - 1000;
				}
			} else {
				uint256 liquidity0 = (amount0 * pairTotalSupply) / r0;
				uint256 liquidity1 = (amount * pairTotalSupply) / r1;
				liquidity = liquidity0 < liquidity1 ? liquidity0 : liquidity1;
			}
		}

	}

