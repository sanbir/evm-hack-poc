// SPDX-License-Identifier: MIT
// File: @openzeppelin/contracts/utils/Context.sol


// OpenZeppelin Contracts (last updated v5.0.1) (utils/Context.sol)

pragma solidity ^0.8.20;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}

// File: @openzeppelin/contracts/access/Ownable.sol


// OpenZeppelin Contracts (last updated v5.0.0) (access/Ownable.sol)

pragma solidity ^0.8.20;


/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * The initial owner is set to the address provided by the deployer. This can
 * later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract Ownable is Context {
    address private _owner;

    /**
     * @dev The caller account is not authorized to perform an operation.
     */
    error OwnableUnauthorizedAccount(address account);

    /**
     * @dev The owner is not a valid owner account. (eg. `address(0)`)
     */
    error OwnableInvalidOwner(address owner);

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the address provided by the deployer as the initial owner.
     */
    constructor(address initialOwner) {
        if (initialOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(initialOwner);
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        _checkOwner();
        _;
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if the sender is not the owner.
     */
    function _checkOwner() internal view virtual {
        if (owner() != _msgSender()) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby disabling any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        if (newOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

// File: @openzeppelin/contracts/security/Pausable.sol


// OpenZeppelin Contracts (last updated v4.7.0) (security/Pausable.sol)

pragma solidity ^0.8.0;


/**
 * @dev Contract module which allows children to implement an emergency stop
 * mechanism that can be triggered by an authorized account.
 *
 * This module is used through inheritance. It will make available the
 * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
 * the functions of your contract. Note that they will not be pausable by
 * simply including this module, only once the modifiers are put in place.
 */
abstract contract Pausable is Context {
    /**
     * @dev Emitted when the pause is triggered by `account`.
     */
    event Paused(address account);

    /**
     * @dev Emitted when the pause is lifted by `account`.
     */
    event Unpaused(address account);

    bool private _paused;

    /**
     * @dev Initializes the contract in unpaused state.
     */
    constructor() {
        _paused = false;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is not paused.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    modifier whenNotPaused() {
        _requireNotPaused();
        _;
    }

    /**
     * @dev Modifier to make a function callable only when the contract is paused.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    modifier whenPaused() {
        _requirePaused();
        _;
    }

    /**
     * @dev Returns true if the contract is paused, and false otherwise.
     */
    function paused() public view virtual returns (bool) {
        return _paused;
    }

    /**
     * @dev Throws if the contract is paused.
     */
    function _requireNotPaused() internal view virtual {
        require(!paused(), "Pausable: paused");
    }

    /**
     * @dev Throws if the contract is not paused.
     */
    function _requirePaused() internal view virtual {
        require(paused(), "Pausable: not paused");
    }

    /**
     * @dev Triggers stopped state.
     *
     * Requirements:
     *
     * - The contract must not be paused.
     */
    function _pause() internal virtual whenNotPaused {
        _paused = true;
        emit Paused(_msgSender());
    }

    /**
     * @dev Returns to normal state.
     *
     * Requirements:
     *
     * - The contract must be paused.
     */
    function _unpause() internal virtual whenPaused {
        _paused = false;
        emit Unpaused(_msgSender());
    }
}

// File: @openzeppelin/contracts/security/ReentrancyGuard.sol


// OpenZeppelin Contracts (last updated v4.9.0) (security/ReentrancyGuard.sol)

pragma solidity ^0.8.0;

/**
 * @dev Contract module that helps prevent reentrant calls to a function.
 *
 * Inheriting from `ReentrancyGuard` will make the {nonReentrant} modifier
 * available, which can be applied to functions to make sure there are no nested
 * (reentrant) calls to them.
 *
 * Note that because there is a single `nonReentrant` guard, functions marked as
 * `nonReentrant` may not call one another. This can be worked around by making
 * those functions `private`, and then adding `external` `nonReentrant` entry
 * points to them.
 *
 * TIP: If you would like to learn more about reentrancy and alternative ways
 * to protect against it, check out our blog post
 * https://blog.openzeppelin.com/reentrancy-after-istanbul/[Reentrancy After Istanbul].
 */
abstract contract ReentrancyGuard {
    // Booleans are more expensive than uint256 or any type that takes up a full
    // word because each write operation emits an extra SLOAD to first read the
    // slot's contents, replace the bits taken up by the boolean, and then write
    // back. This is the compiler's defense against contract upgrades and
    // pointer aliasing, and it cannot be disabled.

    // The values being non-zero value makes deployment a bit more expensive,
    // but in exchange the refund on every call to nonReentrant will be lower in
    // amount. Since refunds are capped to a percentage of the total
    // transaction's gas, it is best to keep them low in cases like this one, to
    // increase the likelihood of the full refund coming into effect.
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;

    uint256 private _status;

    constructor() {
        _status = _NOT_ENTERED;
    }

    /**
     * @dev Prevents a contract from calling itself, directly or indirectly.
     * Calling a `nonReentrant` function from another `nonReentrant`
     * function is not supported. It is possible to prevent this from happening
     * by making the `nonReentrant` function external, and making it call a
     * `private` function that does the actual work.
     */
    modifier nonReentrant() {
        _nonReentrantBefore();
        _;
        _nonReentrantAfter();
    }

    function _nonReentrantBefore() private {
        // On the first call to nonReentrant, _status will be _NOT_ENTERED
        require(_status != _ENTERED, "ReentrancyGuard: reentrant call");

        // Any calls to nonReentrant after this point will fail
        _status = _ENTERED;
    }

    function _nonReentrantAfter() private {
        // By storing the original value once again, a refund is triggered (see
        // https://eips.ethereum.org/EIPS/eip-2200)
        _status = _NOT_ENTERED;
    }

    /**
     * @dev Returns true if the reentrancy guard is currently set to "entered", which indicates there is a
     * `nonReentrant` function in the call stack.
     */
    function _reentrancyGuardEntered() internal view returns (bool) {
        return _status == _ENTERED;
    }
}

// File: contracts/ShareHolding.sol


pragma solidity ^0.8.19;

/*─────────────────────────────────────────────────────────────────────────────
│  External Dependencies (No PRBMath needed; only OpenZeppelin modules)
└─────────────────────────────────────────────────────────────────────────────*/




/*─────────────────────────────────────────────────────────────────────────────
│  ShareHolding
│  - Decentralized, immutable share ledger with exponential pricing and pro-rata
│    reward distribution for DeFi/DAO governance models.
└─────────────────────────────────────────────────────────────────────────────*/
contract ShareHolding is Ownable(msg.sender), Pausable, ReentrancyGuard {
    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                      1. STORAGE & CONFIGURATION                   ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    uint256 public constant TOTAL_SHARES = 100e18;   // 100 shares (1e18 decimals)

    // Price parameters
    uint256 public basePrice;           // Initial price (wei)
    uint256 public growthFactor;        // Exponential curve factor (1e18 scale, e.g., 1e15 == 0.1%)
    uint256 public totalVolumePurchased; // All native coins spent on shares (wei)
    uint256 public lastPurchasePrice;   // Cached last price

    uint256 public maxPurchaseShares = 100e18; // Max shares per buy (owner set)

    // Share ledger and rewards
    mapping(address => uint256) public shareBalances;
    mapping(address => uint256) public pendingSalesRewards;
    mapping(address => uint256) public pendingSystemRewards;

    address[] private holders;         // Array of all holders (for iteration)
    mapping(address => bool) private isHolder; // Fast lookup for holder status

    // Deployment metadata
    uint256 public immutable startTimestamp = block.timestamp;
    uint256 public immutable startBlock = block.number;

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                             2. EVENTS                             ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    event Purchase(address indexed buyer, uint256 nativeIn, uint256 sharesOut, uint256 price);
    event SystemFeesAdded(address indexed from, uint256 amount);
    event RewardsClaimed(address indexed user, uint256 sales, uint256 system);
    event PriceParametersUpdated(uint256 basePrice, uint256 growthFactor);
    event MaxPurchaseUpdated(uint256 newMax);
    event PriceHistory(uint256 indexed ts, uint256 price, uint256 volume);
    event WalletReplaced(address indexed oldW, address indexed newW, uint256 shares);

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                        3. INITIALIZATION                          ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    /**
     * @dev Deploy with a fixed 15-address distribution (basis points).
     *      Any shareholding wallet can later be replaced by the owner, until
     *      renouncing ownership for trustless operation.
     */
    constructor(address[15] memory wallets, uint256 _basePrice, uint256 _growthFactor) {
        require(_basePrice > 0, "basePrice=0");

        // Fixed distribution (sum: 10000 == 100%)
        uint16[15] memory PERCENTAGES = [
            800, 400, 300, 200, 200,
            200, 100, 200, 1200, 500,
            400, 300, 500, 900, 3600
        ];

        for (uint256 i = 0; i < 15; ++i) {
            address w = wallets[i];
            require(w != address(0), "wallet 0");
            uint256 shareAmount = (TOTAL_SHARES * PERCENTAGES[i]) / 10000;
            _setInitialShare(w, shareAmount);
        }
        basePrice = _basePrice;
        growthFactor = _growthFactor;
        lastPurchasePrice = _basePrice;
    }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                        4. USER FUNCTIONS                          ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    /// @notice Buy shares with native coin (ETH/MATIC/BNB).
    function buyShares() external payable nonReentrant whenNotPaused {
        require(msg.value > 0, "no value");
        _buy(msg.sender, msg.value);
    }

    /// @notice Reinvest all pending rewards into new shares.
    function reinvestRewards() external nonReentrant whenNotPaused {
        uint256 amt = pendingSalesRewards[msg.sender] + pendingSystemRewards[msg.sender];
        require(amt > 0, "0 rewards");
        pendingSalesRewards[msg.sender] = 0;
        pendingSystemRewards[msg.sender] = 0;
        _buy(msg.sender, amt);
    }

    /// @notice Claim all rewards from sales and system fees.
    function claimRewards() external nonReentrant {
        uint256 sales = pendingSalesRewards[msg.sender];
        uint256 system = pendingSystemRewards[msg.sender];
        require(sales > 0 || system > 0, "0 rewards");
        pendingSalesRewards[msg.sender] = 0;
        pendingSystemRewards[msg.sender] = 0;
        uint256 total = sales + system;
        (bool ok, ) = payable(msg.sender).call{value: total}("");
        require(ok, "transfer fail");
        emit RewardsClaimed(msg.sender, sales, system);
    }

    /// @notice Distribute incoming system fees to all holders, pro-rata.
    function distributeSystemFees() public payable nonReentrant {
        require(msg.value > 0, "0 value");
        uint256 totalShares_ = _totalShares();
        require(totalShares_ > 0, "no shares");
        for (uint256 i = 0; i < holders.length; ++i) {
            address h = holders[i];
            uint256 s = shareBalances[h];
            if (s == 0) continue;
            pendingSystemRewards[h] += (msg.value * s) / totalShares_;
        }
        emit SystemFeesAdded(msg.sender, msg.value);
    }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                      5. OWNER-ONLY FUNCTIONS                      ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function updatePriceParameters(uint256 newBase, uint256 newGF) external onlyOwner {
        require(newBase > 0, "base=0");
        basePrice = newBase;
        growthFactor = newGF;
        emit PriceParametersUpdated(newBase, newGF);
    }

    function setMaxPurchaseShares(uint256 newMax) external onlyOwner {
        require(newMax >= 1e18 && newMax <= 100e18, "bad max");
        maxPurchaseShares = newMax;
        emit MaxPurchaseUpdated(newMax);
    }

    /// @notice Withdraw any native coins left in contract (should rarely be needed).
    function withdrawNative(uint256 amount) external onlyOwner {
        require(address(this).balance >= amount, "balance");
        (bool ok, ) = payable(owner()).call{value: amount}("");
        require(ok, "wd fail");
    }

    /**
     * @notice Replace a shareholding wallet with a new one (shares + rewards).
     *         Cannot duplicate or use zero address.
     */
    function replaceWallet(address oldW, address newW) external onlyOwner {
        require(oldW != address(0) && newW != address(0) && oldW != newW, "bad addr");
        uint256 bal = shareBalances[oldW];
        require(bal > 0 && shareBalances[newW] == 0, "no shares / dup");
        shareBalances[oldW] = 0;
        shareBalances[newW] = bal;
        pendingSalesRewards[newW] = pendingSalesRewards[oldW];
        pendingSystemRewards[newW] = pendingSystemRewards[oldW];
        pendingSalesRewards[oldW] = 0;
        pendingSystemRewards[oldW] = 0;
        isHolder[oldW] = false;
        isHolder[newW] = true;
        for (uint256 i = 0; i < holders.length; ++i) {
            if (holders[i] == oldW) {
                holders[i] = newW;
                break;
            }
        }
        emit WalletReplaced(oldW, newW, bal);
    }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                         6. READ-ONLY VIEWS                        ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    function getCurrentPrice() public view returns (uint256) { return _price(); }

    function getGlobalStats() external view returns (
        uint256 price, uint256 last, uint256 volume, uint256 numHolders
    ) {
        price = _price();
        last = lastPurchasePrice;
        volume = totalVolumePurchased;
        numHolders = holders.length;
    }

    function getUserStats(address u) external view returns (
        uint256 shares, uint256 sales, uint256 system
    ) {
        shares = shareBalances[u];
        sales = pendingSalesRewards[u];
        system = pendingSystemRewards[u];
    }

    function getAllHolders() external view returns (address[] memory) { return holders; }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                       7. INTERNAL LOGIC                            ║
       ╚═════════════════════════════════════════════════════════════════════╝ */

    // --- Exponential Price Calculation using native Solidity math ---
    // Returns basePrice * (1 + growthFactor/1e18) ^ n
    // n = totalVolumePurchased / 1e18
    function _expBySquaring(uint256 base, uint256 exp, uint256 scale) internal pure returns (uint256) {
        uint256 result = scale;
        while (exp > 0) {
            if (exp % 2 == 1) {
                result = (result * base) / scale;
            }
            base = (base * base) / scale;
            exp /= 2;
        }
        return result;
    }

    function _price() internal view returns (uint256) {
        uint256 n = totalVolumePurchased / 1e18; // Each full ether/matic/etc increases price
        uint256 factor = 1e18 + growthFactor;    // e.g. growthFactor = 1e15 for 0.1% step: 1.001e18
        uint256 multiplier = _expBySquaring(factor, n, 1e18);
        return (basePrice * multiplier) / 1e18;
    }

    function _buy(address buyer, uint256 value) internal {
        uint256 curPrice = _price();
        uint256 shares = (value * 1e18) / curPrice;
        require(shares > 0 && shares <= maxPurchaseShares, "share bounds");
        uint256 frac = (shares * 1e18) / TOTAL_SHARES;

        // Distribute proceeds to all holders, burning their shares proportionally
        for (uint256 i = 0; i < holders.length; ++i) {
            address h = holders[i];
            uint256 bal = shareBalances[h];
            if (bal == 0) continue;
            uint256 lost = (bal * frac) / 1e18;
            if (lost == 0) continue;
            shareBalances[h] = bal - lost;
            pendingSalesRewards[h] += (value * lost) / shares;
        }
        _addShares(buyer, shares);
        totalVolumePurchased += value;
        uint256 newPrice = _price();
        lastPurchasePrice = newPrice;
        emit PriceHistory(block.timestamp, newPrice, totalVolumePurchased);
        emit Purchase(buyer, value, shares, newPrice);
    }

    function _setInitialShare(address a, uint256 amt) internal {
        shareBalances[a] = amt;
        isHolder[a] = true;
        holders.push(a);
    }

    function _addShares(address a, uint256 amt) internal {
        shareBalances[a] += amt;
        if (!isHolder[a]) {
            isHolder[a] = true;
            holders.push(a);
        }
    }

    function _totalShares() internal view returns (uint256 s) {
        for (uint256 i = 0; i < holders.length; ++i) s += shareBalances[holders[i]];
    }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                 8. RECEIVE SYSTEM FEES (FALLBACK)                 ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    /// @dev All received native coin (without function call) is distributed as system fees.
    receive() external payable { distributeSystemFees(); }

    /* ╔═════════════════════════════════════════════════════════════════════╗
       ║                       9. TRUSTLESS OWNERSHIP                      ║
       ╚═════════════════════════════════════════════════════════════════════╝ */
    // NOTE: Standard Ownable includes `renounceOwnership()` for trustless/immutable operation.
}