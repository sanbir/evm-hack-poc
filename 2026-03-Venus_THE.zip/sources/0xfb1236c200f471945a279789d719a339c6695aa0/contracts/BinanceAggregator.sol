// SPDX-License-Identifier: GPL-3.0
pragma solidity 0.8.2;

import "./interfaces/AggregatorV2V3Interface.sol";
import "./access/OwnerIsCreator.sol";
import "./access/ReadWriteAccessControlled.sol";
import "./interfaces/OracleUpdatableInterface.sol";

/**
 * @title Aggregator for a pair
 * @dev This aggregator receives price from a single permitted oracle and creates a new round or overwrites previous round depending
   on the 'storeHistoricalData' flag. This contract does not perform any aggregation and as such is a centralized aggregator
 * @author Sri Krishna Mannem
 */
contract BinanceAggregator is OracleUpdatableInterface, AggregatorV2V3Interface, ReadWriteAccessControlled {
  /***************************************************************************
   * Section: Variables used in multiple other sections
   **************************************************************************/

  /// @dev Transmission records an update request from the OnChainOracle
  struct Transmission {
    int192 answer; // 192 bits ought to be enough for anyone
    uint64 observationsTimestamp; // when were observations made offchain
    uint64 transmissionTimestamp; // when was report received onchain
  }

  /// @dev which pair this aggregator updates. Ex: 'BTC/USD'
  string internal PAIR_NAME;
  string internal AGGREGATOR_DESCRIPTION;

  /// @dev The aggregator roundId to transmission map
  mapping(uint32 => Transmission) internal s_transmissions;

  /// @dev the next roundId to report. Latest roundId is s_reportingRoundId - 1
  uint32 internal s_reportingRoundId;

  /// @dev answers are stored in fixed-point format, with this many digits of precision
  uint8 public immutable override decimals;

  /// @notice aggregator contract version
  uint256 public constant override version = 6;

  /// @notice if true, stores all historical updates. Otherwise only stores latest data
  bool public immutable storeHistoricalData;

  /***************************************************************************
   * Section: Constructor and modifiers
   **************************************************************************/

  /**
   * @param pair_ pair this aggregator updates. Ex: 'BTC/USD'
   * @param decimals_ answers are stored in fixed-point format, with this many digits of precision
   * @param description_ short human-readable description of observable this contract's answers pertain to
   * @param storeHistoricalData_ if true, stores all historical updates. Otherwise only stores latest data
   */
  constructor(
    string memory pair_,
    uint8 decimals_,
    string memory description_,
    bool storeHistoricalData_
  ) {
    PAIR_NAME = pair_;
    decimals = decimals_;
    AGGREGATOR_DESCRIPTION = description_;
    storeHistoricalData = storeHistoricalData_;
  }

  /**
   * @dev reverts if the caller does not have write access granted by the accessController contract
   */
  modifier checkWriteAccess() {
    require(
      address(s_accessController) == address(0) || s_accessController.hasWriteAccess(msg.sender),
      "No write access"
    );
    _;
  }

  /**
   * @dev reverts if the caller does not have read access granted by the accessController contract
   */
  modifier checkReadAccess() {
    require(
      address(s_accessController) == address(0) || s_accessController.hasReadAccess(msg.sender),
      "No read access"
    );
    _;
  }

  /***************************************************************************
   * Section: Updater
   **************************************************************************/

  /**
   * @notice Transmit price updates for a particular pair from OnChainOracle
   * @dev When the aggregator is paused, it overwrites the latest round data
   *
   */
  function transmit(uint64 timestamp_, int192 newPrice_) external override checkWriteAccess {
    Transmission memory prior = s_transmissions[_getLatestRoundId()];
    require(
      timestamp_ > prior.observationsTimestamp,
      "Aggregator: Received time stamp less than previous recorded value"
    );
    require(block.timestamp < timestamp_ + 60 minutes, "Aggregator: Update took longer than an hour, hence expired");
    s_transmissions[s_reportingRoundId] = Transmission({
      answer: newPrice_,
      observationsTimestamp: timestamp_,
      transmissionTimestamp: uint32(block.timestamp)
    });
    //Store historical records when not paused
    if (storeHistoricalData) {
      s_reportingRoundId++;
    }
  }

  /**
   * @notice Pair this aggregator handles
   */
  function getPair() external view returns (string memory) {
    return PAIR_NAME;
  }

  /***************************************************************************
   * Section: v2 AggregatorInterface
   **************************************************************************/

  /**
   * @notice median from the most recent report
   */
  function latestAnswer() external view virtual override checkReadAccess returns (int256) {
    return s_transmissions[_getLatestRoundId()].answer;
  }

  /**
   * @notice timestamp of block in which last report was transmitted
   */
  function latestTimestamp() external view virtual override checkReadAccess returns (uint256) {
    return s_transmissions[_getLatestRoundId()].transmissionTimestamp;
  }

  /**
   * @notice Aggregator round (NOT OCR round) in which last report was transmitted
   */
  function latestRound() external view virtual override checkReadAccess returns (uint256) {
    return _getLatestRoundId();
  }

  /**
   * @notice price of the asset at this round
   * @param roundId the aggregator round of the target report
   */
  function getAnswer(uint256 roundId) external view virtual override checkReadAccess returns (int256) {
    require(storeHistoricalData, "Aggregator does not record historical data");
    if (roundId > 0xFFFFFFFF) {
      return 0;
    }
    return s_transmissions[uint32(roundId)].answer;
  }

  /**
   * @notice timestamp of block in which report from given aggregator round was transmitted
   * @param roundId round to retrieve the timestamp for
   */
  function getTimestamp(uint256 roundId) external view virtual override checkReadAccess returns (uint256) {
    require(storeHistoricalData, "Aggregator does not record historical data");
    if (roundId > 0xFFFFFFFF) {
      return 0;
    }
    return s_transmissions[uint32(roundId)].transmissionTimestamp;
  }

  /***************************************************************************
   * Section: v3 AggregatorInterface
   **************************************************************************/

  /**
   * @notice human-readable description of observable this contract is reporting on
   */
  function description() external view virtual override returns (string memory) {
    return AGGREGATOR_DESCRIPTION;
  }

  /**
   * @notice details for the given aggregator round
   * @param roundId_ round to retrieve the data for
   * @return roundId roundId
   * @return answer price of the pair at this round
   * @return startedAt timestamp of when observations were made offchain
   * @return updatedAt timestamp of block in which report from given roundId was transmitted
   * @return answeredInRound roundId
   */
  function getRoundData(uint80 roundId_)
    external
    view
    virtual
    override
    checkReadAccess
    returns (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    )
  {
    require(storeHistoricalData, "Aggregator does not record historical data");
    if (roundId_ > type(uint32).max) {
      return (0, 0, 0, 0, 0);
    }
    Transmission memory transmission = s_transmissions[uint32(roundId_)];
    return (
      roundId_,
      transmission.answer,
      transmission.observationsTimestamp,
      transmission.transmissionTimestamp,
      roundId_
    );
  }

  /**
   * @notice aggregator details for the most recently transmitted report
   * @return roundId round to get the data for
   * @return answer price of the pair at this round
   * @return startedAt timestamp of when observations were made offchain
   * @return updatedAt timestamp of block containing latest report
   * @return answeredInRound aggregator round of latest report
   */
  function latestRoundData()
    external
    view
    virtual
    override
    checkReadAccess
    returns (
      uint80 roundId,
      int256 answer,
      uint256 startedAt,
      uint256 updatedAt,
      uint80 answeredInRound
    )
  {
    Transmission memory transmission = s_transmissions[_getLatestRoundId()];
    return (
      _getLatestRoundId(),
      transmission.answer,
      transmission.observationsTimestamp,
      transmission.transmissionTimestamp,
      _getLatestRoundId()
    );
  }

  function _getLatestRoundId() internal view returns (uint32) {
    return s_reportingRoundId == 0 ? 0 : s_reportingRoundId - 1;
  }
}
