// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.20;
import {AbstractWithdrawShadowTokenV3Upgradeable} from "./abstract/AbstractWithdrawShadowTokenUpgradeableV3.sol";

contract WithdrawShadowTokenV3 is AbstractWithdrawShadowTokenV3Upgradeable{
    string public name;

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }
    
    function initialize(string memory _name, address withdrawSignAdmin, address _owner) public initializer {
        name = _name;
        AbstractWithdrawShadowTokenV3Upgradeable.__AbstractWithdrawShadowToken_init(withdrawSignAdmin, _owner);
    }

    function _withdrawAfter(address to_, address _shadowToken, address _realToken, bytes32 orderNo_, uint256 amount_, uint256 feeAmount) internal pure override {
        to_;
        _shadowToken;
        _realToken;
        orderNo_;
        amount_;
        feeAmount;
    }

}