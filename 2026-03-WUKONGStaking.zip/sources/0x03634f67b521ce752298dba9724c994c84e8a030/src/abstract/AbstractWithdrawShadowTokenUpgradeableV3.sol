// SPDX-License-Identifier: MIT 
pragma solidity ^0.8.20;
import {Initializable} from "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import {SafeERC20, IERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {PausableUpgradeable} from "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {OwnableUpgradeable} from "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

abstract contract AbstractWithdrawShadowTokenV3Upgradeable is Initializable, UUPSUpgradeable, PausableUpgradeable, OwnableUpgradeable{
    using SafeERC20 for IERC20;
    
    address private constant ETH_ADDRESS = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
    address public signAdmin;
    mapping(bytes32 => bool) public withdrawOrderNo;
    /// @notice Shadow tokens are for compatibility with off-chain business
    mapping(address => address) public shadowTokenMap;
    event ChangeSignAdmin(address indexed oldAdmin, address indexed newAdmin);
    event UpdateShadowToken(address indexed shadowToken, address indexed realToken);
    event Withdraw(
        address indexed to_,
        address indexed _token,
        bytes32 indexed orderNo_,
        uint256 amount_
    );

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    receive() virtual external payable {}
    function __AbstractWithdrawShadowToken_init(address _signAdmin, address _owner) internal onlyInitializing {
        require(_signAdmin != address(0), "signAdmin cannot be 0");
        require(_owner != address(0), "owner cannot be 0");
        __AbstractWithdrawShadowToken_init_unchained(_signAdmin);
        __Pausable_init();
        __Ownable_init(_owner);
    }
    function __AbstractWithdrawShadowToken_init_unchained(address _signAdmin) internal onlyInitializing {
        _changeSignAdmin(_signAdmin);
    }
    function changeSignAdmin(address _signAdmin) external onlyOwner {
        _changeSignAdmin(_signAdmin);
    }

    function batchUpdateShadowToken(address[] memory _shadowTokens, address[] memory _realTokens) external onlyOwner {
        require(_shadowTokens.length == _realTokens.length, "length not match");
        _batchUpdateShadowToken(_shadowTokens, _realTokens);
    }

    function pause() external onlyOwner {
        _pause();
    }
    function unpause() external onlyOwner {
        _unpause();
    }
    
    function _changeSignAdmin(address _signAdmin) internal {
        require(_signAdmin != address(0), "signAdmin cannot be 0");
        address oldAdmin = signAdmin;
        signAdmin = _signAdmin;
        emit ChangeSignAdmin(oldAdmin, signAdmin);
    }


    function _batchUpdateShadowToken(address[] memory _shadowTokens, address[] memory _realTokens) internal {
        for (uint256 i = 0; i < _shadowTokens.length; i++) {
            require(_getTokenDecimals(_realTokens[i]) == _getTokenDecimals(_shadowTokens[i]), "decimals not match");
            shadowTokenMap[_shadowTokens[i]] = _realTokens[i];
            emit UpdateShadowToken(_shadowTokens[i], _realTokens[i]);
        }
    }
    function _getTokenDecimals(address _token) internal view returns (uint256) {
        if (_token == ETH_ADDRESS) return 18;
        return IERC20Metadata(_token).decimals();
    }
    function withdraw(
        address to_,
        address _shadowToken,
        bytes32 orderNo_,
        uint256 amount_,
        uint256 feeAmount,
        uint256 expireTime,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external payable whenNotPaused {
        require(!withdrawOrderNo[orderNo_], "order had withdraw");
        require(expireTime >= block.timestamp, "expire signature");
        bytes32 digest = keccak256(abi.encode(address(this), to_, _shadowToken, orderNo_, amount_, feeAmount, expireTime, block.chainid));
        require(ECDSA.recover(digest, v, r, s) == signAdmin, "invalid signature");
        withdrawOrderNo[orderNo_] = true;
        address realToken = shadowTokenMap[_shadowToken];
        require(realToken != address(0), "invalid shadow");
        if (realToken == ETH_ADDRESS){
            (bool _suc, ) = to_.call{gas: 23000, value: amount_}("");
            require(_suc, "transfer fail");
        }else {
            IERC20(realToken).safeTransfer(to_, amount_);
        }
        _withdrawAfter(to_, _shadowToken, realToken, orderNo_, amount_, feeAmount);
        emit Withdraw(to_, _shadowToken, orderNo_, amount_);
    }

    function withdraw(address _token, address _to, uint256 _amount) external onlyOwner {
        if (_token == ETH_ADDRESS){
            (bool _suc, ) = _to.call{gas: 23000, value: _amount}("");
            require(_suc, "transfer fail");
        }else {
            IERC20(_token).safeTransfer(_to, _amount);
        }
    }

    function _withdrawAfter(address to_, address _shadowToken, address _realToken, bytes32 orderNo_, uint256 amount_, uint256 feeAmount) internal virtual;

    function _authorizeUpgrade(address newImplementation) internal override onlyOwner {}
    
    uint256[50] __gap;
}