// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {PoolKey} from "infinity-core/src/types/PoolKey.sol";
import {BalanceDelta, BalanceDeltaLibrary} from "infinity-core/src/types/BalanceDelta.sol";
import {BeforeSwapDelta, BeforeSwapDeltaLibrary} from "infinity-core/src/types/BeforeSwapDelta.sol";
import {PoolId, PoolIdLibrary} from "infinity-core/src/types/PoolId.sol";
import {Currency} from "infinity-core/src/types/Currency.sol";
import {IHooks} from "infinity-core/src/interfaces/IHooks.sol";
import {ICLPoolManager} from "infinity-core/src/pool-cl/interfaces/ICLPoolManager.sol";
import {CLBaseHook} from "./CLBaseHook.sol";
import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {EnumerableSet} from "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";
import {CLPoolParametersHelper} from "infinity-core/src/pool-cl/libraries/CLPoolParametersHelper.sol";
import {IProtocolFeeController} from "../IProtocolFeeController.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";

contract CLAlphaHook is Ownable2Step, CLBaseHook {
    using PoolIdLibrary for PoolKey;
    using EnumerableSet for EnumerableSet.AddressSet;
    using CLPoolParametersHelper for bytes32;

    error PoolNotEnabled();
    error PoolNotStarted();

    event PoolStartedAtUpdated(PoolId indexed poolId, uint256 startedTimestamp, address operator);

    mapping(PoolId => uint256) public poolStartedTimestamp;
    mapping(PoolId => EnumerableSet.AddressSet) internal poolOwners;

    constructor(ICLPoolManager _poolManager, address _owner) CLBaseHook(_poolManager) Ownable(_owner) {}

    function getPoolKeyParameters(int24 tickSpacing) external view returns (bytes32) {
        return bytes32(uint256(this.getHooksRegistrationBitmap())).setTickSpacing(tickSpacing);
    }

    function getPoolId(address token0, address token1, uint24 fee, int24 tickSpacing) external view returns (PoolId) {
        IProtocolFeeController protocolFeeController =
            IProtocolFeeController(address(poolManager.protocolFeeController()));
        (address _token0, address _token1) = sortTokens(token0, token1);
        PoolKey memory key = PoolKey({
            currency0: Currency.wrap(_token0),
            currency1: Currency.wrap(_token1),
            hooks: IHooks(address(this)),
            poolManager: poolManager,
            fee: protocolFeeController.getLPFeeFromTotalFee(fee),
            parameters: this.getPoolKeyParameters(tickSpacing)
        });
        return key.toId();
    }

    function getPoolIdFromKey(PoolKey calldata key) external pure returns (PoolId) {
        return key.toId();
    }

    function getPoolOwners(PoolId poolId) external view returns (address[] memory) {
        return poolOwners[poolId].values();
    }

    function isPoolOwner(PoolId poolId, address owner) public view returns (bool) {
        return poolOwners[poolId].contains(owner);
    }

    function isPoolEnabled(PoolId poolId) public view returns (bool) {
        return poolStartedTimestamp[poolId] > 0;
    }

    function isPoolStarted(PoolId poolId) public view returns (bool) {
        return poolStartedTimestamp[poolId] > 0 && poolStartedTimestamp[poolId] <= block.timestamp;
    }

    function getHooksRegistrationBitmap() external pure override returns (uint16) {
        return _hooksRegistrationBitmapFrom(
            Permissions({
                beforeInitialize: true,
                afterInitialize: false,
                beforeAddLiquidity: true,
                afterAddLiquidity: false,
                beforeRemoveLiquidity: true,
                afterRemoveLiquidity: false,
                beforeSwap: true,
                afterSwap: false,
                beforeDonate: false,
                afterDonate: false,
                beforeSwapReturnDelta: false,
                afterSwapReturnDelta: false,
                afterAddLiquidityReturnDelta: false,
                afterRemoveLiquidityReturnDelta: false
            })
        );
    }

    function emergencyWithdraw(address token) public onlyOwner {
        if (token == address(0)) {
            payable(owner()).transfer(address(this).balance);
        } else {
            IERC20(token).transfer(owner(), IERC20(token).balanceOf(address(this)));
        }
    }

    function emergencyWithdrawERC721(address token, uint256 tokenId) public onlyOwner {
        IERC721(token).transferFrom(address(this), owner(), tokenId);
    }

    // ---------------------- only owner functions ----------------------
    function setPoolStartedTimestamp(PoolId poolId, uint256 timestamp) public onlyOwner {
        poolStartedTimestamp[poolId] = timestamp;
        emit PoolStartedAtUpdated(poolId, timestamp, msg.sender);
    }

    function addPoolOwners(PoolId poolId, address[] calldata owners) public onlyOwner {
        for (uint256 i = 0; i < owners.length; i++) {
            require(owners[i] != address(0), "Invalid owner");
            require(owners[i].code.length == 0, "Can't add contract address as owner");
            poolOwners[poolId].add(owners[i]);
        }
    }

    function removePoolOwners(PoolId poolId, address[] calldata owners) public onlyOwner {
        for (uint256 i = 0; i < owners.length; i++) {
            poolOwners[poolId].remove(owners[i]);
        }
    }

    // ---------------------- internal functions ----------------------
    function _beforeInitialize(address, PoolKey calldata key, uint160) internal view override returns (bytes4) {
        if (!isPoolEnabled(key.toId())) {
            revert PoolNotEnabled();
        }
        if (!isPoolStarted(key.toId()) && !isPoolOwner(key.toId(), tx.origin)) {
            revert PoolNotStarted();
        }
        return this.beforeInitialize.selector;
    }

    function _beforeAddLiquidity(
        address,
        PoolKey calldata key,
        ICLPoolManager.ModifyLiquidityParams calldata,
        bytes calldata
    ) internal view override returns (bytes4) {
        if (!isPoolStarted(key.toId()) && !isPoolOwner(key.toId(), tx.origin)) {
            revert PoolNotStarted();
        }
        return this.beforeAddLiquidity.selector;
    }

    function _beforeRemoveLiquidity(
        address,
        PoolKey calldata key,
        ICLPoolManager.ModifyLiquidityParams calldata,
        bytes calldata
    ) internal view override returns (bytes4) {
        if (!isPoolStarted(key.toId()) && !isPoolOwner(key.toId(), tx.origin)) {
            revert PoolNotStarted();
        }
        return this.beforeRemoveLiquidity.selector;
    }

    function _beforeSwap(address, PoolKey calldata key, ICLPoolManager.SwapParams calldata, bytes calldata)
        internal
        view
        override
        returns (bytes4, BeforeSwapDelta, uint24)
    {
        if (!isPoolStarted(key.toId())) {
            revert PoolNotStarted();
        }
        return (this.beforeSwap.selector, BeforeSwapDeltaLibrary.ZERO_DELTA, 0);
    }

    function sortTokens(address token0, address token1) internal pure returns (address _token0, address _token1) {
        if (address(token0) < address(token1)) {
            (_token0, _token1) = (token0, token1);
        } else {
            (_token0, _token1) = (token1, token0);
        }
    }
}
