// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.20;

import "@openzeppelin/contracts-upgradeable/token/ERC20/ERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";

/**
 * @title ArtxToken
 * @dev An upgradeable ERC20 contract for Artx token.
 *
 * Features:
 * - UUPS Upgradeable.
 * - ERC20 standard token.
 * - Access control with Operator and Owner roles.
 * - Minting and burning functionality.
 * - Tracking of total minted and burned amounts.
 */
contract ArtxToken is
    Initializable,
    ERC20Upgradeable,
    AccessControlUpgradeable,
    OwnableUpgradeable,
    UUPSUpgradeable
{
    // --- State Variables ---
    uint256 public totalMinted;      // Current total minted amount
    uint256 public totalBurned;      // Current total burned amount
    
    // --- Roles ---
    bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");
    
    // --- Events ---
    event TotalMintedUpdated(uint256 oldAmount, uint256 newAmount);
    event TotalBurnedUpdated(uint256 oldAmount, uint256 newAmount);

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    // ==================== READ FUNCTIONS (VIEW/PURE) ====================

    /**
     * @dev Returns the number of decimals used to get its user representation.
     */
    function decimals() public view virtual override returns (uint8) {
        return 18;
    }

    /**
     * @dev Returns the total supply of tokens.
     */
    function totalSupply() public view virtual override returns (uint256) {
        return super.totalSupply();
    }

    // ==================== SETTING FUNCTIONS (ADMIN/OPERATOR) ====================

    /**
     * @dev Initializes the contract.
     * @param name The name of the token.
     * @param symbol The symbol of the token.
     * @param initialSupply The initial supply of the token. Should equal the sum of InitMint allocations (no decimals).
     * @param initMintRecipients Addresses to receive InitMint allocations during initialization.
     * @param initMintAmounts Amounts (no decimals) for each recipient, must sum to initialSupply.
     */
    function __ArtxToken_init(
        string memory name,
        string memory symbol,
        uint256 initialSupply,
        address[] memory initMintRecipients,
        uint256[] memory initMintAmounts
    ) public initializer {
        __ERC20_init(name, symbol);
        __AccessControl_init();
        __Ownable_init();
        __UUPSUpgradeable_init();
        
        // Setup roles
        _setupRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _setupRole(OPERATOR_ROLE, msg.sender);
        
        // Validate and mint InitMint allocations on init
        require(initMintRecipients.length == initMintAmounts.length, "InitMint: length mismatch");

        uint256 sumInitMint = 0;
        uint8 tokenDecimals = decimals();

        for (uint256 i = 0; i < initMintRecipients.length; i++) {
            address to = initMintRecipients[i];
            uint256 amountWithoutDecimals = initMintAmounts[i];

            require(to != address(0), "InitMint: zero recipient");
            require(amountWithoutDecimals > 0, "InitMint: zero amount");

            // Accumulate to validate total equals initialSupply (no decimals)
            sumInitMint += amountWithoutDecimals;

            // Mint with decimals
            uint256 amountWithDecimals = amountWithoutDecimals * 10**tokenDecimals;
            _mint(to, amountWithDecimals);
        }

        // Ensure the sum of InitMint allocations equals the declared initialSupply (no decimals)
        require(sumInitMint == initialSupply, "InitMint: amounts sum != initialSupply");

        // Track total minted with decimals
        totalMinted = initialSupply * 10**tokenDecimals;
    }

    // ==================== WRITE OPERATION FUNCTIONS ====================

    /**
     * @dev Mints new tokens to a specified address.
     * @param to The address to mint tokens to.
     * @param amount The amount of tokens to mint.
     * Can only be called by accounts with OPERATOR_ROLE.
     */
    function mint(address to, uint256 amount) external onlyRole(OPERATOR_ROLE) {
        require(to != address(0), "Cannot mint to zero address");
        require(amount > 0, "Amount must be greater than zero");
        
        uint256 oldAmount = totalMinted;
        totalMinted += amount;
        
        _mint(to, amount);
        
        emit TotalMintedUpdated(oldAmount, totalMinted);
    }

    /**
     * @dev Burns tokens and increases the burned amount.
     * @param amount The amount of tokens to burn.
     * Can be called by any account to burn their own tokens.
     */
    function burn(uint256 amount) external {
        require(amount > 0, "Amount must be greater than zero");
        require(balanceOf(msg.sender) >= amount, "Insufficient balance to burn");
        
        uint256 oldBurned = totalBurned;
        totalBurned += amount;
        
        _burn(msg.sender, amount);
        
        emit TotalBurnedUpdated(oldBurned, totalBurned);
    }

    /**
     * @dev Burns tokens from a specified address and increases the burned amount.
     * @param from The address to burn tokens from.
     * @param amount The amount of tokens to burn.
     * Can only be called by accounts with OPERATOR_ROLE.
     */
    function burnFrom(address from, uint256 amount) external onlyRole(OPERATOR_ROLE) {
        require(from != address(0), "Cannot burn from zero address");
        require(amount > 0, "Amount must be greater than zero");
        require(balanceOf(from) >= amount, "Insufficient balance to burn");
        
        // Check and decrease allowance
        uint256 currentAllowance = allowance(from, msg.sender);
        require(currentAllowance >= amount, "ERC20: insufficient allowance");
        _approve(from, msg.sender, currentAllowance - amount);
        
        uint256 oldBurned = totalBurned;
        totalBurned += amount;
        
        _burn(from, amount);
        
        emit TotalBurnedUpdated(oldBurned, totalBurned);
    }

    // ==================== INTERNAL/PRIVATE FUNCTIONS ====================

    /**
     * @dev Authorizes an upgrade to a new implementation contract.
     * Can only be called by the owner.
     */
    function _authorizeUpgrade(address newImplementation)
        internal
        override
        onlyOwner
    {}
}
