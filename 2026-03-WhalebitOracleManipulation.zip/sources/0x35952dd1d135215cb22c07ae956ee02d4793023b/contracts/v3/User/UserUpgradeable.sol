// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.27;

import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "../ITactile.sol";

contract UserUpgradeable is Initializable {
    // Address of the old tactile contract.
    ITactile public OLD_TACTILE;

    // Mapping to store the inviter for each user.
    mapping(address => address) private _inviter;
    // Mapping to store invitees for each user.
    mapping(address => address[]) private _invitees;
    // Mapping to store the total number of invitees for each user.
    mapping(address => uint256) private _totalInvited;
    // Mapping to store the migration status for each user.
    mapping(address => bool) private _isMigrated;

    // Mapping to store the level of each user.
    mapping(address => uint256) private _level;
    // Mapping to track whether a user is registered.
    mapping(address => bool) private _isRegistered;

    // Mapping to store the balance of each user.
    mapping (address => uint256) private _userBalance;
    // Mapping user => level => open matrix.
    mapping(address => mapping(uint256 => bool)) private _userLevelToActiveMatrix;

    // Address for company
    address public _COMPANY;

    // Flag to check if migration is available.
    bool public isMigrateAvailable;

    // Events to notify about registration and level upgrades.
    event Registration(address indexed user, address indexed inviter);
    event LevelUp(address indexed user);

    // Custom errors for better debugging and validation.
    error InviterIsNowRegistered();
    error NotAvailableBalance();
    error AlreadyRegistred();
    error AlreadyMaxLevel();

    // Constructor to initialize company in the contract.
    function ___initializeUser(address company, address oldTactile) public onlyInitializing {
        _isRegistered[company] = true;
        _level[company] = 12;
        _COMPANY = company;
        OLD_TACTILE = ITactile(oldTactile);
    }

    // Modifier to ensure that a user is registered.
    modifier whenUserRegistered(address user) {
        if (_isRegistered[user] == false) { revert(); }
        _;
    }

    // Internal function to register a user with an inviter.
    function _register(address user, address inviter) internal {
        if (_isRegistered[user] == true) { return;}
        // Init params.
        _isRegistered[user] = true;
        _level[user] = 0;
        _inviter[user] = inviter;
        _invitees[inviter].push(user);
        _totalInvited[inviter]++;
        // Create event.
        emit Registration(user, inviter);
    }

    // Internal function to change upliner for a user.
    function _changeUpliner(address user, address newUpliner) internal {
        address oldUpliner = _inviter[user];
        _inviter[user] = newUpliner;
        _totalInvited[oldUpliner]--;
        _invitees[newUpliner].push(user);
        _totalInvited[newUpliner]++;
    }

    // Get the level of a user.
    function getLevel(address user) public view returns (uint256) {
        return _level[user];
    }

    // Get the inviter of a user.
    function getPartner(address user) external view returns (address) {
        return _inviter[user];
    }

    // Get the inviter and total invitees for a user.
    function getRefData(address user) external view returns (address, uint256) {
        return (_inviter[user], _totalInvited[user]);
    }

    // Get the list of invitees for a user.
    function getInvitees(address user) external view returns (address[] memory) {
        return _invitees[user];
    }

    // Get the balance of a user.
    function getBalance(address user) external view returns (uint256) {
        return _userBalance[user];
    }

    // Check if a user is registered.
    function getIsRegistered(address user) public view returns (bool) {
        return _isRegistered[user];
    }

    // Internal function to update the level of a user.
    function _updateLevel(address user, uint256 lvlFrom) internal returns (bool) {
        uint256 lvl = _level[user];

        if (lvl != 12 && (lvl == lvlFrom || lvl + 1 == lvlFrom)) {
            _level[user] = ++lvl;
            emit LevelUp(user);
        }

        lvlFrom++;
        if (lvlFrom > 12) {
            return false;
        }

        return !_userLevelToActiveMatrix[user][lvlFrom];
    }

    // Internal function to set the level of a user.
    function _setUserLevel(address user, uint256 level) internal returns (bool) {
        if (level > 12) {
            return false;
        }
        _level[user] = level;
        return true;
    }

    // Internal function to update the level of a user from recovery.
    function _updateLevelFromRecovery(address user, uint256 level) internal returns (bool) {
        _level[user] = level;
        emit LevelUp(user);
        return true;
    }

    // Internal function to update information about open matrixes.
    function _updateUserActiveMatrix(address user, uint256 level, bool isOpen) internal {
        _userLevelToActiveMatrix[user][level] = isOpen;
    }

    // External function for get information about open matrix on param level.
    function getUserActiveMatrix(address user, uint256 level) external view returns (bool) {
        return _userLevelToActiveMatrix[user][level];
    }

    // Internal function to update the balance of a user.
    function _updateBalance(address user, uint256 newBalance) internal {
        _userBalance[user] = newBalance;
    }

    // Internal function to deposit funds to a users balance.
    function _depositTo(address user, uint256 amount) internal {
        unchecked {
            _userBalance[user] += amount;
        }
    }

    // Get user migration data.
    function getIsMigrated(address user) external view returns (bool) {
        return _isMigrated[user];
    }

    // Internal function to withdraw funds from a user's balance.
    function _withdrawFrom(address user, uint256 amount) internal {
        unchecked {
            if (_userBalance[user] < amount) { revert NotAvailableBalance(); }
            _userBalance[user] -= amount;
        }
    }

    // Internal function to migrate a user from the old tactile contract.
    function _migrateUser(address user, address newInviter) internal returns (bool) {
        if (isMigrateAvailable == false) { return false; }
        // Check if migration is available and user is not migrated.
        if (_isMigrated[user] == true) { revert(); }
        // Get old level and balance.
        uint256 oldLevel = OLD_TACTILE.getLevel(user);
        uint256 oldBalance = OLD_TACTILE.getBalance(user);
        // Register user. If user is already registered, it will not be registered again.
        _register(user, newInviter);
        // Update level and balance.
        _updateLevelFromRecovery(user, oldLevel);
        _updateBalance(user, oldBalance);
        // Set migration status.
        _isMigrated[user] = true;
        return true;
    }

    // Internal function to set the migration flag.
    function _setMigrateAvailable(bool param) internal {
        isMigrateAvailable = param;
    }
}