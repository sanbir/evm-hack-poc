// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.27;

import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

contract PriceUpgradeable is Initializable {
    // Base price point used for calculating prices at each matrix level.
    uint256 private _basePricePoint;
    // Level to Price mapping without open fee - original price.
    mapping (uint256=>uint256) private _originalPrice;
    // Level to Price mapping based on final price if user activate level.
    mapping (uint256=>uint256) private _price;
    // Max level in Tactile system.
    uint256 private constant _LEVELS = 12;
    // Constructor initializes the base price point and sets the prices for all levels.
    function ___initializePrice(uint256 pricePoint) public onlyInitializing {
        _basePricePoint = pricePoint;
        _setPrice(pricePoint);
    }

    // Internal function to update prices for each level based on a new base price.
    function _setPrice(uint256 newBasePrice) internal {
        if (_basePricePoint < newBasePrice) { revert(); }
        _basePricePoint = newBasePrice;
        uint256 pastPrice = newBasePrice;
        for (uint256 index = 1; index <= _LEVELS; index++) {
            // Set the original price for this level before fee manipulation.
            _originalPrice[index] = pastPrice;
            // Calculate the final price by subtracting a 10% fee.
            uint256 finalPriceForThisLevel = (((pastPrice - _feeBasedOn10Percent(pastPrice))));
            _price[index] = finalPriceForThisLevel;
            // For the next level, the starting price is twice the final price of the current level.
            pastPrice = finalPriceForThisLevel * 2;
        }
    }

    // External view function to retrieve the price details for a given level.
    function getPriceForLevel(uint256 level) external view returns (uint256, uint256) {
        return _getPriceForLevel(level);
    }

    // External view function to retrieve the price details for a given level.
    function _getPriceForLevel(uint256 level) internal view returns (uint256, uint256) {
        return (_originalPrice[level], _price[level]);
    }

    // Internal pure function to calculate a 10% fee based on the given amount.
    function _feeBasedOn10Percent(uint256 amount) private pure returns (uint256) {
        unchecked {
            return ((amount * 10) / 100); // Calculate 10% of the amount as a fee.
        }
    }
}