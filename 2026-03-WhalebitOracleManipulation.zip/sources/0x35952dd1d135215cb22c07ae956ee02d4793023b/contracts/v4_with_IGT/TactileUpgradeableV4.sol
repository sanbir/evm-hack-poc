// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.27;

import "../v3/User/UserUpgradeable.sol";
import "../v3/Utils/PriceUpgradeable.sol";
import "./Utils/SignatureCheckerUpgradeable.sol";
import "../v3/Programs/Base/IMatrix.sol";

import "@openzeppelin/contracts/utils/cryptography/SignatureChecker.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

contract TactileUpgradeableV4 is UserUpgradeable, PriceUpgradeable, SignatureCheckerUpgradeable, PausableUpgradeable, OwnableUpgradeable, UUPSUpgradeable {
    // Mapping to track which addresses are matrix contracts.
    mapping (address => bool) public isMatrix;
    // Mapping to track the contract address for each level.
    mapping (uint256 => address) public levels;
    // Address of payment contract.
    address public payments;
    // Address of upload upliners and reregister users;
    mapping (address => bool) public isUploader;

    // ==== EIP-712 typed data ====
    bytes32 private constant OPEN_EMPTY_TYPEHASH = keccak256("OpenEmptyMatrix(uint64 level,address user,uint32 nonce)");
    bytes32 private constant REGISTER_TYPEHASH   = keccak256("Register(address user,bytes32 uplinersHash)");
    bytes32 private constant EIP712_DOMAIN_TYPEHASH = keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 private _EIP712NameHash;
    bytes32 private _EIP712VersionHash;
    bytes32 private _EIP712DomainSeparator;
    uint256 private _EIP712CachedChainId;
    address private _EIP712CachedThis;
    bool public acceptLegacySignatures;

    // Custom errors for better debugging and validation.
    error isContract();
    error isNotMatrix();
    error isNotPayments();
    error wrongParams();
    error isNotUploader();
    error RegisterError();
    // Constructor to initialize the contract.
    // The contract starts in a paused state for security reasons.

    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    function initialize(address company, uint256 basePrice, address initialOwner, address signer, address oldTactile) public initializer {
        UserUpgradeable.___initializeUser(company, oldTactile);
        PriceUpgradeable.___initializePrice(basePrice);
        SignatureCheckerUpgradeable.___initialize(signer);
        __Pausable_init();
        __Ownable_init(initialOwner);
        __UUPSUpgradeable_init();
        _pause();
    }

    // Modifier to ensure that the caller is not a contract.
    modifier NotContract() {
        if (_isContract(msg.sender)) { revert isContract(); }
        _;
    }

    // Modifier to ensure that the caller is a registered matrix contract.
    modifier onlyMatrix() {
        require(isMatrix[msg.sender], isNotMatrix());
        _;
    }

    // Modifier to ensure that the caller is a registered payment contract.
    modifier onlyPayment() {
        require(payments == msg.sender, isNotPayments());
        _;
    }

    // Modifier to ensure that the caller is a registered uploader contract.
    modifier onlyUploader() {
        require(isUploader[msg.sender], isNotUploader());
        _;
    }

    // Function to upload user and his upliners.
    function register(address[] memory upliners, bytes memory signature) external NotContract() {
        // Check upliners length.
        if (upliners.length == 0 || upliners.length > 10) { revert RegisterError(); }
        // Verify upliners.
        _verifyUpliner(upliners, signature);
        // Register user and upliners.
        for (uint256 i = 0; i < upliners.length; i++) {
            // Register user.
            if (i == 0) {
                _register(msg.sender, upliners[0]);
            } else {
                // Register upliners.
                if (upliners[i] == _COMPANY || upliners[i] == address(0)) {
                    _register(upliners[i - 1], _COMPANY);
                    break;
                }
                _register(upliners[i - 1], upliners[i]);
            }
        }
        // Migrate user. Always migrate user if migration is available.
        bool migrate = _migrateUser(msg.sender, upliners[0]);
        // If user is migrated, migrate matrixes.
        if (migrate == true) {
            // Level of user is 0 if user is not migrated.
            uint256 level = getLevel(msg.sender);
            if (level == 0) { return; }
            // Migrate matrixes from old tactile contract.
            for (uint256 index = 1; index <= level; index++) {
                // Get matrix.
                IMatrix matrix = IMatrix(levels[index]);
                // Migrate user from old tactile matrix.
                matrix.migrateMatrixFromOldTactile(msg.sender);
            }
        }
    }

    // Open empty matrix, check signature.
    function openEmptyMatrix(uint64 level, uint32 nonce, bytes memory signature) external {
        _verify(level, nonce, signature);
        uint256 internalLevel = getLevel(msg.sender);
        // Check user level, if user already choice option.
        if (internalLevel > level) { revert(); }
        // Check level is not 0.
        if (level == 0) { revert(); }
        // Check on registration.
        bool isRegistered = getIsRegistered(msg.sender);
        if (!isRegistered) { revert(); }
        // Open matrix levels.
        for (uint256 index = internalLevel + 1; index <= level; index++) {
            IMatrix matrix = IMatrix(levels[index]);
            matrix.openEmptyMatrixForUser(msg.sender);
        }
        _updateLevelFromRecovery(msg.sender, level);
    }

    // Register users and upliners from uploader.
    function registerFromUploader(address[] memory users, address[][] memory allUpliners) external onlyUploader() {
        // Check upliners length.
        if (users.length == 0 || users.length > 10) { revert(); }
        // Check users and upliners length.
        if (users.length != allUpliners.length) { revert(); }
        // Register users and upliners.
        for (uint256 i = 0; i < users.length; i++) {
            // Get user and upliner.
            address user = users[i];
            address[] memory upliners = allUpliners[i];
            // Register user and upliners.
            _register(user, upliners[0]);
            
            // Register upliners with for loop.
            for (uint256 j = 0; j < upliners.length; j++) {
            if (j == 0) {
                // Register user and upliner.
                _register(user, upliners[0]);
            } else {
                // Register upliners.
                if (upliners[j] == _COMPANY || upliners[j] == address(0)) {
                    _register(upliners[j - 1], _COMPANY);
                    break;
                }
                _register(upliners[j - 1], upliners[j]);
                }
            }
            // Migrate user.
            bool migrate = _migrateUser(user, upliners[0]);
            // If user is migrated, migrate matrixes.
            if (migrate == true) {
                // Level of user is 0 if user is not migrated.
                for (uint256 index = 1; index <= 12; index++) {
                    // Get matrix level.
                    IMatrix matrix = IMatrix(levels[index]);
                    // Migrate matrix.
                    matrix.migrateMatrixFromOldTactile(user);
                }
            }
        }
    }

    // Set user level.
    function setUserLevel(address user, uint256 level) external onlyUploader() {
        _setUserLevel(user, level);
    }

    // Set basic price point for matrix. Only owner can cast this function. Owner can be DAO.
    function setPrice(uint256 price) external onlyOwner() {
        _setPrice(price);
        for (uint256 index = 1; index <= 12; index++) {
            IMatrix matrix = IMatrix(levels[index]);
            (uint256 orginiPrice, uint256 finalPrice) = _getPriceForLevel(index);
            matrix.setPrice(orginiPrice, finalPrice);
        }
    }

    // Updates the balance of a user. Can only be called by a payment contract.
    function updateBalance(address user, uint256 newBalance) external onlyPayment() {
        _updateBalance(user, newBalance);
    }

    // Deposits funds to a users account. Can only be called by a matrix contract.
    function depositTo(address user, uint256 amount) external onlyMatrix() {
        _depositTo(user, amount);
    }

    // Deposits funds to a users account. Can only be called by a payment contract.
    function paymentDepositTo(address user, uint256 amount) external onlyPayment() {
        _depositTo(user, amount);
    }

    // Withdraws funds from a users account. Can only be called by a matrix contract.
    function withdrawFrom(address user, uint256 amount) external onlyMatrix() {
        _withdrawFrom(user, amount);
    }

    // Updates the level of a user and triggers matrix actions. Can only be called by a matrix contract.
    function updateLevel(address user, uint256 lvl) external onlyMatrix() {
        bool toUp = _updateLevel(user, lvl);
        lvl++;
        if (toUp) {
            IMatrix matrix = IMatrix(levels[lvl]);
            matrix.buyMatrixFromUpgrade(user);
        }
    }

    // Updates the level of a user and triggers matrix actions. Can only be called by a matrix contract.
    function updateLevelFromBuy(address user, uint256 lvl) external onlyMatrix() {
        _updateLevel(user, lvl);
    }

    // Updates open matrixes for user, call only available from matrix.
    function updateOpenLevel(address user, uint256 lvl, bool isOpen) external onlyMatrix() {
        _updateUserActiveMatrix(user, lvl, isOpen);
    }

    // Adds a new matrix contract and associates it with a specific level.
    function addAddressToMatrix(address matrix, uint256 lvl) external onlyOwner() {
        // Remove old matrix.
        address oldMatrix = levels[lvl];
        isMatrix[oldMatrix] = false;
        // Set new matrix.
        if (lvl != 0) {
            levels[lvl] = matrix;
        }
        isMatrix[matrix] = true;
    }

    // Set new uploader, only owner can call this function.
    function setUploader(address _newUploader, bool _isUploader) external onlyOwner() {
        isUploader[_newUploader] = _isUploader;
    }

    // Set payments contract.
    function setPayment(address newPayment) external onlyOwner() {
        payments = newPayment;
    }

    // Set new signer for signature validation.
    function setSigner(address signer) external onlyOwner() {
        _setSigner(signer);
    }

    // Unpauses the contract.
    function launch() external onlyOwner() {
        _unpause();
    }

    // Set migration flag.
    function setMigrateAvailable(bool param) external onlyOwner() {
        _setMigrateAvailable(param);
    }

    // Checks if an address is a contract.
    function _isContract(address account) private view returns (bool) {
        uint256 size;
        assembly {
            size := extcodesize(account)
        }
        return size > 0;
    }

    function _authorizeUpgrade(address implementation) override internal onlyOwner() {}

    // ==== EIP-712 overrides and helpers ====

    // ===== EIP-712 functions =====

    /// @notice Initializes EIP-712 domain and optionally disables legacy signatures
    /// @param name EIP-712 domain name
    /// @param version EIP-712 domain version
    /// @param disableLegacy If true, disables accepting legacy eth_sign signatures
    function initEIP712(string memory name, string memory version, bool disableLegacy) external onlyOwner() {
        ___initEIP712(name, version);
        if (disableLegacy) { _setAcceptLegacySignatures(false); }
    }

    /// @notice Toggle accepting legacy eth_sign signatures (for migration/testing)
    function setAcceptLegacySignatures(bool enabled) external onlyOwner() {
        _setAcceptLegacySignatures(enabled);
    }

    function _verify(uint256 level, uint32 nonce, bytes memory signature) internal override {
        bytes32 structHash = keccak256(abi.encode(
            OPEN_EMPTY_TYPEHASH,
            uint64(level),
            msg.sender,
            nonce
        ));
        bytes32 digest = _hashTypedDataV4(structHash);

        bool ok = ECDSA.recover(digest, signature) == signer;
        if (!ok && acceptLegacySignatures) {
            bytes32 legacy = _legacyPrefixed(keccak256(abi.encodePacked(level, msg.sender, nonce)));
            ok = SignatureChecker.isValidSignatureNow(signer, legacy, signature);
            if (ok) { digest = legacy; }
        }
        if (!ok) { revert BadSignature(); }
        if (isAlreadyPassed[digest]) { revert AlreadyPassed(digest); }
        isAlreadyPassed[digest] = true;
    }

    function _verifyUpliner(address[] memory upliners, bytes memory signature) internal view override returns (bool) {
        bytes32 uplinersHash = keccak256(abi.encodePacked(upliners));
        bytes32 structHash = keccak256(abi.encode(
            REGISTER_TYPEHASH,
            msg.sender,
            uplinersHash
        ));
        bytes32 digest = _hashTypedDataV4(structHash);

        bool ok = ECDSA.recover(digest, signature) == signer;
        if (!ok && acceptLegacySignatures) {
            bytes32 legacy = _legacyPrefixed(keccak256(abi.encodePacked(msg.sender, upliners)));
            ok = SignatureChecker.isValidSignatureNow(signer, legacy, signature);
        }
        if (!ok) { revert BadSignature(); }
        return true;
    }

    function ___initEIP712(string memory name, string memory version) internal {
        _EIP712NameHash = keccak256(bytes(name));
        _EIP712VersionHash = keccak256(bytes(version));
        _rebuildDomainSeparator();
    }

    function _setAcceptLegacySignatures(bool enabled) internal { acceptLegacySignatures = enabled; }

    function _hashTypedDataV4(bytes32 structHash) internal view returns (bytes32) {
        return keccak256(abi.encodePacked("\x19\x01", _domainSeparatorV4(), structHash));
    }

    function _domainSeparatorV4() internal view returns (bytes32) {
        if (address(this) == _EIP712CachedThis && block.chainid == _EIP712CachedChainId) {
            return _EIP712DomainSeparator;
        }
        return keccak256(abi.encode(
            EIP712_DOMAIN_TYPEHASH,
            _EIP712NameHash,
            _EIP712VersionHash,
            block.chainid,
            address(this)
        ));
    }

    function _rebuildDomainSeparator() private {
        _EIP712CachedThis = address(this);
        _EIP712CachedChainId = block.chainid;
        _EIP712DomainSeparator = keccak256(abi.encode(
            EIP712_DOMAIN_TYPEHASH,
            _EIP712NameHash,
            _EIP712VersionHash,
            block.chainid,
            address(this)
        ));
    }

    function _legacyPrefixed(bytes32 hash) private pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
    }

    // ===== DEBUG HELPERS (view only) =====

    function debugRegisterDigest(address user, address[] memory upliners) external view returns (bytes32) {
        bytes32 uplinersHash = keccak256(abi.encodePacked(upliners));
        bytes32 structHash = keccak256(abi.encode(
            REGISTER_TYPEHASH,
            user,
            uplinersHash
        ));
        return _hashTypedDataV4(structHash);
    }

    function debugRegisterStructHash(address user, address[] memory upliners) external pure returns (bytes32) {
        bytes32 uplinersHash = keccak256(abi.encodePacked(upliners));
        return keccak256(abi.encode(
            REGISTER_TYPEHASH,
            user,
            uplinersHash
        ));
    }
    
    function debugDomainSeparator() external view returns (bytes32) {
        return _domainSeparatorV4();
    }

    function debugNameVersion() external view returns (bytes32, bytes32) {
        return (_EIP712NameHash, _EIP712VersionHash);
    }

    function debugRegisterTypehash() external pure returns (bytes32) {
        return REGISTER_TYPEHASH;
    }

    function debugUplinersHash(address[] memory upliners) external pure returns (bytes32) {
        return keccak256(abi.encodePacked(upliners));
    }

    function debugUplinersPacked(address[] memory upliners) external pure returns (bytes memory) {
        return abi.encodePacked(upliners);
    }
}