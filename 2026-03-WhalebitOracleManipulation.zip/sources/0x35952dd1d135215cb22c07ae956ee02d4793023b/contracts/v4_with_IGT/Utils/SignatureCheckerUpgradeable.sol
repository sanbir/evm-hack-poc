// SPDX-License-Identifier: MIT
pragma solidity 0.8.27;

import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
/// @title SignatureCheckerUpgradeable
/// @notice Legacy signature checker base (storage layout must remain unchanged for upgrades)
contract SignatureCheckerUpgradeable is Initializable {
    // signer address, we trust him.
    address public signer;
    // Mapping to track whether a message has already been processed.
    mapping (bytes32 => bool) public isAlreadyPassed;

    // Custom errors for better debugging and validation.
    error BadSignature();           // Error for an invalid signature.
    error AlreadyPassed(bytes32);   // Error if the message has already been processed.

    // Constructor to set the initial signer address.
    function ___initialize(address _signer) public onlyInitializing { signer = _signer; }

    // Verifies the signature of a message. Returns true if the signature is valid and not been processed before.
    function _verify(uint256 level, uint32 nonce, bytes memory signature) internal virtual {
        // Generate the hashed message with a prefix to match Ethereum's signed messages.
        bytes32 message = _prefixed(keccak256(abi.encodePacked(level ,msg.sender, nonce)));
        // Check if the signature is valid.
        if (_recoverSigner(message, signature) != signer) { revert BadSignature(); }
        // Check if the message has already been passed.
        if (isAlreadyPassed[message]) { revert AlreadyPassed(message); }
        // Mark this message as processed.
        isAlreadyPassed[message] = true;
    }

    // Verifies the signature of a upliners.
    function _verifyUpliner(address[] memory upliners, bytes memory signature) internal view virtual returns (bool) {
        bytes32 message = _prefixed(keccak256(abi.encodePacked(msg.sender, upliners)));
        if (_recoverSigner(message, signature) != signer) { revert BadSignature(); }
        return true;
    }

    // Checks if a signature has already been processed. Returns true if the message has already been passed.
    function checkSignature(uint256 level, uint32 nonce) external view returns (bool) {
        bytes32 message = _prefixed(keccak256(abi.encodePacked(level ,msg.sender, nonce)));
        return  isAlreadyPassed[message];
    }

    // Sets a new signer address.
    function _setSigner(address _newSigner) internal {
        signer = _newSigner;
    }

    // Splits a ECDSA signature into its components: v, r, and s.
    function _splitSignature(bytes memory sig)
        private
        pure
        returns (uint8 v, bytes32 r, bytes32 s)
    {
        require(sig.length == 65);
        assembly {
            // first 32 bytes, after the length prefix.
            r := mload(add(sig, 32))
            // second 32 bytes.
            s := mload(add(sig, 64))
            // final byte (first byte of the next 32 bytes).
            v := byte(0, mload(add(sig, 96)))
        }

        return (v, r, s);
    }

    // Recovers the signer address from a signed message.
    function _recoverSigner(bytes32 message, bytes memory sig)
        private
        pure
        returns (address)
    {
        (uint8 v, bytes32 r, bytes32 s) = _splitSignature(sig);

        return ecrecover(message, v, r, s);
    }

    // Prefixes a hash to mimic the behavior of Ethereum's `eth_sign`.
    function _prefixed(bytes32 hash) private pure returns (bytes32) {
        return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
    }

    function getSigner() external view returns (address) {
        return signer;
    }
}