// SPDX-License-Identifier: ISC
pragma solidity ^0.8.27;

import "@openzeppelin/contracts-upgradeable/token/ERC20/ERC20Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

/// @title IGT (Upgradeable)
/// @notice ERC20 token with minter role, burner role.
contract IGT is Initializable, ERC20Upgradeable, AccessControlUpgradeable, UUPSUpgradeable {

    // ===== Custom Errors =====
    error InvalidAddress();
    error InvalidValue();

    // Role for accounts that are allowed to mint and burn tokens
    bytes32 constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 constant BURNER_ROLE = keccak256("BURNER_ROLE");

    /// @custom:oz-upgrades-unsafe-allow constructor
    /// @notice Constructor calls _disableInitializers() to protect UUPS logic
    constructor() {
        _disableInitializers();
    }

    /// @notice intializing contract instead of constructor (uups)
    /// @param name_ token name
    /// @param symbol_ token symbol
    /// @param admin administrator address
    /// @param bank bank address
    function initialize(
        string memory name_, 
        string memory symbol_, 
        address admin,
        address bank
    ) external initializer {
        require(admin != address(0), InvalidAddress());
        require(bank != address(0), InvalidAddress());

        __ERC20_init(name_, symbol_);
        __AccessControl_init();
        __UUPSUpgradeable_init();

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(MINTER_ROLE, bank);
        _grantRole(BURNER_ROLE, bank);
    }

    /// @dev Upgrade authorization function (requires DEFAULT_ADMIN_ROLE)
    function _authorizeUpgrade(address newImplementation) internal override onlyRole(DEFAULT_ADMIN_ROLE) {}

    /// @notice allows admin to withdraw accidentally sent tokens from the contract
    function withdrawStuckTokens(address token) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(token != address(0), InvalidAddress());

        ERC20Upgradeable(token).transfer(msg.sender, ERC20Upgradeable(token).balanceOf(address(this)));
    }

    /// @notice Mint tokens to one account (only MINTER_ROLE)
    function mint(address account, uint256 amount) external onlyRole(MINTER_ROLE) {
        require(account != address(0), InvalidAddress());
        require(amount > 0, InvalidValue());

        _mint(account, amount);
    }

    /// @notice Burns tokens (only BURNER_ROLE)
    function burn(uint256 amount) external onlyRole(BURNER_ROLE) {
        require(amount > 0, InvalidValue());

        _burn(msg.sender, amount);
    }

    /// @notice Sets MINTER_ROLE (only DEFAULT_ADMIN_ROLE)
    function setMinterRole(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(account != address(0), InvalidAddress());

        _grantRole(MINTER_ROLE, account);
    }

    /// @notice Removes MINTER_ROLE (only DEFAULT_ADMIN_ROLE)
    function removeMinterRole(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(account != address(0), InvalidAddress());

        _revokeRole(MINTER_ROLE, account);
    }

    /// @notice Sets BURNER_ROLE (only DEFAULT_ADMIN_ROLE)
    function setBurnerRole(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {
        require(account != address(0), InvalidAddress());

        _grantRole(BURNER_ROLE, account);
    }

    /// @notice Removes BURNER_ROLE (only DEFAULT_ADMIN_ROLE)
    function removeBurnerRole(address account) external onlyRole(DEFAULT_ADMIN_ROLE) {  
        require(account != address(0), InvalidAddress());

        _revokeRole(BURNER_ROLE, account);
    }
}