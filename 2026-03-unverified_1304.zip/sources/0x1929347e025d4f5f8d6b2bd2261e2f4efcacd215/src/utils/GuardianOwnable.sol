// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { Ownable2Step } from "@openzeppelin/contracts/access/Ownable2Step.sol";
import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";

import { GuardianRescuable } from "./GuardianRescuable.sol";

/**
 * @title GuardianOwnable
 * @author Fun.xyz
 */
abstract contract GuardianOwnable is Ownable2Step, GuardianRescuable {
    error RenounceDisabled();

    function guardian() public view override returns (address) {
        return owner();
    }

    function renounceOwnership() public view override onlyOwner {
        revert RenounceDisabled();
    }
}
