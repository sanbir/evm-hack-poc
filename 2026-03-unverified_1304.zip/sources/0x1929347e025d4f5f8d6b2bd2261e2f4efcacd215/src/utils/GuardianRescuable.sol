// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {
    SafeERC20
} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title GuardianRescuable
 * @author Fun.xyz
 */
abstract contract GuardianRescuable {
    using SafeERC20 for IERC20;

    error NotGuardian(address sender);

    modifier onlyGuardian() {
        if (msg.sender != guardian()) {
            revert NotGuardian(msg.sender);
        }
        _;
    }

    function guardian() public virtual returns (address);

    function withdrawNative(
        address payable recipient,
        uint256 amount
    ) external onlyGuardian {
        recipient.transfer(amount);
    }

    function withdrawErc20(
        IERC20 token,
        address recipient,
        uint256 amount
    ) external onlyGuardian {
        token.safeTransfer(recipient, amount);
    }

    function withdrawAllNative(
        address payable recipient
    ) external onlyGuardian {
        recipient.transfer(address(this).balance);
    }

    function withdrawAllErc20(
        IERC20 token,
        address recipient
    ) external onlyGuardian {
        uint256 balance = token.balanceOf(address(this));
        token.safeTransfer(recipient, balance);
    }
}
