// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.13;

import {
    BasePaymaster
} from "@account-abstraction/contracts/core/BasePaymaster.sol";
import {
    IEntryPoint
} from "@account-abstraction/contracts/interfaces/IEntryPoint.sol";
import {
    UserOperation
} from "@account-abstraction/contracts/interfaces/UserOperation.sol";
import { ECDSA } from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import { EIP712 } from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";

import {
    InspectablePaymasterInterface
} from "../interfaces/InspectablePaymasterInterface.sol";
import {
    CheckoutPaymasterEventsAndErrors
} from "./CheckoutPaymasterEventsAndErrors.sol";

enum ActiveState {
    UNSPECIFIED, // 0
    INACTIVE, // 1
    ACTIVE // 2
}

/**
 * @title CheckoutPaymaster
 * @author Fun.xyz
 */
contract CheckoutPaymaster is
    BasePaymaster,
    InspectablePaymasterInterface,
    EIP712,
    CheckoutPaymasterEventsAndErrors
{
    string public constant EIP712_NAME = "CheckoutPaymaster";
    string public constant VERSION = "2"; // Note: Was a uint256 in version 1.

    bytes32 private constant SPONSOR_USER_OP_TYPEHASH =
        keccak256(
            "SponsorUserOp("
            "bytes32 userOpHash,"
            "uint64 deadline"
            ")"
        );
    bytes1 private constant CONTEXT_ACTIVE = bytes1(uint8(0));
    bytes1 private constant CONTEXT_INACTIVE = bytes1(uint8(1));

    ActiveState internal _ACTIVE_STATE_;
    PostOpMode internal _LAST_OP_MODE_;

    mapping(address => bool) internal _OPERATORS_;
    mapping(address => bool) internal _SIGNERS_;
    mapping(bytes32 => bool) internal _SPONSORED_USER_OP_HASHES_;

    modifier onlyOperator() {
        if (!_OPERATORS_[msg.sender]) {
            revert OperatorNotAllowed(msg.sender);
        }
        _;
    }

    modifier activate() {
        _ACTIVE_STATE_ = ActiveState.ACTIVE;
        _;
        _ACTIVE_STATE_ = ActiveState.INACTIVE;
    }

    constructor(
        IEntryPoint entryPoint
    ) BasePaymaster(entryPoint) EIP712(EIP712_NAME, VERSION) {
        _ACTIVE_STATE_ = ActiveState.INACTIVE;
    }

    function setOperators(
        address[] calldata operators,
        bool isAllowed
    ) external onlyOwner {
        uint256 n = operators.length;
        for (uint256 i; i < n; ++i) {
            address operator = operators[i];
            _OPERATORS_[operator] = isAllowed;
            emit OperatorSet(operator, isAllowed);
        }
    }

    function setSigners(
        address[] calldata signers,
        bool isAllowed
    ) external onlyOwner {
        uint256 n = signers.length;
        for (uint256 i; i < n; ++i) {
            address signer = signers[i];
            _SIGNERS_[signer] = isAllowed;
            emit SignerSet(signer, isAllowed);
        }
    }

    function activateAndCall(
        address target,
        bytes calldata callData
    ) external payable onlyOperator activate returns (bytes memory) {
        (bool success, bytes memory returnData) = payable(target).call{
            value: msg.value
        }(callData);
        if (!success) {
            assembly {
                revert(add(returnData, 32), mload(returnData))
            }
        }
        return returnData;
    }

    function getLastOpMode() external view returns (PostOpMode) {
        return _LAST_OP_MODE_;
    }

    function isOperatorAllowed(address operator) external view returns (bool) {
        return _OPERATORS_[operator];
    }

    function isSignerAllowed(address signer) external view returns (bool) {
        return _SIGNERS_[signer];
    }

    function DOMAIN_SEPARATOR() external view virtual returns (bytes32) {
        return _domainSeparatorV4();
    }

    /**
     * @notice Validate a user operation that is using this paymaster.
     *
     * @param userOp ERC-4337 UserOperation.
     *
     * @return context The context containing the sponsor, spender, gasPriceUserOp, and opHash.
     * @return validationData The validation result.
     */
    function _validatePaymasterUserOp(
        UserOperation calldata userOp,
        bytes32 /* opHash */,
        uint256 /* maxCost */
    ) internal override returns (bytes memory context, uint256 validationData) {
        // Assume paymasterAndData.length >= 20 based on reasonable EntryPoint behavior.
        uint256 len = userOp.paymasterAndData.length;
        if (len > 20) {
            // Format of paymasterAndData:
            //   -  [0:20]  address paymaster
            //   - [20:40]  address signer
            //   - [40:48]  uint64  deadline
            //   - [48:113] bytes   signature
            if (len != 113) {
                revert InvalidPaymasterAndDataLength(len);
            }

            address expectedSigner = address(
                bytes20(userOp.paymasterAndData[20:40])
            );
            uint64 deadline = uint64(bytes8(userOp.paymasterAndData[40:48]));
            bytes memory signature = userOp.paymasterAndData[48:];

            _validateSponsoredUserOp(
                signature,
                expectedSigner,
                deadline,
                userOp
            );

            context = abi.encodePacked(CONTEXT_ACTIVE);
        } else {
            context = abi.encodePacked(CONTEXT_INACTIVE);
        }
        validationData = 0;
    }

    /**
     * @notice Post-operation handler.
     * @dev Records the result of the user operation (e.g. success or revert).
     *
     *      Also, reverts if the paymaster was not active, ensuring that only allowed
     *      operators can make use of this paymaster.
     *
     * @param mode The mode enum representing the operation result.
     */
    function _postOp(
        PostOpMode mode,
        bytes calldata context,
        uint256 /* actualGasCost */
    ) internal override {
        if (
            context[0] == CONTEXT_INACTIVE &&
            _ACTIVE_STATE_ != ActiveState.ACTIVE
        ) {
            revert Inactive();
        }
        _LAST_OP_MODE_ = mode;
    }

    function _validateSponsoredUserOp(
        bytes memory signature,
        address expectedSigner,
        uint64 deadline,
        UserOperation calldata userOp
    ) internal {
        if (block.timestamp > deadline) {
            revert SignatureExpired(deadline);
        }

        if (!_SIGNERS_[expectedSigner]) {
            revert SignerNotAllowed(expectedSigner);
        }

        // Zero-out paymasterAndData before hashing the userOp.
        UserOperation memory userOpClone = userOp;
        userOpClone.paymasterAndData = bytes("");
        userOpClone.signature = bytes("");
        bytes32 userOpHash = entryPoint.getUserOpHash(userOpClone);

        bytes32 structHash = keccak256(
            abi.encode(SPONSOR_USER_OP_TYPEHASH, userOpHash, deadline)
        );

        bytes32 digest = _hashTypedDataV4(structHash);

        address recoveredSigner = ECDSA.recover(digest, signature);
        if (recoveredSigner != expectedSigner) {
            revert SignatureInvalid(recoveredSigner, expectedSigner);
        }

        if (_SPONSORED_USER_OP_HASHES_[userOpHash]) {
            revert SponsoredUserOpRepeated(userOpHash);
        }

        _SPONSORED_USER_OP_HASHES_[userOpHash] = true;

        emit UserOpSponsored(userOpHash);
    }
}
