// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

/// @title Constant state
/// @notice Constant state used by the Universal Router
library Constants {
    /// @dev Used for identifying cases when a v2 pair has already received input tokens
    uint256 internal constant ALREADY_PAID = 0;

    /// @dev Used as a flag for identifying the transfer of ETH instead of a token
    address internal constant ETH = address(0);

    /// @dev The length of the bytes encoded address
    uint256 internal constant ADDR_SIZE = 20;

    /// @dev The length of the bytes encoded fee numerator
    uint256 internal constant FEE_NUMERATOR_SIZE = 2;

    /// @dev The offset of a single token address (20), fee numerator (2) and pool address (20)
    uint256 internal constant NEXT_V2_PAIR_OFFSET = ADDR_SIZE + FEE_NUMERATOR_SIZE + ADDR_SIZE;

    /// @dev The offset of an encoded pair
    /// Token (20) + Fee Numerator (2) + Pool (20) + Token (20) = 62
    uint256 internal constant V2_POP_OFFSET = NEXT_V2_PAIR_OFFSET + ADDR_SIZE;

    /// @dev The minimum length of an encoding that contains 2 or more pairs
    uint256 internal constant MULTIPLE_V2_PAIRS_MIN_LENGTH = V2_POP_OFFSET + NEXT_V3_POOL_OFFSET;

    /// @dev The offset of a single token address (20) and pool address (20)
    uint256 internal constant NEXT_V3_POOL_OFFSET = ADDR_SIZE + ADDR_SIZE;

    /// @dev The offset of an encoded pool key
    /// Token (20) + Pool (20) + Token (20) = 60
    uint256 internal constant V3_POP_OFFSET = NEXT_V3_POOL_OFFSET + ADDR_SIZE;

    /// @dev The minimum length of an encoding that contains 2 or more pools
    uint256 internal constant MULTIPLE_V3_POOLS_MIN_LENGTH = V3_POP_OFFSET + NEXT_V3_POOL_OFFSET;
}
