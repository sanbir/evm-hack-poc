// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity >=0.8.0;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
import {Constants} from '../../libraries/Constants.sol';
import {IAerodrome, AERODROME_ROUTER} from './interfaces/IAerodrome.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';

abstract contract AerodromeSwapRouter {
    using SafeTransferLib for ERC20;

    function aerodromeExactInputSingle(IAerodrome.ExactInputSingleParams memory params) internal {
        if (params.amountIn == ActionConstants.CONTRACT_BALANCE) {
            params.amountIn = ERC20(params.tokenIn).balanceOf(address(this));
        }
        ERC20(params.tokenIn).safeApprove(AERODROME_ROUTER, params.amountIn);
        IAerodrome(AERODROME_ROUTER).exactInputSingle(params);
    }
}
