// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

address constant AERODROME_ROUTER = address(0xBE6D8f0d05cC4be24d5167a3eF062215bE6D18a5);

interface IAerodrome {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        int24 tickSpacing;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }

    function exactInputSingle(ExactInputSingleParams calldata params) external returns (uint256 amountOut);
}
