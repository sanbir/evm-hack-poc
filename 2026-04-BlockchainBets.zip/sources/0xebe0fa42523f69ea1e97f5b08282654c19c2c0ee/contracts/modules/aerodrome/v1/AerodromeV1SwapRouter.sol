// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
import {Permit2Payments} from '../../Permit2Payments.sol';
import {V3Path} from '../../uniswap/v3/V3Path.sol';
import {UniswapV2Library} from '../../uniswap/v2/UniswapV2Library.sol';
import {Constants} from '../../../libraries/Constants.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';

interface IAerodromeV1Pool {
    function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
    function getReserves() external view returns (uint256 reserve0, uint256 reserve1, uint256 blockTimestampLast);
    function getAmountOut(uint256 amountIn, address tokenIn) external view returns (uint256 amountOut);
}

abstract contract AerodromeV1SwapRouter is Permit2Payments {
    using V3Path for bytes;
    using SafeTransferLib for ERC20;

    function _swap(bytes calldata path, address recipient) private {
        unchecked {
            (address tokenIn, address pool, address tokenOut) = path.decodeFirstPool();
            while (true) {
                // 1. Determine the amount just received by the pool.
                (uint256 reserve0, uint256 reserve1,) = IAerodromeV1Pool(pool).getReserves();
                (address token0,) = tokenIn < tokenOut ? (tokenIn, tokenOut) : (tokenOut, tokenIn);
                (uint256 reserveInput,) = tokenIn == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
                uint256 amountInput = ERC20(tokenIn).balanceOf(pool) - reserveInput;

                // 2. Query pool for output given this input.
                uint256 amountOutput = IAerodromeV1Pool(pool).getAmountOut(amountInput, tokenIn);

                // 3. Prepare swap parameters.
                (uint256 amount0Out, uint256 amount1Out) =
                    tokenIn == token0 ? (uint256(0), amountOutput) : (amountOutput, uint256(0));

                // 4. Determine next hop recipient.
                address nextRecipient;
                bool hasNext = path.hasMultiplePools();
                address nextPool;
                address nextTokenOut;
                if (hasNext) {
                    path = path.skipToken();
                    (, nextPool, nextTokenOut) = path.decodeFirstPool();
                    nextRecipient = nextPool;
                } else {
                    // Final hop – deliver directly to the user-supplied recipient.
                    nextRecipient = recipient;
                }

                // 5. Execute the swap.
                IAerodromeV1Pool(pool).swap(amount0Out, amount1Out, nextRecipient, new bytes(0));

                if (!hasNext) break;

                // Prepare variables for next iteration
                tokenIn = tokenOut;
                tokenOut = nextTokenOut;
                pool = nextPool;
            }
        }
    }

    function aerodromeV1SwapExactInput(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMinimum,
        bytes calldata path,
        address payer
    ) internal {
        // Extract the first hop parameters (tokenIn + first pool) for upfront transfer handling.
        (address firstTokenIn, address firstPool,) = path.decodeFirstPool();

        // Transfer input tokens into the first pool if required.
        if (amountIn != Constants.ALREADY_PAID) {
            if (amountIn == ActionConstants.CONTRACT_BALANCE) {
                amountIn = ERC20(firstTokenIn).balanceOf(address(this));
            }
            payOrPermit2Transfer(firstTokenIn, payer, firstPool, amountIn);
        }

        if (amountOutMinimum == 0) {
            _swap(path, recipient);
        } else {
            // Derive the final output token of the path.
            // The path is encoded as: token | pool | token | [pool | token] ...
            // Hence the last 20 bytes always hold the address of the final token.
            address finalTokenOut = UniswapV2Library.decodeLastOutput(path);
            uint256 balanceBefore = ERC20(finalTokenOut).balanceOf(recipient);

            // Perform the swaps.
            _swap(path, recipient);

            // Slippage check only if a minimum was specified.
            uint256 amountOut = ERC20(finalTokenOut).balanceOf(recipient) - balanceBefore;
            if (amountOut < amountOutMinimum) revert();
        }
    }
}
