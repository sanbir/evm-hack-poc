// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';
import {IBalancerVault} from './interfaces/IBalancerVault.sol';

abstract contract BalancerSwapRouter {
    using SafeTransferLib for ERC20;

    address internal immutable balancerVault;

    constructor(address _vault) {
        balancerVault = _vault;
    }

    function balancerSwapExactIn(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMin,
        bytes32 poolId,
        address assetIn,
        address assetOut
    ) internal {
        // use amountIn == ActionConstants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
        if (amountIn == ActionConstants.CONTRACT_BALANCE) {
            amountIn = ERC20(assetIn).balanceOf(address(this));
        }

        _approveExact(assetIn, amountIn);

        IBalancerVault(balancerVault).swap(
            IBalancerVault.SingleSwap({
                poolId: poolId,
                kind: IBalancerVault.SwapKind.GIVEN_IN,
                assetIn: assetIn,
                assetOut: assetOut,
                amount: amountIn,
                userData: new bytes(0)
            }),
            IBalancerVault.FundManagement({
                sender: address(this),
                fromInternalBalance: false,
                recipient: payable(recipient),
                toInternalBalance: false
            }),
            amountOutMin,
            block.timestamp
        );
    }

    function balancerBatchSwapExactIn(
        address recipient,
        IBalancerVault.BatchSwap[] memory swaps,
        address[] memory assets,
        int256[] memory limits
    ) internal {
        for (uint256 i = 0; i < assets.length; i++) {
            if (limits[i] > 0) {
                _approveExact(assets[i], uint256(limits[i]));
            }
        }

        IBalancerVault(balancerVault).batchSwap(
            IBalancerVault.SwapKind.GIVEN_IN,
            swaps,
            assets,
            IBalancerVault.FundManagement({
                sender: address(this),
                fromInternalBalance: false,
                recipient: payable(recipient),
                toInternalBalance: false
            }),
            limits,
            block.timestamp
        );
    }

    function _approveExact(address token, uint256 amount) private {
        ERC20(token).safeApprove(balancerVault, amount);
    }
}
