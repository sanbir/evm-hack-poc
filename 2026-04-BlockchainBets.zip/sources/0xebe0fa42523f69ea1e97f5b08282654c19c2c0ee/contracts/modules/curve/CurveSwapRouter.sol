// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity >=0.8.0;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
import {Constants} from '../../libraries/Constants.sol';
import {Payments} from '../Payments.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';

interface IStableSwap {
    function get_dy(int128 i, int128 j, uint256 dx) external view returns (uint256);
    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy) external payable;
    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy, address receiver)
        external
        payable
        returns (uint256);
    function exchange_received(int128 i, int128 j, uint256 dx, uint256 min_dy, address receiver)
        external
        payable
        returns (uint256);
    function calc_withdraw_one_coin(uint256 amount, int128 coinIndex) external view returns (uint256);
}

interface ILegacyStableSwap {
    function get_dy(int128 i, int128 j, uint256 dx) external view returns (uint256);
    function exchange(int128 i, int128 j, uint256 dx, uint256 min_dy) external payable;
    function calc_withdraw_one_coin(uint256 amount, int128 coinIndex) external view returns (uint256);
}

interface ICryptoSwap {
    function get_dy(uint256 i, uint256 j, uint256 dx) external view returns (uint256);
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 min_dy) external payable;
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 min_dy, address receiver) external payable;
    function exchange(uint256 i, uint256 j, uint256 dx, uint256 min_dy, bool use_eth, address receiver)
        external
        payable;
    function exchange_received(uint256 i, uint256 j, uint256 dx, uint256 min_dy, address receiver) external payable;
    function exchange_received(uint256 i, uint256 j, uint256 dx, uint256 min_dy) external payable;
    function calc_withdraw_one_coin(uint256 amount, uint256 coinIndex) external view returns (uint256);
}

abstract contract CurveSwapRouter is Payments {
    error InvalidInput();

    using SafeTransferLib for ERC20;

    error UnsupportedPoolType(uint8 poolType);
    error SwapFailed();

    enum PoolType {
        LEGACY_CRYPTO,
        CRYPTO,
        OPTIMIZED_ETH_CRYPTO,
        LEGACY_STABLE,
        STABLE
    }

    struct SwapParams {
        PoolType poolType; // Type of the Curve pool
        address pool; // Pool address
        address tokenIn; // Input token address (address(0) for ETH)
        address tokenOut; // Output token address (address(0) for ETH)
        uint256 amountIn; // Amount of input tokens
        uint256 amountOutMin; // Minimum amount of output tokens
        uint256 indexIn; // Input token index
        uint256 indexOut; // Output token index
        address recipient; // Recipient of the output tokens
        bool useEth; // Whether to use ETH (only for OPTIMIZED_ETH_CRYPTO)
    }

    function curveSwapExactIn(SwapParams memory params) internal {
        // Only approve if token is not ETH and not ETH_ADDRESS
        bool useEth = params.tokenIn == Constants.ETH;
        if (useEth) {
            if (params.amountIn == ActionConstants.CONTRACT_BALANCE) {
                params.amountIn = address(this).balance;
            }
        } else {
            if (params.amountIn == ActionConstants.CONTRACT_BALANCE) {
                params.amountIn = ERC20(params.tokenIn).balanceOf(address(this));
            }
            ERC20(params.tokenIn).safeApprove(params.pool, params.amountIn);
        }

        // Handle different pool types
        if (params.poolType == PoolType.LEGACY_CRYPTO) {
            _handleLegacyCryptoSwap(params);
        } else if (params.poolType == PoolType.CRYPTO) {
            _handleCryptoSwap(params);
        } else if (params.poolType == PoolType.OPTIMIZED_ETH_CRYPTO) {
            _handleOptimizedEthCryptoSwap(params);
        } else if (params.poolType == PoolType.LEGACY_STABLE) {
            _handleLegacyStableSwap(params);
        } else if (params.poolType == PoolType.STABLE) {
            _handleStableSwap(params);
        } else {
            revert UnsupportedPoolType(uint8(params.poolType));
        }

        if (params.recipient != address(0) && params.recipient != address(this)) {
            if (params.poolType == PoolType.LEGACY_CRYPTO || params.poolType == PoolType.LEGACY_STABLE) {
                // For legacy pools that don't support recipient parameter, we need to transfer manually
                pay(params.tokenOut, params.recipient, ActionConstants.CONTRACT_BALANCE);
            }
        }
    }

    function _handleLegacyCryptoSwap(SwapParams memory params) private {
        ICryptoSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
            params.indexIn, params.indexOut, params.amountIn, params.amountOutMin
        );
    }

    function _handleCryptoSwap(SwapParams memory params) private {
        if (params.recipient == address(this)) {
            ICryptoSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
                params.indexIn, params.indexOut, params.amountIn, params.amountOutMin
            );
        } else {
            ICryptoSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
                params.indexIn, params.indexOut, params.amountIn, params.amountOutMin, params.recipient
            );
        }
    }

    function _handleOptimizedEthCryptoSwap(SwapParams memory params) private {
        ICryptoSwap(params.pool).exchange{value: params.useEth ? params.amountIn : 0}(
            params.indexIn, params.indexOut, params.amountIn, params.amountOutMin, params.useEth, params.recipient
        );
    }

    function _handleLegacyStableSwap(SwapParams memory params) private {
        ILegacyStableSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
            toInt128(params.indexIn), toInt128(params.indexOut), params.amountIn, params.amountOutMin
        );
    }

    function _handleStableSwap(SwapParams memory params) private {
        if (params.recipient == address(this)) {
            IStableSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
                toInt128(params.indexIn), toInt128(params.indexOut), params.amountIn, params.amountOutMin
            );
        } else {
            IStableSwap(params.pool).exchange{value: params.tokenIn == Constants.ETH ? params.amountIn : 0}(
                toInt128(params.indexIn),
                toInt128(params.indexOut),
                params.amountIn,
                params.amountOutMin,
                params.recipient
            );
        }
    }

    function toInt128(uint256 input) private pure returns (int128) {
        require(input <= uint128(type(int128).max), InvalidInput());
        return int128(uint128(input));
    }
}
