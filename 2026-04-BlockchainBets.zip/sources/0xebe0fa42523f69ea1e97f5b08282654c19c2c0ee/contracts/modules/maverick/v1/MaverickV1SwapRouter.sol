// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {V3Path} from '../../uniswap/v3/V3Path.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';
import {Permit2Payments} from '../../Permit2Payments.sol';
import {Locker} from '../../../libraries/Locker.sol';

interface IMaverickV1Pool {
    function swap(
        address recipient,
        uint256 amount,
        bool tokenAIn,
        bool exactOutput,
        uint256 sqrtPriceLimit,
        bytes calldata data
    ) external returns (uint256 amountIn, uint256 amountOut);
}

/// @title Router for Maverick v1 Trades
abstract contract MaverickV1SwapRouter is Permit2Payments {
    using V3Path for bytes;

    error MaverickV1InvalidSwap();
    error MaverickV1TooLittleReceived();
    error MaverickV1InvalidPayer();

    /// @dev The minimum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MIN_TICK)
    uint256 private constant MIN_SQRT_RATIO = 4295128739;

    /// @dev The maximum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MAX_TICK)
    uint256 private constant MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342;

    function swapCallback(uint256 amountIn, uint256 amountOut, bytes calldata data) external {
        if (amountIn == 0 || amountOut == 0) revert MaverickV1InvalidSwap();
        (address tokenIn, address payer) = abi.decode(data, (address, address));
        if (payer != address(this) && payer != Locker.get()) revert MaverickV1InvalidPayer();

        // Pay the pool (msg.sender)
        payOrPermit2Transfer(tokenIn, payer, msg.sender, amountIn);
    }

    /// @notice Performs a Maverick v1 exact input swap
    /// @param recipient The recipient of the output tokens
    /// @param amountIn The amount of input tokens for the trade
    /// @param amountOutMinimum The minimum desired amount of output tokens
    /// @param path The path of the trade as a bytes string
    /// @param payer The address that will be paying the input
    function maverickV1SwapExactInput(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMinimum,
        bytes calldata path,
        address payer
    ) internal {
        (address tokenIn, address pool, address tokenOut) = path.decodeFirstPool();
        // use amountIn == ActionConstants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
        if (amountIn == ActionConstants.CONTRACT_BALANCE) {
            amountIn = ERC20(tokenIn).balanceOf(address(this));
        }

        uint256 amountOut = amountIn;
        while (true) {
            bool hasMultiplePools = path.hasMultiplePools();

            // the outputs of prior swaps become the inputs to subsequent ones
            amountOut = _swap(
                amountOut, // amountOut from last swap becomes amountIn
                hasMultiplePools ? address(this) : recipient, // for intermediate swaps, this contract custodies
                pool,
                tokenIn,
                tokenOut,
                payer
            );

            // decide whether to continue or terminate
            if (hasMultiplePools) {
                payer = address(this); // for intermediate swaps, this contract custodies
                path = path.skipToken();
                (tokenIn, pool, tokenOut) = path.decodeFirstPool();
            } else {
                break;
            }
        }

        if (amountOut < amountOutMinimum) revert MaverickV1TooLittleReceived();
    }

    /// @dev Performs a single swap for exactIn
    function _swap(uint256 amount, address recipient, address pool, address tokenIn, address tokenOut, address payer)
        private
        returns (uint256 amountOut)
    {
        bool tokenAIn = tokenIn < tokenOut;

        (, amountOut) = IMaverickV1Pool(pool).swap(
            recipient,
            amount,
            tokenAIn,
            false,
            (tokenAIn ? MAX_SQRT_RATIO - 1 : MIN_SQRT_RATIO + 1),
            abi.encode(tokenIn, payer)
        );

        return amountOut;
    }
}
