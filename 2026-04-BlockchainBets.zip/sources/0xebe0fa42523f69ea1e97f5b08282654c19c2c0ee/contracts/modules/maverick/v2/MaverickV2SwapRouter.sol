// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {V3Path} from '../../uniswap/v3/V3Path.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';
import {Permit2Payments, SafeCast160} from '../../Permit2Payments.sol';

interface IMaverickV2Pool {
    struct SwapParams {
        uint256 amount;
        bool tokenAIn;
        bool exactOutput;
        int32 tickLimit;
    }

    function swap(address recipient, SwapParams memory params, bytes calldata data)
        external
        returns (uint256 amountIn, uint256 amountOut);
}

/// @title Router for Maverick v2 Trades
abstract contract MaverickV2SwapRouter is Permit2Payments {
    using V3Path for bytes;
    using SafeCast160 for uint256;

    error MaverickV2TooLittleReceived();

    /// @notice Performs a Maverick v2 exact input swap
    /// @param recipient The recipient of the output tokens
    /// @param amountIn The amount of input tokens for the trade
    /// @param amountOutMinimum The minimum desired amount of output tokens
    /// @param path The path of the trade as a bytes string
    /// @param payer The address that will be paying the input
    function maverickV2SwapExactInput(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMinimum,
        bytes calldata path,
        address payer
    ) internal {
        (address tokenIn, address pool, address tokenOut) = path.decodeFirstPool();
        if (payer == address(this)) {
            // use amountIn == ActionConstants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
            if (amountIn == ActionConstants.CONTRACT_BALANCE) {
                amountIn = ERC20(tokenIn).balanceOf(address(this));
            }
            pay(tokenIn, pool, amountIn);
        } else {
            permit2TransferFrom(tokenIn, payer, pool, amountIn.toUint160());
        }

        uint256 amountOut = amountIn;
        while (true) {
            bool hasMultiplePools = path.hasMultiplePools();
            address nextRecipient;
            address nextTokenOut;
            if (hasMultiplePools) {
                path = path.skipToken();
                (, nextRecipient, nextTokenOut) = path.decodeFirstPool();
            } else {
                nextRecipient = recipient;
            }

            // the outputs of prior swaps become the inputs to subsequent ones
            amountOut = _swap(
                amountOut, // amountOut from last swap becomes amountIn
                nextRecipient, // for intermediate swaps -> next pool
                pool,
                tokenIn < tokenOut
            );

            // decide whether to continue or terminate
            if (hasMultiplePools) {
                pool = nextRecipient;
                tokenIn = tokenOut;
                tokenOut = nextTokenOut;
            } else {
                break;
            }
        }

        if (amountOut < amountOutMinimum) revert MaverickV2TooLittleReceived();
    }

    /// @dev Performs a single swap for exactIn
    function _swap(uint256 amountIn, address recipient, address pool, bool tokenAIn)
        private
        returns (uint256 amountOut)
    {
        IMaverickV2Pool.SwapParams memory swapParams =
            IMaverickV2Pool.SwapParams(amountIn, tokenAIn, false, tokenAIn ? type(int32).max : type(int32).min);

        (, amountOut) = IMaverickV2Pool(pool).swap(recipient, swapParams, '');

        return amountOut;
    }
}
