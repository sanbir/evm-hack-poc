// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity >=0.8.0;

import {ERC20} from 'solmate/src/tokens/ERC20.sol';
import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
import {ActionConstants} from '@uniswap/v4-periphery/src/libraries/ActionConstants.sol';
import {Permit2Payments, SafeCast160} from '../Permit2Payments.sol';

interface IPsm {
    function sellGem(address recipient, uint256 gemAmount) external;
    function buyGem(address recipient, uint256 gemAmount) external;
    function tout() external view returns (uint256);
}

abstract contract SkyRouter is Permit2Payments {
    using SafeTransferLib for ERC20;
    using SafeCast160 for uint256;

    enum TradeType {
        SellUSDCForUSDS,
        SellUSDCForDAI,
        BuyUSDCWithUSDS,
        BuyUSDCWithDAI
    }

    IPsm private constant USDS_PSM_WRAPPER = IPsm(0xA188EEC8F81263234dA3622A406892F3D630f98c);
    IPsm private constant DSS_LITE_PSM = IPsm(0xf6e72Db5454dd049d0788e411b06CfAF16853042);
    ERC20 private constant USDC = ERC20(0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48);
    ERC20 private constant USDS = ERC20(0xdC035D45d973E3EC169d2276DDab16f1e407384F);
    ERC20 private constant DAI = ERC20(0x6B175474E89094C44Da98b954EedeAC495271d0F);
    uint256 private WAD = 1e18;

    error SkyTooMuchRequested();

    function tradeGem(TradeType tradeType, address payer, address recipient, uint256 amountIn, uint256 amountOut)
        internal
    {
        ERC20 tokenIn;
        function (address, uint256) external targetFunc;
        bool isSell = true;
        if (tradeType == TradeType.SellUSDCForUSDS) {
            tokenIn = USDC;
            targetFunc = USDS_PSM_WRAPPER.sellGem;
        } else if (tradeType == TradeType.SellUSDCForDAI) {
            tokenIn = USDC;
            targetFunc = DSS_LITE_PSM.sellGem;
        } else if (tradeType == TradeType.BuyUSDCWithUSDS) {
            tokenIn = USDS;
            targetFunc = USDS_PSM_WRAPPER.buyGem;
            isSell = false;

            // The following part is only needed if fees are be enabled.
            // uint256 amount18 = amountOut * 1e12;
            // amount18 += amount18 * USDS_PSM_WRAPPER.tout() / WAD;
            // if (amountIn < amount18) revert SkyTooMuchRequested();
            // amountIn = amount18;
        } else {
            // tradeType == TradeType.BuyUSDCWithDAI
            tokenIn = DAI;
            targetFunc = DSS_LITE_PSM.buyGem;
            isSell = false;

            // The following part is only needed if fees are be enabled.
            // uint256 amount18 = amountOut * 1e12;
            // amount18 += amount18 * DSS_LITE_PSM.tout() / WAD;
            // if (amountIn < amount18) revert SkyTooMuchRequested();
            // amountIn = amount18;
        }
        if (payer != address(this)) {
            permit2TransferFrom(address(tokenIn), payer, address(this), amountIn.toUint160());
        } else if (amountIn == ActionConstants.CONTRACT_BALANCE) {
            amountIn = tokenIn.balanceOf(address(this));
            if (isSell == false) {
                amountOut = amountIn / 1e12;
            }
        }
        tokenIn.safeApprove(targetFunc.address, amountIn);
        targetFunc(recipient, isSell ? amountIn : amountOut);
    }
}
