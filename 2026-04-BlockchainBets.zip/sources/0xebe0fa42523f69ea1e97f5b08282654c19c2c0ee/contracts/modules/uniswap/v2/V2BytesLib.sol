// SPDX-License-Identifier: GPL-3.0-or-later

/// @title Library for Bytes Manipulation
pragma solidity ^0.8.0;

import {Constants} from '../../../libraries/Constants.sol';

library V2BytesLib {
    error SliceOutOfBounds();

    /// @notice Returns the address starting at byte 0
    /// @dev length and overflow checks must be carried out before calling
    /// @param _bytes The input bytes string to slice
    /// @return _address The address starting at byte 0
    function toAddress(bytes calldata _bytes) internal pure returns (address _address) {
        if (_bytes.length < Constants.ADDR_SIZE) revert SliceOutOfBounds();
        assembly {
            _address := shr(96, calldataload(_bytes.offset))
        }
    }

    /// @notice Returns the pair details starting at byte 0
    /// @dev length and overflow checks must be carried out before calling
    /// @param _bytes The input bytes string to slice
    /// @return tokenIn The address at byte 0
    /// @return feeNumerator The uint16 starting at byte 20
    /// @return pair The address starting at byte 22
    /// @return tokenOut The address at byte 42
    function toPair(bytes calldata _bytes)
        internal
        pure
        returns (address tokenIn, uint16 feeNumerator, address pair, address tokenOut)
    {
        if (_bytes.length < Constants.V2_POP_OFFSET) revert SliceOutOfBounds();
        assembly {
            tokenIn := shr(96, calldataload(_bytes.offset))
            feeNumerator := shr(240, calldataload(add(_bytes.offset, 20)))
            pair := shr(96, calldataload(add(_bytes.offset, 22)))
            tokenOut := shr(96, calldataload(add(_bytes.offset, 42)))
        }
    }

    /// @notice Returns the last address in the bytes calldata
    /// @dev length and overflow checks must be carried out before calling
    /// @param _bytes The input bytes string to slice
    /// @return _address The last address in the bytes calldata
    function toLastAddress(bytes calldata _bytes) internal pure returns (address _address) {
        if (_bytes.length < Constants.ADDR_SIZE) revert SliceOutOfBounds();
        assembly {
            _address := shr(96, calldataload(add(_bytes.offset, sub(_bytes.length, 20))))
        }
    }
}
