// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {IUniswapV2Pair} from '@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol';
import {UniswapV2Library} from './UniswapV2Library.sol';
import {Permit2Payments} from '../../Permit2Payments.sol';
import {Constants} from '../../../libraries/Constants.sol';
import {ERC20} from 'solmate/src/tokens/ERC20.sol';

/// @title Router for Uniswap v2 Trades
abstract contract V2SwapRouter is Permit2Payments {
    using UniswapV2Library for bytes;

    error V2TooLittleReceived();
    error V2TooMuchRequested();
    error V2InvalidPath();

    function _v2Swap(bytes calldata path, address recipient) private {
        unchecked {
            (address input, uint16 feeNumerator, address pair, address output) = path.toPair();
            while (true) {
                (address token0,) = UniswapV2Library.sortTokens(input, output);
                (uint256 reserve0, uint256 reserve1,) = IUniswapV2Pair(pair).getReserves();
                (uint256 reserveInput, uint256 reserveOutput) =
                    input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
                uint256 amountInput = ERC20(input).balanceOf(pair) - reserveInput;
                uint256 amountOutput =
                    UniswapV2Library.getAmountOut(amountInput, feeNumerator, reserveInput, reserveOutput);
                (uint256 amount0Out, uint256 amount1Out) =
                    input == token0 ? (uint256(0), amountOutput) : (amountOutput, uint256(0));
                address nextRecipient;
                bool hasNext = path.hasMultiplePairs();
                if (hasNext) {
                    path = path.skipToken();
                    (input, feeNumerator, nextRecipient, output) = path.toPair();
                } else {
                    nextRecipient = recipient;
                }
                IUniswapV2Pair(pair).swap(amount0Out, amount1Out, nextRecipient, new bytes(0));
                if (!hasNext) break;
                pair = nextRecipient;
            }
        }
    }

    /// @notice Performs a Uniswap v2 exact input swap
    /// @param recipient The recipient of the output tokens
    /// @param amountIn The amount of input tokens for the trade
    /// @param amountOutMinimum The minimum desired amount of output tokens
    /// @param path The path of the trade as an array of token addresses
    /// @param payer The address that will be paying the input
    function v2SwapExactInput(
        address recipient,
        uint256 amountIn,
        uint256 amountOutMinimum,
        bytes calldata path,
        address payer
    ) internal {
        if (path.length < Constants.V2_POP_OFFSET) revert V2InvalidPath();

        if (
            amountIn != Constants.ALREADY_PAID // amountIn of 0 to signal that the pair already has the tokens
        ) {
            (address input,, address firstPair,) = path.toPair();
            payOrPermit2Transfer(input, payer, firstPair, amountIn);
        }

        if (amountOutMinimum == 0) {
            _v2Swap(path, recipient);
        } else {
            // The last 20 bytes always hold the address of the final token.
            ERC20 tokenOut = ERC20(path.decodeLastOutput());
            uint256 balanceBefore = tokenOut.balanceOf(recipient);

            _v2Swap(path, recipient);

            uint256 amountOut = tokenOut.balanceOf(recipient) - balanceBefore;
            if (amountOut < amountOutMinimum) revert V2TooLittleReceived();
        }
    }
}
