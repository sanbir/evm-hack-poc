// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity ^0.8.24;

import {Permit2Payments} from '../../Permit2Payments.sol';
import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
import {Currency} from '@uniswap/v4-core/src/types/Currency.sol';
import {V4RouterOnlySwap} from './V4RouterOnlySwap.sol';

/// @title Router for Uniswap v4 Trades
abstract contract V4SwapRouter is V4RouterOnlySwap, Permit2Payments {
    constructor(address _poolManager) V4RouterOnlySwap(IPoolManager(_poolManager)) {}

    function _pay(Currency token, address payer, uint256 amount) internal override {
        payOrPermit2Transfer(Currency.unwrap(token), payer, address(poolManager), amount);
    }
}
