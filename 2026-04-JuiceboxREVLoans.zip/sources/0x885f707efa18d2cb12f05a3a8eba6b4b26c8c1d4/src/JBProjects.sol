// SPDX-License-Identifier: MIT
pragma solidity 0.8.23;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ERC2771Context} from "@openzeppelin/contracts/metatx/ERC2771Context.sol";
import {ERC721, Context} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {IERC165} from "@openzeppelin/contracts/utils/introspection/IERC165.sol";

import {IJBProjects} from "./interfaces/IJBProjects.sol";
import {IJBTokenUriResolver} from "./interfaces/IJBTokenUriResolver.sol";

/// @notice Stores project ownership and metadata.
/// @dev Projects are represented as ERC-721s.
contract JBProjects is ERC721, ERC2771Context, Ownable, IJBProjects {
    //*********************************************************************//
    // --------------------- public stored properties -------------------- //
    //*********************************************************************//

    /// @notice The number of projects that have been created using this contract.
    /// @dev The count is incremented with each new project created.
    /// @dev The resulting ERC-721 token ID for each project is the newly incremented count value.
    uint256 public override count;

    /// @notice The contract resolving each project ID to its ERC721 URI.
    IJBTokenUriResolver public override tokenUriResolver;

    //*********************************************************************//
    // -------------------------- constructor ---------------------------- //
    //*********************************************************************//

    /// @param owner The owner of the contract who can set metadata.
    /// @param feeProjectOwner The address that will receive the fee-project. If `address(0)` the fee-project will not
    /// be minted.
    /// @param trustedForwarder The trusted forwarder for the ERC2771Context.
    constructor(
        address owner,
        address feeProjectOwner,
        address trustedForwarder
    )
        ERC721("Juicebox Projects", "JUICEBOX")
        Ownable(owner)
        ERC2771Context(trustedForwarder)
    {
        if (feeProjectOwner != address(0)) {
            createFor(feeProjectOwner);
        }
    }

    //*********************************************************************//
    // -------------------------- public views --------------------------- //
    //*********************************************************************//

    /// @notice Indicates whether this contract adheres to the specified interface.
    /// @dev See {IERC165-supportsInterface}.
    /// @param interfaceId The ID of the interface to check for adherence to.
    /// @return A flag indicating if the provided interface ID is supported.
    function supportsInterface(bytes4 interfaceId) public view virtual override(IERC165, ERC721) returns (bool) {
        return interfaceId == type(IJBProjects).interfaceId || super.supportsInterface(interfaceId);
    }

    /// @notice Returns the URI where the ERC-721 standard JSON of a project is hosted.
    /// @param projectId The ID of the project to get a URI of.
    /// @return The token URI to use for the provided `projectId`.
    function tokenURI(uint256 projectId) public view override returns (string memory) {
        // Keep a reference to the resolver.
        IJBTokenUriResolver resolver = tokenUriResolver;

        // If there's no resolver, there's no URI.
        if (resolver == IJBTokenUriResolver(address(0))) return "";

        // Return the resolved URI.
        return resolver.getUri(projectId);
    }

    //*********************************************************************//
    // -------------------------- internal views ------------------------- //
    //*********************************************************************//

    /// @dev `ERC-2771` specifies the context as being a single address (20 bytes).
    function _contextSuffixLength() internal view override(ERC2771Context, Context) returns (uint256) {
        return super._contextSuffixLength();
    }

    /// @notice The calldata. Preferred to use over `msg.data`.
    /// @return calldata The `msg.data` of this call.
    function _msgData() internal view override(ERC2771Context, Context) returns (bytes calldata) {
        return ERC2771Context._msgData();
    }

    /// @notice The message's sender. Preferred to use over `msg.sender`.
    /// @return sender The address which sent this call.
    function _msgSender() internal view override(ERC2771Context, Context) returns (address sender) {
        return ERC2771Context._msgSender();
    }

    //*********************************************************************//
    // ---------------------- external transactions ---------------------- //
    //*********************************************************************//

    /// @notice Sets the address of the resolver used to retrieve the tokenURI of projects.
    /// @param resolver The address of the new resolver.
    function setTokenUriResolver(IJBTokenUriResolver resolver) external override onlyOwner {
        // Store the new resolver.
        tokenUriResolver = resolver;

        emit SetTokenUriResolver({resolver: resolver, caller: _msgSender()});
    }

    //*********************************************************************//
    // ---------------------- public transactions ---------------------- //
    //*********************************************************************//

    /// @notice Create a new project for the specified owner, which mints an NFT (ERC-721) into their wallet.
    /// @dev Anyone can create a project on an owner's behalf.
    /// @param owner The address that will be the owner of the project.
    /// @return projectId The token ID of the newly created project.
    function createFor(address owner) public override returns (uint256 projectId) {
        // Increment the count, which will be used as the ID.
        projectId = ++count;

        emit Create({projectId: projectId, owner: owner, caller: _msgSender()});

        // Mint the project.
        _safeMint(owner, projectId);
    }
}
