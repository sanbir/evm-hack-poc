// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IMonaToken {
    function burnsellMona(uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
    function burnLimit() external view returns (uint256);
}
contract BurnAddress {
    address public owner;
    address public monaTokenAddress;
    uint40 public tapcount;
    uint256 public sellMona;
    uint256 public burnedMona;

    IMonaToken public monaToken;

    event Sell(uint256 amount);
    event Burned(uint256 amount);

    constructor(address _monaToken) {
        owner = msg.sender;
        monaTokenAddress = _monaToken;
        monaToken = IMonaToken(_monaToken);
    }

    function transferOwnership(address newOwner) external {
        require(msg.sender == owner, "only owner can transfer ownership");
        owner = newOwner;
    }

    function setMonaTokenAddress(address _monaToken) external {
        require(msg.sender == owner, "only owner can set monaTokenAddress");
        monaTokenAddress = _monaToken;
        monaToken = IMonaToken(_monaToken);
    }

    function sell(uint256 amount) external {
        require(msg.sender == monaTokenAddress, "only monaToken can call this function");
        sellMona += amount;
        emit Sell(amount);
    }

    function burn() external {
        if(msg.sender == monaTokenAddress) {
            uint256 amount = sellMona - burnedMona;
            if(amount == 0) {
                return;
            }
            uint256 currentBurned = monaToken.balanceOf(address(0xdead));
            uint256 burnLimit = monaToken.burnLimit();
            if(currentBurned < burnLimit) {
                uint256 needBurn = burnLimit - currentBurned;
                if(needBurn < amount) {
                    amount = needBurn;
                }
                burnedMona += amount;
                monaToken.burnsellMona(amount);
                emit Burned(amount);
            }

        }else {
            tapcount++;
        }
    }
}