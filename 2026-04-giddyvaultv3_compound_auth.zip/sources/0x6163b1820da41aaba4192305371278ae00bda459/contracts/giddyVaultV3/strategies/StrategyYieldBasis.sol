// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "../interfaces/yieldbasis/IYieldBasisLT.sol";
import "../interfaces/yieldbasis/IYieldBasisGauge.sol";
import "../interfaces/yieldbasis/IYieldBasisFactory.sol";
import "../interfaces/yieldbasis/IYieldBasisOracle.sol";
import "../interfaces/yieldbasis/IYieldBasisLTMigrator.sol";
import "../interfaces/common/IERC4626.sol";
import "./GiddyBaseStrategyV3.sol";

/**
 * @title StrategyYieldBasis
 * @notice YieldBasis strategy for Giddy V3 vaults
 * @dev Implements YieldBasis LT token deposits with gauge staking for YB rewards
 *      Inherits from GiddyBaseStrategyV3 for common functionality
 *      Handles deposits of WBTC/cbBTC/tBTC into YieldBasis LT contracts
 *      Automatically stakes received LT tokens in gauges to earn YB emissions
 */
contract StrategyYieldBasis is GiddyBaseStrategyV3 {
  using SafeERC20 for IERC20;

  // ============ Constants ============

  // YieldBasis Factory contract address (constant across all markets)
  address public constant FACTORY = 0x370a449FeBb9411c95bf897021377fe0B7D100c0;
  // Swap address for reserve deposits
  address public constant SWAP_ADDRESS = 0x8276f373E5c107fF9c4672e3Eb89abc7f8c493f8;

  // ============ State Variables ============

  // Market-specific contract addresses
  address public ltToken;      // YieldBasis LT token (yb-WBTC, yb-cbBTC, or yb-tBTC)
  address public gauge;        // YieldBasis gauge for staking LT tokens
  address public oracle;       // Price oracle for the LT token
  uint256 public marketId;     // Market ID in Factory (0=WBTC, 1=cbBTC, 2=tBTC)
  
  // Management configuration
  bool public swapForDeposits; // If true, deposit via swap address; if false, deposit directly to protocol
  bool public useStaking;      // Whether to stake LT tokens in gauge (true) or keep unstaked (false)

  // ============ Events ============

  event DepositRouteChanged(bool swapForDeposits);

  // ============ Initialization ============

  /**
   * @notice Initialize the YieldBasis strategy
   * @param _params Strategy initialization parameters (name, vaultToken, factory, vault, rewardTokens)
   * @param _ltToken Address of the YieldBasis LT token contract
   * @param _gauge Address of the YieldBasis gauge contract for staking
   * @param _oracle Address of the price oracle for the LT token
   * @param _marketId Market ID in the Factory contract
   */
  function initialize(StrategyInitParams calldata _params, address _ltToken, address _gauge, address _oracle, uint256 _marketId) external initializer {
    __BaseStrategy_init(_params);

    ltToken = _ltToken;
    gauge = _gauge;
    oracle = _oracle;
    marketId = _marketId;
    useStaking = true; // Default to staked position

    // Approve LT token contract to spend vault token (underlying asset)
    IERC20(vaultToken).approve(ltToken, type(uint256).max);
    // Approve gauge to spend LT tokens
    IERC20(ltToken).approve(gauge, type(uint256).max);
  }

  // ============ Deposit/Withdraw Functions ============

  /**
   * @notice Deposit vault tokens into YieldBasis and stake LT tokens
   * @param amount The amount of vault tokens to deposit
   * @dev Routes to either direct protocol deposit or swap address deposit based on swapForDeposits flag
   */
  function _deposit(uint256 amount) internal override {
    if (amount == 0) return;

    if (!swapForDeposits) {
      // Direct deposit route (current logic)
      _depositDirect(amount);
    } else {
      // Swap address deposit route
      _depositViaSwapAddress(amount);
    }
  }

  /**
   * @notice Direct deposit into YieldBasis protocol
   * @param amount The amount of vault tokens to deposit
   * @dev 1. Deposits underlying asset (WBTC/cbBTC/tBTC) into LT contract
   *      2. Receives LT tokens (yb-WBTC/yb-cbBTC/yb-tBTC)
   *      3. Stakes LT tokens in gauge if useStaking is true
   */
  function _depositDirect(uint256 amount) internal {
    // Deposit underlying asset into LT contract to receive LT tokens
    IYieldBasisLT(ltToken).deposit(amount, address(this));

    // Stake LT tokens in gauge if staking is enabled
    if (useStaking) {
      uint256 ltBalance = IERC20(ltToken).balanceOf(address(this));
      IYieldBasisGauge(gauge).deposit(ltBalance, address(this));
    }
  }

  /**
   * @notice Deposit via swap address reserves
   * @param amount The amount of vault tokens to deposit
   * @dev 1. Calculates LT tokens needed using current exchange rate
   *      2. Transfers underlying assets to swap address
   *      3. Pulls gauge shares (staked tokens) from swap address
   */
  function _depositViaSwapAddress(uint256 amount) internal {
    uint256 assetsPerLtToken = IYieldBasisLT(ltToken).preview_withdraw(1e18);
    uint256 depositAmount = amount;

    // STAKED: deposit via gauge shares.
    if (useStaking) {
      uint256 availableGaugeShares = IYieldBasisGauge(gauge).balanceOf(SWAP_ADDRESS);
      if (availableGaugeShares == 0) return;
      uint256 ltTokensNeeded = (depositAmount * 1e18) / assetsPerLtToken;
      uint256 gaugeSharesNeeded = IERC4626(gauge).previewDeposit(ltTokensNeeded);

      if (gaugeSharesNeeded > availableGaugeShares) {
        uint256 ltTokensFromShares = IERC4626(gauge).convertToAssets(availableGaugeShares);
        depositAmount = (ltTokensFromShares * assetsPerLtToken) / 1e18;
        if (depositAmount == 0) return;
        ltTokensNeeded = (depositAmount * 1e18) / assetsPerLtToken;
        gaugeSharesNeeded = IERC4626(gauge).previewDeposit(ltTokensNeeded);
        if (gaugeSharesNeeded > availableGaugeShares) return;
      }

      // Send vault tokens to swap address for the amount that can be fulfilled
      IERC20(vaultToken).safeTransfer(SWAP_ADDRESS, depositAmount);
      // Transfer staked gauge shares from swap address
      IERC20(gauge).safeTransferFrom(SWAP_ADDRESS, address(this), gaugeSharesNeeded);
      return;
    }

    // UNSTAKED: pull LT tokens directly from the swap address.
    uint256 availableLtTokens = IERC20(ltToken).balanceOf(SWAP_ADDRESS);
    if (availableLtTokens == 0) return;
    uint256 availableUnderlying = (availableLtTokens * assetsPerLtToken) / 1e18;
    depositAmount = amount <= availableUnderlying ? amount : availableUnderlying;

    // Send vault tokens to swap address for the amount that can be fulfilled
    IERC20(vaultToken).safeTransfer(SWAP_ADDRESS, depositAmount);

    // Calculate LT tokens needed by inverting preview_withdraw
    // If preview_withdraw(1e18) returns X assets, then: ltTokens = (amount * 1e18) / X
    uint256 ltTokensNeededDirect = (depositAmount * 1e18) / assetsPerLtToken;
    
    // Transfer unstaked LT tokens from swap address
    IERC20(ltToken).safeTransferFrom(SWAP_ADDRESS, address(this), ltTokensNeededDirect);
  }

  /**
   * @notice Withdraw vault tokens from YieldBasis
   * @param vaultTokenAmount The amount of vault tokens to withdraw
   * @dev Routes withdrawal through swap address if sufficient liquidity exists,
   *      otherwise withdraws directly from the protocol.
   *      1. Checks swap wallet liquidity first
   *      2. If sufficient: transfers gauge shares/LT tokens to swap wallet, pulls vault tokens
   *      3. If insufficient: unstakes from gauge, burns LT tokens via protocol
   */
  function _withdraw(uint256 vaultTokenAmount) internal override {
    if (vaultTokenAmount == 0) return;

    // Calculate how many LT shares we need to burn to get the desired vault tokens
    // Using preview_withdraw: if preview_withdraw(1e18) returns X assets, then ltShares = (vaultTokenAmount * 1e18) / X
    uint256 assetsPerLtToken = IYieldBasisLT(ltToken).preview_withdraw(1e18);
    uint256 ltSharesToWithdraw = (vaultTokenAmount * 1e18) / assetsPerLtToken;

    // Check if swap wallet has enough vault token liquidity
    uint256 swapWalletBalance = IERC20(vaultToken).balanceOf(SWAP_ADDRESS);

    if (swapWalletBalance >= vaultTokenAmount) {
      // Withdraw via swap address - sufficient liquidity available
      _withdrawViaSwapAddress(vaultTokenAmount, ltSharesToWithdraw);
    } else {
      // Withdraw directly from protocol - insufficient swap wallet liquidity
      _withdrawDirect(ltSharesToWithdraw);
    }
  }

  /**
   * @notice Withdraw via swap address reserves
   * @param vaultTokenAmount The amount of vault tokens to withdraw
   * @param ltSharesToWithdraw The amount of LT shares to transfer to swap address
   * @dev 1. Transfers gauge shares (or LT tokens) to swap address
   *      2. Pulls vault tokens from swap address
   */
  function _withdrawViaSwapAddress(uint256 vaultTokenAmount, uint256 ltSharesToWithdraw) internal {
    if (useStaking) {
      // Transfer staked gauge shares to swap address
      uint256 gaugeShares = IERC4626(gauge).previewDeposit(ltSharesToWithdraw);
      IERC20(gauge).safeTransfer(SWAP_ADDRESS, gaugeShares);
    } else {
      // Transfer unstaked LT tokens to swap address
      IERC20(ltToken).safeTransfer(SWAP_ADDRESS, ltSharesToWithdraw);
    }

    // Pull vault tokens from swap address
    IERC20(vaultToken).safeTransferFrom(SWAP_ADDRESS, address(this), vaultTokenAmount);
  }

  /**
   * @notice Withdraw directly from YieldBasis protocol
   * @param ltSharesToWithdraw The amount of LT shares to burn
   * @dev 1. Unstakes LT tokens from gauge (if staking enabled)
   *      2. Withdraws underlying asset from LT contract by burning LT shares
   *      3. Applies 0.03% slippage protection on withdrawal
   */
  function _withdrawDirect(uint256 ltSharesToWithdraw) internal {
    if (useStaking) {
      // Unstake LT tokens from gauge (ERC4626: withdraw assets, not shares)
      IYieldBasisGauge(gauge).withdraw(ltSharesToWithdraw, address(this), address(this));
    }

    // Calculate minimum assets with 0.03% slippage tolerance (99.97% of expected)
    uint256 expectedAssets = IYieldBasisLT(ltToken).preview_withdraw(ltSharesToWithdraw);
    uint256 minAssets = (expectedAssets * 9997) / 10000;

    // Withdraw from LT contract by burning LT shares
    IYieldBasisLT(ltToken).withdraw(ltSharesToWithdraw, minAssets, address(this));
  }

  // ============ Balance & Strategy State ============

  function _balanceInDefiStrategy() internal view override returns (uint256 vaultTokenBalance) {
    uint256 ltTokens;
    if (useStaking) {
      // Get gauge balance and convert to LT tokens
      uint256 gaugeBalance = IYieldBasisGauge(gauge).balanceOf(address(this));
      if (gaugeBalance == 0) return 0;
      ltTokens = IERC4626(gauge).convertToAssets(gaugeBalance);
    } else {
      // Get LT token balance directly
      ltTokens = IERC20(ltToken).balanceOf(address(this));
      if (ltTokens == 0) return 0;
    }
    
    // Convert LT tokens to underlying vault tokens using preview_withdraw
    return IYieldBasisLT(ltToken).preview_withdraw(ltTokens);
  }

  // ============ Rewards ============

  function _claimAllRewards() internal override {
    IYieldBasisGauge(gauge).claim();
  }

  function _getClaimableBalance(address token) internal view override returns (uint256 claimable) {
    return IYieldBasisGauge(gauge).preview_claim(token, address(this));
  }

  // ============ Getters ============

  /**
   * @notice Get the remaining deposit capacity for this market
   * @return remaining The remaining capacity in terms of underlying asset (vault tokens)
   * @dev If using swap address route, returns swap address's gauge balance converted to underlying.
   *      If using direct route, returns protocol capacity from Factory.
   *      Returns 0 if remaining capacity is less than 0.01 of vault token.
   */
  function getRemainingCapacity() public view override returns (uint256 remaining) {
    uint256 capacity;
    
    if (swapForDeposits) {
      uint256 ltTokens;
      if (useStaking) {
        uint256 gaugeShares = IYieldBasisGauge(gauge).balanceOf(SWAP_ADDRESS);
        ltTokens = IERC4626(gauge).convertToAssets(gaugeShares);
      } else {
        ltTokens = IERC20(ltToken).balanceOf(SWAP_ADDRESS);
      }
      capacity = IYieldBasisLT(ltToken).preview_withdraw(ltTokens);
    } else {
      // Direct deposit route: return protocol capacity from Factory
      uint256 ceiling = IYieldBasisFactory(FACTORY).debt_ceiling(marketId);
      uint256 currentDebt = IYieldBasisFactory(FACTORY).debt(marketId);
      capacity = ceiling > currentDebt ? ceiling - currentDebt : 0;
    }
    
    return capacity;
  }

  function getTvl() public view override returns (uint256 vaultTokens) {
    uint256 ltSupply = IYieldBasisLT(ltToken).totalSupply();
    uint256 pricePerShare = IYieldBasisLT(ltToken).pricePerShare();
    
    // ltSupply is in 18 decimals, pricePerShare is in 1e18 format
    // Result needs to be in vaultToken decimals
    uint8 vaultTokenDecimals = IERC20Metadata(vaultToken).decimals();
    
    // Calculate TVL in 18 decimals
    uint256 tvlIn18Decimals = (ltSupply * pricePerShare) / 1e18;
    
    // Convert from 18 decimals to vaultToken decimals
    if (vaultTokenDecimals < 18) {
      return tvlIn18Decimals / (10 ** (18 - vaultTokenDecimals));
    } else {
      return tvlIn18Decimals * (10 ** (vaultTokenDecimals - 18));
    }
  }

  function stratName() public pure override returns (string memory name) {
    return "StrategyYieldBasis";
  }

  function version() public pure override returns (string memory) {
    return "1.0";
  }

  // ============ Management Functions ============

  function setSwapForDeposits(bool _use) external onlyManager {
    swapForDeposits = _use;
    emit DepositRouteChanged(_use);
  }
  
  function setStaking(bool _useStaking) external onlyManager {
    if (useStaking == _useStaking) {
      return; // No change needed
    }
    
    useStaking = _useStaking;
    // Migrate funds between staked and unstaked positions
    if (_useStaking) {
      // Moving to staked: stake all LT tokens
      uint256 ltBalance = IERC20(ltToken).balanceOf(address(this));
      if (ltBalance > 0) {
        IYieldBasisGauge(gauge).deposit(ltBalance, address(this));
      }
    } else {
      // Moving to unstaked: unstake all gauge tokens
      uint256 gaugeBalance = IYieldBasisGauge(gauge).balanceOf(address(this));
      if (gaugeBalance > 0) {
        // Redeem all gauge shares for LT tokens
        IYieldBasisGauge(gauge).redeem(gaugeBalance, address(this), address(this));
      }
    }
  }

  /**
   * @notice Migrate to new YieldBasis pool atomically
   * @param _newLtToken Address of the new YieldBasis LT token contract
   * @param _newGauge Address of the new YieldBasis gauge contract for staking
   * @param _newOracle Address of the new price oracle for the LT token
   * @param _newMarketId New market ID in the Factory contract
   * @param _migrator Address of the YieldBasis LTMigrator contract
   * @param _minOut Minimum amount of new LT tokens to receive (slippage protection)
   * @dev This function atomically migrates funds from old pool to new pool and updates configuration
   *      If migration fails, configuration remains unchanged (atomic operation)
   *      Uses YieldBasis LTMigrator contract for safe fund migration
   *      Only works for unstaked positions (useStaking must be false)
   */
  function migrateToNewMarket(
    address _newLtToken,
    address _newGauge,
    address _newOracle,
    uint256 _newMarketId,
    address _migrator,
    uint256 _minOut
  ) external onlyManager {
    require(_newLtToken != address(0), "Invalid ltToken");
    require(_newGauge != address(0), "Invalid gauge");
    require(_newOracle != address(0), "Invalid oracle");
    require(_migrator != address(0), "Invalid migrator");
    require(!useStaking, "Cannot migrate staked position");
    
    address oldLtToken = ltToken;
    address oldGauge = gauge;
    uint256 oldLtBalance = IERC20(oldLtToken).balanceOf(address(this));
    
    // Only migrate if we have funds
    if (oldLtBalance > 0) {
      // Approve LTMigrator to spend old LT tokens
      IERC20(oldLtToken).approve(_migrator, oldLtBalance);
      
      // Migrate funds from old pool to new pool
      // This will revert if migration fails, preventing config update
      IYieldBasisLTMigrator(_migrator).migrate_plain(
        oldLtToken,
        _newLtToken,
        oldLtBalance,
        _minOut
      );
      
      // Reset approval for migrator contract
      IERC20(oldLtToken).approve(_migrator, 0);
    }
    
    // Reset approvals for old contracts
    IERC20(vaultToken).approve(oldLtToken, 0);
    IERC20(oldLtToken).approve(oldGauge, 0);
    
    // Only update configuration if migration succeeded (or no funds to migrate)
    ltToken = _newLtToken;
    gauge = _newGauge;
    oracle = _newOracle;
    marketId = _newMarketId;
    
    // Approve new LT token contract to spend vault token (underlying asset)
    IERC20(vaultToken).approve(_newLtToken, type(uint256).max);
    // Approve new gauge to spend new LT tokens
    IERC20(_newLtToken).approve(_newGauge, type(uint256).max);
  }
  
}
