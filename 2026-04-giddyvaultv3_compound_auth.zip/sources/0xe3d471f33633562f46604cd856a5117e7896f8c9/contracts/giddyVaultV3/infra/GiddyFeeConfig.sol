// SPDX-License-Identifier: UNLICENSED

pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "./GiddyStrategyFactory.sol";

/**
 * @title GiddyFeeConfig
 * @notice Centralized performance fee management for Giddy V3 vaults
 * @dev Manages performance fees for all vaults on a network with hierarchical fee structure
 *      Priority: vault-specific → category-specific → default
 */
contract GiddyFeeConfig {
    using SafeERC20 for IERC20;

    // ============ Constants ============

    /// @notice Maximum performance fee (50% in basis points)
    uint256 public constant MAX_PERFORMANCE_FEE = 5000;

    // ============ Structs ============

    /**
     * @dev Struct containing fee configuration for a vault
     * @param performanceFee Performance fee in basis points (on gains)
     */
    struct FeeConfig {
        uint256 performanceFee;     // Basis points (e.g., 2000 = 20%)
    }

    // ============ Errors ============

    error NotManager();

    // ============ State Variables ============

    /// @notice Reference to the strategy factory
    GiddyStrategyFactory public strategyFactory;

    /// @notice Default performance fee for all vaults (in basis points)
    uint256 public defaultPerformanceFee;

    /// @notice Address that receives all performance fees
    address public feeRecipient;

    /// @notice Mapping of vault addresses to their custom fee configurations
    mapping(address => FeeConfig) public vaultFeeConfigs;

    /// @notice Mapping to track which vaults have custom configurations
    mapping(address => bool) public hasVaultCustomFee;

    /// @notice Mapping of category names to their custom fee configurations
    mapping(string => FeeConfig) public categoryFeeConfigs;

    // ============ Modifiers ============

    /// @notice Throws if called by any account other than the strategy factory owner or a keeper
    modifier onlyManager() {
        if (!strategyFactory.isKeeper(msg.sender)) revert NotManager();
        _;
    }

    // ============ Initialization ============

    /**
     * @notice Constructor for the configuration contract
     * @param _defaultPerformanceFee Default performance fee in basis points
     * @param _feeRecipient Fee recipient address for all vaults
     * @param _strategyFactory Address of the strategy factory
     */
    constructor(
        uint256 _defaultPerformanceFee,
        address _feeRecipient,
        address _strategyFactory
    ) {
        require(_strategyFactory != address(0), "Invalid strategy factory address");
        require(_defaultPerformanceFee <= MAX_PERFORMANCE_FEE, "Invalid performance fee");
        require(_feeRecipient != address(0), "Invalid fee recipient");

        defaultPerformanceFee = _defaultPerformanceFee;
        feeRecipient = _feeRecipient;
        strategyFactory = GiddyStrategyFactory(_strategyFactory);
    }

    // ============ Vault-Specific Fee Management ============

    /**
     * @notice Set performance fee for a specific vault
     * @param vault Address of the vault
     * @param performanceFee Performance fee in basis points
     */
    function setVaultPerformanceFee(
        address vault,
        uint256 performanceFee
    ) external onlyManager {
        require(vault != address(0), "Invalid vault address");
        require(performanceFee <= MAX_PERFORMANCE_FEE, "Invalid performance fee");

        vaultFeeConfigs[vault] = FeeConfig({
            performanceFee: performanceFee
        });
        hasVaultCustomFee[vault] = true;
    }

    /**
     * @notice Remove vault-specific fee configuration (will use category or default)
     * @param vault Address of the vault
     */
    function removeVaultFeeConfig(address vault) external onlyManager {
        require(vault != address(0), "Invalid vault address");
        require(hasVaultCustomFee[vault], "Vault has no custom fee");

        delete vaultFeeConfigs[vault];
        hasVaultCustomFee[vault] = false;
    }

    // ============ Category-Specific Fee Management ============

    /**
     * @notice Set performance fee for a specific category
     * @param category Category name (e.g., "convex", "curve", "compound")
     * @param performanceFee Performance fee in basis points
     */
    function setCategoryPerformanceFee(
        string calldata category,
        uint256 performanceFee
    ) external onlyManager {
        require(bytes(category).length > 0, "Invalid category");
        require(performanceFee <= MAX_PERFORMANCE_FEE, "Invalid performance fee");

        categoryFeeConfigs[category] = FeeConfig({
            performanceFee: performanceFee
        });
    }

    /**
     * @notice Remove category-specific fee configuration (will use default)
     * @param category Category name
     */
    function removeCategoryPerformanceFee(string calldata category) external onlyManager {
        require(bytes(category).length > 0, "Invalid category");
        require(categoryFeeConfigs[category].performanceFee > 0, "Category has no custom fee");

        delete categoryFeeConfigs[category];
    }

    // ============ Global Fee Management ============

    /**
     * @notice Update the default performance fee for all vaults
     * @param newDefaultFee New default performance fee in basis points
     */
    function setDefaultPerformanceFee(uint256 newDefaultFee) external onlyManager {
        require(newDefaultFee <= MAX_PERFORMANCE_FEE, "Invalid performance fee");
        defaultPerformanceFee = newDefaultFee;
    }

    /**
     * @notice Update the fee recipient for all vaults
     * @param newFeeRecipient New fee recipient address
     */
    function setFeeRecipient(address newFeeRecipient) external onlyManager {
        require(newFeeRecipient != address(0), "Invalid fee recipient");
        feeRecipient = newFeeRecipient;
    }

    // ============ Fee Query Functions ============

    /**
     * @notice Get performance fee for a vault with hierarchical logic
     * Priority: vault-specific → category-specific → default
     * @param vault Address of the vault
     * @param category Category of the vault
     * @return performanceFee Performance fee in basis points
     */
    function getPerformanceFee(
        address vault,
        string calldata category
    ) external view returns (uint256 performanceFee) {
        // Optimized hierarchical lookup with single return
        return hasVaultCustomFee[vault]
            ? vaultFeeConfigs[vault].performanceFee
            : (categoryFeeConfigs[category].performanceFee > 0
                ? categoryFeeConfigs[category].performanceFee
                : defaultPerformanceFee);
    }

    /**
     * @notice Get vault-specific performance fee
     * @param vault Address of the vault
     * @return hasCustomFee Whether the vault has custom performance fee
     * @return performanceFee Performance fee in basis points (if custom)
     */
    function getVaultPerformanceFee(address vault) external view returns (bool hasCustomFee, uint256 performanceFee) {
        hasCustomFee = hasVaultCustomFee[vault];
        performanceFee = hasCustomFee ? vaultFeeConfigs[vault].performanceFee : 0;
    }

    /**
     * @notice Get category-specific performance fee
     * @param category Category name
     * @return hasCustomFee Whether the category has custom performance fee
     * @return performanceFee Performance fee in basis points (if custom)
     */
    function getCategoryPerformanceFee(string calldata category) external view returns (bool hasCustomFee, uint256 performanceFee) {
        performanceFee = categoryFeeConfigs[category].performanceFee;
        hasCustomFee = performanceFee > 0;
    }

    // ============ Emergency Functions ============

    /**
     * @notice Emergency function to rescue stuck tokens
     * @param token Address of the token to rescue
     * @param to Address to send the tokens to
     * @param amount Amount of tokens to rescue
     */
    function rescueToken(
        address token,
        address to,
        uint256 amount
    ) external onlyManager {
        require(token != address(0), "Invalid token address");
        require(to != address(0), "Invalid recipient address");
        require(amount > 0, "Invalid amount");

        IERC20(token).safeTransfer(to, amount);
    }
}
