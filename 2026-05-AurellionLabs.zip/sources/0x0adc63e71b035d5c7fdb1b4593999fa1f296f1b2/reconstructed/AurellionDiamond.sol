// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title Aurellion Diamond proxy (RECONSTRUCTED)
/// @notice RECONSTRUCTED for playground debugging from on-chain runtime bytecode
///         at 0x0Adc63e71B035d5c7FDB1B4593999FA1F296f1B2 (226 bytes). Unverified
///         on Arbiscan. EIP-2535-style fallback: loads facet address from the
///         selector→facet mapping slot and DELEGATECALLs into it.
/// @dev Mapping key layout observed on-chain:
///      slot = keccak256(bytes32(selector) . DIAMOND_STORAGE_POSITION)
contract AurellionDiamond {
    /// @dev Diamond storage position used by this deployment (from bytecode).
    bytes32 private constant DIAMOND_STORAGE_POSITION =
        0xc8fcad8db84d3cc18b4c41d551ea0ee66dd599cde068d998e57d5e09332c131c;

    error FunctionDoesNotExist();

    /// @notice Routes every call to the facet registered for msg.sig.
    /// @dev There is no initialize() body in this proxy bytecode. The external
    ///      call `diamond.initialize(owner)` hits this fallback with selector
    ///      0xc4d66de8; the diamond storage maps that selector → SafeOwnable
    ///      facet (0x3CA79C1c…E70f), which DELEGATECALLs into
    ///      SafeOwnable.initialize(address) and re-seizes owner. Step In peels
    ///      through this fallback into that facet body.
    fallback() external payable {
        // Load facet address for this selector from diamond storage.
        address facet;
        bytes32 position = DIAMOND_STORAGE_POSITION;
        assembly {
            mstore(0x00, shr(224, calldataload(0)))
            mstore(0x20, position)
            facet := and(sload(keccak256(0x00, 0x40)), shr(96, not(0)))
        }
        if (facet == address(0)) {
            // "Diamond: Function does not exist"
            revert FunctionDoesNotExist();
        }
        // DELEGATECALL into facet with original calldata — facet runs in this
        // diamond's storage context (owner / initializer slots live here).
        assembly {
            calldatacopy(0, 0, calldatasize())
            let result := delegatecall(gas(), facet, 0, calldatasize(), 0, 0)
            returndatacopy(0, 0, returndatasize())
            switch result
            case 0 { revert(0, returndatasize()) }
            default { return(0, returndatasize()) }
        }
    }

    receive() external payable {}
}
