// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title SafeOwnable facet (RECONSTRUCTED)
/// @notice RECONSTRUCTED for playground debugging from on-chain runtime bytecode
///         at 0x3CA79C1cf29B8d19F7c643bB6E6bc9c49762E70f (1438 bytes). Unverified
///         on Arbiscan. Selectors match the deployed dispatcher:
///           owner() / initialize(address) / transferOwnership / acceptOwnership /
///           renounceOwnership / cancelRenounceOwnership / RENOUNCE_DELAY().
/// @dev Storage layout taken from the bytecode (not guessed):
///   - OpenZeppelin Initializable ERC-7201 slot 0xf0c57e16…6a00
///   - Custom ownership slot   0x31c1f840…ce1
///   - Renounce/pending slot   0x31c1f840…d79
///
/// ROOT CAUSE (SlowMist / ExVul):
///   Ownership was assigned on this diamond WITHOUT bumping the Initializable
///   version (bytes 0–7 of the 0xf0c57e… slot stayed 0). Therefore
///   initialize(address) still succeeds for ANY caller and overwrites owner.
contract SafeOwnableFacet {
    // --- ERC-7201 Initializable (OpenZeppelin) ---------------------------------
    // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.Initializable")) - 1)) & ~bytes32(uint256(0xff))
    bytes32 private constant INITIALIZABLE_STORAGE =
        0xf0c57e16840df040f15088dc2f81fe391c3923bec73e23a9662efc9c229c6a00;

    // --- Custom ownership storage (observed on-chain) --------------------------
    bytes32 private constant OWNER_STORAGE =
        0x31c1f8402397e5b1e3d75f3da7207ce6f54556b27afe723742768c4e4be50ce1;
    bytes32 private constant RENOUNCE_STORAGE =
        0x31c1f8402397e5b1e3d75f3da7207ce6f54556b27afe723742768c4e4be50d79;

    error InvalidInitialization();
    error NotOwner();

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event Initialized(uint64 version);

    /// @notice Current diamond owner (stored under OWNER_STORAGE).
    function owner() public view returns (address result) {
        bytes32 slot = OWNER_STORAGE;
        assembly {
            result := sload(slot)
        }
    }

    /// @notice ONE-SHOT initializer in theory — but only gated by Initializable.
    /// @dev VULNERABLE RE-INIT: if `_initialized` is still 0 (ownership was set
    ///      through a path that never called this initializer), ANY caller can
    ///      re-run this and seize `owner`, then diamondCut malicious facets.
    function initialize(address initialOwner) external {
        // --- Initializable guard (OZ layout at INITIALIZABLE_STORAGE) ----------
        // Layout: uint64 _initialized | bool _initializing in the low bytes.
        bytes32 initSlot = INITIALIZABLE_STORAGE;
        uint64 initialized;
        bool initializing;
        assembly {
            let packed := sload(initSlot)
            initialized := and(packed, 0xffffffffffffffff)
            initializing := and(shr(64, packed), 0xff)
        }

        // OZ-style: allow only when never initialized (or during construction).
        // BUG SURFACE: a live diamond whose owner was set WITHOUT setting
        // _initialized still has initialized == 0 → this check PASSES.
        if (initialized != 0 && !initializing) {
            revert InvalidInitialization();
        }

        // Mark initialized = 1 (version 1), clear initializing.
        assembly {
            let packed := sload(initSlot)
            // clear low 64 bits then OR 1
            packed := or(and(packed, not(0xffffffffffffffff)), 1)
            sstore(initSlot, packed)
        }

        // Transfer ownership to the attacker-supplied address (the exploit).
        _transferOwnership(initialOwner);

        emit Initialized(1);
    }

    function transferOwnership(address newOwner) external {
        _checkOwner();
        // Ownable2Step: set pending owner (simplified for reconstruction)
        bytes32 slot = RENOUNCE_STORAGE;
        assembly {
            sstore(slot, newOwner)
        }
    }

    function acceptOwnership() external {
        // pending owner accepts (simplified)
        address pending;
        bytes32 slot = RENOUNCE_STORAGE;
        assembly {
            pending := sload(slot)
        }
        if (msg.sender != pending) revert NotOwner();
        _transferOwnership(msg.sender);
    }

    function renounceOwnership() external {
        _checkOwner();
        _transferOwnership(address(0));
    }

    function cancelRenounceOwnership() external {
        _checkOwner();
        bytes32 slot = RENOUNCE_STORAGE;
        assembly {
            sstore(slot, 0)
        }
    }

    function RENOUNCE_DELAY() external pure returns (uint256) {
        return 0; // placeholder — exact constant not required for the drain path
    }

    function _checkOwner() internal view {
        if (msg.sender != owner()) revert NotOwner();
    }

    function _transferOwnership(address newOwner) internal {
        address oldOwner = owner();
        bytes32 slot = OWNER_STORAGE;
        assembly {
            sstore(slot, newOwner)
        }
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}
