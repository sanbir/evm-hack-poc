// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title DiamondCut facet (RECONSTRUCTED)
/// @notice RECONSTRUCTED for playground debugging from on-chain runtime bytecode
///         at 0x4415c7a891c2e53015f7A9E3818c366962C0f1C1 (5501 bytes). Unverified
///         on Arbiscan. Error strings match mudgen-style LibDiamond ("LibDiamond: …").
///         Storage positions match this diamond deployment (0xc8fcad8d… family).
/// @dev Entry: diamondCut(FacetCut[],address,bytes) selector 0x1f931c1c.
///      Called via diamond DELEGATECALL so address(this) is the diamond.

interface IDiamondCut {
    enum FacetCutAction { Add, Replace, Remove }
    struct FacetCut {
        address facetAddress;
        FacetCutAction action;
        bytes4[] functionSelectors;
    }
}

library LibDiamond {
    /// @dev Same diamond storage family as AurellionDiamond proxy fallback lookup.
    bytes32 constant DIAMOND_STORAGE_POSITION =
        0xc8fcad8db84d3cc18b4c41d551ea0ee66dd599cde068d998e57d5e09332c131c;
    /// @dev Contract owner slot used by enforceIsContractOwner (observed in bytecode).
    bytes32 constant CONTRACT_OWNER_POSITION =
        0xc8fcad8db84d3cc18b4c41d551ea0ee66dd599cde068d998e57d5e09332c131f;

    struct FacetAddressAndSelectorPosition {
        address facetAddress;
        uint16 selectorPosition;
    }

    struct DiamondStorage {
        // selector → facet
        mapping(bytes4 => FacetAddressAndSelectorPosition) facetAddressAndSelectorPosition;
        bytes4[] selectors;
        mapping(bytes4 => bool) supportedInterfaces;
        address contractOwner;
    }

    function diamondStorage() internal pure returns (DiamondStorage storage ds) {
        bytes32 position = DIAMOND_STORAGE_POSITION;
        assembly { ds.slot := position }
    }

    function enforceIsContractOwner() internal view {
        address owner;
        bytes32 slot = CONTRACT_OWNER_POSITION;
        assembly { owner := sload(slot) }
        require(msg.sender == owner, "LibDiamond: Must be contract owner");
    }

    event DiamondCut(IDiamondCut.FacetCut[] _diamondCut, address _init, bytes _calldata);

    function diamondCut(
        IDiamondCut.FacetCut[] memory _diamondCut,
        address _init,
        bytes memory _calldata
    ) internal {
        for (uint256 i = 0; i < _diamondCut.length; i++) {
            IDiamondCut.FacetCutAction action = _diamondCut[i].action;
            if (action == IDiamondCut.FacetCutAction.Add) {
                addFunctions(_diamondCut[i].facetAddress, _diamondCut[i].functionSelectors);
            } else if (action == IDiamondCut.FacetCutAction.Replace) {
                replaceFunctions(_diamondCut[i].facetAddress, _diamondCut[i].functionSelectors);
            } else if (action == IDiamondCut.FacetCutAction.Remove) {
                removeFunctions(_diamondCut[i].facetAddress, _diamondCut[i].functionSelectors);
            } else {
                revert("LibDiamond: Incorrect FacetCutAction");
            }
        }
        emit DiamondCut(_diamondCut, _init, _calldata);
        initializeDiamondCut(_init, _calldata);
    }

    function addFunctions(address _facetAddress, bytes4[] memory _selectors) internal {
        require(_selectors.length > 0, "LibDiamond: No selectors provided");
        require(_facetAddress != address(0), "LibDiamond: Add facet address is zero");
        // bytecode also checks code size > 0
        DiamondStorage storage ds = diamondStorage();
        for (uint256 i = 0; i < _selectors.length; i++) {
            bytes4 sel = _selectors[i];
            require(ds.facetAddressAndSelectorPosition[sel].facetAddress == address(0),
                "LibDiamond: Selector already exists");
            ds.facetAddressAndSelectorPosition[sel] = FacetAddressAndSelectorPosition({
                facetAddress: _facetAddress,
                selectorPosition: uint16(ds.selectors.length)
            });
            ds.selectors.push(sel);
        }
    }

    function replaceFunctions(address _facetAddress, bytes4[] memory _selectors) internal {
        require(_selectors.length > 0, "LibDiamond: No selectors provided");
        require(_facetAddress != address(0), "LibDiamond: Replace facet address is zero");
        DiamondStorage storage ds = diamondStorage();
        for (uint256 i = 0; i < _selectors.length; i++) {
            bytes4 sel = _selectors[i];
            address oldFacet = ds.facetAddressAndSelectorPosition[sel].facetAddress;
            require(oldFacet != address(0), "LibDiamond: Selector not found");
            require(oldFacet != _facetAddress, "LibDiamond: Replace with same facet");
            ds.facetAddressAndSelectorPosition[sel].facetAddress = _facetAddress;
        }
    }

    function removeFunctions(address _facetAddress, bytes4[] memory _selectors) internal {
        require(_selectors.length > 0, "LibDiamond: No selectors provided");
        DiamondStorage storage ds = diamondStorage();
        for (uint256 i = 0; i < _selectors.length; i++) {
            bytes4 sel = _selectors[i];
            FacetAddressAndSelectorPosition memory old = ds.facetAddressAndSelectorPosition[sel];
            require(old.facetAddress != address(0), "LibDiamond: Selector not found");
            // swap-and-pop selectors array (simplified)
            uint16 pos = old.selectorPosition;
            uint16 last = uint16(ds.selectors.length - 1);
            if (pos != last) {
                bytes4 lastSel = ds.selectors[last];
                ds.selectors[pos] = lastSel;
                ds.facetAddressAndSelectorPosition[lastSel].selectorPosition = pos;
            }
            ds.selectors.pop();
            delete ds.facetAddressAndSelectorPosition[sel];
        }
    }

    function initializeDiamondCut(address _init, bytes memory _calldata) internal {
        if (_init == address(0)) {
            require(_calldata.length == 0, "LibDiamond: _calldata is empty but _init is not address(0)");
            return;
        }
        require(_calldata.length > 0, "LibDiamond: _calldata has data but _init is address(0)");
        (bool ok, bytes memory err) = _init.delegatecall(_calldata);
        if (!ok) {
            if (err.length > 0) {
                assembly { revert(add(err, 32), mload(err)) }
            }
            revert("LibDiamond: _init function failed");
        }
    }
}

contract DiamondCutFacet {
    /// @notice EIP-2535 diamondCut — add/replace/remove facet functions.
    /// @dev Attack path: after re-init the exploit is owner, so enforceIsContractOwner
    ///      passes and Add{pullERC20,sweepERC20} is applied.
    function diamondCut(
        IDiamondCut.FacetCut[] calldata _diamondCut,
        address _init,
        bytes calldata _calldata
    ) external {
        LibDiamond.enforceIsContractOwner();
        LibDiamond.diamondCut(_diamondCut, _init, _calldata);
    }
}
