// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {IHooks} from "v4-core/interfaces/IHooks.sol";
import {PoolKey} from "v4-core/types/PoolKey.sol";
import {Currency} from "v4-core/types/Currency.sol";
import {BalanceDelta, BalanceDeltaLibrary} from "v4-core/types/BalanceDelta.sol";
import {BeforeSwapDelta} from "v4-core/types/BeforeSwapDelta.sol";
import {ModifyLiquidityParams, SwapParams} from "v4-core/types/PoolOperation.sol";
import {Hooks} from "v4-core/libraries/Hooks.sol";
import "./interfaces/ISprayPoints.sol";

/// @notice Swap-only Uniswap v4 hook that accrues BUMS spray points.
/// @dev Address must be CREATE2-mined for BEFORE_INITIALIZE | AFTER_SWAP.
contract BumsSprayHook is IHooks {
    using BalanceDeltaLibrary for BalanceDelta;
    using Hooks for IHooks;

    uint256 public constant POINTS_PER_ETH = 1000;
    uint8 public constant USE_UNWRAP_SURCHARGE = 1;
    uint8 public constant USE_SPRAY_REROLL = 2;

    address public immutable poolManager;
    address public immutable expectedCurrency0;
    address public immutable expectedCurrency1;
    uint24 public immutable expectedFee;
    int24 public immutable expectedTickSpacing;
    ISprayPoints public immutable sprayPoints;

    bool public poolBound;
    bytes32 public boundPoolHash;

    event SprayReported(address indexed beneficiary, bytes32 indexed poolId, uint256 points, int256 ethVolumeAbs);
    event PoolBound(bytes32 indexed poolId, address currency0, address currency1, uint24 fee, int24 tickSpacing);

    modifier onlyPoolManager() {
        require(msg.sender == poolManager, "pm only");
        _;
    }

    constructor(
        address _poolManager,
        address _expectedCurrency0,
        address _expectedCurrency1,
        uint24 _expectedFee,
        int24 _expectedTickSpacing,
        ISprayPoints _sprayPoints
    ) {
        require(_poolManager != address(0), "pm zero");
        require(_expectedCurrency0 < _expectedCurrency1, "currency order");
        require(address(_sprayPoints) != address(0), "spray zero");

        poolManager = _poolManager;
        expectedCurrency0 = _expectedCurrency0;
        expectedCurrency1 = _expectedCurrency1;
        expectedFee = _expectedFee;
        expectedTickSpacing = _expectedTickSpacing;
        sprayPoints = _sprayPoints;

        IHooks(address(this)).validateHookPermissions(
            Hooks.Permissions({
                beforeInitialize: true,
                afterInitialize: false,
                beforeAddLiquidity: false,
                afterAddLiquidity: false,
                beforeRemoveLiquidity: false,
                afterRemoveLiquidity: false,
                beforeSwap: false,
                afterSwap: true,
                beforeDonate: false,
                afterDonate: false,
                beforeSwapReturnDelta: false,
                afterSwapReturnDelta: false,
                afterAddLiquidityReturnDelta: false,
                afterRemoveLiquidityReturnDelta: false
            })
        );
    }

    function beforeInitialize(address, PoolKey calldata key, uint160)
        external
        override
        onlyPoolManager
        returns (bytes4)
    {
        require(!poolBound, "bound");
        require(Currency.unwrap(key.currency0) == expectedCurrency0, "wrong pool");
        require(Currency.unwrap(key.currency1) == expectedCurrency1, "wrong pool");
        require(key.fee == expectedFee, "wrong pool");
        require(key.tickSpacing == expectedTickSpacing, "wrong pool");
        require(address(key.hooks) == address(this), "wrong hook");

        poolBound = true;
        boundPoolHash = keccak256(abi.encode(key));
        emit PoolBound(boundPoolHash, expectedCurrency0, expectedCurrency1, expectedFee, expectedTickSpacing);
        return IHooks.beforeInitialize.selector;
    }

    function afterSwap(
        address sender,
        PoolKey calldata key,
        SwapParams calldata,
        BalanceDelta delta,
        bytes calldata hookData
    ) external override onlyPoolManager returns (bytes4, int128) {
        require(poolBound, "unbound");
        require(keccak256(abi.encode(key)) == boundPoolHash, "wrong pool");

        int128 ethDelta = expectedCurrency0 == address(0) ? delta.amount0() : delta.amount1();
        uint256 ethVolumeAbs = _abs(ethDelta);
        uint256 points = (ethVolumeAbs * POINTS_PER_ETH) / 1 ether;

        if (points > 0) {
            address beneficiary = _beneficiary(sender, hookData);
            sprayPoints.earn(beneficiary, points, boundPoolHash, int256(ethVolumeAbs));
            emit SprayReported(beneficiary, boundPoolHash, points, int256(ethVolumeAbs));
        }

        return (IHooks.afterSwap.selector, 0);
    }

    function _beneficiary(address sender, bytes calldata hookData) internal pure returns (address) {
        if (hookData.length == 32) {
            address decoded = abi.decode(hookData, (address));
            if (decoded != address(0)) return decoded;
        }
        return sender;
    }

    function _abs(int128 value) internal pure returns (uint256) {
        return value < 0 ? uint256(uint128(-value)) : uint256(uint128(value));
    }

    function afterInitialize(address, PoolKey calldata, uint160, int24) external pure override returns (bytes4) {
        revert("unused");
    }

    function beforeAddLiquidity(address, PoolKey calldata, ModifyLiquidityParams calldata, bytes calldata)
        external
        pure
        override
        returns (bytes4)
    {
        revert("unused");
    }

    function afterAddLiquidity(
        address,
        PoolKey calldata,
        ModifyLiquidityParams calldata,
        BalanceDelta,
        BalanceDelta,
        bytes calldata
    ) external pure override returns (bytes4, BalanceDelta) {
        revert("unused");
    }

    function beforeRemoveLiquidity(address, PoolKey calldata, ModifyLiquidityParams calldata, bytes calldata)
        external
        pure
        override
        returns (bytes4)
    {
        revert("unused");
    }

    function afterRemoveLiquidity(
        address,
        PoolKey calldata,
        ModifyLiquidityParams calldata,
        BalanceDelta,
        BalanceDelta,
        bytes calldata
    ) external pure override returns (bytes4, BalanceDelta) {
        revert("unused");
    }

    function beforeSwap(address, PoolKey calldata, SwapParams calldata, bytes calldata)
        external
        pure
        override
        returns (bytes4, BeforeSwapDelta, uint24)
    {
        revert("unused");
    }

    function beforeDonate(address, PoolKey calldata, uint256, uint256, bytes calldata)
        external
        pure
        override
        returns (bytes4)
    {
        revert("unused");
    }

    function afterDonate(address, PoolKey calldata, uint256, uint256, bytes calldata)
        external
        pure
        override
        returns (bytes4)
    {
        revert("unused");
    }
}
