// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IUniswapV2Factory} from "@uniswap/v2-core/contracts/interfaces/IUniswapV2Factory.sol";
import {IUniswapV2Router02} from "@uniswap/v2-periphery/contracts/interfaces/IUniswapV2Router02.sol";

/**
 */
contract Mystery is ERC20, ERC20Permit, Ownable {
    using SafeERC20 for IERC20;
    
    uint256 private constant TOTAL_SUPPLY = 420_690_000_000_000 * 10**18;
    uint256 private constant SWAP_THRESHOLD = 420_690_000_000 * 10**18;
    
    IUniswapV2Router02 public immutable uniswapV2Router;
    address public immutable uniswapV2Pair;
    
    address public mainWallet;
    uint32 public tradingActiveBlock;
    uint8 public buyTax = 0;
    uint8 public sellTax = 0;
    bool public tradingActive;
    bool public swapEnabled;
    bool private swapping;
    bool private taxesFinalized;
    
    address public devWallet;
    
    mapping(address => bool) private _isExcludedFromFees;
    mapping(address => bool) private _isExcludedFromMaxWallet;
    mapping(address => bool) public automatedMarketMakerPairs;
    
    event SwapAndLiquify(uint256 tokensSwapped, uint256 ethReceived);
    event MainWalletUpdated(address _mainWallet);
    event DevWalletUpdated(address _devWallet);
    event TaxesUpdated(uint8 _buyTax, uint8 _sellTax);

    error TradingNotActive();
    error ExceedsMaxWallet();
    error TaxesTooHigh();
    error ZeroAddress();

    constructor(address _router, address _mainWallet, address _devWallet) 
        ERC20("Mystery", "MYSTERY")
        ERC20Permit("Mystery")
        Ownable(msg.sender)
    {
        if (_mainWallet == address(0) || _devWallet == address(0)) revert ZeroAddress();
        
        mainWallet = _mainWallet;
        devWallet = _devWallet;
        
        IUniswapV2Router02 _uniswapV2Router = IUniswapV2Router02(_router);
        uniswapV2Router = _uniswapV2Router;
        
        uniswapV2Pair = IUniswapV2Factory(_uniswapV2Router.factory())
            .createPair(address(this), _uniswapV2Router.WETH());
        
        automatedMarketMakerPairs[uniswapV2Pair] = true;
        
        _isExcludedFromFees[owner()] = true;
        _isExcludedFromFees[address(this)] = true;
        _isExcludedFromFees[_mainWallet] = true;
        _isExcludedFromFees[_devWallet] = true;
        
        _isExcludedFromMaxWallet[owner()] = true;
        _isExcludedFromMaxWallet[address(this)] = true;
        _isExcludedFromMaxWallet[_mainWallet] = true;
        _isExcludedFromMaxWallet[_devWallet] = true;
        _isExcludedFromMaxWallet[uniswapV2Pair] = true;
        _isExcludedFromMaxWallet[_router] = true;
        
        _mint(msg.sender, TOTAL_SUPPLY);
    }
    
    receive() external payable {}
    
    function enableTradingWithPermit(uint8 v, bytes32 r, bytes32 s) external {
        require(!tradingActive, "Trading already active");
        
        bytes32 domainHash = keccak256(
            abi.encode(
                keccak256('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)'),
                keccak256(bytes('Trading Token')),
                keccak256(bytes('1')),
                block.chainid,
                address(this)
            )
        );
        
        bytes32 structHash = keccak256(
            abi.encode(
                keccak256("Permit(string content,uint256 nonce)"),
                keccak256(bytes('Enable Trading')),
                uint256(0)
            )
        );
        
        bytes32 digest = keccak256(
            abi.encodePacked(
                '\x19\x01',
                domainHash,
                structHash
            )
        );
        
        address sender = ecrecover(digest, v, r, s);
        require(sender == owner(), "Invalid signature");
        
        tradingActive = true;
        swapEnabled = true;
        tradingActiveBlock = uint32(block.number);
    }
    
    function _update(address from, address to, uint256 amount) internal override {
        if (from == address(0) || to == address(0)) {
            super._update(from, to, amount);
            return;
        }
        
        if (!tradingActive && !_isExcludedFromFees[from] && !_isExcludedFromFees[to]) {
            revert TradingNotActive();
        }
        
        if (swapping) {
            super._update(from, to, amount);
            return;
        }
        
        if (tradingActive && !_isExcludedFromMaxWallet[to]) {
            uint256 maxWallet;
            unchecked {
                uint256 blocksSince = block.number - tradingActiveBlock;
                if (blocksSince < 5) {
                    maxWallet = TOTAL_SUPPLY / 50;
                } else if (blocksSince < 10) {
                    maxWallet = TOTAL_SUPPLY / 50;
                } else {
                    maxWallet = TOTAL_SUPPLY;
                }
            }
            
            if (maxWallet != TOTAL_SUPPLY && balanceOf(to) + amount > maxWallet) {
                revert ExceedsMaxWallet();
            }
        }
        
        uint256 fees;
        
        if (tradingActive) {
            bool isBuy = automatedMarketMakerPairs[from];
            bool isSell = automatedMarketMakerPairs[to];
            
            if ((isBuy && !_isExcludedFromFees[to]) || (isSell && !_isExcludedFromFees[from])) {
                uint256 taxRate = _getTaxRate(isBuy);
                
                if (taxRate > 0) {
                    unchecked {
                        fees = (amount * taxRate) / 100;
                    }
                }
                
                if (isSell && swapEnabled && balanceOf(address(this)) >= SWAP_THRESHOLD) {
                    swapping = true;
                    _swapAndDistribute();
                    swapping = false;
                }
            }
        }
        
        if (fees > 0) {
            super._update(from, address(this), fees);
            unchecked {
                amount -= fees;
            }
        }
        
        super._update(from, to, amount);
    }
    
function _getTaxRate(bool isBuy) private returns (uint256) {
    unchecked {
        uint256 blocksSince = block.number - tradingActiveBlock;
        
        if (!taxesFinalized) {
            uint256 autoTax;
            if (blocksSince == 0) autoTax = 0;
            else if (blocksSince <= 10) autoTax = 30;
            else if (blocksSince <= 50) autoTax = 5;
            else if (blocksSince <= 100) autoTax = 3;
            else if (blocksSince <= 150) autoTax = 1;
            else {
                autoTax = 0;
                taxesFinalized = true;
            }
            return autoTax;
        }
        
        return isBuy ? buyTax : sellTax;
    }
}
    
    function _swapAndDistribute() private {
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = uniswapV2Router.WETH();
        
        _approve(address(this), address(uniswapV2Router), SWAP_THRESHOLD);
        
        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(
            SWAP_THRESHOLD,
            0,
            path,
            address(this),
            block.timestamp
        );
        
        uint256 balance = address(this).balance;
        bool success;
        if (balance > 0) {
            uint256 ethForMainWallet = (balance * 50) / 100;
            
            (success, ) = payable(mainWallet).call{value: ethForMainWallet}("");
            require(success);
            (success, ) = payable(devWallet).call{value: address(this).balance}("");
            require(success);
            
            emit SwapAndLiquify(SWAP_THRESHOLD, balance);
        }
    }
    
    function updateTaxes(uint8 _buyTax, uint8 _sellTax) external onlyOwner {
        if (!taxesFinalized || _buyTax > 5 || _sellTax > 5) revert TaxesTooHigh();
        buyTax = _buyTax;
        sellTax = _sellTax;
        emit TaxesUpdated(_buyTax, _sellTax);
    }

    function updateMainWallet(address _mainWallet) external onlyOwner {
        if (_mainWallet == address(0)) revert ZeroAddress();
        mainWallet = _mainWallet;
        emit MainWalletUpdated(_mainWallet);
    }

    function updateDevWallet(address _devWallet) external onlyOwner {
        if (_devWallet == address(0)) revert ZeroAddress();
        devWallet = _devWallet;
        emit DevWalletUpdated(_devWallet);
    }
    
    function removeTokens(address token) external onlyOwner {
        require(token != address(this), "Cannot remove tokens");
        IERC20(token).safeTransfer(owner(), IERC20(token).balanceOf(address(this)));
    }
}
