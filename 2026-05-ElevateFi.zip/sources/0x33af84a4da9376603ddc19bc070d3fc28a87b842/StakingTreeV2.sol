/*


███████ ███████ ██         ███    ██ ███████ ████████ ██     ██  ██████  ██████  ██   ██ 
██      ██      ██         ████   ██ ██         ██    ██     ██ ██    ██ ██   ██ ██  ██  
█████   █████   ██         ██ ██  ██ █████      ██    ██  █  ██ ██    ██ ██████  █████   
██      ██      ██         ██  ██ ██ ██         ██    ██ ███ ██ ██    ██ ██   ██ ██  ██  
███████ ██      ██         ██   ████ ███████    ██     ███ ███   ██████  ██   ██ ██   ██ 
                                                                                         
                                                                                         
*/
// SPDX-License-Identifier: MIT
// Website:  https://elevatefi.io

pragma solidity 0.8.30;

/// @title StakingTree V2
/// @notice Your MLM referrer tree with the "upline must already be registered" rule.
/// @dev No constructor; use initialize(). Includes one-time seeding + hard seal (admin=0).
contract StakingTreeV2 {
    // --- storage ---
    mapping(address => address) public referrer;
    mapping(address => address[]) public directReferrals;

    // one-time initializer + seeding guard
    bool private _initialized;
    address public admin; // only used for seeding; will be set to address(0) by seal()

    event UserRegistration(address indexed user, address indexed upline);
    event Sealed();

    // --- modifiers ---
    modifier initializer() {
        require(!_initialized, "Already initialized");
        _initialized = true;
        _;
    }

    modifier onlyAdmin() {
        require(msg.sender == admin, "Not admin");
        _;
    }

    // --- init / admin-only bootstrap ---
    /// @notice Initialize the logic  and set a bootstrap admin.
    function initialize(address admin_) external initializer {
        require(admin_ != address(0), "Admin zero");
        admin = admin_;
    }

    /// @notice Seed initial relationships (bypasses the "upline registered" check).
    /// @dev Call in batches; each user must be unset, arrays must be same length.
    function adminSeed(address[] calldata users, address[] calldata uplines) external onlyAdmin {
        require(users.length == uplines.length, "Length mismatch");
        unchecked {
            for (uint256 i = 0; i < users.length; ++i) {
                address user = users[i];
                address upline = uplines[i];
                require(user != address(0) && upline != user, "Bad pair");
                require(referrer[user] == address(0), "Already set");
                referrer[user] = upline;
                directReferrals[upline].push(user);
                emit UserRegistration(user, upline);
            }
        }
    }

    /// @notice Irreversibly drop admin after seeding.
    function seal() external onlyAdmin {
        admin = address(0);
        emit Sealed();
    }

    /// @notice Register your referrer (upline). Can only be set once.
    /// @dev Reverts if the caller already has a referrer, or if `upline` equals the caller.
    /// This function does not enforce nonzero `upline`; using the zero address is allowed
    /// only if your app flow intends to represent “no upline”.
    /// @param upline The address of your referrer.
    function registerReferrer(address upline) external {
        require(referrer[msg.sender] == address(0), "Referrer set");
        require(upline != msg.sender, "Cannot refer self");

        // RULE: upline must already be registered (no roots allowed).
        require(referrer[upline] != address(0), "Upline must be registered");

        referrer[msg.sender] = upline;
        
        // If zero upline is allowed but you don't want to track 0's children, guard this push:
        if (upline != address(0)) {
            directReferrals[upline].push(msg.sender);
        }

        emit UserRegistration(msg.sender, upline);
    }

    /// @notice Returns the referrer (upline) for a given `user`.
    /// @param user The account to query.
    /// @return The recorded upline address, or the zero address if none.
    function getReferrer(address user) external view returns (address) {
        return referrer[user];
    }

    /// @notice Returns the list of direct downlines for `user`.
    /// @param user The upline whose direct referrals will be returned.
    /// @return An array of addresses directly referred by `user` (may be empty).
    function getDirectDownlines(address user) external view returns (address[] memory) {
        return directReferrals[user];
    }

    /// @notice Returns the number of direct downlines for `user`.
    /// @param user The upline whose direct referral count will be returned.
    /// @return The length of the direct downlines array.
    function getDirectDownlinesTotal(address user) external view returns (uint256) {
        return directReferrals[user].length;
    }
}