// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

// ┌─────────────────────────────────────────────────────────────────────────┐
// │  $HEIST — Dr. Heisenberg                                                │
// │                                                                         │
// │  Website : https://heisenberg.fyi                                       │
// │  X       : https://x.com/heisenbergllc                                  │
// │                                                                         │
// │  Any other contract claiming to be the official $HEIST token is a fake. │
// │  Always verify the deployed address against the sources above.          │
// └─────────────────────────────────────────────────────────────────────────┘

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @title HeistToken
/// @author Dr. Heisenberg
/// @custom:website https://heisenberg.fyi
/// @custom:x https://x.com/heisenbergllc
/// @notice The fixed-supply $HEIST ERC-20. Total supply (91,111 * 1e18) is minted to the deployer at construction.
/// @dev Standard OpenZeppelin ERC-20. No mint/burn entry points after construction; supply only changes via
/// @dev users sending tokens to the dead address (e.g., the hook's buy-and-burn flow).
contract HeistToken is ERC20 {
    /// @notice Mints the entire fixed supply to `recipient`.
    /// @param name_ Token name (e.g., "Heist").
    /// @param symbol_ Token symbol (e.g., "HEIST").
    /// @param totalSupplyWhole Whole-token supply, will be scaled by 10**decimals().
    /// @param recipient Address to receive the entire initial supply.
    constructor(string memory name_, string memory symbol_, uint256 totalSupplyWhole, address recipient)
        ERC20(name_, symbol_)
    {
        _mint(recipient, totalSupplyWhole * (10 ** decimals()));
    }
}
