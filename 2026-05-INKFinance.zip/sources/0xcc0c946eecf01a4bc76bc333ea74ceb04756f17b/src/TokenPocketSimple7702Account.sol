// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import "../lib/account-abstraction/contracts/accounts/Simple7702Account.sol";

contract TokenPocketSimple7702Account is Simple7702Account {

    event ExecuteFailures(uint256 indexed index);

    function executeBatchAndSkipFailures(Call[] calldata calls) virtual external {
        _requireForExecute();

        uint256 callsLength = calls.length;
        for (uint256 i = 0; i < callsLength; i++) {
            Call calldata call = calls[i];
            bool success = Exec.call(call.target, call.value, call.data, gasleft());
            if (!success) {
                emit ExecuteFailures(i);
            }
        }
    }
}