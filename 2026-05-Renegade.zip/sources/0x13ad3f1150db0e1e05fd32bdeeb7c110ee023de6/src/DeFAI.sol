// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract DeFAI is ERC20 {
    constructor(address initialAccount) ERC20("AISweatShop", "DeFAI") {
        _mint(initialAccount, 1_000_000_000 ether);
    }
}
