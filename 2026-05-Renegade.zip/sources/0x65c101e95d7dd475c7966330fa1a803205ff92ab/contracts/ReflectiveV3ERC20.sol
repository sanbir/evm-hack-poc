// SPDX-License-Identifier: GPL-3.0

pragma solidity 0.8.17;

import { ERC20 } from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import { LibCommon } from "./lib/LibCommon.sol";

/// @title ERC20 Token with Extended Reflection Mechanism
/// @notice This contract implements ERC20 standards along with an additional reward feature for token holders
abstract contract ReflectiveV3ERC20 is ERC20 {
  // Constants
  uint256 private constant BPS_DIVISOR = 10_000;
  uint256 public constant MAX_REWARDS_EXCLUSION_LIMIT = 100;

  mapping(address => uint256) private _rOwned;
  mapping(address => uint256) private _tOwned;

  uint256 private constant UINT_256_MAX = type(uint256).max;
  uint256 private _rTotal;
  uint256 private _tFeeTotal;

  uint256 public tFeeBPS;
  bool private immutable isReflective;

  mapping (address => bool) private _isRewardsExcluded;
  address[] public rewardsExcluded;

  // events
  event ExcludedFromRewards(address indexed account);
  event IncludedInRewards(address indexed account);

  // custom errors
  error TokenIsNotReflective();
  error TotalReflectionTooSmall();
  error ZeroTransferError();
  error BurningNotEnabled();
  error ERC20InsufficientBalance(
    address recipient,
    uint256 fromBalance,
    uint256 balance
  );
  error AlreadyExcludedFromRewards();
  error AlreadyIncludedInRewards();
  error ReachedMaxRewardExclusionLimit();

  /// @notice Returns the total supply of the token
  /// @return The total supply of the token
  function _tTotal() public view virtual returns (uint256) {
    return totalSupply();
  }

  /// @notice Constructor to initialize the ReflectiveV2ERC20 token
  /// @param name_ The name of the token
  /// @param symbol_ The symbol of the token
  /// @param tokenOwner The address of the token owner
  /// @param totalSupply_ The initial total supply of the token
  /// @param decimalsToSet The number of decimal places for the token
  /// @param tFeeBPS_ The reflection fee in basis points
  /// @param isReflective_ Indicates if the token is reflective
  constructor(
    string memory name_,
    string memory symbol_,
    address tokenOwner,
    uint256 totalSupply_,
    uint8 decimalsToSet,
    uint256 tFeeBPS_,
    bool isReflective_
  ) ERC20(name_, symbol_) {
    if (totalSupply_ != 0) {
      super._mint(tokenOwner, totalSupply_ * 10 ** decimalsToSet);
      _rTotal = (UINT_256_MAX - (UINT_256_MAX % totalSupply_));
    }

    _rOwned[tokenOwner] = _rTotal;
    tFeeBPS = tFeeBPS_;
    isReflective = isReflective_;
  }

  /// @notice Returns the balance of tokens for a specific address
  /// @param account The address to query the balance of
  /// @return The balance of tokens
  function balanceOf(address account) public view override returns (uint256) {
    if (isReflective) {
      if (_isRewardsExcluded[account]) return _tOwned[account];

      return tokenFromReflection(_rOwned[account]);
    } else {
      return super.balanceOf(account);
    }
  }

  /// @notice Transfers tokens from one account to another
  /// @param from The address to transfer tokens from
  /// @param to The address to transfer tokens to
  /// @param value The amount of tokens to transfer
  /// @return A boolean indicating success
  function transferFrom(
    address from,
    address to,
    uint256 value
  ) public virtual override returns (bool) {
    address spender = super._msgSender();
    _spendAllowance(from, spender, value);
    _transfer(from, to, value);
    return true;
  }

  /// @notice Transfers tokens to a specified address
  /// @param to The address to transfer tokens to
  /// @param value The amount of tokens to transfer
  /// @return A boolean indicating success
  function transfer(
    address to,
    uint256 value
  ) public virtual override returns (bool) {
    address owner = super._msgSender();
    _transfer(owner, to, value);
    return true;
  }

  // override internal OZ standard ERC20 functions related to transfer

  /// @notice Internal function to transfer tokens from one account to another
  /// @param from The address to transfer tokens from
  /// @param to The address to transfer tokens to
  /// @param amount The amount of tokens to transfer
  function _transfer(
    address from,
    address to,
    uint256 amount
  ) internal override {
    if (isReflective) {
      LibCommon.validateAddress(from);
      LibCommon.validateAddress(to);
      if (amount == 0) {
        revert ZeroTransferError();
      }

      if (_isRewardsExcluded[from] && !_isRewardsExcluded[to]) {
          _transferFromExcluded(from, to, amount);
      } else if (!_isRewardsExcluded[from] && _isRewardsExcluded[to]) {
          _transferToExcluded(from, to, amount);
      } else if (!_isRewardsExcluded[from] && !_isRewardsExcluded[to]) {
          _transferStandard(from, to, amount);
      } else if (_isRewardsExcluded[from] && _isRewardsExcluded[to]) {
          _transferBothExcluded(from, to, amount);
      } else {
          _transferStandard(from, to, amount);
      }
    } else {
      super._transfer(from, to, amount);
    }
  }

  /// @notice Internal function to burn tokens, disallowed if reflection mechanism is used
  /// @param account The account to burn tokens from
  /// @param value The amount of tokens to burn
  function _burn(address account, uint256 value) internal override {
    if (isReflective) {
      revert BurningNotEnabled();
    } else {
      super._burn(account, value);
    }
  }

  /// @notice Sets a new reflection fee
  /// @dev Should only be called by the contract owner
  /// @param _tFeeBPS The reflection fee in basis points
  function _setReflectionFee(uint256 _tFeeBPS) internal {
    if (!isReflective) {
      revert TokenIsNotReflective();
    }

    tFeeBPS = _tFeeBPS;
  }

  /// @notice Calculates the number of tokens from a reflection amount
  /// @param rAmount The reflection amount
  /// @return The number of tokens corresponding to the reflection amount
  function tokenFromReflection(uint256 rAmount) public view returns (uint256) {
    if (rAmount > _rTotal) {
      revert TotalReflectionTooSmall();
    }

    uint256 currentRate = _getRate();
    return rAmount / currentRate;
  }

  /// @notice Excludes an account from receiving rewards
  /// @param account The account to exclude from rewards
  function _excludeFromRewards(
    address account
  ) internal {
    if (!isReflective) {
      revert TokenIsNotReflective();
    }
    if (_isRewardsExcluded[account]) {
      revert AlreadyExcludedFromRewards();
    }
    if (rewardsExcluded.length >= MAX_REWARDS_EXCLUSION_LIMIT) {
      revert ReachedMaxRewardExclusionLimit();
    }

    if(_rOwned[account] > 0) {
        _tOwned[account] = tokenFromReflection(_rOwned[account]);
    }

    _isRewardsExcluded[account] = true;
    rewardsExcluded.push(account);

    emit ExcludedFromRewards(account);
  }

  /// @notice Includes an account to receive rewards
  /// @param account The account to include for rewards
  function _includeInRewards(address account) internal {
    if (!isReflective) {
      revert TokenIsNotReflective();
    }
    if (!_isRewardsExcluded[account]) {
      revert AlreadyIncludedInRewards();
    }

    for (uint256 i = 0; i < rewardsExcluded.length; i++) {
      if (rewardsExcluded[i] == account) {
        rewardsExcluded[i] = rewardsExcluded[rewardsExcluded.length - 1];
        _isRewardsExcluded[account] = false;
        _tOwned[account] = 0;
        rewardsExcluded.pop();
        emit IncludedInRewards(account);

        break;
      }
    }
  }

  /// @notice Transfers a standard amount of tokens with reflection applied
  /// @param sender The address sending the tokens
  /// @param recipient The address receiving the tokens
  /// @param tAmount The total token amount to transfer
  function _transferStandard(
    address sender,
    address recipient,
    uint256 tAmount
  ) private {
    uint256 tFee = calculateFee(tAmount, sender, recipient);
    uint256 tTransferAmount = tAmount - tFee;
    (uint256 rAmount, uint256 rFee, uint256 rTransferAmount) = _getRValues(
      tAmount,
      tFee,
      tTransferAmount
    );

    if (tAmount != 0) {
      _rUpdate(sender, recipient, rAmount, rTransferAmount);

      _reflectFee(rFee, tFee);
      emit Transfer(sender, recipient, tAmount);
    }
  }

  /// @notice Transfers a token amount from an excluded account
  /// @param sender The address sending the tokens
  /// @param recipient The address receiving the tokens
  /// @param tAmount The total token amount to transfer
  function _transferFromExcluded(
    address sender,
    address recipient,
    uint256 tAmount
  ) private {
    uint256 tFee = calculateFee(tAmount, sender, recipient);
    uint256 tTransferAmount = tAmount - tFee;
    (uint256 rAmount, uint256 rFee, uint256 rTransferAmount) = _getRValues(
      tAmount,
      tFee,
      tTransferAmount
    );

    if (tAmount != 0) {
      _rUpdate(sender, recipient, rAmount, rTransferAmount);
      _tOwned[sender] = _tOwned[sender] - (tAmount);

      _reflectFee(rFee, tFee);
      emit Transfer(sender, recipient, tAmount);
    }
  }

  /// @notice Transfers a token amount to an excluded account
  /// @param sender The address sending the tokens
  /// @param recipient The address receiving the tokens
  /// @param tAmount The total token amount to transfer
  function _transferToExcluded(
    address sender,
    address recipient,
    uint256 tAmount
  ) private {
    uint256 tFee = calculateFee(tAmount, sender, recipient);
    uint256 tTransferAmount = tAmount - tFee;
    (uint256 rAmount, uint256 rFee, uint256 rTransferAmount) = _getRValues(
      tAmount,
      tFee,
      tTransferAmount
    );

    if (tAmount != 0) {
      _rUpdate(sender, recipient, rAmount, rTransferAmount);
      _tOwned[recipient] = _tOwned[recipient] + (tTransferAmount);

      _reflectFee(rFee, tFee);
      emit Transfer(sender, recipient, tAmount);
    }
  }

  /// @notice Transfers a token amount between two excluded accounts
  /// @param sender The address sending the tokens
  /// @param recipient The address receiving the tokens
  /// @param tAmount The total token amount to transfer
  function _transferBothExcluded(address sender, address recipient, uint256 tAmount) private {
    uint256 tFee = calculateFee(tAmount, sender, recipient);
    uint256 tTransferAmount = tAmount - tFee;
    (uint256 rAmount, uint256 rFee, uint256 rTransferAmount) = _getRValues(
      tAmount,
      tFee,
      tTransferAmount
    );

    if (tAmount != 0) {
      _rUpdate(sender, recipient, rAmount, rTransferAmount);
      _tOwned[sender] = _tOwned[sender] - (tAmount);
      _tOwned[recipient] = _tOwned[recipient] + (tTransferAmount);

      _reflectFee(rFee, tFee);
      emit Transfer(sender, recipient, tAmount);
    }
  }

  /// @notice Reflects the fee to all holders by deducting it from the total reflections
  /// @param rFee The reflection fee amount
  /// @param tFee The token fee amount
  function _reflectFee(uint256 rFee, uint256 tFee) private {
    _rTotal = _rTotal - rFee;
    _tFeeTotal = _tFeeTotal + tFee;
  }

  /// @notice Calculates the reflection fee from a token amount
  /// @param amount The token amount to calculate the fee from
  /// @param sender The address of the sender
  /// @param recipient The address of the recipient
  /// @return The calculated fee amount
  function calculateFee(uint256 amount, address sender, address recipient) private view returns (uint256) {
    if (_isRewardsExcluded[sender] || _isRewardsExcluded[recipient]) {
      return 0;
    } else {
      return (amount * tFeeBPS) / BPS_DIVISOR;
    }
  }

  /// @notice Transfers tokens without applying reflection fees
  /// @param from The address to transfer tokens from
  /// @param to The address to transfer tokens to
  /// @param tAmount The total token amount to transfer
  function _transferNonReflectedTax(
    address from,
    address to,
    uint256 tAmount
  ) internal {
    if (isReflective) {
      if (tAmount != 0) {
        uint256 currentRate = _getRate();
        uint256 rAmount = tAmount * currentRate;

        _rUpdate(from, to, rAmount, rAmount);
        emit Transfer(from, to, tAmount);
      }
    } else {
      super._transfer(from, to, tAmount);
    }
  }

  /// @notice Retrieves the reflection values from token values
  /// @param tAmount The token amount
  /// @param tFee The token fee amount
  /// @param tTransferAmount The transfer amount
  /// @return The reflection values (rAmount, rFee, rTransferAmount)
  function _getRValues(
    uint256 tAmount,
    uint256 tFee,
    uint256 tTransferAmount
  ) private view returns (uint256, uint256, uint256) {
    uint256 currentRate = _getRate();
    uint256 rAmount = tAmount * currentRate;
    uint256 rFee = tFee * currentRate;
    uint256 rTransferAmount = tTransferAmount * currentRate;

    return (rAmount, rFee, rTransferAmount);
  }

  /// @notice Retrieves the current reflection rate
  /// @return The current reflection rate
  function _getRate() private view returns (uint256) {
    (uint256 rSupply, uint256 tSupply) = _getCurrentSupply();
    return rSupply / tSupply;
  }

  /// @notice Retrieves the current reflection and token supplies
  /// @return The current reflection and token supplies
  function _getCurrentSupply() private view returns (uint256, uint256) {
    return (_rTotal, _tTotal());
  }

  /// @notice Updates the reflection balances for a transfer
  /// @param sender The address sending the tokens
  /// @param recipient The address receiving the tokens
  /// @param rSubAmount The amount to be deducted from the sender
  /// @param rTransferAmount The amount to be added to the recipient
  function _rUpdate(
    address sender,
    address recipient,
    uint256 rSubAmount,
    uint256 rTransferAmount
  ) private {
    uint256 fromBalance = _rOwned[sender];
    if (fromBalance < rSubAmount) {
      revert ERC20InsufficientBalance(recipient, fromBalance, rSubAmount);
    }
    _rOwned[sender] = _rOwned[sender] - rSubAmount;
    _rOwned[recipient] = _rOwned[recipient] + rTransferAmount;
  }
}
