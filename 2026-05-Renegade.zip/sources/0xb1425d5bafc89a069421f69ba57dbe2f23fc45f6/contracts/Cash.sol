// SPDX-License-Identifier: UNLICENSED

pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "./roles/MinterRole.sol";


contract Cash is ERC20Burnable, MinterRole {

    constructor() ERC20("Block Cash", "BKC") {
        _setupRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _mint(msg.sender, 204_0000 * 10 ** decimals());
    }

    function mint(address to, uint amount) public onlyMinter {
        _mint(to, amount);
    }
}