// SPDX-License-Identifier: UNLICENSED

pragma solidity ^0.8.0;

import '@openzeppelin/contracts/access/AccessControl.sol';


abstract contract MinterRole is AccessControl {
    
    bytes32 public constant MINTER = keccak256("MINTER_ROLE");

    modifier onlyMinter(){
        require(hasRole(MINTER, msg.sender), "Not a MINTER");
        _;
    }
}
