// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

/**
 * @dev Contract module which provides a basic access control mechanism, where
 * there is an account (an owner) that can be granted exclusive access to
 * specific functions.
 *
 * By default, the owner account will be the one that deploys the contract. This
 * can later be changed with {transferOwnership}.
 *
 * This module is used through inheritance. It will make available the modifier
 * `onlyOwner`, which can be applied to your functions to restrict their use to
 * the owner.
 */
abstract contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    /**
     * @dev Initializes the contract setting the deployer as the initial owner.
     */
    constructor() {
        _transferOwnership(_msgSender());
    }

    /**
     * @dev Returns the address of the current owner.
     */
    function owner() public view virtual returns (address) {
        return _owner;
    }

    /**
     * @dev Throws if called by any account other than the owner.
     */
    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    /**
     * @dev Leaves the contract without owner. It will not be possible to call
     * `onlyOwner` functions anymore. Can only be called by the current owner.
     *
     * NOTE: Renouncing ownership will leave the contract without an owner,
     * thereby removing any functionality that is only available to the owner.
     */
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Can only be called by the current owner.
     */
    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }

    /**
     * @dev Transfers ownership of the contract to a new account (`newOwner`).
     * Internal function without access restriction.
     */
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

contract Referral is Ownable{
    
    address private rootAddress = 0x797DaF126D9158743734dE32c58DB86E90A48F50;

    mapping(address => bool) private _isContractDealer; 

    mapping(address => address) public userReferral;
    mapping(address => address[]) public directReferrals; // 记录下级（反向索引）
    
    event BindReferral(address indexed user,address parent);

    function setContractDealerFlag(address addr,bool flag) public onlyOwner{
        _isContractDealer[addr] = flag;
    }

    function getContractDealerFlag(address addr) public view returns(bool flag){
        flag = _isContractDealer[addr];
    }

    modifier onlyContractDealer() {
        require(_isContractDealer[_msgSender()] == true, "Ownable: _contract_dealer is not the owner");
        _;
    }

    function getRootAddress()external view returns(address){
        return rootAddress;
    }

    function getReferral(address _address)external view returns(address){
        
        return userReferral[_address];

    }

    function isBindReferral(address _address) external view returns(bool){
        if(_address == rootAddress) return true;

        if(userReferral[_address] == address(0)){
            return false;
        }
        return true;
    }

    function getReferralCount(address _address) external view returns(uint256){

        return directReferrals[_address].length;

    }

    function getDirectReferrals(address _address) external view returns(address[] memory){

        return directReferrals[_address];

    }

    function bindReferral(address _referral,address _user) external onlyContractDealer{

        require(_referral != address(0), "Inviter cannot be zero address");
        require(_user != address(0), "user cannot is zero address");

        require(userReferral[_user] == address(0), "Already bound");        
        require(_referral != _user, "Cannot bind self"); //A = A        
        require(userReferral[_referral] != _user, "Circular binding not allowed"); //A=B B=A

        // 检查是否形成闭环：从 _inviter 一路往上追溯，看有没有 msg.sender
        address current = _referral;
        while (current != address(0)) {
            require(current != _user, "Circular binding not allowed");
            current = userReferral[current];
        }
       
        userReferral[_user] = _referral;
        directReferrals[_referral].push(_user); // 记录下级
        emit BindReferral(_user, _referral);
    }

    function getReferrals(address _address,uint256 _num) external view returns(address[] memory){
        address current = userReferral[_address];
        address[] memory temp = new address[](_num);
        uint256 count = 0;

        while (current != address(0) && count < _num) {
            temp[count] = current;
            current = userReferral[current];
            count++;
        }

        // 内存截断（只返回有效部分）
        assembly {
            mstore(temp, count)
        }

        return temp;
    }

}