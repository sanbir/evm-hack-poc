// SPDX-License-Identifier: MIT
pragma solidity >=0.4.16 >=0.6.2 >=0.8.4 ^0.8.20;
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}
interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);
}
interface IWBNB {
    function deposit() external payable;
    function withdraw(uint256 amount) external;
    function balanceOf(address account) external view returns (uint256);
}
interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
    function getPair(address tokenA, address tokenB) external view returns (address pair);
}
interface IUniswapV2Pair {
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function token0() external view returns (address);
    function token1() external view returns (address);
    function sync() external;
    function totalSupply() external view returns (uint256);
}
interface IUniswapV2Router {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external payable;
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;
    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256 deadline
    ) external;
    function addLiquidityETH(
        address token,
        uint256 amountTokenDesired,
        uint256 amountTokenMin,
        uint256 amountETHMin,
        address to,
        uint256 deadline
    ) external payable returns (uint256 amountToken, uint256 amountETH, uint256 liquidity);
    function addLiquidity(
        address tokenA,
        address tokenB,
        uint256 amountADesired,
        uint256 amountBDesired,
        uint256 amountAMin,
        uint256 amountBMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);
    function removeLiquidity(
        address tokenA,
        address tokenB,
        uint256 liquidity,
        uint256 amountAMin,
        uint256 amountBMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB);
    function removeLiquidityETH(
        address token,
        uint256 liquidity,
        uint256 amountTokenMin,
        uint256 amountETHMin,
        address to,
        uint256 deadline
    ) external returns (uint256 amountToken, uint256 amountETH);
}
abstract contract ReentrancyGuard {
    uint256 private constant NOT_ENTERED = 1;
    uint256 private constant ENTERED = 2;
    uint256 private _status;
    error ReentrancyGuardReentrantCall();
    constructor() {
        _status = NOT_ENTERED;
    }
    modifier nonReentrant() {
        _nonReentrantBefore();
        _;
        _nonReentrantAfter();
    }
    function _nonReentrantBefore() private {
        if (_status == ENTERED) {
            revert ReentrancyGuardReentrantCall();
        }
        _status = ENTERED;
    }
    function _nonReentrantAfter() private {
        _status = NOT_ENTERED;
    }
    function _reentrancyGuardEntered() internal view returns (bool) {
        return _status == ENTERED;
    }
}
interface IERC20Errors {
    error ERC20InsufficientBalance(address sender, uint256 balance, uint256 needed);
    error ERC20InvalidSender(address sender);
    error ERC20InvalidReceiver(address receiver);
    error ERC20InsufficientAllowance(address spender, uint256 allowance, uint256 needed);
    error ERC20InvalidApprover(address approver);
    error ERC20InvalidSpender(address spender);
}
interface IERC721Errors {
    error ERC721InvalidOwner(address owner);
    error ERC721NonexistentToken(uint256 tokenId);
    error ERC721IncorrectOwner(address sender, uint256 tokenId, address owner);
    error ERC721InvalidSender(address sender);
    error ERC721InvalidReceiver(address receiver);
    error ERC721InsufficientApproval(address operator, uint256 tokenId);
    error ERC721InvalidApprover(address approver);
    error ERC721InvalidOperator(address operator);
}
interface IERC1155Errors {
    error ERC1155InsufficientBalance(address sender, uint256 balance, uint256 needed, uint256 tokenId);
    error ERC1155InvalidSender(address sender);
    error ERC1155InvalidReceiver(address receiver);
    error ERC1155MissingApprovalForAll(address operator, address owner);
    error ERC1155InvalidApprover(address approver);
    error ERC1155InvalidOperator(address operator);
    error ERC1155InvalidArrayLength(uint256 idsLength, uint256 valuesLength);
}
contract AIDCStaticPool {
    address public businessContract;
    address public aidcToken;
    address public burnWallet; 
    mapping(address => uint256) public userHashPower; 
    mapping(address => uint256) public userClaimedReward; 
    mapping(address => uint256) public rewardDebt; 
    uint256 public totalHashPower; 
    uint256 public accRewardPerShare; 
    event Claim(address indexed user, uint256 reward, uint256 userHashPower, uint256 totalHashPower);
    event RewardDeposited(uint256 amount, uint256 accRewardPerShare);
    event NodeLPRegistered(uint256 count);
    modifier onlyBusiness() {
        require(msg.sender == businessContract, "Only Business");
        _;
    }
    constructor(address _aidcToken, address _burnWallet, address _businessContract) {
        require(_burnWallet != address(0), "Invalid burn wallet");
        require(_businessContract != address(0), "Invalid business contract");
        aidcToken = _aidcToken;
        burnWallet = _burnWallet;
        businessContract = _businessContract;
    }
    function distributeReward(uint256 amount) external onlyBusiness returns (bool) {
        if (totalHashPower == 0) {
            require(burnWallet != address(0), "Burn wallet not set");
            IERC20(aidcToken).transfer(burnWallet, amount);
            emit RewardDeposited(amount, 0);
            return true;
        }
        accRewardPerShare += amount * 1e18 / totalHashPower;
        emit RewardDeposited(amount, accRewardPerShare);
        return true;
    }
    function updateReward(address _user, uint256 _newHP) external onlyBusiness {
        uint256 pending = _pendingReward(_user);
        uint256 oldHP = userHashPower[_user];
        if (_newHP > oldHP) {
            totalHashPower += _newHP - oldHP;
        } else if (_newHP < oldHP) {
            totalHashPower -= oldHP - _newHP;
        }
        userHashPower[_user] = _newHP;
        rewardDebt[_user] = _newHP * accRewardPerShare / 1e18;
        if (pending > 0) {
            userClaimedReward[_user] += pending;
            IERC20(aidcToken).transfer(_user, pending);
            emit Claim(_user, pending, oldHP, totalHashPower);
        }
    }
    function registerNodeHashPower(address[] calldata _nodes, uint256 _bnbAmount) external onlyBusiness {
        for (uint256 i; i < _nodes.length; i++) {
            uint256 oldHP = userHashPower[_nodes[i]];
            uint256 pending = _pendingReward(_nodes[i]);
            uint256 newHP = oldHP + _bnbAmount;
            rewardDebt[_nodes[i]] = newHP * accRewardPerShare / 1e18;
            if (pending > 0) {
                userClaimedReward[_nodes[i]] += pending;
                IERC20(aidcToken).transfer(_nodes[i], pending);
                emit Claim(_nodes[i], pending, oldHP, totalHashPower);
            }
            userHashPower[_nodes[i]] = newHP;
            totalHashPower += _bnbAmount;
        }
        emit NodeLPRegistered(_nodes.length);
    }
    function _pendingReward(address _user) internal view returns (uint256) {
        uint256 hp = userHashPower[_user];
        if (hp == 0) return 0;
        return hp * accRewardPerShare / 1e18 - rewardDebt[_user];
    }
    function pendingReward(address _user) external view returns (uint256) {
        return _pendingReward(_user);
    }
    function getUserHashPower(address _user) external view returns (uint256) {
        return userHashPower[_user];
    }
    function getTotalHashPower() external view returns (uint256) {
        return totalHashPower;
    }
    function getUserClaimedReward(address _user) external view returns (uint256) {
        return userClaimedReward[_user];
    }
    function getAccRewardPerShare() external view returns (uint256) {
        return accRewardPerShare;
    }
    function getRewardDebt(address _user) external view returns (uint256) {
        return rewardDebt[_user];
    }
    function rescueETH(uint256 amount) external onlyBusiness {
        (bool sent, ) = payable(msg.sender).call{value: amount}("");
        require(sent, "ETH transfer failed");
    }
    function rescueToken(address token, uint256 amount) external onlyBusiness {
        IERC20(token).transfer(msg.sender, amount);
    }
}
interface IERC20Metadata is IERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
}
abstract contract Ownable is Context {
    address private _owner;
    error OwnableUnauthorizedAccount(address account);
    error OwnableInvalidOwner(address owner);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    constructor(address initialOwner) {
        if (initialOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(initialOwner);
    }
    modifier onlyOwner() {
        _checkOwner();
        _;
    }
    function owner() public view virtual returns (address) {
        return _owner;
    }
    function _checkOwner() internal view virtual {
        if (owner() != _msgSender()) {
            revert OwnableUnauthorizedAccount(_msgSender());
        }
    }
    function renounceOwnership() public virtual onlyOwner {
        _transferOwnership(address(0));
    }
    function transferOwnership(address newOwner) public virtual onlyOwner {
        if (newOwner == address(0)) {
            revert OwnableInvalidOwner(address(0));
        }
        _transferOwnership(newOwner);
    }
    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}
abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    mapping(address account => uint256) private _balances;
    mapping(address account => mapping(address spender => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;
    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }
    function name() public view virtual returns (string memory) {
        return _name;
    }
    function symbol() public view virtual returns (string memory) {
        return _symbol;
    }
    function decimals() public view virtual returns (uint8) {
        return 18;
    }
    function totalSupply() public view virtual returns (uint256) {
        return _totalSupply;
    }
    function balanceOf(address account) public view virtual returns (uint256) {
        return _balances[account];
    }
    function transfer(address to, uint256 value) public virtual returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, value);
        return true;
    }
    function allowance(address owner, address spender) public view virtual returns (uint256) {
        return _allowances[owner][spender];
    }
    function approve(address spender, uint256 value) public virtual returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, value);
        return true;
    }
    function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
        address spender = _msgSender();
        _spendAllowance(from, spender, value);
        _transfer(from, to, value);
        return true;
    }
    function _transfer(address from, address to, uint256 value) internal {
        if (from == address(0)) {
            revert ERC20InvalidSender(address(0));
        }
        if (to == address(0)) {
            revert ERC20InvalidReceiver(address(0));
        }
        _update(from, to, value);
    }
    function _update(address from, address to, uint256 value) internal virtual {
        if (from == address(0)) {
            _totalSupply += value;
        } else {
            uint256 fromBalance = _balances[from];
            if (fromBalance < value) {
                revert ERC20InsufficientBalance(from, fromBalance, value);
            }
            unchecked {
                _balances[from] = fromBalance - value;
            }
        }
        if (to == address(0)) {
            unchecked {
                _totalSupply -= value;
            }
        } else {
            unchecked {
                _balances[to] += value;
            }
        }
        emit Transfer(from, to, value);
    }
    function _mint(address account, uint256 value) internal {
        if (account == address(0)) {
            revert ERC20InvalidReceiver(address(0));
        }
        _update(address(0), account, value);
    }
    function _burn(address account, uint256 value) internal {
        if (account == address(0)) {
            revert ERC20InvalidSender(address(0));
        }
        _update(account, address(0), value);
    }
    function _approve(address owner, address spender, uint256 value) internal {
        _approve(owner, spender, value, true);
    }
    function _approve(address owner, address spender, uint256 value, bool emitEvent) internal virtual {
        if (owner == address(0)) {
            revert ERC20InvalidApprover(address(0));
        }
        if (spender == address(0)) {
            revert ERC20InvalidSpender(address(0));
        }
        _allowances[owner][spender] = value;
        if (emitEvent) {
            emit Approval(owner, spender, value);
        }
    }
    function _spendAllowance(address owner, address spender, uint256 value) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance < type(uint256).max) {
            if (currentAllowance < value) {
                revert ERC20InsufficientAllowance(spender, currentAllowance, value);
            }
            unchecked {
                _approve(owner, spender, currentAllowance - value, false);
            }
        }
    }
}
contract AIDCLPToken is ERC20 {
    address public businessContract; 
    event Mint(address indexed user, uint256 amount);
    event Burn(address indexed user, uint256 amount);
    modifier onlyBusiness() {
        require(msg.sender == businessContract, "Only business contract");
        _;
    }
    constructor(address _businessContract) ERC20("AIDC LP Token", "AIDC-LP") {
        businessContract = _businessContract;
    }
    function mint(address to, uint256 amount) external onlyBusiness {
        _mint(to, amount);
        emit Mint(to, amount);
    }
    function burn(address from, uint256 amount) external onlyBusiness {
        _burn(from, amount);
        emit Burn(from, amount);
    }
    function _update(address from, address to, uint256 amount) internal virtual override {
        require(from == address(0) || to == address(0), "Transfer not allowed");
        super._update(from, to, amount);
    }
}
interface IAIDCToken {
    function getUniswapRouter() external view returns (address);
    function getUniswapPair() external view returns (address);
}
contract AIDCBusiness is Ownable(msg.sender), ReentrancyGuard {
    IAIDCToken public aidcToken;
    AIDCLPToken public lpToken;
    AIDCStaticPool public staticPool;
    address public uniswapRouter;
    address public uniswapPair;
    address public maintenanceWallet; 
    address public burnWallet; 
    address public defaultReferrer; 
    address public designatedWallet; 
    mapping(address => uint256) public userInvest; 
    mapping(address => uint256) public userAddedBNB; 
    mapping(address => uint256) public userLPToken; 
    mapping(address => address) public referrers; 
    mapping(address => address) public userReferrer; 
    mapping(address => bool) public userHasInvested; 
    mapping(address => uint256) public userDirectReferrals; 
    mapping(address => address[]) public directReferralList; 
    mapping(address => uint256) public teamInvest; 
    uint256 public totalUsers; 
    uint256 public totalInvested; 
    uint256 public totalLPTokenAmount; 
    uint256 public constant MIN_INVEST = 0.1 ether;
    uint256 public constant MAX_INVEST = 10 ether;
    uint256 public constant BASE = 10000;
    uint256 public constant BONUS_BP_PER_DAY = 100; 
    uint256 public constant BONUS_BASE = 10000; 
    uint256 public hashPowerBaseTime; 
    uint256 public constant POOL_RATE = 5000; 
    uint256 public constant DYNAMIC_RATE = 3000; 
    uint256 public constant DESIGNATED_RATE = 1000; 
    uint256 public constant MAINTENANCE_RATE = 1000; 
    event Invest(address indexed user, uint256 amount, uint256 hashPower, uint256 totalUserHashPower, uint256 totalHashPower);
    event AddLiquidity(address indexed user, uint256 bnbAmount, uint256 liquidity);
    event ExitPool(address indexed user, uint256 bnbAmount, uint256 aidcAmount);
    event Bind(address indexed user, address indexed referrer);
    modifier onlyAIDCToken() {
        require(msg.sender == address(aidcToken), "Only AIDC token");
        _;
    }
    constructor(
        address _aidcToken, 
        address _defaultReferrer, 
        address _maintenanceWallet, 
        address _designatedWallet, 
        address _burnWallet 
    ) {
        aidcToken = IAIDCToken(_aidcToken);
        defaultReferrer = _defaultReferrer;
        maintenanceWallet = _maintenanceWallet;
        designatedWallet = _designatedWallet;
        burnWallet = _burnWallet;
        staticPool = new AIDCStaticPool(_aidcToken, _burnWallet, address(this));
        lpToken = new AIDCLPToken(address(this));
        uniswapRouter = aidcToken.getUniswapRouter();
        uniswapPair = aidcToken.getUniswapPair();
        hashPowerBaseTime = block.timestamp / 1 days * 1 days;
    }
    function bindReferrer(address _user, address _ref) external onlyAIDCToken {
        require(_user != address(0), "Invalid user");
        require(_ref != address(0), "Invalid referrer");
        require(_user != _ref, "Cannot self-refer");
        require(referrers[_user] == address(0), "Already bound");
        referrers[_user] = _ref;
        if (userReferrer[_user] == address(0)) {
            userReferrer[_user] = _ref;
            _addToDirectList(_ref, _user);
            emit Bind(_user, _ref);
        }
    }
    function execute(address _user, bool _isWhite, uint256 _scaleFactor) external payable onlyAIDCToken nonReentrant {
        uint256 amount = msg.value;
        if (_isWhite) {
            _addPool(_user, amount);
            return;
        }
        uint256 scaledMin = MIN_INVEST / _scaleFactor; 
        uint256 scaledMax = MAX_INVEST / _scaleFactor; 
        if (amount >= scaledMin && amount <= scaledMax) {
            _invest(_user, amount);
            return;
        } else if (amount == 0.00001 ether) {
            uint256 hp = staticPool.getUserHashPower(_user);
            staticPool.updateReward(_user, hp);
        } else if (amount == 0.00002 ether) {
            _exitPool(_user);
        }
        _safeTransferETH(_user, amount);
    }
    function _invest(address _user, uint256 _amount) internal {
        if (userReferrer[_user] == address(0) && defaultReferrer != address(0) && _user != defaultReferrer) {
            userReferrer[_user] = defaultReferrer;
            _addToDirectList(defaultReferrer, _user);
            emit Bind(_user, defaultReferrer);
        }
        if (!userHasInvested[_user]) {
            userHasInvested[_user] = true;
            totalUsers++;
            if (userReferrer[_user] != address(0)) {
                userDirectReferrals[userReferrer[_user]]++;
            }
        }
        uint256 poolAmount = _amount * POOL_RATE / BASE; 
        uint256 dynamicAmount = _amount * DYNAMIC_RATE / BASE; 
        uint256 designatedAmount = _amount * DESIGNATED_RATE / BASE; 
        uint256 maintenanceAmount = _amount * MAINTENANCE_RATE / BASE; 
        (uint256 liquidity, uint256 usedWBNB) = _addLiquidityForUser(_user, poolAmount, address(this));
        require(liquidity > 0, "Failed to add LP");
        lpToken.mint(_user, liquidity);
        uint256 bonusBP = _getHashPowerBonus();
        uint256 hp = _amount * bonusBP / BONUS_BASE;
        userInvest[_user] += _amount;
        userAddedBNB[_user] += usedWBNB;
        userLPToken[_user] += liquidity;
        totalInvested += _amount;
        totalLPTokenAmount += liquidity;
        uint256 oldHP = staticPool.getUserHashPower(_user);
        staticPool.updateReward(_user, oldHP + hp);
        _updateTeamInvest(_user, _amount);
        if (dynamicAmount > 0) {
            _distributeDynamicReward(_user, _amount, dynamicAmount);
        }
        if (maintenanceAmount > 0) {
            _safeTransferETH(maintenanceWallet, maintenanceAmount);
        }
        if (designatedAmount > 0) {
            _safeTransferETH(designatedWallet, designatedAmount);
        }
        emit Invest(_user, _amount, hp, staticPool.getUserHashPower(_user), staticPool.getTotalHashPower());
    }
    function _exitPool(address _user) internal {
        require(userLPToken[_user] > 0, "No LP");
        uint256 lpAmount = userLPToken[_user];
        address WETH = IUniswapV2Router(uniswapRouter).WETH();
        IERC20(uniswapPair).approve(uniswapRouter, lpAmount);
        (uint256 wbnbAmount, uint256 aidcAmount) = IUniswapV2Router(uniswapRouter)
            .removeLiquidity(
                WETH,
                address(aidcToken),
                lpAmount,
                0, 0,
                address(this),
                block.timestamp + 300
            );
        IWBNB(WETH).withdraw(wbnbAmount);
        uint256 userBNB = wbnbAmount > userAddedBNB[_user] ? userAddedBNB[_user] : wbnbAmount;
        uint256 extraBNB = wbnbAmount - userBNB;
        IERC20(address(aidcToken)).transfer(0x000000000000000000000000000000000000dEaD, aidcAmount);
        staticPool.updateReward(_user, 0);
        userAddedBNB[_user] = 0;
        userLPToken[_user] = 0;
        if(totalLPTokenAmount >= lpAmount)totalLPTokenAmount -= lpAmount;
        if(totalUsers > 0)totalUsers--;
        if(userReferrer[_user] != address(0)) {
            if(userDirectReferrals[userReferrer[_user]] > 0)userDirectReferrals[userReferrer[_user]]--;
        }
        userHasInvested[_user] = false;
        lpToken.burn(_user, lpAmount);
        if (userBNB > 0) {
            _safeTransferETH(_user, userBNB);
        }
        if (extraBNB > 0) {
            _safeTransferETH(burnWallet, extraBNB);
        }
        emit ExitPool(_user, userBNB, aidcAmount);
    }
    function _addToDirectList(address referrer, address user) internal {
        directReferralList[referrer].push(user);
    }
    function _updateTeamInvest(address _user, uint256 _amount) internal {
        address current = userReferrer[_user];
        uint256 safety;
        while (current != address(0) && safety < 255) {
            teamInvest[current] += _amount;
            current = userReferrer[current];
            safety++;
        }
    }
    function _addPool(address _user, uint256 _amount) internal {
        require(_amount > 0, "Zero amount");
        (uint256 liquidity,) = _addLiquidityForUser(_user, _amount, _user);
        require(liquidity > 0, "Failed to add LP");
        uint256 oldHP = staticPool.getUserHashPower(_user);
        staticPool.updateReward(_user, oldHP + liquidity);
    }
    function _getHashPowerBonus() internal view returns (uint256 bonusBP) {
        uint256 daysElapsed = (block.timestamp - hashPowerBaseTime) / 1 days;
        return BONUS_BASE + daysElapsed * BONUS_BP_PER_DAY;
    }
    function distributeFromStaticPool(uint256 amount) external onlyAIDCToken returns (bool) {
        return staticPool.distributeReward(amount);
    }
    function registerNodeHashPower(address[] calldata _nodes, uint256 _bnbAmount) external onlyAIDCToken {
        staticPool.registerNodeHashPower(_nodes, _bnbAmount);
    }
    function _addLiquidityForUser(address user, uint256 poolAmount, address lpRecipient) internal returns (uint256, uint256){
        if (poolAmount == 0) return (0, 0);
        address WETH = IUniswapV2Router(uniswapRouter).WETH();
        IWBNB wbnb = IWBNB(WETH);
        wbnb.deposit{value: poolAmount}();
        require(wbnb.balanceOf(address(this)) >= poolAmount, "ERR: WBNB deposit failed");
        (uint256 wbnbForAIDC, uint256 wbnbForPool) = _calculateOptimalSplit(poolAmount);
        require(wbnbForAIDC > 0, "ERR: Swap 0 AIDC - low liquidity");
        require(wbnbForPool > 0, "ERR: Swap 0 LP - low liquidity");
        address AIDC = address(aidcToken);
        address[] memory path = new address[](2);
        path[0] = WETH;
        path[1] = AIDC;
        uint256 aidcBalanceBefore = IERC20(AIDC).balanceOf(address(this));
        IERC20(WETH).approve(uniswapRouter, wbnbForAIDC);
        IUniswapV2Router(uniswapRouter)
            .swapExactTokensForTokensSupportingFeeOnTransferTokens(
                wbnbForAIDC, 0, path, address(this), block.timestamp + 300
            );
        uint256 aidcAmount = IERC20(AIDC).balanceOf(address(this)) - aidcBalanceBefore;
        require(aidcAmount > 0, "ERR: Swap 0 AIDC - low liquidity");
        IERC20(AIDC).approve(uniswapRouter, aidcAmount);
        IERC20(WETH).approve(uniswapRouter, wbnbForPool);
        (uint256 usedWBNB,, uint256 liquidity) = IUniswapV2Router(uniswapRouter)
            .addLiquidity(
                WETH, AIDC,
                wbnbForPool, aidcAmount,
                0, 0,
                lpRecipient,
                block.timestamp + 300
            );
        require(liquidity > 0, "ERR: AddLiquidity 0 LP - pool imbalance");
        uint256 leftoverWBNB = wbnbForPool - usedWBNB;
        if (leftoverWBNB > 0) {
            IWBNB(WETH).withdraw(leftoverWBNB);
            _safeTransferETH(user, leftoverWBNB);
        }
        emit AddLiquidity(user, poolAmount, liquidity);
        return (liquidity, usedWBNB);
    }
    function _sqrt(uint256 y) internal pure returns (uint256 z) {
        if (y > 3) {
            z = y;
            uint256 x = y / 2 + 1;
            while (x < z) {
                z = x;
                x = (y / x + x) / 2;
            }
        } else if (y != 0) {
            z = 1;
        }
    }
    function _calculateOptimalSplit(uint256 poolAmount) internal view returns (uint256 swapAmount, uint256 lpAmount) {
        if (poolAmount == 0) return (0, 0);
        IUniswapV2Pair pair = IUniswapV2Pair(uniswapPair);
        (uint112 reserve0, uint112 reserve1,) = pair.getReserves();
        address WETH = IUniswapV2Router(uniswapRouter).WETH();
        uint256 wbnbReserve;
        if (pair.token0() == WETH) {
            wbnbReserve = uint256(reserve0);
        } else {
            wbnbReserve = uint256(reserve1);
        }
        if (wbnbReserve == 0) {
            return (0, 0);
        }
        uint256 c = wbnbReserve * wbnbReserve + wbnbReserve * poolAmount;
        swapAmount = _sqrt(c) - wbnbReserve;
        if (swapAmount == 0) swapAmount = 1;
        if (swapAmount >= poolAmount) swapAmount = poolAmount * 7 / 10;
        lpAmount = poolAmount - swapAmount;
    }
    function _distributeDynamicReward(address user, uint256 investAmount, uint256 dynamicAmount) internal {
        address currentReferrer = userReferrer[user];
        uint256 remainingAmount = dynamicAmount;
        for (uint256 level = 1; level <= 15; level++) {
            if (currentReferrer == address(0)) break;
            {
                (bool qualified, uint256 rate) = _getRate(level, userDirectReferrals[currentReferrer]);
                if (qualified && userHasInvested[currentReferrer] && rate > 0) {
                    uint256 reward = investAmount * rate / BASE;
                    if (reward > 0 && remainingAmount >= reward) {
                        remainingAmount -= reward;
                        _safeTransferETH(currentReferrer, reward);
                    }
                }
            }
            currentReferrer = userReferrer[currentReferrer];
        }
        if (remainingAmount > 0) {
            _safeTransferETH(burnWallet, remainingAmount);
        }
    }
    function _getRate(uint256 level, uint256 directReferrals) private pure returns (bool qualified, uint256 rate) {
        if (level == 1 && directReferrals >= 1) {
            return (true, 600); 
        } else if (level == 2 && directReferrals >= 2) {
            return (true, 500); 
        } else if (level == 3 && directReferrals >= 3) {
            return (true, 400); 
        } else if (level == 4 && directReferrals >= 4) {
            return (true, 300); 
        } else if (level == 5 && directReferrals >= 4) {
            return (true, 200); 
        } else if (level >= 6 && level <= 15 && directReferrals >= 6) {
            return (true, 100); 
        }
        return (false, 0);
    }
    function pendingReward(address _user) external view returns (uint256) {
        return staticPool.pendingReward(_user);
    }
    function getDirectReferralList(address _user, uint256 _start, uint256 _count) external view returns (address[] memory wallets, uint256[] memory amounts) {
        uint256 total = directReferralList[_user].length;
        if (_start >= total) return (new address[](0), new uint256[](0));
        uint256 end = _start + _count;
        if (end > total) end = total;
        uint256 size = end - _start;
        wallets = new address[](size);
        amounts = new uint256[](size);
        for (uint256 i = 0; i < size; i++) {
            address w = directReferralList[_user][_start + i];
            wallets[i] = w;
            amounts[i] = userInvest[w];
        }
    }
    function getUserInfo(address _user) external view returns (
        uint256 invest,
        uint256 addedBNB,
        uint256 lpTokenAmount,
        uint256 hashPower,
        uint256 claimedReward,
        address referrer,
        bool hasInvested,
        uint256 directReferrals,
        uint256 teamInvestAmount,
        uint256 pendingRewardAmount
    ) {
        invest = userInvest[_user];
        addedBNB = userAddedBNB[_user];
        lpTokenAmount = userLPToken[_user];
        hashPower = staticPool.getUserHashPower(_user);
        claimedReward = staticPool.getUserClaimedReward(_user);
        referrer = userReferrer[_user];
        hasInvested = userHasInvested[_user];
        directReferrals = userDirectReferrals[_user];
        teamInvestAmount = teamInvest[_user];
        pendingRewardAmount = staticPool.pendingReward(_user);
    }
    function getGlobalInfo() external view returns (
        uint256 users,
        uint256 invested,
        uint256 lpTotal,
        uint256 hpTotal,
        uint256 accReward,
        uint256 bonusBP
    ) {
        users = totalUsers;
        invested = totalInvested;
        lpTotal = totalLPTokenAmount;
        hpTotal = staticPool.getTotalHashPower();
        accReward = staticPool.getAccRewardPerShare();
        bonusBP = _getHashPowerBonus();
    }
    function setMaintenanceWallet(address _wallet) external onlyOwner {
        maintenanceWallet = _wallet;
    }
    function setBurnWallet(address _wallet) external onlyOwner {
        burnWallet = _wallet;
    }
    function setDefaultReferrer(address _referrer) external onlyOwner {
        defaultReferrer = _referrer;
    }
    function setDesignatedWallet(address _wallet) external onlyOwner {
        designatedWallet = _wallet;
    }
    function _safeTransferETH(address _to, uint256 _amount) internal {
        if (_amount == 0) return;
        (bool sent, ) = payable(_to).call{value: _amount}("");
        require(sent, "ETH transfer failed");
    }
    function rescueETH(uint256 amount) external onlyOwner {
        _safeTransferETH(msg.sender, amount);
    }
    function rescueToken(address token, uint256 amount) external onlyOwner {
        IERC20(token).transfer(msg.sender, amount);
    }
    function rescueStaticPoolETH(uint256 amount) external onlyOwner {
        staticPool.rescueETH(amount);
    }
    function rescueStaticPoolToken(address token, uint256 amount) external onlyOwner {
        staticPool.rescueToken(token, amount);
    }
    receive() external payable {}
}