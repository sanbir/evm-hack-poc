// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * Referral
 */
interface IERC20 {
    function transfer(address to, uint256 amount) external returns (bool);
    function balanceOf(address owner) external view returns (uint256);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}

interface IReserve {
    function getBalance() external view returns (uint256 tokenBalance, uint256 ethBalance);
    function token() external view returns (address);
}

// V-31: Two interfaces for the two-step migration chain
// Interface for reading invite/level/volume data from the ORIGINAL contract
interface IOriginalReferral {
    function inviter(address user) external view returns (address);
    function hasBound(address user) external view returns (bool);
    function selfVolume(address user) external view returns (uint256);
    function teamVolume(address user) external view returns (uint256);
    function teamCount(address user) external view returns (uint256);
    function level(address user) external view returns (uint256);
    function totalReward(address user) external view returns (uint256);
    function pendingReward(address user) external view returns (uint256);
}

// Interface for reading pendingReward from the ALREADY-MIGRATED contract (0x4627d206...)
// This contract has the same ABI as original but already has user data migrated
interface IMigratedReferral {
    function pendingReward(address user) external view returns (uint256);
    function migratedPendingReward(address user) external view returns (uint256);
}

library SafeERC20 {
    function safeTransfer(IERC20 token, address to, uint256 value) internal {
        (bool success, bytes memory data) = address(token).call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, value)
        );
        require(success && (data.length == 0 || abi.decode(data, (bool))), "safeTransfer failed");
    }

    function safeTransferFrom(IERC20 token, address from, address to, uint256 value) internal {
        (bool success, bytes memory data) = address(token).call(
            abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value)
        );
        require(success && (data.length == 0 || abi.decode(data, (bool))), "safeTransferFrom failed");
    }
}

contract Referral {

    using SafeERC20 for IERC20;

    address public owner;
    IERC20 public rewardToken;
    IReserve public reserve;

    mapping(address => bool) public isAuthorized;
    mapping(address => address) public inviter;
    mapping(address => bool) public hasBound;
    mapping(address => uint256) public teamCount;
    mapping(address => uint256) public teamVolume;
    mapping(address => uint256) public selfVolume;
    mapping(address => uint256) public totalReward;
    mapping(address => uint256) public pendingReward;
    mapping(address => uint256) public level;
    mapping(address => bool) public isValidUser;

    // V-28: Track stake performance so it can be deducted on unstake
    mapping(address => uint256) public stakePerformanceVolume;

    // V-29: Track presale performance so deduction is capped at actual contribution
    mapping(address => uint256) public presalePerformanceVolume;

    uint256[6] public levelThreshold = [0, 25_000e18, 100_000e18, 200_000e18, 1_000_000e18, 2_000_000e18];
    uint256 public base1 = 500;
    uint256 public base2 = 300;
    uint256 public base3 = 200;
    uint256[6] public levelBonus = [0, 50, 100, 200, 300, 500];
    uint256 public minValidAmount = 100e18;

    uint256[6] public dividendRates = [0, 3000, 2500, 2000, 1500, 1000];
    uint256 constant BPS = 10000;
    mapping(uint256 => uint256) public dividendPool;
    mapping(address => uint256) public lastClaimedDividend;
    mapping(address => uint256) public levelTeamVolume;
    // V-30: Track total contribution per level for accurate dividend distribution
    uint256[6] public totalLevelContribution;
    // V-30: Track migrated user count for getAllMigratedUsers
    address[] public migratedUsersList;
    mapping(address => bool) public migratedUserMap;
    // V-30: Prevent double-sync in syncLevelContribution
    mapping(address => bool) public levelSynced;

    bool public authorizationGuard = true;

    event Bind(address user, address inviter);
    event Reward(address from, address to, uint256 amount, uint256 level);
    event LevelUp(address user, uint256 newLevel);
    event LevelDown(address user, uint256 newLevel);
    event ThresholdUpdated(uint256[6] newThreshold);
    event BonusUpdated(uint256[6] newBonus);
    event MinValidUpdated(uint256 oldValue, uint256 newValue);
    event BaseRatesSet(uint256 base1, uint256 base2, uint256 base3);
    event DividendRatesUpdated(uint256[6] newRates);
    event RewardTokenUpdated(address oldToken, address newToken);
    event DividendDeposited(uint256 level, uint256 amount);
    event DividendClaimed(address user, uint256 amount, uint256 level);
    event DividendRateUpdated(uint256[6] newRates);
    event ReserveUpdated(address oldReserve, address newReserve);
    event AuthorizedSet(address indexed account, bool indexed status);
    event AuthorizationGuardToggled(bool indexed enabled);
    event MigrationStarted(address indexed oldReferral_, uint256 snapshotBlock);
    event UserMigrated(address indexed user, address inviter, uint256 selfVol, uint256 teamVol, uint256 lv, uint256 teamCnt);
    event MigrationCompleted(uint256 totalUsers);

    // V-28: Performance deduction events
    event PerformanceDeducted(address indexed user, uint256 amount, uint8 reason);
    // reason: 1=pre-sale sell, 2=stake unstaking, 3=bond redeem, 4=node transfer/sell
    event StakePerformanceRecorded(address indexed user, address indexed inviter, uint256 amount, uint256 lockDays);
    event StakePerformanceDeducted(address indexed user, uint256 amount);

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    modifier onlyAuthorized() {
        if (authorizationGuard) {
            require(isAuthorized[msg.sender] || msg.sender == owner, "not authorized");
        }
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function setAuthorized(address account, bool status) external onlyOwner {
        require(account != address(0), "zero address");
        isAuthorized[account] = status;
        emit AuthorizedSet(account, status);
    }

    function setAuthorizedBatch(address[] calldata accounts, bool status) external onlyOwner {
        for (uint256 i = 0; i < accounts.length; i++) {
            require(accounts[i] != address(0), "zero address");
            isAuthorized[accounts[i]] = status;
            emit AuthorizedSet(accounts[i], status);
        }
    }

    function toggleAuthorizationGuard() external onlyOwner {
        authorizationGuard = !authorizationGuard;
        emit AuthorizationGuardToggled(authorizationGuard);
    }

    function bind(address _inviter) external {
        require(!hasBound[msg.sender], "already bound");
        require(_inviter != msg.sender && _inviter != address(0), "invalid inviter");
        inviter[msg.sender] = _inviter;
        hasBound[msg.sender] = true;
        address u1 = _inviter;
        address u2 = inviter[u1];
        address u3 = inviter[u2];
        if (u1 != address(0)) teamCount[u1]++;
        if (u2 != address(0)) teamCount[u2]++;
        if (u3 != address(0)) teamCount[u3]++;
        emit Bind(msg.sender, _inviter);
    }

    function record(address user, uint256 amount) external onlyAuthorized {
        require(amount > 0, "zero amount");
        if (amount >= minValidAmount) {
            isValidUser[user] = true;
        }
        uint256 oldLevelUser = level[user];
        uint256 oldLtvUser = levelTeamVolume[user];
        selfVolume[user] += amount;
        address u1 = inviter[user];
        address u2 = inviter[u1];
        address u3 = inviter[u2];
        if (u1 != address(0)) {
            uint256 oldLevel = level[u1];
            uint256 oldLtv = levelTeamVolume[u1];
            teamVolume[u1] += amount;
            levelTeamVolume[u1] += amount;
            _updateLevel(u1);
            _syncContribution(u1, oldLevel, oldLtv);
        }
        if (u2 != address(0)) {
            uint256 oldLevel = level[u2];
            uint256 oldLtv = levelTeamVolume[u2];
            teamVolume[u2] += amount;
            levelTeamVolume[u2] += amount;
            _updateLevel(u2);
            _syncContribution(u2, oldLevel, oldLtv);
        }
        if (u3 != address(0)) {
            uint256 oldLevel = level[u3];
            uint256 oldLtv = levelTeamVolume[u3];
            teamVolume[u3] += amount;
            levelTeamVolume[u3] += amount;
            _updateLevel(u3);
            _syncContribution(u3, oldLevel, oldLtv);
        }
        _updateLevel(user);
        _syncContribution(user, oldLevelUser, oldLtvUser);
    }

    /**
     * V-28: Record performance with explicit action reason.
     * reason codes (add side):
     *   0 = default buy (pre-sale, bond, node) — adds to teamVolume/levelTeamVolume/u1-u3
     *   6 = stake lock (>= 180 days) — same as reason 0, but also tracks in stakePerformanceVolume
     *
     * Only stake locks >= 180 days (15552000 seconds) count toward referral performance.
     * lockDays must be passed in seconds.
     */
    function recordWithReason(address user, uint256 amount, uint256 lockDays) external onlyAuthorized {
        require(amount > 0, "zero amount");
        // Stake with lock < 180 days does NOT generate referral performance
        uint256 MIN_STAKE_LOCK = 180 days; // 15552000 seconds
        bool isQualifiedStake = (lockDays > 0 && lockDays >= MIN_STAKE_LOCK);
        // For non-stake actions (lockDays = 0), always record
        // For stake actions, only record if lockDays >= 180 days
        if (lockDays > 0 && !isQualifiedStake) return;

        selfVolume[user] += amount;
        address u1 = inviter[user];
        address u2 = inviter[u1];
        address u3 = inviter[u2];

        if (u1 != address(0)) {
            uint256 oldLevel = level[u1];
            uint256 oldLtv = levelTeamVolume[u1];
            teamVolume[u1] += amount;
            levelTeamVolume[u1] += amount;
            _updateLevel(u1);
            _syncContribution(u1, oldLevel, oldLtv);
        }
        if (u2 != address(0)) {
            uint256 oldLevel = level[u2];
            uint256 oldLtv = levelTeamVolume[u2];
            teamVolume[u2] += amount;
            levelTeamVolume[u2] += amount;
            _updateLevel(u2);
            _syncContribution(u2, oldLevel, oldLtv);
        }
        if (u3 != address(0)) {
            uint256 oldLevel = level[u3];
            uint256 oldLtv = levelTeamVolume[u3];
            teamVolume[u3] += amount;
            levelTeamVolume[u3] += amount;
            _updateLevel(u3);
            _syncContribution(u3, oldLevel, oldLtv);
        }

        // For qualified stake locks (>= 180 days), track so it can be deducted on unstake
        if (isQualifiedStake) {
            stakePerformanceVolume[user] += amount;
            emit StakePerformanceRecorded(user, u1, amount, lockDays);
        } else if (lockDays == 0) {
            // V-29: Non-stake buy (pre-sale, bond, node without lock) — track for presale deduction
            presalePerformanceVolume[user] += amount;
        }

        if (amount >= minValidAmount) {
            isValidUser[user] = true;
        }
        uint256 oldLevelUser = level[user];
        uint256 oldLtvUser = levelTeamVolume[user];
        _updateLevel(user);
        if (u1 != address(0)) _updateLevel(u1);
        if (u2 != address(0)) _updateLevel(u2);
        if (u3 != address(0)) _updateLevel(u3);
        _syncContribution(user, oldLevelUser, oldLtvUser);
    }

    /**
     * V-28: Deduct referral performance when a stake is unstaked.
     * The full original stake amount is deducted from the inviter chain,
     * since only locks >= 180 days were counted at deposit time.
     */
    function deductPerformanceByStake(address user, uint256 originalStakeAmount) external onlyAuthorized {
        require(originalStakeAmount > 0, "zero amount");

        uint256 toDeduct = originalStakeAmount;
        // Cap at what was actually recorded for this user
        if (toDeduct > stakePerformanceVolume[user]) {
            toDeduct = stakePerformanceVolume[user];
        }
        if (toDeduct == 0) return;

        stakePerformanceVolume[user] -= toDeduct;

        address u1 = inviter[user];
        address u2 = inviter[u1];
        address u3 = inviter[u2];

        _deductFromChain(u1, toDeduct);
        _deductFromChain(u2, toDeduct);
        _deductFromChain(u3, toDeduct);

        emit StakePerformanceDeducted(user, toDeduct);
    }

    /**
     * V-28: Internal helper — deduct amount from a single referrer's chain.
     */
    function _deductFromChain(address referrer, uint256 amount) internal {
        if (referrer == address(0)) return;
        uint256 oldLv = level[referrer];
        uint256 oldLtv = levelTeamVolume[referrer];
        if (teamVolume[referrer] >= amount) {
            teamVolume[referrer] -= amount;
        } else {
            teamVolume[referrer] = 0;
        }
        if (levelTeamVolume[referrer] >= amount) {
            levelTeamVolume[referrer] -= amount;
        } else {
            levelTeamVolume[referrer] = 0;
        }
        _updateLevel(referrer);
        _syncContribution(referrer, oldLv, oldLtv);
    }

    /**
     * V-28 (fixed): Unified deductPerformance — routes by reason code.
     * Called by Bond, Staking, GenesisNode, Presale.
     * reason: 1=pre-sale sell, 2=stake unstaking, 3=bond redeem, 4=node transfer/sell
     */
    function deductPerformance(address user, uint256 amount, uint8 reason) external onlyAuthorized {
        require(amount > 0, "zero amount");
        require(reason >= 1 && reason <= 4, "invalid reason");

        emit PerformanceDeducted(user, amount, reason);

        if (reason == 2) {
            // Stake unstaking: cap at actual stakePerformanceVolume
            uint256 toDeduct = amount;
            if (toDeduct > stakePerformanceVolume[user]) {
                toDeduct = stakePerformanceVolume[user];
            }
            if (toDeduct == 0) return;
            stakePerformanceVolume[user] -= toDeduct;
            address u1 = inviter[user];
            address u2 = inviter[u1];
            address u3 = inviter[u2];
            _deductFromChain(u1, toDeduct);
            _deductFromChain(u2, toDeduct);
            _deductFromChain(u3, toDeduct);
        } else {
            // Presale sell (1), bond redeem (3), node transfer (4): cap at presalePerformanceVolume
            uint256 toDeduct = amount;
            if (toDeduct > presalePerformanceVolume[user]) {
                toDeduct = presalePerformanceVolume[user];
            }
            if (toDeduct == 0) return;
            presalePerformanceVolume[user] -= toDeduct;
            address u1 = inviter[user];
            address u2 = inviter[u1];
            address u3 = inviter[u2];
            _deductFromChain(u1, toDeduct);
            _deductFromChain(u2, toDeduct);
            _deductFromChain(u3, toDeduct);
        }
    }

    // V-30: Sync levelTeamVolume to totalLevelContribution when level or ltv changes
    function _syncContribution(address user, uint256 oldLevel, uint256 oldLtv) internal {
        uint256 newLevel = level[user];
        uint256 newLtv = levelTeamVolume[user];
        if (oldLevel > 0 && oldLevel != newLevel) {
            totalLevelContribution[oldLevel] -= oldLtv;
        }
        if (newLevel > 0) {
            totalLevelContribution[newLevel] += newLtv;
        }
    }

    function _updateLevel(address user) internal {
        uint256 volume = teamVolume[user];
        uint256 newLevel = 0;
        for (uint256 i = 5; i > 0; i--) {
            if (volume >= levelThreshold[i]) {
                newLevel = i;
                break;
            }
        }
        if (level[user] != newLevel) {
            uint256 oldLevel = level[user];
            level[user] = newLevel;
            if (newLevel > oldLevel) {
                emit LevelUp(user, newLevel);
            } else {
                emit LevelDown(user, newLevel);
            }
        }
    }

    function distribute(address user, uint256 amount) external onlyAuthorized {
        require(amount > 0, "zero amount");
        address u1 = inviter[user];
        address u2 = inviter[u1];
        address u3 = inviter[u2];
        _pay(user, u1, amount, base1, 1);
        _pay(user, u2, amount, base2, 2);
        _pay(user, u3, amount, base3, 3);
    }

    function _pay(address from, address to, uint256 amount, uint256 base, uint256 lv) internal {
        if (to == address(0) || !isValidUser[to]) return;
        uint256 bonus = levelBonus[level[to]];
        uint256 rate = base + bonus;
        uint256 reward = amount * rate / 10000;
        if (reward == 0) return;
        // Use low-level call so failed transfers don't revert — go to pending instead
        (bool success, ) = address(rewardToken).call(
            abi.encodeWithSelector(IERC20.transfer.selector, to, reward)
        );
        if (success) {
            totalReward[to] += reward;
            emit Reward(from, to, reward, lv);
        } else {
            pendingReward[to] += reward;
            emit Reward(from, to, 0, lv);
        }
    }

    // Claim new contract invite rewards (normal operation)
    function claimPending() external {
        uint256 pending = pendingReward[msg.sender];
        require(pending > 0, "no pending reward");
        pendingReward[msg.sender] = 0;
        rewardToken.safeTransfer(msg.sender, pending);
        totalReward[msg.sender] += pending;
    }

    // Claim old contract pending rewards (migrated)
    function claimMigratedReward() external {
        uint256 pending = migratedPendingReward[msg.sender];
        require(pending > 0, "no migrated pending reward");
        migratedPendingReward[msg.sender] = 0;
        totalReward[msg.sender] += pending;
        rewardToken.safeTransfer(msg.sender, pending);
        emit DividendClaimed(msg.sender, pending, 0);
    }

    function fundDividendFromReserve() external onlyOwner {
        require(address(reserve) != address(0), "reserve not set");
        address tokenAddr = reserve.token();
        uint256 balance = IERC20(tokenAddr).balanceOf(address(reserve));
        require(balance > 0, "reserve empty");
        for (uint256 lv = 1; lv <= 5; lv++) {
            uint256 poolAmount = balance * dividendRates[lv] / BPS;
            if (poolAmount > 0) {
                IERC20(tokenAddr).safeTransferFrom(address(reserve), address(this), poolAmount);
                dividendPool[lv] += poolAmount;
                emit DividendDeposited(lv, poolAmount);
            }
        }
    }

    function claimDividend() external {
        uint256 userLevel = level[msg.sender];
        require(userLevel >= 1 && userLevel <= 5, "not eligible for dividend");
        uint256 pool = dividendPool[userLevel];
        require(pool > 0, "dividend pool empty");
        uint256 userContribution = levelTeamVolume[msg.sender];
        require(userContribution > 0, "no contribution");
        uint256 totalContrib = _getTotalLevelContribution(userLevel);
        require(totalContrib > 0, "no total contribution");

        uint256 lastClaimed = lastClaimedDividend[msg.sender];
        uint256 share = pool * userContribution / totalContrib;
        uint256 pending = 0;

        if (share > lastClaimed) {
            pending = share - lastClaimed;
        } else if (pool >= share && share > 0) {
            // V-30: Pool shrank — allow claim of full remaining share instead of being stuck
            pending = share;
            lastClaimedDividend[msg.sender] = 0;
        }
        require(pending > 0, "no pending dividend");

        lastClaimedDividend[msg.sender] = share;
        dividendPool[userLevel] -= pending;
        rewardToken.safeTransfer(msg.sender, pending);
        totalReward[msg.sender] += pending;
        emit DividendClaimed(msg.sender, pending, userLevel);
    }

    function _getTotalLevelContribution(uint256 lv) internal view returns (uint256 total) {
        return totalLevelContribution[lv];
    }

    function getPendingDividend(address user) external view returns (uint256) {
        uint256 userLevel = level[user];
        if (userLevel < 1 || userLevel > 5) return 0;
        uint256 pool = dividendPool[userLevel];
        if (pool == 0) return 0;
        uint256 userContribution = levelTeamVolume[user];
        if (userContribution == 0) return 0;
        uint256 totalContrib = totalLevelContribution[userLevel];
        if (totalContrib == 0) return 0;
        uint256 share = pool * userContribution / totalContrib;
        uint256 lastClaimed = lastClaimedDividend[user];
        if (share > lastClaimed) return share - lastClaimed;
        if (pool >= share && share > 0) return share;
        return 0;
    }

    function setReserve(address _reserve) external onlyOwner {
        require(_reserve != address(0), "zero address");
        address oldReserve = address(reserve);
        reserve = IReserve(_reserve);
        emit ReserveUpdated(oldReserve, _reserve);
    }

    function setThreshold(uint256[6] calldata arr) external onlyOwner {
        levelThreshold = arr;
        emit ThresholdUpdated(arr);
    }

    function setBonus(uint256[6] calldata arr) external onlyOwner {
        levelBonus = arr;
        emit BonusUpdated(arr);
    }

    function setMinValid(uint256 v) external onlyOwner {
        uint256 oldValue = minValidAmount;
        minValidAmount = v;
        emit MinValidUpdated(oldValue, v);
    }

    function setRewardToken(address t) external onlyOwner {
        require(t != address(0), "zero token");
        address oldToken = address(rewardToken);
        rewardToken = IERC20(t);
        emit RewardTokenUpdated(oldToken, t);
    }

    function setBaseRates(uint256 _base1, uint256 _base2, uint256 _base3) external onlyOwner {
        require(_base1 > 0 && _base2 > 0 && _base3 > 0, "invalid rates");
        base1 = _base1;
        base2 = _base2;
        base3 = _base3;
        emit BaseRatesSet(_base1, _base2, _base3);
    }

    function setDividendRates(uint256[6] calldata arr) external onlyOwner {
        require(arr[0] == 0, "lv0 must be 0");
        dividendRates = arr;
        emit DividendRatesUpdated(arr);
    }

    function getUserInfo(address user) external view returns (address inviter_, uint256 selfVolume_, uint256 teamVolume_, uint256 teamCount_, uint256 level_, uint256 totalReward_) {
        inviter_ = inviter[user];
        selfVolume_ = selfVolume[user];
        teamVolume_ = teamVolume[user];
        teamCount_ = teamCount[user];
        level_ = level[user];
        totalReward_ = totalReward[user];
    }

    function getReferralStats() external view returns (uint256 base1_, uint256 base2_, uint256 base3_, uint256 minValid_, uint256[6] memory thresholds, uint256[6] memory bonuses, uint256[6] memory divRates, uint256[5] memory divPools, bool authGuard_) {
        base1_ = base1;
        base2_ = base2;
        base3_ = base3;
        minValid_ = minValidAmount;
        thresholds = levelThreshold;
        bonuses = levelBonus;
        divRates = dividendRates;
        for (uint256 i = 1; i <= 5; i++) {
            divPools[i - 1] = dividendPool[i];
        }
        authGuard_ = authorizationGuard;
    }

    // ========== MIGRATION V2: Two-contract migration setup ==========
    // Original contract: stores invite relationship, level, volume
    address public originalReferral;
    // Already-migrated contract: stores pendingReward that users haven't claimed yet
    address public migratedReferral;
    uint256 public migrationSnapshotBlock;

    /**
     * hasMigrated: tracks whether user has been manually imported via migrateUser().
     * This is SEPARATE from oldMigrated — a user can:
     *   1. Be migrated from OLD contract (oldMigrated) → import old pending rewards
     *   2. Be migrated via new contract migrateUser() (hasMigrated) → import owner-provided data
     * The two tracks are independent; users can participate in new contract after either migration.
     */
    mapping(address => bool) public hasMigrated;
    // oldMigrated: tracks whether user has been migrated from original contract
    mapping(address => bool) public oldMigrated;

    /**
     * setMigrationContracts: Set both source contracts.
     * _originalReferral = 0x64125e3E... — stores invite/level/volume
     * _migratedReferral = 0x4627d206... — already migrated, stores pendingReward
     * Both must be set before migration begins.
     */
    function setMigrationContracts(address _originalReferral, address _migratedReferral) external onlyOwner {
        require(_originalReferral != address(0), "zero original");
        require(_migratedReferral != address(0), "zero migrated");
        require(originalReferral == address(0), "already set");
        originalReferral = _originalReferral;
        migratedReferral = _migratedReferral;
        emit MigrationStarted(_originalReferral, 0);
    }

    /**
     * migrateUser: Owner manually migrates a user with explicit data.
     * Uses hasMigrated (independent of oldMigrated from old contract migration).
     * Syncs levelTeamVolume, updates user+u1-u3 levels & totalLevelContribution.
     */
    function migrateUser(
        address user,
        address _inviter,
        uint256 _selfVolume,
        uint256 _teamVolume,
        uint256 _teamCount,
        uint256 _level,
        uint256 _totalReward,
        bool _hasBound
    ) external onlyOwner {
        require(!hasMigrated[user], "already migrated via new method");
        hasMigrated[user] = true;
        hasBound[user] = _hasBound;
        inviter[user] = _inviter;
        selfVolume[user] = _selfVolume;
        teamVolume[user] = _teamVolume;
        teamCount[user] = _teamCount;
        level[user] = _level;
        totalReward[user] = _totalReward;

        if (_selfVolume >= minValidAmount) {
            isValidUser[user] = true;
        }

        // Set levelTeamVolume BEFORE capturing old state (required for _syncContribution)
        levelTeamVolume[user] = _teamVolume;

        // Capture old state BEFORE _updateLevel changes it
        uint256 userOldLv = level[user];
        uint256 userOldLtv = levelTeamVolume[user];

        _updateLevel(user);
        _syncContribution(user, userOldLv, userOldLtv);

        // Update 3-layer referrer levels + sync their contributions
        address u1 = _inviter;
        address u2 = inviter[u1];
        address u3 = inviter[u2];

        if (u1 != address(0)) {
            uint256 u1OldLv = level[u1];
            uint256 u1OldLtv = levelTeamVolume[u1];
            _updateLevel(u1);
            _syncContribution(u1, u1OldLv, u1OldLtv);
        }
        if (u2 != address(0)) {
            uint256 u2OldLv = level[u2];
            uint256 u2OldLtv = levelTeamVolume[u2];
            _updateLevel(u2);
            _syncContribution(u2, u2OldLv, u2OldLtv);
        }
        if (u3 != address(0)) {
            uint256 u3OldLv = level[u3];
            uint256 u3OldLtv = levelTeamVolume[u3];
            _updateLevel(u3);
            _syncContribution(u3, u3OldLv, u3OldLtv);
        }

        levelSynced[user] = true;

        if (!migratedUserMap[user]) {
            migratedUserMap[user] = true;
            migratedUsersList.push(user);
        }

        emit UserMigrated(user, _inviter, _selfVolume, _teamVolume, _level, _teamCount);
    }

    function migrateUsersBatch1(
        address[] calldata users,
        address[] calldata inviters,
        uint256[] calldata selfVolumes,
        uint256[] calldata teamVolumes,
        uint256[] calldata pendingRewards
    ) external onlyOwner {
        uint256 len = users.length;
        require(len == inviters.length && len == selfVolumes.length && len == teamVolumes.length && len == pendingRewards.length, "len mismatch");
        require(len <= 50, "batch too large");
        for (uint256 i = 0; i < len; i++) {
            address u = users[i];
            if (hasMigrated[u]) continue;
            hasMigrated[u] = true;
            inviter[u] = inviters[i];
            selfVolume[u] = selfVolumes[i];
            teamVolume[u] = teamVolumes[i];
            if (selfVolumes[i] >= minValidAmount) {
                isValidUser[u] = true;
            }
            _updateLevel(u);
            uint256 oldLv = level[u];
            uint256 oldLtv = levelTeamVolume[u];
            address b1u1 = inviters[i];
            address b1u2 = inviter[b1u1];
            address b1u3 = inviter[b1u2];
            if (b1u1 != address(0)) _updateLevel(b1u1);
            if (b1u2 != address(0)) _updateLevel(b1u2);
            if (b1u3 != address(0)) _updateLevel(b1u3);
            _syncContribution(u, oldLv, oldLtv);
            levelSynced[u] = true;
            if (pendingRewards[i] > 0) {
                migratedPendingReward[u] = pendingRewards[i];
            }
            if (!migratedUserMap[u]) {
                migratedUserMap[u] = true;
                migratedUsersList.push(u);
            }
        }
    }

    function migrateUsersBatch2(
        address[] calldata users,
        uint256[] calldata teamCounts,
        uint256[] calldata levels,
        uint256[] calldata totalRewards,
        bool[] calldata hasBounds,
        uint256[] calldata pendingRewards
    ) external onlyOwner {
        uint256 len = users.length;
        require(len == teamCounts.length && len == levels.length && len == totalRewards.length && len == hasBounds.length && len == pendingRewards.length, "len mismatch");
        require(len <= 50, "batch too large");
        for (uint256 i = 0; i < len; i++) {
            address u = users[i];
            if (hasMigrated[u]) continue;
            hasMigrated[u] = true;
            teamCount[u] = teamCounts[i];
            level[u] = levels[i];
            totalReward[u] = totalRewards[i];
            hasBound[u] = hasBounds[i];
            _updateLevel(u);
            uint256 oldLv = level[u];
            uint256 oldLtv = levelTeamVolume[u];
            address u1 = inviter[u];
            address u2 = inviter[u1];
            address u3 = inviter[u2];
            if (u1 != address(0)) _updateLevel(u1);
            if (u2 != address(0)) _updateLevel(u2);
            if (u3 != address(0)) _updateLevel(u3);
            _syncContribution(u, oldLv, oldLtv);
            levelSynced[u] = true;
            if (pendingRewards[i] > 0) {
                migratedPendingReward[u] = pendingRewards[i];
            }
            if (!migratedUserMap[u]) {
                migratedUserMap[u] = true;
                migratedUsersList.push(u);
            }
        }
    }

    function getMigrationStatus(address user) external view returns (bool migrated, uint256 selfVol, uint256 teamVol, uint256 lv, uint256 totalRw) {
        migrated = hasMigrated[user];
        selfVol = selfVolume[user];
        teamVol = teamVolume[user];
        lv = level[user];
        totalRw = totalReward[user];
    }

    function completeMigration() external onlyOwner {
        emit MigrationCompleted(0);
    }

    function getAllMigratedUsers() external view returns (address[] memory) {
        return migratedUsersList;
    }

    // ========== MIGRATION V3: Import from OLD Referral contract ==========
    // V-27: Pending reward tracking for migrated users (old contract)
    mapping(address => uint256) public migratedPendingReward;

    event MigratedPendingReward(address indexed user, uint256 pendingReward, address oldReferral);
    event PullMigrationCompleted(uint256 userCount, uint256 totalPendingReward);
    event Funded(address indexed from, uint256 amount, uint256 newBalance);

    /**
     * migrateUserFromOld: Migrate a single user from original contract + read pendingReward from original contract.
     * Uses oldMigrated (independent of hasMigrated for new contract migration).
     * - Reads invite/level/volume from originalReferral (0x64125e3E...)
     * - Reads pendingReward from originalReferral — NOT from migrated contract, so even users
     *   who already claimed in the intermediate contract can still claim here.
     * User can continue to use new contract normally after this migration.
     */
    function migrateUserFromOld(address user) external onlyOwner {
        require(originalReferral != address(0), "original referral not set");
        require(migratedReferral != address(0), "migrated referral not set");
        require(!oldMigrated[user], "already migrated from original");

        IOriginalReferral orig = IOriginalReferral(originalReferral);

        // Read invite/level/volume from ORIGINAL contract
        hasBound[user] = orig.hasBound(user);
        inviter[user] = orig.inviter(user);
        selfVolume[user] = orig.selfVolume(user);
        teamVolume[user] = orig.teamVolume(user);
        teamCount[user] = orig.teamCount(user);
        level[user] = orig.level(user);
        totalReward[user] = orig.totalReward(user);

        // levelTeamVolume not available in original contract — default to teamVolume
        levelTeamVolume[user] = orig.teamVolume(user);

        // V-29: Presale performance = old selfVolume
        presalePerformanceVolume[user] = orig.selfVolume(user);

        if (selfVolume[user] >= minValidAmount) {
            isValidUser[user] = true;
        }

        // Mark as old-migrated (independent of hasMigrated)
        oldMigrated[user] = true;

        // Capture old state before _updateLevel
        uint256 userOldLv = level[user];
        uint256 userOldLtv = levelTeamVolume[user];

        _updateLevel(user);
        _syncContribution(user, userOldLv, userOldLtv);

        // Update 3-layer referrer levels + sync their contributions
        address u1 = inviter[user];
        address u2 = inviter[u1];
        address u3 = inviter[u2];

        if (u1 != address(0)) {
            uint256 u1OldLv = level[u1];
            uint256 u1OldLtv = levelTeamVolume[u1];
            _updateLevel(u1);
            _syncContribution(u1, u1OldLv, u1OldLtv);
        }
        if (u2 != address(0)) {
            uint256 u2OldLv = level[u2];
            uint256 u2OldLtv = levelTeamVolume[u2];
            _updateLevel(u2);
            _syncContribution(u2, u2OldLv, u2OldLtv);
        }
        if (u3 != address(0)) {
            uint256 u3OldLv = level[u3];
            uint256 u3OldLtv = levelTeamVolume[u3];
            _updateLevel(u3);
            _syncContribution(u3, u3OldLv, u3OldLtv);
        }

        levelSynced[user] = true;

        if (!migratedUserMap[user]) {
            migratedUserMap[user] = true;
            migratedUsersList.push(user);
        }

        // Read pendingReward from the ORIGINAL contract (0x64125e3E...)
        // NOT from the intermediate contract — so users who already claimed in the
        // intermediate contract can still claim their full original pending reward here.
        uint256 pending = orig.pendingReward(user);
        if (pending > 0) {
            migratedPendingReward[user] = pending;
        }

        emit UserMigrated(user, inviter[user], selfVolume[user], teamVolume[user], level[user], teamCount[user]);
    }

    /**
     * pullMigrationFromOld: Migrate batch users from original contract (max 50).
     * - Reads invite/level/volume from originalReferral (0x64125e3E...)
     * - Reads pendingReward from originalReferral — NOT from intermediate contract,
     *   so users who already claimed in the intermediate contract can still claim here.
     * Uses oldMigrated (independent of hasMigrated).
     */
    function pullMigrationFromOld(address[] calldata users) external onlyOwner {
        require(originalReferral != address(0), "original referral not set");
        require(migratedReferral != address(0), "migrated referral not set");
        require(users.length <= 50, "batch too large");

        uint256 count = 0;
        uint256 totalPending = 0;
        IOriginalReferral orig = IOriginalReferral(originalReferral);

        for (uint256 i = 0; i < users.length; i++) {
            address user = users[i];
            if (oldMigrated[user]) continue;

            // Read from ORIGINAL contract
            hasBound[user] = orig.hasBound(user);
            inviter[user] = orig.inviter(user);
            selfVolume[user] = orig.selfVolume(user);
            teamVolume[user] = orig.teamVolume(user);
            teamCount[user] = orig.teamCount(user);
            level[user] = orig.level(user);
            totalReward[user] = orig.totalReward(user);
            levelTeamVolume[user] = orig.teamVolume(user);

            // V-29: Presale performance
            presalePerformanceVolume[user] = orig.selfVolume(user);

            if (selfVolume[user] >= minValidAmount) {
                isValidUser[user] = true;
            }

            oldMigrated[user] = true;

            // Capture old state before _updateLevel
            uint256 userOldLv = level[user];
            uint256 userOldLtv = levelTeamVolume[user];

            _updateLevel(user);
            _syncContribution(user, userOldLv, userOldLtv);

            // Update 3-layer referrers
            address ul1 = inviter[user];
            address ul2 = inviter[ul1];
            address ul3 = inviter[ul2];

            if (ul1 != address(0)) {
                uint256 ul1OldLv = level[ul1];
                uint256 ul1OldLtv = levelTeamVolume[ul1];
                _updateLevel(ul1);
                _syncContribution(ul1, ul1OldLv, ul1OldLtv);
            }
            if (ul2 != address(0)) {
                uint256 ul2OldLv = level[ul2];
                uint256 ul2OldLtv = levelTeamVolume[ul2];
                _updateLevel(ul2);
                _syncContribution(ul2, ul2OldLv, ul2OldLtv);
            }
            if (ul3 != address(0)) {
                uint256 ul3OldLv = level[ul3];
                uint256 ul3OldLtv = levelTeamVolume[ul3];
                _updateLevel(ul3);
                _syncContribution(ul3, ul3OldLv, ul3OldLtv);
            }

            levelSynced[user] = true;

            if (!migratedUserMap[user]) {
                migratedUserMap[user] = true;
                migratedUsersList.push(user);
            }

            // Read pendingReward from the ORIGINAL contract — NOT from intermediate contract
            uint256 pending = orig.pendingReward(user);
            if (pending > 0) {
                migratedPendingReward[user] += pending;
                totalPending += pending;
            }

            count++;
        }

        emit PullMigrationCompleted(count, totalPending);
    }

    // V-27: Get migrated pending reward (old contract)
    function getMigratedPendingReward(address user) external view returns (uint256) {
        return migratedPendingReward[user];
    }

    // V-27: Get old contract migration status
    function getOldMigrationStatus(address user) external view returns (bool migrated, uint256 pending) {
        migrated = oldMigrated[user];
        pending = migratedPendingReward[user];
    }

    // V-30: Sync all level contributions for a batch of migrated users (call after migration)
    function syncLevelContribution(address[] calldata users) external onlyOwner {
        require(users.length <= 50, "batch too large");
        for (uint256 i = 0; i < users.length; i++) {
            address u = users[i];
            if (levelSynced[u]) continue;
            levelSynced[u] = true;
            uint256 lv = level[u];
            if (lv > 0) {
                totalLevelContribution[lv] += levelTeamVolume[u];
            }
        }
    }

    // V-27: Owner funds this contract with reward tokens (from new AIS) for migrated claims
    function fundForMigration(uint256 amount) external onlyOwner {
        require(amount > 0, "zero amount");
        rewardToken.safeTransferFrom(msg.sender, address(this), amount);
        emit Funded(msg.sender, amount, rewardToken.balanceOf(address(this)));
    }
}