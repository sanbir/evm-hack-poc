// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.4;

library KuratowskiAddress {
  address constant public ADDR = 0xCBB1a3EC67C3F96e1396837555f3D4E236FB12eF;
}

library EulerAddress {
  address constant public ADDR = 0x288C8b1a2c68FE8d459c3C89FbACbf58BC240e90;
}

library TuringAddress {
  address constant public ADDR = 0x8E383D2219Edc205e780dAf461a1FFf67D96Bbb2;
}

library BanachAddress {
  address constant public ADDR = 0xB41B28DD09D2232526AC3E90c0aF20cDcFA074b6;
}

library GoldskyAddress {
  address constant public ADDR = 0x4074db36Ff38320f63f9bb9c7B096c1366FEEC7A;
}
