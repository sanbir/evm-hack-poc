// SPDX-License-Identifier: BUSL-1.1

pragma solidity ^0.8.17;

import {KuratowskiAddress, EulerAddress, TuringAddress, BanachAddress, GoldskyAddress} from "../__addresses/CommonUpdaterAddresses.sol";
import {BnbMultiFeedAdapterWithoutRoundsV7} from "./BnbMultiFeedAdapterWithoutRoundsV7.sol";

contract BnbMultiFeedAdapterWithoutRoundsV8 is BnbMultiFeedAdapterWithoutRoundsV7 {
  function _validateBlockTimestamp(
    uint256 lastBlockTimestamp
  ) internal view virtual override returns (bool) {
    if (
      msg.sender == MAIN_UPDATER_ADDRESS ||
      msg.sender == FALLBACK_UPDATER_ADDRESS ||
      msg.sender == MANUAL_UPDATER_ADDRESS ||
      msg.sender == OEV_EXECUTOR_PROXY_ADDRESS_V7 ||
      msg.sender == KuratowskiAddress.ADDR ||
      msg.sender == EulerAddress.ADDR ||
      msg.sender == TuringAddress.ADDR ||
      msg.sender == BanachAddress.ADDR ||
      msg.sender == GoldskyAddress.ADDR
    ) {
      return block.timestamp > lastBlockTimestamp;
    }

    return false;
  }
}
