// SPDX-License-Identifier: MIT
pragma solidity ^0.8.22;

import {UUPSUpgradeable} from "@openzeppelin/contracts/proxy/utils/UUPSUpgradeable.sol";
import {IRoleHub, DEFAULT_ADMIN_ROLE, UPGRADER_ROLE, PAUSER_ROLE} from "./access/RoleHub.sol";

/// @notice Minimal ERC20 interface (balance and approval only)
interface IERC20Minimal {
    /// @notice Get token balance
    function balanceOf(address account) external view returns (uint256);
    /// @notice Approve spending allowance
    function approve(address spender, uint256 value) external returns (bool);
    /// @notice Transfer tokens
    function transfer(address to, uint256 value) external returns (bool);
}

/// @notice Minimal Uniswap V3 SwapRouter02 interface (Strategy-specific)
interface IStrategySwapRouter {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(ExactInputSingleParams calldata params) external returns (uint256 amountOut);
}

/// @notice Minimal Uniswap V3 Pool interface
interface IUniswapV3Pool {
    /// @notice Get token0 address
    function token0() external view returns (address);
    /// @notice Get token1 address
    function token1() external view returns (address);
    /// @notice Get fee tier
    function fee() external view returns (uint24);
    /// @notice Get tick spacing
    function tickSpacing() external view returns (int24);
    /// @notice Get current price info
    function slot0() external view returns (
        uint160 sqrtPriceX96,
        int24 tick,
        uint16 observationIndex,
        uint16 observationCardinality,
        uint16 observationCardinalityNext,
        uint8 feeProtocol,
        bool unlocked
    );
    /// @notice Get TWAP tick cumulative values
    function observe(uint32[] calldata secondsAgos)
        external
        view
        returns (int56[] memory tickCumulatives, uint160[] memory secondsPerLiquidityCumulativeX128s);
}

/// @notice Minimal Uniswap V3 NonfungiblePositionManager interface
interface INonfungiblePositionManager {
    struct MintParams {
        address token0;
        address token1;
        uint24 fee;
        int24 tickLower;
        int24 tickUpper;
        uint256 amount0Desired;
        uint256 amount1Desired;
        uint256 amount0Min;
        uint256 amount1Min;
        address recipient;
        uint256 deadline;
    }

    struct CollectParams {
        uint256 tokenId;
        address recipient;
        uint128 amount0Max;
        uint128 amount1Max;
    }

    struct DecreaseLiquidityParams {
        uint256 tokenId;
        uint128 liquidity;
        uint256 amount0Min;
        uint256 amount1Min;
        uint256 deadline;
    }

    /// @notice Mint a new position
    function mint(MintParams calldata params)
        external
        returns (uint256 tokenId, uint128 liquidity, uint256 amount0, uint256 amount1);

    /// @notice Decrease liquidity of an existing position
    function decreaseLiquidity(DecreaseLiquidityParams calldata params)
        external
        returns (uint256 amount0, uint256 amount1);

    /// @notice Collect fees from an existing position
    function collect(CollectParams calldata params) external returns (uint256 amount0, uint256 amount1);

    struct IncreaseLiquidityParams {
        uint256 tokenId;
        uint256 amount0Desired;
        uint256 amount1Desired;
        uint256 amount0Min;
        uint256 amount1Min;
        uint256 deadline;
    }

    /// @notice Add liquidity to an existing position
    function increaseLiquidity(IncreaseLiquidityParams calldata params)
        external
        returns (uint128 liquidity, uint256 amount0, uint256 amount1);

    /// @notice Burn a zero-liquidity NFT position
    function burn(uint256 tokenId) external;

    /// @notice Return position info (including uncollected fees)
    function positions(uint256 tokenId) external view returns (
        uint96 nonce,
        address operator,
        address token0,
        address token1,
        uint24 fee,
        int24 tickLower,
        int24 tickUpper,
        uint128 liquidity,
        uint256 feeGrowthInside0LastX128,
        uint256 feeGrowthInside1LastX128,
        uint128 tokensOwed0,
        uint128 tokensOwed1
    );
}

/// @notice Strategy contract skeleton for Uniswap V3 LP management
/// @dev Price determination is handled off-chain (Keeper)
contract StrategyUniswapV3 is UUPSUpgradeable {
    // --- Constants (set once in initialize) ---
    /// @notice Uniswap V3 SwapRouter02 (chain-specific, set at initialize)
    address private SWAP_ROUTER;

    // --- Reentrancy Guard ---
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;
    uint256 private _status = _NOT_ENTERED;

    // --- Roles ---
    /// @notice Admin address
    address public admin;
    /// @notice Vault address
    address public vault;

    // --- Config ---
    /// @notice Target pool
    address public pool;
    /// @notice Pool token0
    address public token0;
    /// @notice Pool token1
    address public token1;
    /// @notice Fee tier
    uint24 public feeTier;
    /// @notice Lower tick
    int24 public tickLower;
    /// @notice Upper tick
    int24 public tickUpper;
    /// @notice Allowed slippage in bps
    uint16 public slippageBps;
    /// @notice TWAP observation window (seconds). Uses spot price when 0
    uint32 public twapWindowSeconds;
    /// @notice Token ID of the minted position
    uint256 public positionTokenId;
    /// @notice Current liquidity
    uint128 public currentLiquidity;
    /// @notice Deadline offset in seconds (block.timestamp + deadlineSeconds). Set in initialize.
    uint256 public deadlineSeconds;

    /// @notice PositionManager address (chain-specific, set at initialize)
    address public positionManager;

    /// @notice Pause flag
    bool public paused;

    /// @notice Initialization guard (UUPS-safe; replaces previous constructor logic)
    bool private _initialized;

    /// @notice Override fee tier for rebalance swaps (0 = use pool.fee())
    /// @dev 2026-04-24: when LPing in a high-fee-tier pool (e.g. 0.3%), routing the
    ///      rebalance swap through a lower-tier pool (e.g. 0.05%) of the same pair cuts
    ///      cost on both swap fee and slippage. If left 0, pool.fee() is used as before.
    uint24 public swapFeeOverride;

    /// @notice RoleHub proxy address. Wired via reinitializeV2_setRoleHub.
    /// @dev    Slot 12 onwards (after slot 11 packed: positionManager + paused +
    ///         _initialized + swapFeeOverride). When zero, modifiers fall back
    ///         to legacy `admin` var.
    address public roleHub;

    /// @notice V2 reinitializer guard. Packed with roleHub at slot 12 offset 20.
    bool private _initializedV2;

    /// @notice Reserved storage for future upgrades. DO NOT re-order above fields.
    /// @dev 2026-04-24: consumed 1 slot (swapFeeOverride), so __gap reduced 48 -> 47
    /// @dev 2026-05-06: Hub-and-Spoke consumed 1 slot (roleHub + _initializedV2 packed); __gap 47 -> 46
    uint256[46] private __gap;

    // --- Events ---
    event VaultUpdated(address indexed vault);
    event ParamsUpdated(address indexed pool, uint24 feeTier, int24 tickLower, int24 tickUpper, uint16 slippageBps);
    event PositionManagerUsed(address indexed manager);
    event AdminUpdated(address indexed admin);
    event Minted(uint256 liquidity);
    event Collected(uint256 amount0, uint256 amount1);
    event Rebalanced(int24 tickLower, int24 tickUpper, uint256 liquidity);
    /// @notice Record token amounts sent to Vault
    event WithdrawnToVault(uint256 amount0, uint256 amount1);
    event Paused(address indexed caller);
    event Unpaused(address indexed caller);
    event EmergencyWithdraw(address indexed to, uint256 amount0, uint256 amount1);
    event DeadlineSecondsUpdated(uint256 secondsValue);
    event LiquidityAdded(uint256 indexed tokenId, uint128 addedLiquidity);
    /// @notice Emitted when the swap fee override is changed
    /// @param oldFee previous value (0 = unset)
    /// @param newFee new value (e.g. 0, 100, 500, 3000, 10000; 0 clears the override)
    event SwapFeeOverrideUpdated(uint24 oldFee, uint24 newFee);

    error NotAuthorized();
    error PausedError();
    error InvalidParams();
    error Reentrancy();

    /// @notice Admin only — pre-V2 falls back to legacy `admin` var.
    modifier onlyAdmin() {
        _checkAdmin();
        _;
    }

    /// @notice Admin or Vault only.
    modifier onlyAdminOrVault() {
        _checkAdminOrVault();
        _;
    }

    /// @notice Vault or Admin only (alias of onlyAdminOrVault).
    modifier onlyVaultOrAdmin() {
        _checkAdminOrVault();
        _;
    }

    /// @notice Pauser or admin only — for emergency response.
    /// @dev    Post-V2: PAUSER_ROLE OR DEFAULT_ADMIN_ROLE on Hub. Pre-V2: legacy
    ///         admin only. Allows Emergency hot-wallet (PAUSER) to pause Strategy
    ///         operations independently of admin.
    modifier onlyAdminOrPauser() {
        _checkAdminOrPauser();
        _;
    }

    function _checkAdmin() private view {
        address h = roleHub;
        if (h == address(0)) {
            if (msg.sender != admin) revert NotAuthorized();
        } else {
            if (!IRoleHub(h).hasRole(DEFAULT_ADMIN_ROLE, msg.sender)) revert NotAuthorized();
        }
    }

    function _checkAdminOrPauser() private view {
        address h = roleHub;
        if (h != address(0) && IRoleHub(h).hasRole(PAUSER_ROLE, msg.sender)) return;
        _checkAdmin();
    }

    function _checkAdminOrVault() private view {
        if (msg.sender == vault) return;
        _checkAdmin();
    }

    /// @notice Reverts when paused
    modifier whenNotPaused() {
        if (paused) revert PausedError();
        _;
    }

    /// @notice Prevent reentrancy
    modifier nonReentrant() {
        if (_status == _ENTERED) revert Reentrancy();
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }

    /// @notice Empty constructor for the implementation contract (proxy storage is used instead).
    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {}

    /// @notice Initialize the strategy contract (called once on the proxy).
    function initialize(address admin_, address positionManager_, address swapRouter_) external {
        if (_initialized) revert InvalidParams();
        _initialized = true;
        if (admin_ == address(0) || positionManager_ == address(0) || swapRouter_ == address(0)) revert InvalidParams();
        admin = admin_;
        positionManager = positionManager_;
        SWAP_ROUTER = swapRouter_;
        deadlineSeconds = 300; // default 5 minutes (previously inline initializer)
    }

    /// @notice UUPS: only legacy admin (pre-V2) or UPGRADER_ROLE holder (post-V2) can upgrade.
    function _authorizeUpgrade(address) internal view override {
        address h = roleHub;
        if (h != address(0)) {
            if (!IRoleHub(h).hasRole(UPGRADER_ROLE, msg.sender)) revert NotAuthorized();
            return;
        }
        if (msg.sender != admin) revert NotAuthorized();
    }

    /// @notice V2 reinitializer — wires this proxy to a RoleHub.
    function reinitializeV2_setRoleHub(address newRoleHub) external {
        if (_initializedV2) revert InvalidParams();
        if (msg.sender != admin) revert NotAuthorized();
        if (newRoleHub == address(0)) revert InvalidParams();
        _initializedV2 = true;
        roleHub = newRoleHub;
    }

    // --- Admin setup ---
    /// @notice Update admin address
    function setAdmin(address newAdmin) external onlyAdmin {
        if (newAdmin == address(0)) revert InvalidParams();
        admin = newAdmin;
        emit AdminUpdated(newAdmin);
    }

    /// @notice Set the Vault (admin only)
    function setVault(address vault_) external onlyAdmin {
        if (vault_ == address(0)) revert InvalidParams();
        vault = vault_;
        emit VaultUpdated(vault_);
    }

    /// @notice Set pool, range, slippage, and TWAP window
    function setParams(
        address pool_,
        uint24 feeTier_,
        int24 tickLower_,
        int24 tickUpper_,
        uint16 slippageBps_,
        uint32 twapWindowSeconds_
    ) external onlyAdminOrVault {
        if (pool_ == address(0)) revert InvalidParams();
        if (tickLower_ >= tickUpper_) revert InvalidParams();
        int24 ts = IUniswapV3Pool(pool_).tickSpacing();
        if (tickLower_ % ts != 0 || tickUpper_ % ts != 0) revert InvalidParams();
        pool = pool_;
        token0 = IUniswapV3Pool(pool_).token0();
        token1 = IUniswapV3Pool(pool_).token1();
        feeTier = feeTier_;
        tickLower = tickLower_;
        tickUpper = tickUpper_;
        slippageBps = slippageBps_;
        twapWindowSeconds = twapWindowSeconds_;
        emit ParamsUpdated(pool_, feeTier_, tickLower_, tickUpper_, slippageBps_);
        emit PositionManagerUsed(positionManager);
    }

    /// @notice Pause the strategy
    /// @notice Pause the strategy. Callable by PAUSER_ROLE OR DEFAULT_ADMIN_ROLE.
    function pause() external onlyAdminOrPauser {
        paused = true;
        emit Paused(msg.sender);
    }

    /// @notice Unpause the strategy (callable from Vault as well, or by PAUSER/admin).
    function unpause() external onlyAdminOrVault {
        paused = false;
        emit Unpaused(msg.sender);
    }

    /// @notice Set deadline offset in seconds (minimum 60s)
    function setDeadlineSeconds(uint256 seconds_) external onlyAdmin {
        if (seconds_ < 60) revert InvalidParams();
        deadlineSeconds = seconds_;
        emit DeadlineSecondsUpdated(seconds_);
    }

    /// @notice Set the fee tier used for rebalance swaps (or 0 to use the LP pool's own fee)
    /// @dev Allowed values: 0 (= use pool.fee()), 100 (0.01%), 500 (0.05%), 3000 (0.30%), 10000 (1.00%)
    ///      Example: LPing in a 0.30% pool but wanting only the rebalance swap to route
    ///      through a 0.05% pool -> call setSwapFeeOverride(500). Large cost saving on
    ///      both swap fee and slippage.
    /// @dev Safety: the swap reverts if no pool exists for that pair at that fee tier.
    ///      Verify beforehand via Uniswap V3 Factory.getPool(token0, token1, newFee).
    function setSwapFeeOverride(uint24 newFee) external onlyAdmin {
        if (newFee != 0 && newFee != 100 && newFee != 500 && newFee != 3000 && newFee != 10000) {
            revert InvalidParams();
        }
        emit SwapFeeOverrideUpdated(swapFeeOverride, newFee);
        swapFeeOverride = newFee;
    }

    /// @notice Return token0/token1 balances held by Strategy (including LP position value + uncollected fees)
    /// @dev Including uncollected LP fees (tokensOwed) in TVL prevents free-rider attacks
    ///      (fee dilution) from deposits made just before fee collection
    function getBalances() external view returns (uint256 amount0, uint256 amount1) {
        amount0 = IERC20Minimal(token0).balanceOf(address(this));
        amount1 = IERC20Minimal(token1).balanceOf(address(this));
        // If an LP position exists, add the token amounts in the position and uncollected fees
        if (positionTokenId != 0 && currentLiquidity > 0 && pool != address(0)) {
            (uint256 pos0, uint256 pos1) = _getPositionAmounts();
            amount0 += pos0;
            amount1 += pos1;
            // Add uncollected LP fees (tokensOwed) to TVL (separated into helper to avoid stack-too-deep)
            (uint128 owed0, uint128 owed1) = _getTokensOwed(positionTokenId);
            amount0 += uint256(owed0);
            amount1 += uint256(owed1);
        }
    }

    /// @notice Get uncollected LP fees (extracted to separate function to avoid stack-too-deep)
    function _getTokensOwed(uint256 tokenId) internal view returns (uint128 owed0, uint128 owed1) {
        try INonfungiblePositionManager(positionManager).positions(tokenId)
            returns (uint96, address, address, address, uint24, int24, int24, uint128,
                     uint256, uint256, uint128 o0, uint128 o1)
        {
            owed0 = o0;
            owed1 = o1;
        } catch {}
    }

    /// @notice Calculate estimated token0/token1 amounts in the current LP position
    /// @dev Uses TWAP price to prevent share price distortion via spot price manipulation.
    ///      Falls back to spot price when twapWindowSeconds == 0.
    ///      References actual NFPM ticks to prevent TVL inflation from setParams/LP desync
    function _getPositionAmounts() internal view returns (uint256 amount0, uint256 amount1) {
        uint160 sqrtPriceX96;
        if (twapWindowSeconds > 0) {
            // Use TWAP sqrtPrice (resistant to spot manipulation)
            int24 twapTick = _consultTwap(twapWindowSeconds);
            sqrtPriceX96 = TickMathLib.getSqrtRatioAtTick(twapTick);
        } else {
            // fallback: spot price
            (sqrtPriceX96,,,,,,) = IUniswapV3Pool(pool).slot0();
        }
        // Default to stored ticks, then override with actual NFPM ticks (prevent desync)
        int24 tL = tickLower;
        int24 tU = tickUpper;
        if (positionTokenId != 0) {
            try INonfungiblePositionManager(positionManager).positions(positionTokenId)
                returns (uint96, address, address, address, uint24, int24 lo, int24 hi,
                         uint128, uint256, uint256, uint128, uint128)
            { if (lo < hi) { tL = lo; tU = hi; } } catch {}
        }
        uint160 sqrtRatioAX96 = TickMathLib.getSqrtRatioAtTick(tL);
        uint160 sqrtRatioBX96 = TickMathLib.getSqrtRatioAtTick(tU);
        (amount0, amount1) = LiquidityAmounts.getAmountsForLiquidity(
            sqrtPriceX96, sqrtRatioAX96, sqrtRatioBX96, currentLiquidity
        );
    }

    /// @notice Get TWAP tick (falls back to spot on observe failure)
    function _consultTwap(uint32 secondsAgo) internal view returns (int24 tick) {
        uint32[] memory secondsAgos = new uint32[](2);
        secondsAgos[0] = secondsAgo;
        secondsAgos[1] = 0;
        try IUniswapV3Pool(pool).observe(secondsAgos)
            returns (int56[] memory tickCumulatives, uint160[] memory)
        {
            int56 delta = tickCumulatives[1] - tickCumulatives[0];
            tick = int24(delta / int56(uint56(secondsAgo)));
            if (delta < 0 && (delta % int56(uint56(secondsAgo)) != 0)) tick--;
        } catch {
            (, tick,,,,,) = IUniswapV3Pool(pool).slot0();
        }
    }

    /// @notice Emergency withdraw: remove all liquidity and send to specified address
    function emergencyWithdraw(address to) external onlyVaultOrAdmin nonReentrant returns (uint256 amount0, uint256 amount1) {
        if (to == address(0)) revert InvalidParams();
        // Destination restricted to the Vault (2026-05, non-custodial hardening):
        // an emergency unwind returns funds to the Vault for proportional user
        // redemption. It cannot send the LP position to an arbitrary address.
        if (to != vault) revert NotAuthorized();
        paused = true; // Auto-pause to prevent keeper from re-funding immediately after emergency
        uint256 tokenId = positionTokenId;

        if (tokenId != 0 && currentLiquidity > 0) {
            // Emergency: use immediate deadline, no slippage protection for speed
            INonfungiblePositionManager(positionManager).decreaseLiquidity(
                INonfungiblePositionManager.DecreaseLiquidityParams({
                    tokenId: tokenId,
                    liquidity: currentLiquidity,
                    amount0Min: 0,
                    amount1Min: 0,
                    deadline: block.timestamp + deadlineSeconds
                })
            );
            INonfungiblePositionManager(positionManager).collect(
                INonfungiblePositionManager.CollectParams({
                    tokenId: tokenId,
                    recipient: address(this),
                    amount0Max: type(uint128).max,
                    amount1Max: type(uint128).max
                })
            );
            currentLiquidity = 0;
            positionTokenId = 0;
            INonfungiblePositionManager(positionManager).burn(tokenId);
        }

        amount0 = IERC20Minimal(token0).balanceOf(address(this));
        amount1 = IERC20Minimal(token1).balanceOf(address(this));
        if (amount0 > 0) _safeTransfer(token0, to, amount0);
        if (amount1 > 0) _safeTransfer(token1, to, amount1);

        emit EmergencyWithdraw(to, amount0, amount1);
    }

    // --- Uniswap v3 actions (skeleton) ---
    /// @notice Mint a new position with held tokens
    /// @dev In MVP, amount/min are caller-specified; price determination is off-chain
    function mintPosition(uint256 amount0Desired, uint256 amount1Desired)
        external
        onlyVaultOrAdmin
        whenNotPaused
        nonReentrant
        returns (uint256 liquidity)
    {
        // Bug B: Prevent double-mint when an existing position is still active
        if (positionTokenId != 0 && currentLiquidity > 0) revert InvalidParams();
        liquidity = _mintPosition(amount0Desired, amount1Desired);
    }

    /// @notice Collect fees from the last minted position
    function collectFees() external onlyVaultOrAdmin whenNotPaused nonReentrant returns (uint256 amount0, uint256 amount1) {
        uint256 tokenId = positionTokenId;
        if (tokenId == 0) revert InvalidParams();

        INonfungiblePositionManager.CollectParams memory params = INonfungiblePositionManager.CollectParams({
            tokenId: tokenId,
            recipient: address(this),
            amount0Max: type(uint128).max,
            amount1Max: type(uint128).max
        });

        (amount0, amount1) = INonfungiblePositionManager(positionManager).collect(params);
        emit Collected(amount0, amount1);
    }

    /// @notice Transfer a token out of the Strategy. Callable ONLY by the Vault.
    /// @dev Used by the Vault's fee-collection / referral-accrual flow.
    ///      2026-05 non-custodial hardening: admin access removed. Previously the
    ///      admin could sweep pool tokens (the LP principal once burned to idle)
    ///      to an arbitrary address; now only the Vault contract can call this.
    function sweepToken(address token, uint256 amount, address to) external {
        if (msg.sender != vault) revert NotAuthorized();
        if (amount == 0 || to == address(0)) revert InvalidParams();
        _safeTransfer(token, to, amount);
    }

    /// @notice Return idle token balances (not yet minted into LP) to Vault
    /// @dev Used when redeem is requested after fundStrategy but before mintPosition
    function sweepIdleToVault() external onlyVaultOrAdmin {
        if (vault == address(0)) revert InvalidParams();
        uint256 bal0 = IERC20Minimal(token0).balanceOf(address(this));
        uint256 bal1 = IERC20Minimal(token1).balanceOf(address(this));
        if (bal0 > 0) _safeTransfer(token0, vault, bal0);
        if (bal1 > 0) _safeTransfer(token1, vault, bal1);
    }

    /// @notice Remove specified liquidity and send tokens to Vault
    /// @dev amount0Min/amount1Min specify slippage tolerance for the decrease
    function withdrawToVault(uint128 liquidity, uint256 amount0Min, uint256 amount1Min)
        external
        onlyVaultOrAdmin
        nonReentrant
        returns (uint256 amount0, uint256 amount1)
    {
        uint256 tokenId = positionTokenId;
        if (tokenId == 0 || liquidity == 0) revert InvalidParams();

        INonfungiblePositionManager(positionManager).decreaseLiquidity(
            INonfungiblePositionManager.DecreaseLiquidityParams({
                tokenId: tokenId,
                liquidity: liquidity,
                amount0Min: amount0Min,
                amount1Min: amount1Min,
                deadline: block.timestamp + deadlineSeconds
            })
        );
        (amount0, amount1) = INonfungiblePositionManager(positionManager).collect(
            INonfungiblePositionManager.CollectParams({
                tokenId: tokenId,
                recipient: address(this),
                amount0Max: type(uint128).max,
                amount1Max: type(uint128).max
            })
        );

        if (currentLiquidity > liquidity) {
            currentLiquidity -= liquidity;
        } else {
            currentLiquidity = 0;
            // On full withdrawal, burn the old NFT to keep state clean
            // (leftover 0-liquidity NFTs can cause NFPM/estimateGas inconsistencies in subsequent mintPosition calls)
            positionTokenId = 0;
            INonfungiblePositionManager(positionManager).burn(tokenId);
        }

        uint256 bal0 = IERC20Minimal(token0).balanceOf(address(this));
        uint256 bal1 = IERC20Minimal(token1).balanceOf(address(this));
        if (bal0 > 0) _safeTransfer(token0, vault, bal0);
        if (bal1 > 0) _safeTransfer(token1, vault, bal1);

        emit WithdrawnToVault(bal0, bal1);
    }

    /// @notice Rebalance by changing the tick range
    /// @dev Simplified flow: decrease -> collect -> re-mint.
    /// @dev The trailing two args are retained for ABI compatibility with the Vault call
    ///      site but are intentionally unused: the decrease floor is computed on-chain from
    ///      the position's TWAP-valued amounts (see _getPositionAmounts) so it cannot be
    ///      weakened by a caller-supplied value. Changing the signature would require a
    ///      Vault upgrade too, so the params are kept and ignored.
    function rebalance(int24 newTickLower, int24 newTickUpper, uint256 /* amount0Min */, uint256 /* amount1Min */)
        external
        onlyVaultOrAdmin
        whenNotPaused
        nonReentrant
        returns (uint256 liquidity)
    {
        // Simplified flow: decrease -> collect -> re-mint with current balances.
        uint256 tokenId = positionTokenId;
        if (tokenId != 0 && currentLiquidity > 0) {
            // On-chain MEV/manipulation protection for the burn: floor the decrease output
            // at the position's TWAP-valued amounts minus slippageBps. If spot (slot0) is
            // manipulated away from TWAP, decreaseLiquidity returns skewed amounts and one
            // side falls below its floor -> the whole rebalance reverts (position untouched).
            // Falls back to no floor (0/0) only when twapWindowSeconds == 0 (no TWAP source).
            uint256 burnMin0;
            uint256 burnMin1;
            if (twapWindowSeconds > 0) {
                (uint256 twapAmt0, uint256 twapAmt1) = _getPositionAmounts();
                burnMin0 = (twapAmt0 * (10_000 - slippageBps)) / 10_000;
                burnMin1 = (twapAmt1 * (10_000 - slippageBps)) / 10_000;
            }
            INonfungiblePositionManager(positionManager).decreaseLiquidity(
                INonfungiblePositionManager.DecreaseLiquidityParams({
                    tokenId: tokenId,
                    liquidity: currentLiquidity,
                    amount0Min: burnMin0,
                    amount1Min: burnMin1,
                    deadline: block.timestamp + deadlineSeconds
                })
            );
            INonfungiblePositionManager(positionManager).collect(
                INonfungiblePositionManager.CollectParams({
                    tokenId: tokenId,
                    recipient: address(this),
                    amount0Max: type(uint128).max,
                    amount1Max: type(uint128).max
                })
            );
            currentLiquidity = 0;
            // Bug A+D: Clear and burn old NFT.
            // Prevents addLiquidity() from incorrectly adding to the old range after single-sided sweep,
            // and prevents 0-liquidity NFTs from accumulating in NFPM.
            positionTokenId = 0;
            INonfungiblePositionManager(positionManager).burn(tokenId);
        }

        tickLower = newTickLower;
        tickUpper = newTickUpper;

        uint256 amount0 = IERC20Minimal(token0).balanceOf(address(this));
        uint256 amount1 = IERC20Minimal(token1).balanceOf(address(this));
        if (amount0 == 0 && amount1 == 0) {
            emit Rebalanced(newTickLower, newTickUpper, 0);
            return 0;
        }

        // Optimal swap: align token ratio to the new range before minting
        // (without swap, mint only consumes one side, leaving the rest idle in Strategy)
        {
            (uint160 sqrtPriceX96,,,,,,) = IUniswapV3Pool(pool).slot0();
            (bool zeroForOne, uint256 swapAmt) = _calcOptimalSwapParams(
                amount0, amount1, sqrtPriceX96, newTickLower, newTickUpper
            );
            if (swapAmt > 0) {
                address tokenIn  = zeroForOne ? token0 : token1;
                address tokenOut = zeroForOne ? token1 : token0;
                _safeApprove(tokenIn, SWAP_ROUTER, swapAmt);
                // Slippage floor referenced to TWAP price, not spot slot0: a slot0 value
                // manipulated within the tx must not be able to loosen minOut. Pricing the
                // floor off TWAP means a manipulated swap cannot settle worse than
                // (TWAP quote * (1 - slippageBps)) -> it reverts and the position is untouched.
                // Falls back to spot only when twapWindowSeconds == 0 (no TWAP source).
                uint160 refSqrt = sqrtPriceX96;
                if (twapWindowSeconds > 0) {
                    refSqrt = TickMathLib.getSqrtRatioAtTick(_consultTwap(twapWindowSeconds));
                }
                uint256 expectedOut = _quoteExactInputFromSqrtPrice(zeroForOne, swapAmt, refSqrt);
                uint256 minOut = (expectedOut * (10_000 - slippageBps)) / 10_000;
                IStrategySwapRouter(SWAP_ROUTER).exactInputSingle(IStrategySwapRouter.ExactInputSingleParams({
                    tokenIn: tokenIn,
                    tokenOut: tokenOut,
                    fee: swapFeeOverride > 0 ? swapFeeOverride : IUniswapV3Pool(pool).fee(),
                    recipient: address(this),
                    amountIn: swapAmt,
                    amountOutMinimum: minOut,
                    sqrtPriceLimitX96: 0
                }));
                _safeApprove(tokenIn, SWAP_ROUTER, 0);
                amount0 = IERC20Minimal(token0).balanceOf(address(this));
                amount1 = IERC20Minimal(token1).balanceOf(address(this));
            }
        }

        // When only one token is available and the new range spans the current price,
        // mint would result in 0 liquidity and revert. In this case, send tokens back to Vault
        // and let the Keeper's next cycle (autoFund) reinvest them.
        {
            (, int24 currentTick,,,,,) = IUniswapV3Pool(pool).slot0();
            bool inRange = currentTick >= newTickLower && currentTick < newTickUpper;
            bool onlyToken0 = amount0 > 0 && amount1 == 0;
            bool onlyToken1 = amount0 == 0 && amount1 > 0;
            if (inRange && (onlyToken0 || onlyToken1)) {
                if (amount0 > 0) _safeTransfer(token0, vault, amount0);
                if (amount1 > 0) _safeTransfer(token1, vault, amount1);
                emit Rebalanced(newTickLower, newTickUpper, 0);
                return 0;
            }
        }

        // Return surplus tokens to Vault after minting
        liquidity = _mintPosition(amount0, amount1);
        {
            uint256 remaining0 = IERC20Minimal(token0).balanceOf(address(this));
            uint256 remaining1 = IERC20Minimal(token1).balanceOf(address(this));
            if (remaining0 > 0) _safeTransfer(token0, vault, remaining0);
            if (remaining1 > 0) _safeTransfer(token1, vault, remaining1);
        }
        emit Rebalanced(newTickLower, newTickUpper, liquidity);
    }

    /// @notice Expected output for exactInput swap at the given sqrtPriceX96 (ignores slippage/fees)
    /// @dev Used only as a reference price for slippage checks; swap fees are absorbed by slippageBps.
    function _quoteExactInputFromSqrtPrice(bool zeroForOne, uint256 amountIn, uint160 sqrtPriceX96)
        internal
        pure
        returns (uint256 amountOut)
    {
        uint256 Q96 = LiquidityAmounts.Q96;
        if (zeroForOne) {
            // token0 -> token1: out ≈ in * (sqrtP/Q96)^2
            uint256 tmp = FullMathLib.mulDiv(amountIn, uint256(sqrtPriceX96), Q96);
            amountOut = FullMathLib.mulDiv(tmp, uint256(sqrtPriceX96), Q96);
        } else {
            // token1 -> token0: out ≈ in * (Q96/sqrtP)^2
            uint256 tmp = FullMathLib.mulDiv(amountIn, Q96, uint256(sqrtPriceX96));
            amountOut = FullMathLib.mulDiv(tmp, Q96, uint256(sqrtPriceX96));
        }
    }

    /// @notice Calculate optimal swap amount and direction (internal helper)
    /// @return zeroForOne true=swap token0->token1, false=swap token1->token0
    /// @return swapAmount Amount to swap (0=no swap needed)
    function _calcOptimalSwapParams(
        uint256 bal0,
        uint256 bal1,
        uint160 sqrtPriceX96,
        int24 tLower,
        int24 tUpper
    ) internal pure returns (bool zeroForOne, uint256 swapAmount) {
        uint160 sqrtPLower = TickMathLib.getSqrtRatioAtTick(tLower);
        uint160 sqrtPUpper = TickMathLib.getSqrtRatioAtTick(tUpper);

        // Below range: token1 is not needed -> swap all token1 to token0
        if (sqrtPriceX96 <= sqrtPLower) {
            return (false, bal1);
        }
        // Above range: token0 is not needed -> swap all token0 to token1
        if (sqrtPriceX96 >= sqrtPUpper) {
            return (true, bal0);
        }

        // In range: calculate optimal swap amount
        uint128 liq0 = bal0 > 0 ? LiquidityAmounts.getLiquidityForAmount0(sqrtPriceX96, sqrtPUpper, bal0) : 0;
        uint128 liq1 = bal1 > 0 ? LiquidityAmounts.getLiquidityForAmount1(sqrtPLower, sqrtPriceX96, bal1) : 0;
        if (liq0 == liq1) return (false, 0);

        // Scale down by >> 48 to prevent overflow
        uint256 sp  = uint256(sqrtPriceX96) >> 48;
        uint256 spL = uint256(sqrtPLower)   >> 48;
        uint256 spU = uint256(sqrtPUpper)   >> 48;
        // D = 2*spU*sp - spU*spL - sp*sp (always positive)
        uint256 D = 2 * spU * sp - spU * spL - sp * sp;
        if (D == 0) return (false, 0);

        if (liq0 < liq1) {
            // Excess token1: swap token1 -> token0
            uint256 amount1For0 = LiquidityAmounts.getAmount1ForLiquidity(sqrtPLower, sqrtPriceX96, liq0);
            if (amount1For0 >= bal1) return (false, 0);
            uint256 excess1 = bal1 - amount1For0;
            uint256 num = sp * (spU - sp);
            swapAmount = FullMathLib.mulDiv(excess1, num, D);
            return (false, swapAmount > bal1 ? bal1 : swapAmount);
        } else {
            // Excess token0: swap token0 -> token1
            uint256 amount0For1 = LiquidityAmounts.getAmount0ForLiquidity(sqrtPriceX96, sqrtPUpper, liq1);
            if (amount0For1 >= bal0) return (true, 0);
            uint256 excess0 = bal0 - amount0For1;
            uint256 num = spU * (sp - spL);
            swapAmount = FullMathLib.mulDiv(excess0, num, D);
            return (true, swapAmount > bal0 ? bal0 : swapAmount);
        }
    }

    /// @notice Add Strategy's idle balance to the existing position (for compounding)
    function addLiquidity()
        external
        onlyVaultOrAdmin
        whenNotPaused
        nonReentrant
        returns (uint128 addedLiquidity, uint256 amount0, uint256 amount1)
    {
        uint256 tokenId = positionTokenId;
        if (tokenId == 0) revert InvalidParams(); // Skip when no position exists

        uint256 idle0 = IERC20Minimal(token0).balanceOf(address(this));
        uint256 idle1 = IERC20Minimal(token1).balanceOf(address(this));
        if (idle0 == 0 && idle1 == 0) return (0, 0, 0);

        // Optimal swap: align idle token ratio to the LP range
        {
            (uint160 sqrtPriceX96,,,,,,) = IUniswapV3Pool(pool).slot0();
            (bool zeroForOne, uint256 swapAmt) = _calcOptimalSwapParams(
                idle0, idle1, sqrtPriceX96, tickLower, tickUpper
            );
            if (swapAmt > 0) {
                address tokenIn  = zeroForOne ? token0 : token1;
                address tokenOut = zeroForOne ? token1 : token0;
                _safeApprove(tokenIn, SWAP_ROUTER, swapAmt);
                // Slippage floor referenced to TWAP price, not spot slot0: a manipulated
                // slot0 must not be able to loosen minOut. expectedOut is computed in
                // tokenOut units (the earlier `swapAmt * 98/100` bug — which compared
                // tokenIn units — stays fixed). Falls back to spot when twapWindowSeconds == 0.
                uint160 refSqrt = sqrtPriceX96;
                if (twapWindowSeconds > 0) {
                    refSqrt = TickMathLib.getSqrtRatioAtTick(_consultTwap(twapWindowSeconds));
                }
                uint256 expectedOut = _quoteExactInputFromSqrtPrice(zeroForOne, swapAmt, refSqrt);
                // [DSP fix] use the configured slippageBps (same as rebalance) instead of a
                // hardcoded 2%, so a single slippage policy governs all strategy swaps.
                uint256 minOut = (expectedOut * (10_000 - slippageBps)) / 10_000;
                IStrategySwapRouter(SWAP_ROUTER).exactInputSingle(IStrategySwapRouter.ExactInputSingleParams({
                    tokenIn: tokenIn,
                    tokenOut: tokenOut,
                    fee: swapFeeOverride > 0 ? swapFeeOverride : IUniswapV3Pool(pool).fee(),
                    recipient: address(this),
                    amountIn: swapAmt,
                    amountOutMinimum: minOut,
                    sqrtPriceLimitX96: 0
                }));
                _safeApprove(tokenIn, SWAP_ROUTER, 0);
                // Re-fetch balances after swap
                idle0 = IERC20Minimal(token0).balanceOf(address(this));
                idle1 = IERC20Minimal(token1).balanceOf(address(this));
            }
        }

        if (idle0 > 0) { _safeApprove(token0, positionManager, 0); _safeApprove(token0, positionManager, idle0); }
        if (idle1 > 0) { _safeApprove(token1, positionManager, 0); _safeApprove(token1, positionManager, idle1); }

        // For compound, increaseLiquidity sets amount0Min/amount1Min to 0.
        // When idle token ratio differs from current pool price ratio, Uniswap only
        // uses one token, causing slippage checks to always fail.
        (uint128 addedLiq, uint256 usedAmount0, uint256 usedAmount1) = INonfungiblePositionManager(positionManager).increaseLiquidity(
            INonfungiblePositionManager.IncreaseLiquidityParams({
                tokenId: tokenId,
                amount0Desired: idle0,
                amount1Desired: idle1,
                amount0Min: 0,
                amount1Min: 0,
                deadline: block.timestamp + deadlineSeconds
            })
        );
        currentLiquidity += addedLiq;

        // addedLiq == 0 occurs when only one-sided tokens are available in range.
        // NFPM consumes nothing, so tokens remain in Strategy.
        // Return to Vault and let fundVaultIdleIfNeeded swap and compound in the next cycle.
        if (addedLiq == 0) {
            _safeApprove(token0, positionManager, 0);
            _safeApprove(token1, positionManager, 0);
            uint256 bal0 = IERC20Minimal(token0).balanceOf(address(this));
            uint256 bal1 = IERC20Minimal(token1).balanceOf(address(this));
            if (bal0 > 0) _safeTransfer(token0, vault, bal0);
            if (bal1 > 0) _safeTransfer(token1, vault, bal1);
            return (0, 0, 0);
        }

        addedLiquidity = addedLiq;
        amount0 = usedAmount0;
        amount1 = usedAmount1;
        emit LiquidityAdded(tokenId, addedLiquidity);
    }

    /// @notice Internal position minting
    function _mintPosition(uint256 amount0Desired, uint256 amount1Desired) internal returns (uint256 liquidity) {
        // Approve tokens to the position manager with safe reset pattern.
        if (amount0Desired > 0) {
            _safeApprove(token0, positionManager, 0);
            _safeApprove(token0, positionManager, amount0Desired);
        }
        if (amount1Desired > 0) {
            _safeApprove(token1, positionManager, 0);
            _safeApprove(token1, positionManager, amount1Desired);
        }

        // Calculate minimum amounts based on current price vs tick range.
        // When in-range, the LP ratio is determined by the pool price, so applying
        // slippageBps to full desired amounts causes "Price slippage check" when
        // the burned position had a different ratio than the new range requires.
        // Slippage protection for the user is provided by the withdrawal step.
        (, int24 currentTick_,,,,,) = IUniswapV3Pool(pool).slot0();
        uint256 amount0Min;
        uint256 amount1Min;
        if (currentTick_ < tickLower) {
            // Above current price: only token0 consumed
            amount0Min = (amount0Desired * (10_000 - slippageBps)) / 10_000;
            amount1Min = 0;
        } else if (currentTick_ >= tickUpper) {
            // Below current price: only token1 consumed
            amount0Min = 0;
            amount1Min = (amount1Desired * (10_000 - slippageBps)) / 10_000;
        } else {
            // In range: ratio is pool-determined, cannot pre-predict the limiting token
            amount0Min = 0;
            amount1Min = 0;
        }

        INonfungiblePositionManager.MintParams memory params = INonfungiblePositionManager.MintParams({
            token0: token0,
            token1: token1,
            fee: feeTier,
            tickLower: tickLower,
            tickUpper: tickUpper,
            amount0Desired: amount0Desired,
            amount1Desired: amount1Desired,
            amount0Min: amount0Min,
            amount1Min: amount1Min,
            recipient: address(this),
            deadline: block.timestamp + deadlineSeconds
        });

        (uint256 tokenId, uint128 liq,,) = INonfungiblePositionManager(positionManager).mint(params);
        positionTokenId = tokenId;
        liquidity = uint256(liq);
        currentLiquidity = liq;
        // Read back actual NFPM ticks after minting to sync stored ticks
        // (prevents desync when ticks set via setParams differ from NFPM)
        try INonfungiblePositionManager(positionManager).positions(tokenId)
            returns (uint96, address, address, address, uint24, int24 tL, int24 tU,
                     uint128, uint256, uint256, uint128, uint128)
        { if (tL < tU) { tickLower = tL; tickUpper = tU; } } catch {}
        emit Minted(liquidity);
    }

    /// @notice Safe wrapper for ERC20 approve
    function _safeApprove(address token, address spender, uint256 amount) internal {
        (bool ok, bytes memory data) =
            token.call(abi.encodeWithSelector(IERC20Minimal.approve.selector, spender, amount));
        if (!ok) revert InvalidParams();
        if (data.length > 0 && !abi.decode(data, (bool))) revert InvalidParams();
    }

    /// @notice Safe wrapper for ERC20 transfer
    function _safeTransfer(address token, address to, uint256 amount) internal {
        (bool ok, bytes memory data) =
            token.call(abi.encodeWithSelector(IERC20Minimal.transfer.selector, to, amount));
        if (!ok) revert InvalidParams();
        if (data.length > 0 && !abi.decode(data, (bool))) revert InvalidParams();
    }
}

/// @notice 512-bit precision mulDiv (Uniswap V3 FullMath -- Strategy-specific)
library FullMathLib {
    function mulDiv(uint256 a, uint256 b, uint256 denominator) internal pure returns (uint256 result) {
        unchecked {
            uint256 prod0;
            uint256 prod1;
            assembly {
                let mm := mulmod(a, b, not(0))
                prod0 := mul(a, b)
                prod1 := sub(sub(mm, prod0), lt(mm, prod0))
            }
            if (prod1 == 0) {
                require(denominator > 0, "DIV0");
                assembly {
                    result := div(prod0, denominator)
                }
                return result;
            }
            require(denominator > prod1, "OVERFLOW");
            uint256 remainder;
            assembly {
                remainder := mulmod(a, b, denominator)
                prod1 := sub(prod1, gt(remainder, prod0))
                prod0 := sub(prod0, remainder)
            }
            uint256 twos = denominator & (~denominator + 1);
            assembly {
                denominator := div(denominator, twos)
                prod0 := div(prod0, twos)
                twos := add(div(sub(0, twos), twos), 1)
            }
            prod0 |= prod1 * twos;
            uint256 inv = (3 * denominator) ^ 2;
            inv *= 2 - denominator * inv;
            inv *= 2 - denominator * inv;
            inv *= 2 - denominator * inv;
            inv *= 2 - denominator * inv;
            inv *= 2 - denominator * inv;
            inv *= 2 - denominator * inv;
            result = prod0 * inv;
            return result;
        }
    }
}

/// @notice Simplified Uniswap V3 TickMath implementation (Strategy-specific)
library TickMathLib {
    int24 internal constant MIN_TICK = -887272;
    int24 internal constant MAX_TICK = -MIN_TICK;
    uint160 internal constant MIN_SQRT_RATIO = 4295128739;
    uint160 internal constant MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342;

    function getSqrtRatioAtTick(int24 tick) internal pure returns (uint160 sqrtPriceX96) {
        uint256 absTick = uint256(int256(tick < 0 ? -tick : tick));
        require(absTick <= uint256(int256(MAX_TICK)), "T");

        uint256 ratio = absTick & 0x1 != 0
            ? 0xfffcb933bd6fad37aa2d162d1a594001
            : 0x100000000000000000000000000000000;
        if (absTick & 0x2 != 0) ratio = (ratio * 0xfff97272373d413259a46990580e213a) >> 128;
        if (absTick & 0x4 != 0) ratio = (ratio * 0xfff2e50f5f656932ef12357cf3c7fdcc) >> 128;
        if (absTick & 0x8 != 0) ratio = (ratio * 0xffe5caca7e10e4e61c3624eaa0941cd0) >> 128;
        if (absTick & 0x10 != 0) ratio = (ratio * 0xffcb9843d60f6159c9db58835c926644) >> 128;
        if (absTick & 0x20 != 0) ratio = (ratio * 0xff973b41fa98c081472e6896dfb254c0) >> 128;
        if (absTick & 0x40 != 0) ratio = (ratio * 0xff2ea16466c96a3843ec78b326b52861) >> 128;
        if (absTick & 0x80 != 0) ratio = (ratio * 0xfe5dee046a99a2a811c461f1969c3053) >> 128;
        if (absTick & 0x100 != 0) ratio = (ratio * 0xfcbe86c7900a88aedcffc83b479aa3a4) >> 128;
        if (absTick & 0x200 != 0) ratio = (ratio * 0xf987a7253ac413176f2b074cf7815e54) >> 128;
        if (absTick & 0x400 != 0) ratio = (ratio * 0xf3392b0822b70005940c7a398e4b70f3) >> 128;
        if (absTick & 0x800 != 0) ratio = (ratio * 0xe7159475a2c29b7443b29c7fa6e889d9) >> 128;
        if (absTick & 0x1000 != 0) ratio = (ratio * 0xd097f3bdfd2022b8845ad8f792aa5825) >> 128;
        if (absTick & 0x2000 != 0) ratio = (ratio * 0xa9f746462d870fdf8a65dc1f90e061e5) >> 128;
        if (absTick & 0x4000 != 0) ratio = (ratio * 0x70d869a156d2a1b890bb3df62baf32f7) >> 128;
        if (absTick & 0x8000 != 0) ratio = (ratio * 0x31be135f97d08fd981231505542fcfa6) >> 128;
        if (absTick & 0x10000 != 0) ratio = (ratio * 0x9aa508b5b7a84e1c677de54f3e99bc9) >> 128;
        if (absTick & 0x20000 != 0) ratio = (ratio * 0x5d6af8dedb81196699c329225ee604) >> 128;
        if (absTick & 0x40000 != 0) ratio = (ratio * 0x2216e584f5fa1ea926041bedfe98) >> 128;
        if (absTick & 0x80000 != 0) ratio = (ratio * 0x48a170391f7dc42444e8fa2) >> 128;

        if (tick > 0) ratio = type(uint256).max / ratio;
        sqrtPriceX96 = uint160((ratio >> 32) + (ratio % (1 << 32) == 0 ? 0 : 1));
        require(sqrtPriceX96 >= MIN_SQRT_RATIO && sqrtPriceX96 < MAX_SQRT_RATIO, "R");
    }
}

/// @notice Uniswap V3 LiquidityAmounts -- library to compute token amounts from liquidity
library LiquidityAmounts {
    /// @dev 2^96 (FixedPoint96.Q96)
    uint256 internal constant Q96 = 0x1000000000000000000000000;

    /// @notice Compute liquidity from token0 amount (sqrtA < sqrtB)
    function getLiquidityForAmount0(
        uint160 sqrtRatioAX96,
        uint160 sqrtRatioBX96,
        uint256 amount0
    ) internal pure returns (uint128) {
        if (sqrtRatioAX96 > sqrtRatioBX96) (sqrtRatioAX96, sqrtRatioBX96) = (sqrtRatioBX96, sqrtRatioAX96);
        uint256 intermediate = FullMathLib.mulDiv(sqrtRatioAX96, sqrtRatioBX96, Q96);
        return uint128(FullMathLib.mulDiv(amount0, intermediate, sqrtRatioBX96 - sqrtRatioAX96));
    }

    /// @notice Compute liquidity from token1 amount (sqrtA < sqrtB)
    function getLiquidityForAmount1(
        uint160 sqrtRatioAX96,
        uint160 sqrtRatioBX96,
        uint256 amount1
    ) internal pure returns (uint128) {
        if (sqrtRatioAX96 > sqrtRatioBX96) (sqrtRatioAX96, sqrtRatioBX96) = (sqrtRatioBX96, sqrtRatioAX96);
        return uint128(FullMathLib.mulDiv(amount1, Q96, sqrtRatioBX96 - sqrtRatioAX96));
    }

    /// @notice Compute token0 amount from liquidity
    function getAmount0ForLiquidity(
        uint160 sqrtRatioAX96,
        uint160 sqrtRatioBX96,
        uint128 liquidity
    ) internal pure returns (uint256) {
        if (sqrtRatioAX96 > sqrtRatioBX96) (sqrtRatioAX96, sqrtRatioBX96) = (sqrtRatioBX96, sqrtRatioAX96);
        return FullMathLib.mulDiv(
            uint256(liquidity) << 96,
            sqrtRatioBX96 - sqrtRatioAX96,
            sqrtRatioBX96
        ) / sqrtRatioAX96;
    }

    /// @notice Compute token1 amount from liquidity
    function getAmount1ForLiquidity(
        uint160 sqrtRatioAX96,
        uint160 sqrtRatioBX96,
        uint128 liquidity
    ) internal pure returns (uint256) {
        if (sqrtRatioAX96 > sqrtRatioBX96) (sqrtRatioAX96, sqrtRatioBX96) = (sqrtRatioBX96, sqrtRatioAX96);
        return FullMathLib.mulDiv(liquidity, sqrtRatioBX96 - sqrtRatioAX96, Q96);
    }

    /// @notice Compute token0/token1 amounts from current price and range
    function getAmountsForLiquidity(
        uint160 sqrtRatioX96,
        uint160 sqrtRatioAX96,
        uint160 sqrtRatioBX96,
        uint128 liquidity
    ) internal pure returns (uint256 amount0, uint256 amount1) {
        if (sqrtRatioAX96 > sqrtRatioBX96) (sqrtRatioAX96, sqrtRatioBX96) = (sqrtRatioBX96, sqrtRatioAX96);
        if (sqrtRatioX96 <= sqrtRatioAX96) {
            amount0 = getAmount0ForLiquidity(sqrtRatioAX96, sqrtRatioBX96, liquidity);
        } else if (sqrtRatioX96 < sqrtRatioBX96) {
            amount0 = getAmount0ForLiquidity(sqrtRatioX96, sqrtRatioBX96, liquidity);
            amount1 = getAmount1ForLiquidity(sqrtRatioAX96, sqrtRatioX96, liquidity);
        } else {
            amount1 = getAmount1ForLiquidity(sqrtRatioAX96, sqrtRatioBX96, liquidity);
        }
    }
}
