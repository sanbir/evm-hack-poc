// SPDX-License-Identifier: BSD-3-Clause
pragma solidity 0.8.25;

import { WeightFunction } from "../Comptroller/Diamond/interfaces/IFacetBase.sol";

contract ComptrollerErrorReporter {
    /// @notice Thrown when You are already in the selected pool.
    error AlreadyInSelectedPool();

    /// @notice Thrown when One or more of your assets are not compatible with the selected pool.
    error IncompatibleBorrowedAssets();

    /// @notice Thrown when Switching to this pool would fail the liquidity check or lead to liquidation.
    error LiquidityCheckFailed(uint256 errorCode, uint256 shortfall);

    /// @notice Thrown when trying to call pool-specific methods on the Core Pool
    error InvalidOperationForCorePool();

    /// @notice Thrown when input array lengths do not match
    error ArrayLengthMismatch();

    /// @notice Thrown when market trying to add in a pool is not listed in the core pool
    error MarketNotListedInCorePool();

    /// @notice Thrown when market is not set in the _poolMarkets mapping
    error MarketConfigNotFound();

    /// @notice Thrown when borrowing is not allowed in the selected pool for a given market.
    error BorrowNotAllowedInPool();

    /// @notice Thrown when trying to remove a market that is not listed in the given pool.
    error PoolMarketNotFound(uint96 poolId, address vToken);

    /// @notice Thrown when a given pool ID does not exist
    error PoolDoesNotExist(uint96 poolId);

    /// @notice Thrown when the pool label is empty
    error EmptyPoolLabel();

    /// @notice Thrown when a vToken is already listed in the specified pool
    error MarketAlreadyListed(uint96 poolId, address vToken);

    /// @notice Thrown when an invalid weighting strategy is provided
    error InvalidWeightingStrategy(WeightFunction strategy);

    // @notice Thrown when no assets are requested for flash loan
    error NoAssetsRequested();

    // @notice Thrown when invalid flash loan parameters are provided
    error InvalidFlashLoanParams();

    // @notice Thrown when flash loan is not enabled on the vToken
    error FlashLoanNotEnabled();

    // @notice Thrown when the sender is not authorized to use flashloan onBehalfOf
    error SenderNotAuthorizedForFlashLoan(address sender);

    // @notice Thrown when the onBehalfOf didn't approve the contract that receives flashloan
    error NotAnApprovedDelegate();

    // @notice Thrown when executeOperation on the receiver contract fails
    error ExecuteFlashLoanFailed();

    // @notice Thrown when the requested amount is zero
    error InvalidAmount();

    // @notice Thrown when failing to create a debt position in mode 1
    error FailedToCreateDebtPosition();

    /// @notice Thrown when attempting to interact with an inactive pool
    error InactivePool(uint96 poolId);

    /// @notice Thrown when repayment amount is insufficient to cover the fee
    error NotEnoughRepayment(uint256 repaid, uint256 required);

    /// @notice Thrown when the vToken market is not listed
    error MarketNotListed(address vToken);

    /// @notice Thrown when flash loans are paused system-wide
    error FlashLoanPausedSystemWide();

    /// @notice Thrown when too many assets are requested in a single flash loan
    error TooManyAssetsRequested(uint256 requested, uint256 maximum);

    /// @notice Thrown when liquidationThreshold * liquidationIncentive >= 1e18, which would make liquidations
    ///         stop reducing (or even increase) the account shortfall
    error UnsafeLiquidationParams(uint256 liquidationThresholdMantissa, uint256 liquidationIncentiveMantissa);

    enum Error {
        NO_ERROR,
        UNAUTHORIZED,
        COMPTROLLER_MISMATCH,
        INSUFFICIENT_SHORTFALL,
        INSUFFICIENT_LIQUIDITY,
        INVALID_CLOSE_FACTOR,
        INVALID_COLLATERAL_FACTOR,
        INVALID_LIQUIDATION_INCENTIVE,
        MARKET_NOT_ENTERED, // no longer possible
        MARKET_NOT_LISTED,
        MARKET_ALREADY_LISTED,
        MATH_ERROR,
        NONZERO_BORROW_BALANCE,
        PRICE_ERROR,
        REJECTION,
        SNAPSHOT_ERROR,
        TOO_MANY_ASSETS,
        TOO_MUCH_REPAY,
        INSUFFICIENT_BALANCE_FOR_VAI,
        MARKET_NOT_COLLATERAL,
        INVALID_LIQUIDATION_THRESHOLD
    }

    enum FailureInfo {
        ACCEPT_ADMIN_PENDING_ADMIN_CHECK,
        ACCEPT_PENDING_IMPLEMENTATION_ADDRESS_CHECK,
        EXIT_MARKET_BALANCE_OWED,
        EXIT_MARKET_REJECTION,
        SET_CLOSE_FACTOR_OWNER_CHECK,
        SET_CLOSE_FACTOR_VALIDATION,
        SET_COLLATERAL_FACTOR_OWNER_CHECK,
        SET_COLLATERAL_FACTOR_NO_EXISTS,
        SET_COLLATERAL_FACTOR_VALIDATION,
        SET_COLLATERAL_FACTOR_WITHOUT_PRICE,
        SET_IMPLEMENTATION_OWNER_CHECK,
        SET_LIQUIDATION_INCENTIVE_OWNER_CHECK,
        SET_LIQUIDATION_INCENTIVE_VALIDATION,
        SET_MAX_ASSETS_OWNER_CHECK,
        SET_PENDING_ADMIN_OWNER_CHECK,
        SET_PENDING_IMPLEMENTATION_OWNER_CHECK,
        SET_PRICE_ORACLE_OWNER_CHECK,
        SUPPORT_MARKET_EXISTS,
        SUPPORT_MARKET_OWNER_CHECK,
        SET_PAUSE_GUARDIAN_OWNER_CHECK,
        SET_VAI_MINT_RATE_CHECK,
        SET_VAICONTROLLER_OWNER_CHECK,
        SET_MINTED_VAI_REJECTION,
        SET_TREASURY_OWNER_CHECK,
        UNLIST_MARKET_NOT_LISTED,
        SET_LIQUIDATION_THRESHOLD_VALIDATION,
        COLLATERAL_FACTOR_GREATER_THAN_LIQUIDATION_THRESHOLD
    }

    /**
     * @dev `error` corresponds to enum Error; `info` corresponds to enum FailureInfo, and `detail` is an arbitrary
     * contract-specific code that enables us to report opaque error codes from upgradeable contracts.
     **/
    event Failure(uint error, uint info, uint detail);

    /**
     * @dev use this when reporting a known error from the money market or a non-upgradeable collaborator
     */
    function fail(Error err, FailureInfo info) internal returns (uint) {
        emit Failure(uint(err), uint(info), 0);

        return uint(err);
    }

    /**
     * @dev use this when reporting an opaque error from an upgradeable collaborator contract
     */
    function failOpaque(Error err, FailureInfo info, uint opaqueError) internal returns (uint) {
        emit Failure(uint(err), uint(info), opaqueError);

        return uint(err);
    }
}

contract TokenErrorReporter {
    enum Error {
        NO_ERROR,
        UNAUTHORIZED,
        BAD_INPUT,
        COMPTROLLER_REJECTION,
        COMPTROLLER_CALCULATION_ERROR,
        INTEREST_RATE_MODEL_ERROR,
        INVALID_ACCOUNT_PAIR,
        INVALID_CLOSE_AMOUNT_REQUESTED,
        INVALID_COLLATERAL_FACTOR,
        MATH_ERROR,
        MARKET_NOT_FRESH,
        MARKET_NOT_LISTED,
        TOKEN_INSUFFICIENT_ALLOWANCE,
        TOKEN_INSUFFICIENT_BALANCE,
        TOKEN_INSUFFICIENT_CASH,
        TOKEN_TRANSFER_IN_FAILED,
        TOKEN_TRANSFER_OUT_FAILED,
        TOKEN_PRICE_ERROR
    }

    /*
     * Note: FailureInfo (but not Error) is kept in alphabetical order
     *       This is because FailureInfo grows significantly faster, and
     *       the order of Error has some meaning, while the order of FailureInfo
     *       is entirely arbitrary.
     */
    enum FailureInfo {
        ACCEPT_ADMIN_PENDING_ADMIN_CHECK,
        ACCRUE_INTEREST_ACCUMULATED_INTEREST_CALCULATION_FAILED,
        ACCRUE_INTEREST_BORROW_RATE_CALCULATION_FAILED,
        ACCRUE_INTEREST_NEW_BORROW_INDEX_CALCULATION_FAILED,
        ACCRUE_INTEREST_NEW_TOTAL_BORROWS_CALCULATION_FAILED,
        ACCRUE_INTEREST_NEW_TOTAL_RESERVES_CALCULATION_FAILED,
        ACCRUE_INTEREST_SIMPLE_INTEREST_FACTOR_CALCULATION_FAILED,
        BORROW_ACCUMULATED_BALANCE_CALCULATION_FAILED,
        BORROW_ACCRUE_INTEREST_FAILED,
        BORROW_CASH_NOT_AVAILABLE,
        BORROW_FRESHNESS_CHECK,
        BORROW_NEW_TOTAL_BALANCE_CALCULATION_FAILED,
        BORROW_NEW_ACCOUNT_BORROW_BALANCE_CALCULATION_FAILED,
        BORROW_MARKET_NOT_LISTED,
        BORROW_COMPTROLLER_REJECTION,
        LIQUIDATE_ACCRUE_BORROW_INTEREST_FAILED,
        LIQUIDATE_ACCRUE_COLLATERAL_INTEREST_FAILED,
        LIQUIDATE_COLLATERAL_FRESHNESS_CHECK,
        LIQUIDATE_COMPTROLLER_REJECTION,
        LIQUIDATE_COMPTROLLER_CALCULATE_AMOUNT_SEIZE_FAILED,
        LIQUIDATE_CLOSE_AMOUNT_IS_UINT_MAX,
        LIQUIDATE_CLOSE_AMOUNT_IS_ZERO,
        LIQUIDATE_FRESHNESS_CHECK,
        LIQUIDATE_LIQUIDATOR_IS_BORROWER,
        LIQUIDATE_REPAY_BORROW_FRESH_FAILED,
        LIQUIDATE_SEIZE_BALANCE_INCREMENT_FAILED,
        LIQUIDATE_SEIZE_BALANCE_DECREMENT_FAILED,
        LIQUIDATE_SEIZE_COMPTROLLER_REJECTION,
        LIQUIDATE_SEIZE_LIQUIDATOR_IS_BORROWER,
        LIQUIDATE_SEIZE_TOO_MUCH,
        MINT_ACCRUE_INTEREST_FAILED,
        MINT_COMPTROLLER_REJECTION,
        MINT_EXCHANGE_CALCULATION_FAILED,
        MINT_EXCHANGE_RATE_READ_FAILED,
        MINT_FRESHNESS_CHECK,
        MINT_NEW_ACCOUNT_BALANCE_CALCULATION_FAILED,
        MINT_NEW_TOTAL_SUPPLY_CALCULATION_FAILED,
        MINT_TRANSFER_IN_FAILED,
        MINT_TRANSFER_IN_NOT_POSSIBLE,
        REDEEM_ACCRUE_INTEREST_FAILED,
        REDEEM_COMPTROLLER_REJECTION,
        REDEEM_EXCHANGE_TOKENS_CALCULATION_FAILED,
        REDEEM_EXCHANGE_AMOUNT_CALCULATION_FAILED,
        REDEEM_EXCHANGE_RATE_READ_FAILED,
        REDEEM_FRESHNESS_CHECK,
        REDEEM_NEW_ACCOUNT_BALANCE_CALCULATION_FAILED,
        REDEEM_NEW_TOTAL_SUPPLY_CALCULATION_FAILED,
        REDEEM_TRANSFER_OUT_NOT_POSSIBLE,
        REDUCE_RESERVES_ACCRUE_INTEREST_FAILED,
        REDUCE_RESERVES_ADMIN_CHECK,
        REDUCE_RESERVES_CASH_NOT_AVAILABLE,
        REDUCE_RESERVES_FRESH_CHECK,
        REDUCE_RESERVES_VALIDATION,
        REPAY_BEHALF_ACCRUE_INTEREST_FAILED,
        REPAY_BORROW_ACCRUE_INTEREST_FAILED,
        REPAY_BORROW_ACCUMULATED_BALANCE_CALCULATION_FAILED,
        REPAY_BORROW_COMPTROLLER_REJECTION,
        REPAY_BORROW_FRESHNESS_CHECK,
        REPAY_BORROW_NEW_ACCOUNT_BORROW_BALANCE_CALCULATION_FAILED,
        REPAY_BORROW_NEW_TOTAL_BALANCE_CALCULATION_FAILED,
        REPAY_BORROW_TRANSFER_IN_NOT_POSSIBLE,
        SET_COLLATERAL_FACTOR_OWNER_CHECK,
        SET_COLLATERAL_FACTOR_VALIDATION,
        SET_COMPTROLLER_OWNER_CHECK,
        SET_INTEREST_RATE_MODEL_ACCRUE_INTEREST_FAILED,
        SET_INTEREST_RATE_MODEL_FRESH_CHECK,
        SET_INTEREST_RATE_MODEL_OWNER_CHECK,
        SET_MAX_ASSETS_OWNER_CHECK,
        SET_ORACLE_MARKET_NOT_LISTED,
        SET_PENDING_ADMIN_OWNER_CHECK,
        SET_RESERVE_FACTOR_ACCRUE_INTEREST_FAILED,
        SET_RESERVE_FACTOR_ADMIN_CHECK,
        SET_RESERVE_FACTOR_FRESH_CHECK,
        SET_RESERVE_FACTOR_BOUNDS_CHECK,
        TRANSFER_COMPTROLLER_REJECTION,
        TRANSFER_NOT_ALLOWED,
        TRANSFER_NOT_ENOUGH,
        TRANSFER_TOO_MUCH,
        ADD_RESERVES_ACCRUE_INTEREST_FAILED,
        ADD_RESERVES_FRESH_CHECK,
        ADD_RESERVES_TRANSFER_IN_NOT_POSSIBLE,
        TOKEN_GET_UNDERLYING_PRICE_ERROR,
        REPAY_VAI_COMPTROLLER_REJECTION,
        REPAY_VAI_FRESHNESS_CHECK,
        VAI_MINT_EXCHANGE_CALCULATION_FAILED,
        SFT_MINT_NEW_ACCOUNT_BALANCE_CALCULATION_FAILED
    }

    /**
     * @dev `error` corresponds to enum Error; `info` corresponds to enum FailureInfo, and `detail` is an arbitrary
     * contract-specific code that enables us to report opaque error codes from upgradeable contracts.
     **/
    event Failure(uint error, uint info, uint detail);

    /**
     * @dev use this when reporting a known error from the money market or a non-upgradeable collaborator
     */
    function fail(Error err, FailureInfo info) internal returns (uint) {
        emit Failure(uint(err), uint(info), 0);

        return uint(err);
    }

    /**
     * @dev use this when reporting an opaque error from an upgradeable collaborator contract
     */
    function failOpaque(Error err, FailureInfo info, uint opaqueError) internal returns (uint) {
        emit Failure(uint(err), uint(info), opaqueError);

        return uint(err);
    }
}

contract VAIControllerErrorReporter {
    enum Error {
        NO_ERROR,
        UNAUTHORIZED, // The sender is not authorized to perform this action.
        REJECTION, // The action would violate the comptroller, vaicontroller policy.
        SNAPSHOT_ERROR, // The comptroller could not get the account borrows and exchange rate from the market.
        PRICE_ERROR, // The comptroller could not obtain a required price of an asset.
        MATH_ERROR, // A math calculation error occurred.
        INSUFFICIENT_BALANCE_FOR_VAI // Caller does not have sufficient balance to mint VAI.
    }

    enum FailureInfo {
        SET_PENDING_ADMIN_OWNER_CHECK,
        SET_PENDING_IMPLEMENTATION_OWNER_CHECK,
        SET_COMPTROLLER_OWNER_CHECK,
        ACCEPT_ADMIN_PENDING_ADMIN_CHECK,
        ACCEPT_PENDING_IMPLEMENTATION_ADDRESS_CHECK,
        VAI_MINT_REJECTION,
        VAI_BURN_REJECTION,
        VAI_LIQUIDATE_ACCRUE_BORROW_INTEREST_FAILED,
        VAI_LIQUIDATE_ACCRUE_COLLATERAL_INTEREST_FAILED,
        VAI_LIQUIDATE_COLLATERAL_FRESHNESS_CHECK,
        VAI_LIQUIDATE_COMPTROLLER_REJECTION,
        VAI_LIQUIDATE_COMPTROLLER_CALCULATE_AMOUNT_SEIZE_FAILED,
        VAI_LIQUIDATE_CLOSE_AMOUNT_IS_UINT_MAX,
        VAI_LIQUIDATE_CLOSE_AMOUNT_IS_ZERO,
        VAI_LIQUIDATE_FRESHNESS_CHECK,
        VAI_LIQUIDATE_LIQUIDATOR_IS_BORROWER,
        VAI_LIQUIDATE_REPAY_BORROW_FRESH_FAILED,
        VAI_LIQUIDATE_SEIZE_BALANCE_INCREMENT_FAILED,
        VAI_LIQUIDATE_SEIZE_BALANCE_DECREMENT_FAILED,
        VAI_LIQUIDATE_SEIZE_COMPTROLLER_REJECTION,
        VAI_LIQUIDATE_SEIZE_LIQUIDATOR_IS_BORROWER,
        VAI_LIQUIDATE_SEIZE_TOO_MUCH,
        MINT_FEE_CALCULATION_FAILED,
        SET_TREASURY_OWNER_CHECK
    }

    /**
     * @dev `error` corresponds to enum Error; `info` corresponds to enum FailureInfo, and `detail` is an arbitrary
     * contract-specific code that enables us to report opaque error codes from upgradeable contracts.
     **/
    event Failure(uint error, uint info, uint detail);

    /**
     * @dev use this when reporting a known error from the money market or a non-upgradeable collaborator
     */
    function fail(Error err, FailureInfo info) internal returns (uint) {
        emit Failure(uint(err), uint(info), 0);

        return uint(err);
    }

    /**
     * @dev use this when reporting an opaque error from an upgradeable collaborator contract
     */
    function failOpaque(Error err, FailureInfo info, uint opaqueError) internal returns (uint) {
        emit Failure(uint(err), uint(info), opaqueError);

        return uint(err);
    }
}
