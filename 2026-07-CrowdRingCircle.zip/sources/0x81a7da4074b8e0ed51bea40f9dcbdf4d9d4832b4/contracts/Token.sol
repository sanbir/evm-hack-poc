// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.28;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract Token is ERC20 {
    // recipients is the vesting contract address
    constructor(
        string memory name,
        string memory symbol,
        address vesting
    ) ERC20(name, symbol) {
        uint256 totalSupply = 1_000_000_000 ether;
        require(
            vesting != address(0),
            "Vesting contract cannot be zero address"
        );
        require(totalSupply > 0, "Total supply cannot be zero");
        _mint(vesting, totalSupply);
    }
}
