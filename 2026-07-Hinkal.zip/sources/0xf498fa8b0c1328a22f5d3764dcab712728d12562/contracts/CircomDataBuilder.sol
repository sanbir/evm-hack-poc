// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.17;

import {CircomData} from "./types/CircomData.sol";
import {CIRCOM_P, HINKAL_EMPORIUM_ACTION_ID} from "./Constants.sol";
import {EmporiumStack} from "./external-actions/emporium/EmporiumStack.sol";

contract CircomDataBuilder {
    int256 public constant MAX_AMOUNT = 2 ** 252;
    uint256 public constant POINTER_SEPARATOR = 2 ** 255;

    function getHashedCalldata(
        CircomData calldata circomData
    ) internal pure returns (uint256) {
        // because of stack too deep error, we need to split the calldata into two parts
        uint256 calldataHash1 = getHashedCalldata1(circomData);
        uint256 calldataHash2 = getHashedCalldata2(circomData);
        return (uint256(keccak256(abi.encode(calldataHash1, calldataHash2))) %
            CIRCOM_P);
    }

    function getHashedCalldata1(
        CircomData calldata circomData
    ) internal pure returns (uint256) {
        return
            uint256(
                keccak256(
                    abi.encode(
                        circomData.publicSignalCount,
                        circomData.relay,
                        circomData.externalAddress,
                        circomData.externalActionId,
                        circomData.externalActionMetadata
                    )
                )
            );
    }

    function getHashedCalldata2(
        CircomData calldata circomData
    ) internal pure returns (uint256) {
        return
            uint256(
                keccak256(
                    abi.encode(
                        circomData.hookData,
                        circomData.encryptedOutputs,
                        circomData.feeStructure,
                        circomData.slippageValues,
                        circomData.onChainCreation,
                        circomData.signatureData,
                        circomData.originalSender
                    )
                )
            );
    }

    function getPointSign(uint256 H) public pure returns (uint256) {
        return H / POINTER_SEPARATOR;
    }

    function getPointY(uint256 H) public pure returns (uint256) {
        return H % POINTER_SEPARATOR;
    }

    function _encodeTokenAddresses(
        address[] calldata erc20TokenAddresses
    ) internal pure returns (uint256[] memory encoded) {
        encoded = new uint256[](erc20TokenAddresses.length);
        for (uint16 i = 0; i < erc20TokenAddresses.length; i++) {
            encoded[i] = uint256(uint160(erc20TokenAddresses[i]));
        }
    }

    function _encodeAmountChanges(
        int256[] calldata amountChanges
    ) internal pure returns (uint256[] memory encoded) {
        encoded = new uint256[](amountChanges.length);
        for (uint16 i = 0; i < amountChanges.length; i++) {
            require(
                amountChanges[i] < MAX_AMOUNT &&
                    amountChanges[i] > -1 * MAX_AMOUNT,
                "amount changed is too large"
            );
            encoded[i] = amountChanges[i] >= 0
                ? uint256(amountChanges[i])
                : CIRCOM_P - uint256(-amountChanges[i]);
        }
    }

    function _flatUint256Matrix(
        uint256[][] calldata matrix
    ) internal pure returns (uint256[] memory flat) {
        uint256 len;
        for (uint16 i = 0; i < matrix.length; i++) {
            len += matrix[i].length;
        }
        flat = new uint256[](len);
        uint256 k;
        for (uint16 i = 0; i < matrix.length; i++) {
            for (uint16 j = 0; j < matrix[i].length; j++) {
                flat[k++] = matrix[i][j];
            }
        }
    }

    function getSignedMessageHash(
        CircomData calldata circomData,
        uint256 emporiumMessage
    ) internal pure returns (uint256) {
        return
            uint256(
                keccak256(
                    abi.encode(
                        circomData.rootHashHinkal,
                        _encodeTokenAddresses(circomData.erc20TokenAddresses),
                        _encodeAmountChanges(circomData.amountChanges),
                        circomData.timeStamp,
                        _flatUint256Matrix(circomData.inputNullifiers),
                        _flatUint256Matrix(circomData.outCommitments),
                        circomData.calldataHash,
                        emporiumMessage,
                        circomData.stealthAddressStructure.H1,
                        getPointY(
                            circomData
                                .stealthAddressStructure
                                .extraRandomization
                        ),
                        circomData.stealthAddressStructure.H0
                    )
                )
            ) % CIRCOM_P;
    }

    function formInputForCircom(
        CircomData calldata circomData
    ) internal pure returns (uint256[] memory) {
        if (
            circomData.externalActionId == HINKAL_EMPORIUM_ACTION_ID &&
            circomData.erc20TokenAddresses.length == 0
        ) {
            return formInputEmporiumMin(circomData);
        } else {
            return formInputNormal(circomData);
        }
    }

    function formInputEmporiumMin(
        CircomData calldata circomData
    ) internal pure returns (uint256[] memory input) {
        bytes calldata metadata = circomData.externalActionMetadata;

        EmporiumStack calldata internalMetadata;

        assembly {
            internalMetadata := add(metadata.offset, 0x20)
        }

        input = new uint256[](circomData.publicSignalCount);

        uint16 index = 0;

        input[index++] = uint256(internalMetadata.message);

        input[index++] = circomData.timeStamp;
        input[index++] = circomData.calldataHash;
    }

    function formInputNormal(
        CircomData calldata circomData
    ) internal pure returns (uint256[] memory input) {
        // 1) message for Emporium message signature verification
        bytes calldata metadata = circomData.externalActionMetadata;

        EmporiumStack calldata internalMetadata;

        assembly {
            internalMetadata := add(metadata.offset, 0x20)
        }
        input = new uint256[](circomData.publicSignalCount);
        uint16 index = 0;
        input = formBasicInput(
            circomData,
            input,
            index,
            uint256(internalMetadata.message)
        );
    }

    function formBasicInput(
        CircomData calldata circomData,
        uint256[] memory input,
        uint256 index,
        uint256 emporiumMessage
    ) internal pure returns (uint256[] memory) {
        // 1) First we list public inputs as in the body of the main template (not the one with exact dimensions)
        input[index++] = circomData.stealthAddressStructure.H1; // = H1y
        input[index++] = circomData.stealthAddressStructure.stealthAddress;
        input[index++] = emporiumMessage; // this is for Emporium message signature verification

        // 2) Then we list the private inputs as in the body of the main template
        input[index++] = circomData.rootHashHinkal;
        input[index++] = getSignedMessageHash(circomData, emporiumMessage);

        for (uint16 i = 0; i < circomData.erc20TokenAddresses.length; i++) {
            input[index++] = uint256(
                uint160(circomData.erc20TokenAddresses[i])
            );
        }

        for (uint16 i = 0; i < circomData.amountChanges.length; i++) {
            require(
                circomData.amountChanges[i] < MAX_AMOUNT &&
                    circomData.amountChanges[i] > -1 * MAX_AMOUNT,
                "amount changed is too large"
            );

            input[index++] = circomData.amountChanges[i] >= 0
                ? uint256(circomData.amountChanges[i])
                : CIRCOM_P - uint256(-circomData.amountChanges[i]);
        }

        for (uint16 i = 0; i < circomData.inputNullifiers.length; i++) {
            for (uint16 j = 0; j < circomData.inputNullifiers[i].length; j++) {
                input[index++] = circomData.inputNullifiers[i][j];
            }
        }

        input[index++] = circomData.timeStamp;

        for (uint16 i = 0; i < circomData.outCommitments.length; i++) {
            for (uint16 j = 0; j < circomData.outCommitments[i].length; j++) {
                input[index++] = circomData.outCommitments[i][j];
            }
        }
        input[index++] = circomData.calldataHash;

        // strip the isNewStyle flag (bit 255) so the circuit gets the clean H0x coordinate
        input[index++] = getPointY(
            circomData.stealthAddressStructure.extraRandomization
        ); // = H0x
        input[index++] = circomData.stealthAddressStructure.H0; // = H0y

        return input;
    }
}
