// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.17;

import {CircomDataBuilder} from "./CircomDataBuilder.sol";
import {CircomData} from "./types/CircomData.sol";
import {RelayStore} from "./RelayStore.sol";
import {Dimensions} from "./types/Dimensions.sol";
import {StealthAddressStructure} from "./types/StealthAddressStructure.sol";

///@title Helper class for Hinkal
contract HinkalHelper is RelayStore, CircomDataBuilder {
    address public hinkalAddress;

    constructor(address[] memory _initialRelays) RelayStore(_initialRelays) {}

    function setHinkalAddress(address _hinkalAddress) external onlyOwner {
        hinkalAddress = _hinkalAddress;
    }

    modifier onlyHinkal() {
        require(
            msg.sender == hinkalAddress,
            "Only Hinkal can call this function"
        );
        _;
    }

    function relayerIsValid(address relay) internal view {
        if (relay != address(0)) {
            require(tx.origin == relay, "Unauthorized relay");
            require(isRelayInList(relay), "Relay is not whitelisted");
        }
    }

    function performProoflessDepositChecks(
        address[] calldata erc20Addresses,
        uint256[] calldata amounts,
        uint256[] calldata tokenIds,
        StealthAddressStructure[] calldata stealthAddressStructures
    ) external view onlyHinkal returns (bool) {
        // to be implemented
    }

    function checkTokenIds(uint256[] calldata tokenIds) internal pure {
        for (uint256 i = 0; i < tokenIds.length; i++) {
            require(tokenIds[i] == 0, "NFTs not supported");
        }
    }

    function dimensionsCheck(
        CircomData calldata circomData,
        Dimensions calldata dimensions
    ) internal pure {
        require(
            circomData.erc20TokenAddresses.length == dimensions.tokenNumber,
            "Token number should be equal"
        );
        require(
            circomData.amountChanges.length == dimensions.tokenNumber,
            "AmountChanges number should be equal"
        );

        require(
            circomData.tokenIds.length == dimensions.tokenNumber,
            "tokenIds number should be equal"
        );

        uint previousNullifierAmount = circomData.inputNullifiers.length > 0
            ? circomData.inputNullifiers[0].length
            : 0;
        for (uint i = 1; i < circomData.inputNullifiers.length; i++) {
            require(
                circomData.inputNullifiers[i].length == previousNullifierAmount,
                "Nullifier amount should be equal"
            );
        }
        require(
            previousNullifierAmount == dimensions.nullifierAmount,
            "Actual and Claimed Nullifier Amount should be equal"
        );

        uint previousCommitmentAmount = circomData.outCommitments.length > 0
            ? circomData.outCommitments[0].length
            : 0;
        for (uint i = 1; i < circomData.outCommitments.length; i++) {
            require(
                circomData.outCommitments[i].length == previousCommitmentAmount,
                "Commitment amount should be equal"
            );
        }
        require(
            previousCommitmentAmount == dimensions.outputAmount,
            "Actual and Claimed Commitment Amount should be equal"
        );

        require(
            circomData.stealthAddressStructure.extraRandomization != 0,
            "Extra-randomization cannot be zero"
        );

        require(
            circomData.onChainCreation.length == dimensions.tokenNumber,
            "onchain creation is equal to tokens count"
        );

        require(
            circomData.slippageValues.length == dimensions.tokenNumber,
            "slippageValues length should be equal to tokens count"
        );

        // hinkalLogicAction is deprecated
        require(
            circomData.hinkalLogicArgs.hinkalLogicAction == 0 &&
                circomData.hinkalLogicArgs.doPreTxApproval == false,
            "inHinkalAddress should be zero"
        );

        require(
            circomData.hinkalLogicArgs.executeApprovalChanges.length ==
                dimensions.tokenNumber,
            "executeApprovalChanges length should be equal to token count"
        );

        require(
            circomData.hinkalLogicArgs.useApprovalUtxoData.length ==
                dimensions.tokenNumber,
            "useApprovalUtxoData length should be equal to token count"
        );

        // useApprovalUtxoData is deprecated
        for (
            uint256 i = 0;
            i < circomData.hinkalLogicArgs.useApprovalUtxoData.length;
            i++
        ) {
            for (
                uint256 j = 0;
                j <
                circomData
                    .hinkalLogicArgs
                    .useApprovalUtxoData[i]
                    .approvalChanges
                    .length;
                j++
            ) {
                require(
                    circomData
                        .hinkalLogicArgs
                        .useApprovalUtxoData[i]
                        .approvalChanges[j] == 0,
                    "approvalChanges should be zero"
                );
            }
        }

        // spend approvals are deprecated
        for (
            uint256 i = 0;
            i < circomData.hinkalLogicArgs.executeApprovalChanges.length;
            i++
        ) {
            require(
                circomData.hinkalLogicArgs.executeApprovalChanges[i] == 0,
                "spend approvals should be zero"
            );
        }
    }

    ///@notice make performance checks for transactions
    ///@dev Check if transacaction is valid before making it
    ///@param circomData circom data
    ///@return inputForCircom
    function performHinkalChecks(
        CircomData calldata circomData,
        Dimensions calldata dimensions,
        address sender
    ) external view returns (uint256[] memory) {
        // if you are forking/develop a network then use MockHinkal to pass next check
        /*
        require(
            circomData.timeStamp > block.timestamp - 7 * 60 &&
                circomData.timeStamp < block.timestamp + 7 * 60,
            "Timestamp provided does not align with current time"
        );
        */

        require(
            (circomData.originalSender == address(0) &&
                circomData.relay != address(0)) ||
                (circomData.originalSender == sender &&
                    circomData.relay == address(0)),
            "invalid value for originalSender"
        );

        require(
            CircomDataBuilder.getHashedCalldata(circomData) ==
                circomData.calldataHash,
            "Calldata Hash Integrity Check Failed"
        );
        relayerIsValid(circomData.relay);
        checkTokenIds(circomData.tokenIds);
        dimensionsCheck(circomData, dimensions);

        return CircomDataBuilder.formInputForCircom(circomData);
    }

    ///@dev No-op; kept for compatibility with deployed Hinkal that calls this after checks.
    function performSideEffects(CircomData calldata) external onlyHinkal {}
}
