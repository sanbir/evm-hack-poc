// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.17;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {IRelayStore} from "./types/IRelayStore.sol";

///@title Storage class for Relayer data
contract RelayStore is Ownable, IRelayStore {
    mapping(address => bool) public relayList;
    address[] public relayStore;

    constructor(address[] memory initialRelays) {
        for (uint16 i = 0; i < initialRelays.length; i++) {
            addRelay(initialRelays[i]);
        }
    }

    function isRelayInList(address relayAddress) public view returns (bool) {
        return relayList[relayAddress];
    }

    ///@notice obtain relayer store
    ///@dev We need seperate Relayer store to return list of all relayers to frontend
    ///@return relayStore List of all Relayers
    function getRelayStore() external view returns (address[] memory) {
        return relayStore;
    }

    function removeRelay(address _relayAddress) external onlyOwner {
        require(isRelayInList(_relayAddress), "Relayer not in list");
        delete relayList[_relayAddress];
        for (uint16 i = 0; i < relayStore.length; i++) {
            if (relayStore[i] == _relayAddress) {
                relayStore[i] = relayStore[relayStore.length - 1];
                break;
            }
        }

        relayStore.pop();
        emit RelayRemoved(_relayAddress);
    }

    function addRelay(address _relayAddress) public onlyOwner {
        require(
            _relayAddress != address(0),
            "Relay address cannot be zero address"
        );

        relayStore.push(_relayAddress);
        relayList[_relayAddress] = true;

        emit RelayAdded(_relayAddress);
    }

    function calculateRelayFee(
        uint256 balance,
        uint256 flatFee,
        uint256 variableRate
    ) public pure returns (uint256 relayFee) {
        relayFee = flatFee + (balance * variableRate) / 10000;
    }
}
