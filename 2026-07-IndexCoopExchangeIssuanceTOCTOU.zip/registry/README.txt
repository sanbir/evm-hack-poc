Authoritative Forge reproduction

Registry folder: 2026-07-IndexCoopExchangeIssuanceTOCTOU_exp
Registry base commit: d37a7da81d7e01a60feb5f1e95c880296b9c48a0

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-07-IndexCoopExchangeIssuanceTOCTOU_exp -vvv
