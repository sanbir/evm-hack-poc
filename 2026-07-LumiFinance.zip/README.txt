EVM Hack Analyzer — exploit POC artifact (ZIP projection)

Transaction: 0x630654fb1c8914405cf81bb02f091b049f19403a152f624f7b8a00c7724c6604
Chain id:    42161
Created:     2026-07-15T06:48:50.170Z

Layout (no full self-contained JSON — that is the separate .poc.json download):
  anvil_state.json      — fork state (accounts + storage + code + block).
  sources/<addr>/…      — verified Solidity sources for each mapped contract.
  poc-data/core.json    — tx envelope, pc→line maps, labels, annotations.
  manifest.json         — summary metadata.

Drop this ZIP onto the EVM Hack Analyzer to reassemble and replay the POC.
For a single-file share (e.g. IPFS pin of one object), use ⬇ poc.json instead.