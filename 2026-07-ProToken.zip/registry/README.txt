Authoritative Forge reproduction

Registry folder: 2026-07-ProToken_exp
Registry base commit: f33fc07accb9f91a2705e3ad67ddf034622e52b8

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-07-ProToken_exp -vvv
