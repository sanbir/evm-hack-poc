// SPDX-License-Identifier: MIT
pragma solidity 0.8.25;

import { MinimalAggregatorV3Interface } from "../interfaces/factories/MinimalAggregatorV3Interface.sol";
import { IEOMultiFeedAdapter } from "../interfaces/factories/IEOMultiFeedAdapter.sol";
import { Initializable } from "@openzeppelin/contracts/proxy/utils/Initializable.sol";
import { FeedUtils } from "./libraries/FeedUtils.sol";

/**
 * @title EOMultiFeedAdapter
 * @author EO
 * @notice A contract that allows to create a price feed by combining multiple base and quote feeds.
 * @dev supports base and quote feeds of type MinimalAggregatorV3Interface, IERC4626, ICustomAdapter
 */
contract EOMultiFeedAdapter is IEOMultiFeedAdapter, MinimalAggregatorV3Interface, Initializable {
    using FeedUtils for Feed;

    /**
     * @notice The maximum number of base feeds.
     */
    uint256 public constant MAX_BASE_FEEDS = 4;

    /**
     * @notice The maximum number of quote feeds.
     */
    uint256 public constant MAX_QUOTE_FEEDS = 2;

    /**
     * @notice The maximum number of decimals for the price feed.
     */
    uint256 public constant MAX_DECIMALS = 64;

    /**
     * @notice The numerator multiplier of the price feed.
     */
    int256 public numeratorMultiplier;

    /**
     * @notice The denominator multiplier of the price feed.
     */
    int256 public denominatorMultiplier;

    /**
     * @notice The decimals precision of the price feed.
     */
    uint8 public decimals;

    /**
     * @notice The description of the price feed.
     */
    string public description;

    /**
     * @notice The base feeds used to calculate the rate of the price feed.
     */
    Feed[] private _baseFeeds;

    /**
     * @notice The quote feeds used to calculate the rate of the price feed.
     */
    Feed[] private _quoteFeeds;

    /**
     * @inheritdoc IEOMultiFeedAdapter
     */
    function initialize(
        Feed[] memory baseFeeds,
        Feed[] memory quoteFeeds,
        uint8 outputDecimals,
        string memory desc
    )
        public
        initializer
    {
        uint8 baseDecimals = 0;
        uint8 quoteDecimals = 0;
        if (baseFeeds.length > MAX_BASE_FEEDS) revert MaxBaseFeedsExceeded();
        if (quoteFeeds.length > MAX_QUOTE_FEEDS) revert MaxQuoteFeedsExceeded();
        for (uint256 i = 0; i < baseFeeds.length; i++) {
            if (baseFeeds[i].feedAddress == address(0)) {
                revert InvalidFeedAddress();
            }
            baseFeeds[i].verify();
            _baseFeeds.push(baseFeeds[i]);
            baseDecimals += baseFeeds[i].getDecimals();
        }

        for (uint256 i = 0; i < quoteFeeds.length; i++) {
            if (quoteFeeds[i].feedAddress == address(0)) {
                revert InvalidFeedAddress();
            }
            quoteFeeds[i].verify();
            _quoteFeeds.push(quoteFeeds[i]);
            quoteDecimals += quoteFeeds[i].getDecimals();
        }

        description = desc;
        decimals = outputDecimals;

        int8 adjustment = int8(outputDecimals) - int8(baseDecimals) + int8(quoteDecimals);

        if (adjustment >= 0) {
            if (baseDecimals + uint8(adjustment) > MAX_DECIMALS) revert MaxDecimalsExceeded();
            numeratorMultiplier = int256(10 ** uint8(adjustment));
            denominatorMultiplier = 1;
        } else {
            if (baseDecimals > MAX_DECIMALS) revert MaxDecimalsExceeded();
            numeratorMultiplier = 1;
            denominatorMultiplier = int256(10 ** uint8(-adjustment));
        }
    }

    /**
     * @notice Returns latest round data
     * @dev Returns zero for roundId, startedAt and answeredInRound.
     * @return roundId The round id, returns 0
     * @return answer The answer, returns the final rate of the price feed,
     *  rate = (rate_base1 * ... * rate_baseN * numeratorMultiplier) /
     *          (rate_quote1 * ... * rate_quoteM * denominatorMultiplier)
     * @return startedAt The started at, returns 0
     * @return updatedAt The updated at, returns latests updatedAt among the base and quote feeds
     * @return answeredInRound The answered in round, returns 0
     */
    function latestRoundData() external view returns (uint80, int256, uint256, uint256, uint80) {
        int256 rate = numeratorMultiplier;
        uint256 baseFeedsLength = _baseFeeds.length;
        // slither-disable-next-line uninitialized-local
        uint256 latestUpdatedAt;
        for (uint256 i = 0; i < baseFeedsLength; i++) {
            (int256 feedRate, uint256 updatedAt) = _baseFeeds[i].getRate();
            // slither-disable-next-line divide-before-multiply
            rate = rate * feedRate;
            if (updatedAt == 0) {
                updatedAt = block.timestamp;
            }
            if (updatedAt > latestUpdatedAt) {
                latestUpdatedAt = updatedAt;
            }
        }
        uint256 quoteFeedsLength = _quoteFeeds.length;
        for (uint256 i = 0; i < quoteFeedsLength; i++) {
            (int256 feedRate, uint256 updatedAt) = _quoteFeeds[i].getRate();
            // slither-disable-next-line divide-before-multiply
            rate = rate / feedRate;
            if (updatedAt == 0) {
                updatedAt = block.timestamp;
            }
            if (updatedAt > latestUpdatedAt) {
                latestUpdatedAt = updatedAt;
            }
        }
        rate = rate / denominatorMultiplier;
        return (0, rate, 0, latestUpdatedAt, 0);
    }

    /**
     * @notice The function to get the base feeds of the price feed.
     * @return The array of base feeds, where each item is (feedInterface, feedAddress, customAdapterAddress),
     *         where feedInterface (0 = MinimalAggregatorV3Interface, 1 = IERC4626, 2 = CustomAdapterInterface)
     */
    function getBaseFeeds() external view returns (Feed[] memory) {
        return _baseFeeds;
    }

    /**
     * @notice The function to get the base feed by index.
     * @param index The index of the base feed.
     * @return The base feed at the given index, (feedInterface, feedAddress, customAdapterAddress),
     *         where feedInterface (0 = MinimalAggregatorV3Interface, 1 = IERC4626, 2 = CustomAdapterInterface)
     */
    function getBaseFeed(uint256 index) external view returns (Feed memory) {
        return _baseFeeds[index];
    }

    /**
     * @notice The function to get the quote feeds of the price feed.
     * @return The array of quote feeds, where each item is (feedInterface, feedAddress, customAdapterAddress),
     *         where feedInterface (0 = MinimalAggregatorV3Interface, 1 = IERC4626, 2 = CustomAdapterInterface)
     */
    function getQuoteFeeds() external view returns (Feed[] memory) {
        return _quoteFeeds;
    }

    /**
     * @notice The function to get the quote feed by index.
     * @param index The index of the quote feed.
     * @return The quote feed at the given index, (feedInterface, feedAddress, customAdapterAddress),
     *         where feedInterface (0 = MinimalAggregatorV3Interface, 1 = IERC4626, 2 = CustomAdapterInterface)
     */
    function getQuoteFeed(uint256 index) external view returns (Feed memory) {
        return _quoteFeeds[index];
    }
}
