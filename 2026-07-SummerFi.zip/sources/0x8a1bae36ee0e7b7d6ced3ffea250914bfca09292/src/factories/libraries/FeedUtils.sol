// SPDX-License-Identifier: MIT
pragma solidity 0.8.25;

import { InterfaceVerifier } from "./InterfaceVerifier.sol";
import { IEOFeedAdapterBase } from "../../interfaces/factories/IEOFeedAdapterBase.sol";
import { MinimalAggregatorV3Interface } from "../../interfaces/factories/MinimalAggregatorV3Interface.sol";
import { IERC4626 } from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import { IDecimals } from "../../interfaces/factories/IDecimals.sol";
import { ICustomAdapter } from "../../interfaces/factories/ICustomAdapter.sol";

import { IEOFeedAdapterBase } from "../../interfaces/factories/IEOFeedAdapterBase.sol";

/**
 * @title FeedUtils
 * @author EO
 * @notice A library for feed verification and rate/decimals retrieval.
 */
library FeedUtils {
    using InterfaceVerifier for address;

    /**
     * @notice The error emitted when the feed interface is not supported.
     * @param feed The address of the feed.
     * @param feedInterface The interface of the feed.
     */
    error FeedInterfaceNotSupported(address feed, IEOFeedAdapterBase.FeedInterface feedInterface);

    /**
     * @notice Verifies the feed interface.
     * @dev Reverts if the feed interface is not supported or the feed interface is not implemented.
     * @param feed The feed to verify.
     */
    function verify(IEOFeedAdapterBase.Feed memory feed) internal view {
        if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.MINIMAL_AGGREGATOR_V3_INTERFACE) {
            feed.feedAddress.verifyMinimalAggregatorV3Interface();
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.IERC4626_VAULT) {
            feed.feedAddress.verifyIERC4626();
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.CUSTOM_ADAPTER_INTERFACE) {
            feed.feedAddress.verifyICustomAdapter(feed.customAdapterAddress);
        } else {
            revert FeedInterfaceNotSupported(feed.feedAddress, feed.feedInterface);
        }
    }

    /**
     * @notice Retrieves the rate of the feed.
     * @dev Reverts if the feed interface is not supported.
     * @param feed The feed to retrieve the rate from.
     * @return rate The rate of the feed.
     * @return updatedAt The timestamp of the last update.
     */
    function getRate(IEOFeedAdapterBase.Feed memory feed) internal view returns (int256 rate, uint256 updatedAt) {
        if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.MINIMAL_AGGREGATOR_V3_INTERFACE) {
            (, rate,, updatedAt,) = MinimalAggregatorV3Interface(feed.feedAddress).latestRoundData();
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.IERC4626_VAULT) {
            IERC4626 vault = IERC4626(feed.feedAddress);
            rate = int256(vault.convertToAssets(10 ** vault.decimals()));
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.CUSTOM_ADAPTER_INTERFACE) {
            rate = ICustomAdapter(feed.customAdapterAddress).getCustomRate(feed.feedAddress);
        } else {
            revert FeedInterfaceNotSupported(feed.feedAddress, feed.feedInterface);
        }
    }

    /**
     * @notice Retrieves the decimals of the feed.
     * @dev Reverts if the feed interface is not supported.
     * @param feed The feed to retrieve the decimals from.
     * @return decimals The decimals of the feed.
     */
    function getDecimals(IEOFeedAdapterBase.Feed memory feed) internal view returns (uint8) {
        if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.MINIMAL_AGGREGATOR_V3_INTERFACE) {
            return IDecimals(feed.feedAddress).decimals();
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.IERC4626_VAULT) {
            return IDecimals(IERC4626(feed.feedAddress).asset()).decimals();
        } else if (feed.feedInterface == IEOFeedAdapterBase.FeedInterface.CUSTOM_ADAPTER_INTERFACE) {
            try ICustomAdapter(feed.customAdapterAddress).getDecimals(feed.feedAddress) returns (uint8 decimals) {
                return decimals;
            } catch {
                return IDecimals(feed.feedAddress).decimals();
            }
        } else {
            revert FeedInterfaceNotSupported(feed.feedAddress, feed.feedInterface);
        }
    }
}
