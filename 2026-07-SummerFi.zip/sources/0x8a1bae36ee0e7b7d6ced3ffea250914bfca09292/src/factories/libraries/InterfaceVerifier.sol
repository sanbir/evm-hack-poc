// SPDX-License-Identifier: MIT
pragma solidity 0.8.25;

import { MinimalAggregatorV3Interface } from "../../interfaces/factories/MinimalAggregatorV3Interface.sol";
import { IERC4626 } from "@openzeppelin/contracts/interfaces/IERC4626.sol";
import { IDecimals } from "../../interfaces/factories/IDecimals.sol";
import { ICustomAdapter } from "../../interfaces/factories/ICustomAdapter.sol";

/**
 * @title InterfaceVerifier
 * @author EO
 * @notice A library for verifying the interface of the feed.
 */
library InterfaceVerifier {
    /**
     * @notice The error emitted when the MinimalAggregatorV3Interface is not implemented.
     * @param feed The address of the feed.
     */
    error MinimalAggregatorV3InterfaceNotImplemented(address feed);

    /**
     * @notice The error emitted when the IERC4626Vault is not implemented.
     * @param feed The address of the feed.
     */
    error IERC4626VaultNotImplemented(address feed);

    /**
     * @notice The error emitted when the CustomAdapter interface is not implemented.
     * @param feed The address of the feed.
     * @param adapter The address of the adapter.
     */
    error CustomAdapterInterfaceNotImplemented(address feed, address adapter);

    /**
     * @notice The error emitted when the Decimals interface is not implemented.
     * @param addr The address of the feed.
     */
    error DecimalsNotImplemented(address addr);

    /**
     * @notice Verifies the MinimalAggregatorV3Interface.
     * @dev feed latestRoundData() AND feed decimals() must be implemented, reverts otherwise.
     * @param feed The address of the feed.
     */
    function verifyMinimalAggregatorV3Interface(address feed) internal view {
        try MinimalAggregatorV3Interface(feed).latestRoundData() returns (uint80, int256, uint256, uint256, uint80) {
            _verifyDecimals(feed);
        } catch {
            revert MinimalAggregatorV3InterfaceNotImplemented(feed);
        }
    }

    /**
     * @notice Verifies the IERC4626Vault.
     * @dev feed convertToAssets() AND feed decimals() AND feed asset decimals must be implemented, reverts otherwise.
     * @param feed The address of the feed.
     */
    function verifyIERC4626(address feed) internal view {
        try IERC4626(feed).convertToAssets(10 ** IERC4626(feed).decimals()) returns (uint256) {
            _verifyDecimals(IERC4626(feed).asset());
        } catch {
            revert IERC4626VaultNotImplemented(feed);
        }
    }

    /**
     * @notice Verifies the ICustomAdapter.
     * @dev feed getCustomRate() AND (plugin getDecimals() OR feed decimals()) must be implemented.
     * @param feed The address of the feed.
     * @param adapter The address of the adapter.
     */
    function verifyICustomAdapter(address feed, address adapter) internal view {
        try ICustomAdapter(adapter).getCustomRate(feed) returns (int256) {
            try ICustomAdapter(adapter).getDecimals(feed) returns (uint8) {
                return;
            } catch {
                _verifyDecimals(feed);
            }
        } catch {
            revert CustomAdapterInterfaceNotImplemented(feed, adapter);
        }
    }

    /**
     * @notice Verifies the IDecimals.
     * @dev decimals() must be implemented, reverts otherwise.
     * @param addr The address of the contract to verify the decimals of.
     */
    function verifyDecimals(address addr) internal view {
        _verifyDecimals(addr);
    }

    /**
     * @notice Internal function to verify the IDecimals.
     * @dev decimals() must be implemented, reverts otherwise.
     * @param addr The address of the contract to verify the decimals of.
     */
    function _verifyDecimals(address addr) private view {
        try IDecimals(addr).decimals() returns (uint8) {
            return;
        } catch {
            revert DecimalsNotImplemented(addr);
        }
    }
}
