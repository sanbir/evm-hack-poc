# Atomic (AtomicLending) — Flash-Loan Uni V3 Spot Manipulation on Arbitrum (~$29.9K)

<!-- non-defihacklabs: Crypto Training original detection & analysis (Twitter hack alerting) -->

> **Vulnerability classes:** vuln/oracle/spot-price · vuln/oracle/price-manipulation · vuln/defi/flash-loan

---

## Key info

| | |
|---|---|
| **Loss** | **~$29,984 USDC** (native USDC on Arbitrum) |
| **Chain** | Arbitrum One (chainId **42161**) |
| **Protocol** | Atomic / AtomicLending (`@atomic__green`) |
| **Attacker EOA** | [`0xf8803DaE…6C7E`](https://arbiscan.io/address/0xf8803dae13a6757e53711214769b5fb52ec26c7e) |
| **Exploit contract** | [`0x44d2D34E…7255`](https://arbiscan.io/address/0x44d2d34e148e1da5c4291c110f6ff0e472037255) |
| **Victim vault** | [`0x51ff48f2…42A8`](https://arbiscan.io/address/0x51ff48f2d43966be796692bdddfae96a435242a8) (unverified) |
| **Strategy / lending** | [`0xF617a3Ad…69d9`](https://arbiscan.io/address/0xf617a3ad1f0ab9d9fe39e48d688bfe44562769d9) / [`0xc1b67703…2504`](https://arbiscan.io/address/0xc1b677039892c048f2efb7e9c5da1b51fde92504) |
| **Price source** | Uni V3 ARB/USDC.e [`0xcDa53B1F…DaD8`](https://arbiscan.io/address/0xcda53b1f66614552f834ceef361a8d12a0b8dad8) |
| **Flash lender** | Aave V3 Pool [`0x794a6135…14aD`](https://arbiscan.io/address/0x794a61358d6845594f94dc1db02a252b5b4814ad) |
| **Attack tx** | [`0xbd4a009c…3a9a`](https://arbiscan.io/tx/0xbd4a009cd609a05f1a64458969a1e2c2065472f0ee06a322246f155be12e3a9a) (block **492104035**) |
| **Alert** | [DefimonAlerts 2026-08-08](https://x.com/DefimonAlerts/status/2085979711163826236) |
| **Bug class** | Same-tx flash-loan **spot** manipulation of the Uni V3 pool used to value concentrated-liquidity collateral / strategy positions |

---

## TL;DR

1. Atomic’s strategy / AtomicLending path **values LP collateral from the live Uni V3 ARB/USDC.e spot**.
2. Attacker’s pre-deployed exploit calls Aave V3 to flash **~2.23M ARB**, skews that pool, then drives mispriced unwind/withdraw against the vault modules.
3. Proceeds are swapped toward **USDC** and sent to the attacker EOA (**~29,984 USDC**).
4. Core vault/strategy contracts are **unverified proxies**.

---

## Attack walkthrough

```mermaid
flowchart LR
  A[Aave flash ARB] --> B[Skew Uni V3 ARB/USDC.e spot]
  B --> C[Mispriced strategy / AtomicLending unwind]
  C --> D[Extract ARB + USDC.e]
  D --> E[Route to native USDC]
  E --> F[Profit to attacker EOA]
  F --> G[Repay Aave]
```

1. Deploy exploit (block 492103439); owner = attacker EOA.
2. `run(2_230_717.8e18, 1, 25_000e6)` — onlyOwner.
3. Flash ARB → swap into Uni V3 → call vault/strategy entrypoints under skewed price → reverse/swap out → transfer USDC to owner → repay flash.

---

## PoC

**Offline (committed `anvil_state.json`):**

```bash
cd 2026-08-AtomicAtomicLendingOracleManipulation_exp
anvil --load-state anvil_state.json --port 8547 --chain-id 42161 &
forge test --match-test testExploit -vvv
```

**Online (Arbitrum archive RPC):**

```bash
ATOMIC_FORK_URL=$ARBITRUM_ARCHIVE_RPC forge test --match-test testExploit -vvv
```

Expected: `[PASS]` with **≥ 29,984.270865 USDC** to the attacker.

Replay entrypoint (historical):

```text
IAtomicExploit(0x44d2…7255).run(2_230_717.8e18, 1, 25_000e6)
// onlyOwner — prank attacker EOA 0xf880…6C7E
```

---

## References

- https://x.com/DefimonAlerts/status/2085979711163826236
- https://arbiscan.io/tx/0xbd4a009cd609a05f1a64458969a1e2c2065472f0ee06a322246f155be12e3a9a
- https://arbiscan.io/address/0x44d2d34e148e1da5c4291c110f6ff0e472037255
- https://arbiscan.io/address/0x51ff48f2d43966be796692bdddfae96a435242a8
