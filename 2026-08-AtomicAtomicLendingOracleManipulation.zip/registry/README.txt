Authoritative Forge reproduction

Registry folder: 2026-08-AtomicAtomicLendingOracleManipulation_exp
Registry base commit: f8b2ae63628a0d571d3d3ce72511491ea2250284

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-AtomicAtomicLendingOracleManipulation_exp -vvv
