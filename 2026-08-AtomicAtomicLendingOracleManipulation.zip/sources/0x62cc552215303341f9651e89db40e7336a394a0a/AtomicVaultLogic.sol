// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.0;

/// @notice Reconstructed view of Atomic vault business logic at
///         0x62cc552215303341f9651e89db40e7336a394a0a (Arbitrum).
/// @dev Unverified on-chain. Selector 0xa806010f (SlowMist: partialBurn path)
///      accepts a manager ECDSA signature whose digest does NOT bind
///      positionId / manager / caller / nonce / deadline / chainId — enabling
///      the same signature to authorize full Uni V3 LP burns across many IDs.
///
///      Line numbers below are editorial anchors mapped onto runtime PCs
///      (hand pcToLine). The highlighted ecrecover line is the actual
///      STATICCALL to precompile 1 at runtime PC 15552.

interface INonfungiblePositionManager {
    function burn(uint256 tokenId) external payable;
    function decreaseLiquidity(bytes calldata params) external payable returns (uint256, uint256);
    function collect(bytes calldata params) external payable returns (uint256, uint256);
}

library ECDSA {
    /// @dev OZ-style recover: staticcall(gas(), 1, data, 0x80, data, 0x20)
    function recover(bytes32 hash, uint8 v, bytes32 r, bytes32 s) internal pure returns (address signer) {
        // VULN / ROOT CAUSE: ecrecover accepts (hash,v,r,s) only.
        // The hash/digest above this call was built WITHOUT binding
        // positionId, positionManager, msg.sender, nonce, deadline, chainId.
        assembly {
            let ptr := mload(0x40)
            mstore(ptr, hash)
            mstore(add(ptr, 0x20), v)
            mstore(add(ptr, 0x40), r)
            mstore(add(ptr, 0x60), s)
            // PC 15552: STATICCALL to ecrecover precompile (address 1)
            if iszero(staticcall(gas(), 1, ptr, 0x80, ptr, 0x20)) {
                revert(0, 0)
            }
            signer := mload(ptr)
        }
    }
}

contract AtomicVaultLogic {
    address public owner;
    address public managerSigner; // authorized manager public key / address
    INonfungiblePositionManager public positionManager;

    /// @notice Selector 0xa806010f — manager-authorized partial / full LP burn.
    /// @dev SlowMist: same (v,r,s) replayed across 21 different position IDs.
    function partialBurn(
        uint256 positionId,
        uint128 liquidity,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external {
        // Digested fields are incomplete — missing positionId / manager /
        // caller / nonce / deadline / chainId (signature replay surface).
        bytes32 digest = keccak256(
            abi.encode(
                // BUG: incomplete binding — positionId and caller NOT included
                liquidity
            )
        );

        // ===== ROOT CAUSE LINE (mapped to ecrecover STATICCALL @ PC 15552) =====
        address signer = ECDSA.recover(digest, v, r, s);
        // ======================================================================

        require(signer == managerSigner, "bad sig");

        // Authorized by the (replayable) manager signature:
        // full / partial burn of the Uni V3 position NFT.
        positionManager.decreaseLiquidity(abi.encode(positionId, liquidity));
        positionManager.collect(abi.encode(positionId));
        // may fully burn when liquidity reaches 0
        // positionManager.burn(positionId);
    }
}
