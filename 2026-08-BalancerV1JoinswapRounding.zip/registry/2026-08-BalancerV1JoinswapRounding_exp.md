# Balancer V1 BPool `joinswapPoolAmountOut` Rounding — Mint BPT for 1 Satoshi

<!-- non-defihacklabs: Crypto Training original detection & analysis (Twitter hack alerting) -->

> **Vulnerability classes:** vuln/precision/rounding · vuln/amm/join-exit · vuln/math/fixed-point

---

## Key info

| | |
|---|---|
| **Loss** | **~$234k** (DPI + USDC + WETH + WBTC from one BPool; sibling V1 pools also hit) |
| **Chain** | Ethereum |
| **Protocol** | Balancer V1 |
| **Victim BPool** | [`0x2257aaac…ac57`](https://etherscan.io/address/0x2257aaac34BcB27900291f7B84eE2565A6cbaC57) (DPI/USDC/WETH/WBTC) |
| **Attacker** | [`0x338C7Ec9…9a41`](https://etherscan.io/address/0x338C7Ec9BefbB451d66Fd8A468c32184f5689a41) |
| **Attack tx** | [`0x72510b25…1aff`](https://etherscan.io/tx/0x72510b257cc09bde8435b83ac1636f9498ffc353583330600b5b8da43d0d1aff) |
| **Fork block** | **25,872,273** |
| **Alert** | [SlowMist](https://x.com/SlowMist_Team/status/2094272540193722744) |
| **Bug class** | After dust-compressing an 8-decimal reserve, `joinswapPoolAmountOut` mints caller-specified BPT while `calcSingleInGivenPoolOut` floors `tokenAmountIn` to 1 wei |

**Not** `2025-11-BalancerV2_exp` — different product generation and mechanism.

---

## Root cause

`BPool.joinswapPoolAmountOut` asks the user for `poolAmountOut` and computes `tokenAmountIn` via `BMath.calcSingleInGivenPoolOut` (18-decimal fixed-point). When WBTC reserves are compressed to dust, the reverse-calc rounds **down** to **1 satoshi**, yet full BPT is still minted. Attacker then exits other pool tokens.

Vulnerable math: `sources/BPool_2257aa/BMath.sol` `calcSingleInGivenPoolOut` (~L156) called from `BPool.sol` `joinswapPoolAmountOut` (~L584).

---

## PoC result

```text
[PASS] testExploit()
DPI profit: 546.257565286935420823
WETH profit: 11.447667518174463645
USDC profit: 27710.408579
WBTC profit: 0.35710643
```

```bash
cd 2026-08-BalancerV1JoinswapRounding_exp
forge test --match-test testExploit -vv
```
