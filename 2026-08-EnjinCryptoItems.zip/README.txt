2026-08-EnjinCryptoItems
Registry folder: 2026-08-EnjinCryptoItems_exp
Packed: 2026-10-02T06:33:36Z
Offline anvil_state.json: yes
output.txt contains [PASS]: yes
Reproduce from registry/ with the shared anvil harness when state is present:
  _shared/run_poc.sh 2026-08-EnjinCryptoItems_exp -vvvvv
