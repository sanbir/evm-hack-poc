Authoritative Forge reproduction

Registry folder: 2026-08-LpdFi_exp
Registry base commit: 06d2a2f125847ef4f8df683b13279aa7985acdf5

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-LpdFi_exp -vvv
