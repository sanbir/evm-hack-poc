Authoritative Forge reproduction

Registry folder: 2026-08-MoonwellMamoOracleManipulation_exp
Registry base commit: d6c70c964a670c7ac83c24b3ca91bd862b1bf9d6

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-MoonwellMamoOracleManipulation_exp -vvv
