Authoritative Forge reproduction

Registry folder: 2026-08-MoreMarkets_exp
Registry base commit: bfe68fe0491c122878a1ce2ea64f9b1d433eb06d

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-MoreMarkets_exp -vvv
