Authoritative Forge reproduction

Registry folder: 2026-08-NexAicFotSkim_exp
Registry base commit: 3270366ae5425c6789d89f15389207c23355b83a

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-NexAicFotSkim_exp -vvv
