Authoritative Forge reproduction

Registry folder: 2026-08-USM_FUM_exp
Registry base commit: 0bce28aad3b2e997e230fa7c34177d80102fb040

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-USM_FUM_exp -vvv
