Authoritative Forge reproduction

Registry folder: 2026-08-UnistreetsLaunchpadFactory_exp
Registry base commit: 74f3aeaddaf9141aa45a34e94079bb292aa20471

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-UnistreetsLaunchpadFactory_exp -vvv
