Authoritative Forge reproduction

Registry folder: 2026-08-ZKPantherGovernanceUpgrade_exp
Registry base commit: fd8cead4a701d255a1d56d20fa3d07d1a91f3c95

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-ZKPantherGovernanceUpgrade_exp -vvv
