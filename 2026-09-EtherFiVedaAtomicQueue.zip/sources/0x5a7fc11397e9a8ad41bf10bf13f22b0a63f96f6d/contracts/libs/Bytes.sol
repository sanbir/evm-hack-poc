// SPDX-License-Identifier: agpl-3.0
pragma solidity 0.8.19;

library Bytes {
	function trimToSize(bytes memory b, uint256 newLen) internal pure {
		require(b.length > newLen, 'BytesLib: only shrinking');
		assembly {
			mstore(b, newLen)
		}
	}

	/***********************************|
	|        Read Bytes Functions       |
	|__________________________________*/

	/**
	 * @dev Reads a bytes32 value from a position in a byte array.
	 * @param b Byte array containing a bytes32 value.
	 * @param index Index in byte array of bytes32 value.
	 * @return result bytes32 value from byte array.
	 */
	function readBytes32(bytes memory b, uint256 index) internal pure returns (bytes32 result) {
		// Arrays are prefixed by a 256 bit length parameter
		index += 32;

		require(b.length >= index, 'BytesLib: length');

		// Read the bytes32 from array memory
		assembly {
			result := mload(add(b, index))
		}
		return result;
	}
}
