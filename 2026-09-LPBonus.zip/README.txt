2026-09-LPBonus
Registry folder: 2026-09-LPBonus_exp
Packed: 2026-10-02T06:33:38Z
Offline anvil_state.json: yes
output.txt contains [PASS]: yes
Reproduce from registry/ with the shared anvil harness when state is present:
  _shared/run_poc.sh 2026-09-LPBonus_exp -vvvvv
