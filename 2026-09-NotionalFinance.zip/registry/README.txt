Authoritative Forge reproduction

Registry folder: 2026-09-NotionalFinance_exp
Registry base commit: 8bb1b1188858067eab174311f8e0c6fe1e65ad47

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-09-NotionalFinance_exp -vvv
