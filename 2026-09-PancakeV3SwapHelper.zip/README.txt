2026-09-PancakeV3SwapHelper
Registry folder: 2026-09-PancakeV3SwapHelper_exp
Packed: 2026-10-12T06:44:30Z
Offline anvil_state.json: no (fork block warm failed)
output.txt passing: yes
Reproduce online: _shared/run_poc.sh 2026-09-PancakeV3SwapHelper_exp -vvvvv
