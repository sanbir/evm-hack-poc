2026-09-PrimeFinance
Registry folder: 2026-09-PrimeFinance_exp
Packed: 2026-10-02T07:33:33Z
Offline anvil_state.json: yes
output.txt contains [PASS]: yes
Reproduce from registry/ with the shared anvil harness when state is present:
  _shared/run_poc.sh 2026-09-PrimeFinance_exp -vvvvv
