// SPDX-License-Identifier: Apache-2.0.
pragma solidity ^0.8.24;
import {ILido} from "../interfaces/lido/ILido.sol";
import {ILidoLocator} from "../interfaces/lido/ILidoLocator.sol";
import {IWithdrawalQueue} from "../interfaces/lido/IWithdrawalQueue.sol";
import "hardhat/console.sol";

interface IWstETH {
  function wrap(uint256 _stETHAmount) external returns (uint256);
  function unwrap(uint256 _wstETHAmount) external returns (uint256);
}

contract LidoProvider {
  address constant NATIVE_ETH_ADDRESS =
    0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;

  bytes32 constant LIDO_PROVIDER_STORAGE_POSITION =
    keccak256("diamond.standard.lidoProvider.storage");
  uint256 constant MAX_WITHDRAWAL_SIZE = 1000 ether;

  struct LidoProviderStorage {
    address lidoLocatorAddress;
    bool isLidoProviderInitialized;
  }

  function _lidoProviderStorage()
    internal
    pure
    returns (LidoProviderStorage storage ds)
  {
    bytes32 position = LIDO_PROVIDER_STORAGE_POSITION;
    assembly {
      ds.slot := position
    }
  }

  struct WithdrawalData {
    uint256 preparingAmount;
    uint256 preparedAmount;
  }

  event Invested(
    address indexed liquidity,
    address indexed asset,
    uint256 amount
  );

  event WithdrawalPrepared(
    address indexed liquidity,
    address indexed asset,
    uint256 amount
  );

  event WithdrawalFinished(
    address indexed liquidity,
    address indexed asset,
    uint256 amount
  );

  function isInitialized() external view returns (bool) {
    return _lidoProviderStorage().isLidoProviderInitialized;
  }

  function initialize(bytes[] memory params) external {
    require(params.length > 0, "No params provided");
    require(
      !_lidoProviderStorage().isLidoProviderInitialized,
      "Already initialized"
    );
    _lidoProviderStorage().lidoLocatorAddress = abi.decode(
      params[0],
      (address)
    );
    _lidoProviderStorage().isLidoProviderInitialized = true;
  }

  function lidoLocatorAddress() public view returns (address) {
    return _lidoProviderStorage().lidoLocatorAddress;
  }

  modifier lidoLocatorCheck() {
    require(lidoLocatorAddress() != address(0), "LidoLocator address not set");
    _;
  }

  modifier assetCheck(address asset) {
    require(asset == NATIVE_ETH_ADDRESS, "Asset must be ether");
    _;
  }

  function _getLido() private view returns (ILido) {
    address lidoAddress = ILidoLocator(lidoLocatorAddress()).lido();
    return ILido(lidoAddress);
  }

  function _getWithdrawalQueue() private view returns (IWithdrawalQueue) {
    address withdrawalQueueAddress = ILidoLocator(lidoLocatorAddress())
      .withdrawalQueue();
    return IWithdrawalQueue(withdrawalQueueAddress);
  }

  function supportedAssets() external pure returns (address[] memory) {
    address[] memory assets = new address[](1);
    assets[0] = NATIVE_ETH_ADDRESS;
    return assets;
  }

  function canDirectlyWithdraw(
    address asset
  ) external pure assetCheck(asset) returns (bool) {
    return false;
  }

  function getWithdrawalData(
    address asset
  )
    public
    view
    lidoLocatorCheck
    assetCheck(asset)
    returns (WithdrawalData memory)
  {
    IWithdrawalQueue withdrawalQueue = _getWithdrawalQueue();
    uint256[] memory withdrawalRequests = withdrawalQueue.getWithdrawalRequests(
      address(this)
    );
    IWithdrawalQueue.WithdrawalRequestStatus[] memory statuses = withdrawalQueue
      .getWithdrawalStatus(withdrawalRequests);

    uint256 totalPending = 0;
    uint256 totalAvailable = 0;

    for (uint256 i = 0; i < statuses.length; i++) {
      if (!statuses[i].isFinalized) {
        totalPending += statuses[i].amountOfStETH;
      } else if (!statuses[i].isClaimed) {
        totalAvailable += statuses[i].amountOfStETH;
      }
    }

    return WithdrawalData(totalPending, totalAvailable);
  }

  function getAssetBalance(
    address asset
  ) public view lidoLocatorCheck assetCheck(asset) returns (uint256) {
    ILido lido = _getLido();
    WithdrawalData memory withdrawalData = getWithdrawalData(asset);
    uint256 totalInWithdrawals = withdrawalData.preparingAmount +
      withdrawalData.preparedAmount;

    return lido.balanceOf(address(this)) + totalInWithdrawals;
  }

  function invest(
    address asset,
    uint256 amount
  ) external payable lidoLocatorCheck assetCheck(asset) {
    ILido lido = _getLido();
    require(!lido.isStakingPaused(), "Staking is paused");
    require(lido.getCurrentStakeLimit() > amount, "Amount exceeds stake limit");
    lido.submit{value: amount}(address(0));
    emit Invested(address(this), asset, amount);
  }

  function prepareWithdrawal(
    address asset,
    uint256 amount
  ) external lidoLocatorCheck assetCheck(asset) {
    ILido lido = _getLido();
    IWithdrawalQueue withdrawalQueue = _getWithdrawalQueue();

    uint256 balance = lido.balanceOf(address(this));
    require(balance >= amount, "Insufficient balance");
    uint256 stEthAllowance = lido.allowance(
      address(this),
      address(withdrawalQueue)
    );
    if (stEthAllowance < amount) {
      lido.approve(address(withdrawalQueue), amount - stEthAllowance);
    }

    uint256 numChunks = (amount + MAX_WITHDRAWAL_SIZE - 1) /
      MAX_WITHDRAWAL_SIZE; // Calculate total number of chunks needed
    uint256[] memory amounts = new uint256[](numChunks);

    uint256 remainingAmount = amount;
    for (uint256 i = 0; i < numChunks; i++) {
      if (remainingAmount > MAX_WITHDRAWAL_SIZE) {
        amounts[i] = MAX_WITHDRAWAL_SIZE;
        remainingAmount -= MAX_WITHDRAWAL_SIZE;
      } else {
        amounts[i] = remainingAmount;
        remainingAmount = 0;
      }
    }

    withdrawalQueue.requestWithdrawals(amounts, address(this));
    emit WithdrawalPrepared(address(this), asset, amount);
  }

  function finishWithdrawal(
    address asset
  ) external lidoLocatorCheck assetCheck(asset) {
    IWithdrawalQueue withdrawalQueue = _getWithdrawalQueue();
    uint256[] memory withdrawalRequests = withdrawalQueue.getWithdrawalRequests(
      address(this)
    );
    IWithdrawalQueue.WithdrawalRequestStatus[] memory statuses = withdrawalQueue
      .getWithdrawalStatus(withdrawalRequests);

    uint256 totalAvailable = 0;
    for (uint256 i = 0; i < withdrawalRequests.length; i++) {
      if (statuses[i].isFinalized && !statuses[i].isClaimed) {
        withdrawalQueue.claimWithdrawal(withdrawalRequests[i]);
        totalAvailable += statuses[i].amountOfStETH;
      }
    }
    emit WithdrawalFinished(address(this), asset, totalAvailable);
  }

  function supportsEmergencyWithdraw(
    address asset
  ) external pure assetCheck(asset) returns (bool) {
    return false;
  }

  function supportsEarnings(
    address asset
  ) external pure assetCheck(asset) returns (bool) {
    return false;
  }
}
