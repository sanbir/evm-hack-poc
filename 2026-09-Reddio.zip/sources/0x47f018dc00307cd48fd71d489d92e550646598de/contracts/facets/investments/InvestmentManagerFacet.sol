// SPDX-License-Identifier: Apache-2.0.
pragma solidity ^0.8.24;

import {Ownable} from "../../utils/Ownable.sol";
import {LibAddress} from "../../libraries/LibAddress.sol";
import {IERC20Detailed} from "../../interfaces/IERC20Detailed.sol";
import {ILiquidityProvider} from "../../interfaces/ILiquidityProvider.sol";
import {IInvestmentManagerDelegated} from "../../interfaces/IInvestmentManagerDelegated.sol";
import "hardhat/console.sol";

contract InvestmentManagerFacet is Ownable {
  using LibAddress for address;

  address constant NATIVE_ETH_ADDRESS =
    0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;

  event OperatorRegistered(address indexed operator);
  event OperatorRemoved(address indexed operator);

  event ProviderAdded(address indexed provider);
  event ProviderRemoved(address indexed provider);

  event AssetPoolsEnabled(address indexed provider, address[] assets);
  event AssetPoolsDisabled(address indexed provider, address[] assets);

  event MinimumReserveRatioUpdated(uint256 minimumReserveRatio);
  event investmentReserveRatioUpdated(uint256 investmentReserveRatio);

  bytes32 constant INVESTMENTMANAGERFACET_STORAGE_POSITION =
    keccak256("diamond.standard.investmentManagerFacet.storage");

  struct IMStorage {
    uint256 minimumReserveRatio;
    uint256 investmentReserveRatio;
    bool isInitialized;
    mapping(address => bool) isOperator;
    mapping(address => uint256) providerIndexPlusOne;
    address[] providers;
    mapping(address => mapping(address => bool)) isAssetPoolEnabled;
  }

  function _iMStorage() internal pure returns (IMStorage storage ds) {
    bytes32 position = INVESTMENTMANAGERFACET_STORAGE_POSITION;
    assembly {
      ds.slot := position
    }
  }

  function minimumReserveRatio() public view returns (uint256) {
    return _iMStorage().minimumReserveRatio;
  }

  function investmentReserveRatio() public view returns (uint256) {
    return _iMStorage().investmentReserveRatio;
  }

  function isInitialized() public view returns (bool) {
    return _iMStorage().isInitialized;
  }

  function isOperator(address operator) public view returns (bool) {
    return _iMStorage().isOperator[operator];
  }

  function providerIndexPlusOne(
    address providerAddress
  ) public view returns (uint) {
    return _iMStorage().providerIndexPlusOne[providerAddress];
  }

  function providers() public view returns (address[] memory) {
    return _iMStorage().providers;
  }

  function providerByIndex(uint256 index) public view returns (address) {
    return _iMStorage().providers[index];
  }

  function isAssetPoolEnabled(
    address providerAddress,
    address asset
  ) public view returns (bool) {
    return _iMStorage().isAssetPoolEnabled[providerAddress][asset];
  }

  function investmentManagerInit(
    address operator,
    uint256 _minimumReserveRatio,
    uint256 _investmentReserveRatio
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    require(!ds.isInitialized, "InvestmentManagerInit: Already initialized");
    require(_investmentReserveRatio >= _minimumReserveRatio, "Invalid ratios");
    ds.minimumReserveRatio = _minimumReserveRatio;
    ds.investmentReserveRatio = _investmentReserveRatio;
    ds.isOperator[operator] = true;
    ds.isInitialized = true;
  }

  modifier onlyOperator() {
    require(isOperator(msg.sender), "Caller is not an operator");
    _;
  }

  modifier onlyAssetPoolEnabled(address providerAddress, address asset) {
    require(
      isAssetPoolEnabled(providerAddress, asset),
      "Asset pool not enabled"
    );
    _;
  }

  function registerOperator(address operator) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    ds.isOperator[operator] = true;
    emit OperatorRegistered(operator);
  }

  function unregisterOperator(address operator) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    ds.isOperator[operator] = false;
    emit OperatorRemoved(operator);
  }

  function updateMinimumReserveRatio(
    uint256 _minimumReserveRatio
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    require(
      ds.investmentReserveRatio >= _minimumReserveRatio,
      "Invalid ratios"
    );
    ds.minimumReserveRatio = _minimumReserveRatio;
    emit MinimumReserveRatioUpdated(_minimumReserveRatio);
  }

  function updateInvestmentReserveRatio(
    uint256 _investmentReserveRatio
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    require(
      _investmentReserveRatio >= ds.minimumReserveRatio,
      "Invalid ratios"
    );
    ds.investmentReserveRatio = _investmentReserveRatio;
    emit investmentReserveRatioUpdated(_investmentReserveRatio);
  }

  function addProvider(
    address providerAddress,
    bytes[] memory params
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    require(
      ds.providerIndexPlusOne[providerAddress] == 0,
      "Provider already added"
    );
    bytes memory providerIsInitializedCallData = abi.encodeWithSelector(
      ILiquidityProvider.isInitialized.selector
    );
    bool providerIsInitialized = abi.decode(
      _delegateToProvider(providerAddress, providerIsInitializedCallData),
      (bool)
    );

    if (!providerIsInitialized) {
      bytes memory providerInitializeCallData = abi.encodeWithSelector(
        ILiquidityProvider.initialize.selector,
        params
      );
      _delegateToProvider(providerAddress, providerInitializeCallData);
    }

    ds.providers.push(providerAddress); // Add address to the array
    ds.providerIndexPlusOne[providerAddress] = ds.providers.length; // Map to its index plus one
    emit ProviderAdded(providerAddress);
  }

  function removeProvider(address providerAddress) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    uint256 indexPlusOne = ds.providerIndexPlusOne[providerAddress];
    require(indexPlusOne != 0, "Provider does not exist");
    uint256 index = indexPlusOne - 1; // Subtract one to get the actual array index

    if (index != ds.providers.length - 1) {
      // If it is not the last element in the array
      address lastProvider = ds.providers[ds.providers.length - 1];
      ds.providers[index] = lastProvider; // Move the last element to the deleted element's position
      ds.providerIndexPlusOne[lastProvider] = index + 1; // Update the mapping, adding one because we store index plus one
    }
    ds.providers.pop(); // Remove the last element of the array
    delete ds.providerIndexPlusOne[providerAddress]; // Remove the element from the mapping
    emit ProviderRemoved(providerAddress);
  }

  function isProvider(address providerAddress) public view returns (bool) {
    return providerIndexPlusOne(providerAddress) != 0;
  }

  function enableAssetPoolsForProvider(
    address providerAddress,
    address[] memory assets
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    for (uint256 i = 0; i < assets.length; i++) {
      ds.isAssetPoolEnabled[providerAddress][assets[i]] = true;
    }
    emit AssetPoolsEnabled(providerAddress, assets);
  }

  function disableAssetPoolsForProvider(
    address providerAddress,
    address[] memory assets
  ) external onlyOwner {
    IMStorage storage ds = _iMStorage();
    for (uint256 i = 0; i < assets.length; i++) {
      ds.isAssetPoolEnabled[providerAddress][assets[i]] = false;
    }
    emit AssetPoolsDisabled(providerAddress, assets);
  }

  function getRemainingBalance(address asset) public view returns (uint256) {
    if (asset == NATIVE_ETH_ADDRESS) {
      return address(this).balance;
    } else {
      return IERC20Detailed(asset).balanceOf(address(this));
    }
  }

  function _delegateToProvider(
    address providerAddress,
    bytes memory callData
  ) internal returns (bytes memory) {
    (bool success, bytes memory returndata) = providerAddress.delegatecall(
      callData
    );
    if (!success) {
      if (returndata.length > 0) {
        assembly {
          let returndata_size := mload(returndata)
          revert(add(32, returndata), returndata_size)
        }
      } else {
        revert("delegatecall failed with no data");
      }
    }
    return returndata;
  }

  function delegateBySelf(
    address providerAddress,
    bytes memory callData
  ) public returns (bytes memory) {
    require(msg.sender == address(this), "Only InvestmentManager can call");
    bytes memory returndata = _delegateToProvider(providerAddress, callData);
    return returndata;
  }

  function _staticToProvider(
    address providerAddress,
    bytes memory callData
  ) internal view returns (bytes memory) {
    bytes memory combinedData = abi.encodeWithSelector(
      IInvestmentManagerDelegated.delegateBySelf.selector,
      providerAddress,
      callData
    );
    (bool success, bytes memory returndata) = address(this).staticcall(
      combinedData
    );
    require(success, "Staticcall failed");
    return abi.decode(returndata, (bytes));
  }

  function supportedAssets(
    address providerAddress
  ) external view returns (address[] memory) {
    ILiquidityProvider provider = ILiquidityProvider(providerAddress);
    bytes memory callData = abi.encodeWithSelector(
      provider.supportedAssets.selector
    );
    return
      abi.decode(_staticToProvider(providerAddress, callData), (address[]));
  }

  function canDirectlyWithdraw(
    address providerAddress,
    address asset
  ) public view returns (bool) {
    bytes memory callData = abi.encodeWithSelector(
      ILiquidityProvider.canDirectlyWithdraw.selector,
      asset
    );
    return abi.decode(_staticToProvider(providerAddress, callData), (bool));
  }

  function getWithdrawalData(
    address providerAddress,
    address asset
  ) public view returns (ILiquidityProvider.WithdrawalData memory) {
    if (isAssetPoolEnabled(providerAddress, asset)) {
      bytes memory callData = abi.encodeWithSelector(
        ILiquidityProvider.getWithdrawalData.selector,
        asset
      );
      return
        abi.decode(
          _staticToProvider(providerAddress, callData),
          (ILiquidityProvider.WithdrawalData)
        );
    } else {
      return ILiquidityProvider.WithdrawalData(0, 0);
    }
  }

  function getAssetBalance(
    address providerAddress,
    address asset
  ) public view returns (uint256) {
    if (isAssetPoolEnabled(providerAddress, asset)) {
      bytes memory callData = abi.encodeWithSelector(
        ILiquidityProvider.getAssetBalance.selector,
        asset
      );
      return
        abi.decode(_staticToProvider(providerAddress, callData), (uint256));
    } else {
      return 0;
    }
  }

  // Function to get the total asset balance for all providers for a specific asset
  function getTotalAssetBalance(
    address asset
  ) public view returns (uint256 totalBalance) {
    uint256 totalInProviders = 0;
    for (uint256 i = 0; i < providers().length; i++) {
      address providerAddress = providerByIndex(i);
      totalInProviders += getAssetBalance(providerAddress, asset);
    }
    return totalInProviders + getRemainingBalance(asset);
  }

  function invest(
    address providerAddress,
    address asset,
    uint256 amount
  ) public onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(
      getRemainingBalance(asset) >=
        amount + (minimumReserveRatio() * getTotalAssetBalance(asset)) / 10000,
      "Investment limit reached"
    );
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.invest.selector,
      asset,
      amount
    );
    _delegateToProvider(providerAddress, data);
  }

  function prepareWithdrawal(
    address providerAddress,
    address asset,
    uint256 amount
  ) public onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(
      !canDirectlyWithdraw(providerAddress, asset),
      "Should direct withdraw"
    );
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.prepareWithdrawal.selector,
      asset,
      amount
    );
    _delegateToProvider(providerAddress, data);
  }

  function finishWithdrawal(
    address providerAddress,
    address asset
  ) public onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(
      !canDirectlyWithdraw(providerAddress, asset),
      "Should direct withdraw"
    );
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.finishWithdrawal.selector,
      asset
    );
    _delegateToProvider(providerAddress, data);
  }

  function directlyWithdraw(
    address providerAddress,
    address asset,
    uint256 amount
  ) public onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(
      canDirectlyWithdraw(providerAddress, asset),
      "Direct withdraw not supported"
    );
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.directlyWithdraw.selector,
      asset,
      amount
    );
    _delegateToProvider(providerAddress, data);
  }

  function emergencyWithdraw(
    address providerAddress,
    address asset,
    uint256 amount
  ) external onlyOwner onlyAssetPoolEnabled(providerAddress, asset) {
    require(
      supportsEmergencyWithdraw(providerAddress, asset),
      "Emergency withdraw not supported"
    );
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.emergencyWithdraw.selector,
      asset,
      amount
    );
    _delegateToProvider(providerAddress, data);
  }

  function getEarnings(
    address providerAddress,
    address asset
  ) public view onlyAssetPoolEnabled(providerAddress, asset) returns (uint256) {
    require(supportsEarnings(providerAddress, asset), "Earnings not supported");
    bytes memory callData = abi.encodeWithSelector(
      ILiquidityProvider.getEarnings.selector,
      asset
    );
    return abi.decode(_staticToProvider(providerAddress, callData), (uint256));
  }

  function reinvest(
    address providerAddress,
    address asset,
    uint256 amount
  ) external onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(supportsEarnings(providerAddress, asset), "Earnings not supported");
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.reinvest.selector,
      asset,
      amount
    );
    _delegateToProvider(providerAddress, data);
  }

  function reinvestAllEarnings(
    address providerAddress,
    address asset
  ) public onlyOperator onlyAssetPoolEnabled(providerAddress, asset) {
    require(supportsEarnings(providerAddress, asset), "Earnings not supported");
    bytes memory data = abi.encodeWithSelector(
      ILiquidityProvider.reinvestAllEarnings.selector,
      asset
    );
    _delegateToProvider(providerAddress, data);
  }

  function rebalance(
    address providerAddress,
    address asset
  ) external onlyAssetPoolEnabled(providerAddress, asset) {
    uint256 totalBalance = getTotalAssetBalance(asset);
    uint256 minimumReserve = (minimumReserveRatio() * totalBalance) / 10000;
    uint256 investmentReserve = (investmentReserveRatio() * totalBalance) /
      10000;
    uint256 investmentThreshold = investmentReserve +
      (investmentReserve - minimumReserve);
    uint256 remainingBalance = getRemainingBalance(asset);
    if (remainingBalance > investmentThreshold) {
      uint256 amount = remainingBalance - investmentReserve;
      invest(providerAddress, asset, amount);
    } else if (remainingBalance < minimumReserve) {
      uint256 amount = investmentReserve - remainingBalance;
      if (canDirectlyWithdraw(providerAddress, asset)) {
        directlyWithdraw(providerAddress, asset, amount);
      } else {
        ILiquidityProvider.WithdrawalData
          memory withdrawalData = getWithdrawalData(providerAddress, asset);
        uint256 preparingAmount = withdrawalData.preparingAmount;
        uint256 preparedAmount = withdrawalData.preparedAmount;
        if (preparedAmount > 0) {
          amount -= preparedAmount;
          finishWithdrawal(providerAddress, asset);
        }
        if (amount > preparingAmount) {
          amount -= getWithdrawalData(providerAddress, asset).preparingAmount;
          prepareWithdrawal(providerAddress, asset, amount);
        }
      }
    }
  }

  function supportsEmergencyWithdraw(
    address providerAddress,
    address asset
  ) public view onlyAssetPoolEnabled(providerAddress, asset) returns (bool) {
    bytes memory callData = abi.encodeWithSelector(
      ILiquidityProvider.supportsEmergencyWithdraw.selector,
      asset
    );
    return abi.decode(_staticToProvider(providerAddress, callData), (bool));
  }

  function supportsEarnings(
    address providerAddress,
    address asset
  ) public view returns (bool) {
    bytes memory callData = abi.encodeWithSelector(
      ILiquidityProvider.supportsEarnings.selector,
      asset
    );
    return abi.decode(_staticToProvider(providerAddress, callData), (bool));
  }
}
