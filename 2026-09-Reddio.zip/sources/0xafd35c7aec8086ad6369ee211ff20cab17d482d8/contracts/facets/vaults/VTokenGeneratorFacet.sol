// SPDX-License-Identifier: Apache-2.0.
pragma solidity ^0.8.24;

import {VToken} from "./VToken.sol";
import {Ownable} from "../../utils/Ownable.sol";
import "hardhat/console.sol";

contract VTokenGeneratorFacet is Ownable {
  event TokenCreated(address tokenAddress);

  function _createToken(
    string memory name,
    string memory symbol,
    uint8 decimals
  ) internal returns (address) {
    VToken newVToken = new VToken(name, symbol, decimals, address(this));
    emit TokenCreated(address(newVToken));
    return address(newVToken);
  }

  function createToken(
    string memory name,
    string memory symbol,
    uint8 decimals
  ) external returns (address) {
    require(
      msg.sender == address(this),
      "VTokenGeneratorFacet: Only self allowed"
    );
    return _createToken(name, symbol, decimals);
  }
}
