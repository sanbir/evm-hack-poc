// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

interface IPancakeFactory {
    function createPair(address tokenA, address tokenB) external returns (address);
}

contract OCEAN is ERC20, Ownable {
    using SafeERC20 for IERC20;

    address private immutable deployer;
    uint8 private immutable tokenDecimals;
    address public immutable pair;
    bool public tradingEnabled;
    mapping(address => bool) public isExempt;

    constructor(
        address factory_,
        address wbnb_,
        string memory name_,
        string memory symbol_,
        uint8 decimals_,
        uint256 supply_
    ) ERC20(name_, symbol_) Ownable(msg.sender) {
        deployer = msg.sender;
        tokenDecimals = decimals_;
        pair = IPancakeFactory(factory_).createPair(address(this), wbnb_);
        _mint(msg.sender, supply_ * 10 ** decimals_);
    }

    function decimals() public view override returns (uint8) {
        return tokenDecimals;
    }

    function enableTrading() external onlyOwner {
        tradingEnabled = true;
    }

    function setExempt(address account, bool value) external onlyOwner {
        isExempt[account] = value;
    }


    function _update(address from, address to, uint256 value) internal override {
        require(
            tradingEnabled || from == deployer || to == deployer || isExempt[from] || isExempt[to],
            "Trading not enabled"
        );
        super._update(from, to, value);
    }

    function rescueBNB() external {
        require(msg.sender == deployer, "Only deployer");
        (bool ok, ) = deployer.call{value: address(this).balance}("");
        require(ok, "BNB send failed");
    }

    function rescueToken(address token) external {
        require(msg.sender == deployer, "Only deployer");
        require(token != address(this), "Cannot rescue own token");
        IERC20(token).safeTransfer(deployer, IERC20(token).balanceOf(address(this)));
    }
}
