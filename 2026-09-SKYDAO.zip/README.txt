2026-09-SKYDAO
Registry folder: 2026-09-SKYDAO_exp
Packed: 2026-10-12T06:43:41Z
Offline anvil_state.json: no
output.txt passing: yes
Reproduce: _shared/run_poc.sh 2026-09-SKYDAO_exp -vvvvv
