// SPDX-License-Identifier: MIT
pragma solidity ^0.8.30;

import {IExecutionHelper} from '../interfaces/core/IExecutionHelper.sol';
import {ExecutionLib} from '../lib/ExecutionLib.sol';
import {EXECTYPE_DEFAULT, EXECTYPE_TRY, ExecType} from '../lib/ModeLib.sol';
import {Execution} from '../types/Structs.sol';

/// @title  ExecutionHelper
/// @dev This contract executes calls in the context of this contract.
/// @author Startale Labs
abstract contract ExecutionHelper is IExecutionHelper {
  using ExecutionLib for bytes;

  /// @notice Executes a call to a target address with specified value and data.
  /// @notice calls to an EOA should be counted as successful.
  /// @param target The address to execute the call on.
  /// @param value The amount of wei to send with the call.
  /// @param callData The calldata to send.
  /// @return result The bytes returned from the execution, which contains the returned data from the target address.
  function _execute(
    address target,
    uint256 value,
    bytes calldata callData
  ) internal virtual returns (bytes memory result) {
    /// @solidity memory-safe-assembly
    assembly {
      result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      if iszero(call(gas(), target, value, result, callData.length, codesize(), 0x00)) {
        // Bubble up the revert if the call reverts.
        returndatacopy(result, 0x00, returndatasize())
        revert(result, returndatasize())
      }
      mstore(result, returndatasize()) // Store the length.
      let o := add(result, 0x20)
      returndatacopy(o, 0x00, returndatasize()) // Copy the returndata.
      mstore(0x40, add(o, returndatasize())) // Allocate the memory.
    }
  }

  /// @notice Executes a call to a target address with specified value and data.
  /// Same as _execute but without return data for gas optimization.
  function _executeNoReturndata(address target, uint256 value, bytes calldata callData) internal virtual {
    /// @solidity memory-safe-assembly
    assembly {
      let result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      if iszero(call(gas(), target, value, result, callData.length, codesize(), 0x00)) {
        // Bubble up the revert if the call reverts.
        returndatacopy(result, 0x00, returndatasize())
        revert(result, returndatasize())
      }
      mstore(0x40, add(result, callData.length)) //allocate memory
    }
  }

  /// @notice Tries to execute a call and captures if it was successful or not.
  /// @dev Similar to _execute but returns a success boolean and catches reverts instead of propagating them.
  /// @notice calls to an EOA should be counted as successful.
  /// @param target The address to execute the call on.
  /// @param value The amount of wei to send with the call.
  /// @param callData The calldata to send.
  /// @return success True if the execution was successful, false otherwise.
  /// @return result The bytes returned from the execution, which contains the returned data from the target address.
  function _tryExecute(
    address target,
    uint256 value,
    bytes calldata callData
  ) internal virtual returns (bool success, bytes memory result) {
    /// @solidity memory-safe-assembly
    assembly {
      result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      success := call(gas(), target, value, result, callData.length, codesize(), 0x00)
      mstore(result, returndatasize()) // Store the length.
      let o := add(result, 0x20)
      returndatacopy(o, 0x00, returndatasize()) // Copy the returndata.
      mstore(0x40, add(o, returndatasize())) // Allocate the memory.
    }
  }

  /// @notice Executes a batch of calls.
  /// @param executions An array of Execution structs each containing target, value, and calldata.
  /// @return result An array of bytes returned from each executed call, corresponding to the returndata from each target address.
  function _executeBatch(Execution[] calldata executions) internal returns (bytes[] memory result) {
    result = new bytes[](executions.length);

    Execution calldata exec;
    for (uint256 i; i < executions.length; i++) {
      exec = executions[i];
      result[i] = _execute(exec.target, exec.value, exec.callData);
    }
  }

  /// @notice Executes a batch of calls without returning the result.
  /// @param executions An array of Execution structs each containing target, value, and calldata.
  function _executeBatchNoReturndata(Execution[] calldata executions) internal {
    Execution calldata exec;
    for (uint256 i; i < executions.length; i++) {
      exec = executions[i];
      _executeNoReturndata(exec.target, exec.value, exec.callData);
    }
  }

  /// @notice Tries to execute a batch of calls and emits an event for each unsuccessful call.
  /// @param executions An array of Execution structs.
  /// @return result An array of bytes returned from each executed call, with unsuccessful calls marked by events.
  function _tryExecuteBatch(Execution[] calldata executions) internal returns (bytes[] memory result) {
    result = new bytes[](executions.length);

    Execution calldata exec;
    for (uint256 i; i < executions.length; i++) {
      exec = executions[i];
      bool success;
      (success, result[i]) = _tryExecute(exec.target, exec.value, exec.callData);
      if (!success) emit TryExecuteUnsuccessful(exec.target, exec.callData, result[i]);
    }
  }

  /// @dev Execute a delegatecall with `delegate` on this account.
  /// @return result The bytes returned from the delegatecall, which contains the returned data from the delegate contract.
  function _executeDelegatecall(address delegate, bytes calldata callData) internal returns (bytes memory result) {
    /// @solidity memory-safe-assembly
    assembly {
      result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      // Forwards the `data` to `delegate` via delegatecall.
      if iszero(delegatecall(gas(), delegate, result, callData.length, codesize(), 0x00)) {
        // Bubble up the revert if the call reverts.
        returndatacopy(result, 0x00, returndatasize())
        revert(result, returndatasize())
      }
      mstore(result, returndatasize()) // Store the length.
      let o := add(result, 0x20)
      returndatacopy(o, 0x00, returndatasize()) // Copy the returndata.
      mstore(0x40, add(o, returndatasize())) // Allocate the memory.
    }
  }

  /// @dev Execute a delegatecall with `delegate` on this account.
  /// Same as _executeDelegatecall but without return data for gas optimization.
  function _executeDelegatecallNoReturndata(address delegate, bytes calldata callData) internal {
    /// @solidity memory-safe-assembly
    assembly {
      let result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      if iszero(delegatecall(gas(), delegate, result, callData.length, codesize(), 0x00)) {
        // Bubble up the revert if the call reverts.
        returndatacopy(result, 0x00, returndatasize())
        revert(result, returndatasize())
      }
      mstore(0x40, add(result, callData.length)) //allocate memory
    }
  }

  /// @dev Execute a delegatecall with `delegate` on this account and catch reverts.
  /// @return success True if the delegatecall was successful, false otherwise.
  /// @return result The bytes returned from the delegatecall, which contains the returned data from the delegate contract.
  function _tryExecuteDelegatecall(
    address delegate,
    bytes calldata callData
  ) internal returns (bool success, bytes memory result) {
    /// @solidity memory-safe-assembly
    assembly {
      result := mload(0x40)
      calldatacopy(result, callData.offset, callData.length)
      // Forwards the `data` to `delegate` via delegatecall.
      success := delegatecall(gas(), delegate, result, callData.length, codesize(), 0x00)
      mstore(result, returndatasize()) // Store the length.
      let o := add(result, 0x20)
      returndatacopy(o, 0x00, returndatasize()) // Copy the returndata.
      mstore(0x40, add(o, returndatasize())) // Allocate the memory.
    }
  }

  /// @dev Executes a single transaction based on the specified execution type.
  /// @param executionCalldata The calldata containing the transaction details (target address, value, and data).
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  function _handleSingleExecution(bytes calldata executionCalldata, ExecType execType) internal {
    (address target, uint256 value, bytes calldata callData) = executionCalldata.decodeSingle();
    if (execType == EXECTYPE_DEFAULT) {
      _executeNoReturndata(target, value, callData);
    } else if (execType == EXECTYPE_TRY) {
      (bool success, bytes memory result) = _tryExecute(target, value, callData);
      if (!success) emit TryExecuteUnsuccessful(target, callData, result);
    } else {
      revert UnsupportedExecType(execType);
    }
  }

  /// @dev Executes a batch of transactions based on the specified execution type.
  /// @param executionCalldata The calldata for a batch of transactions.
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  function _handleBatchExecution(bytes calldata executionCalldata, ExecType execType) internal {
    Execution[] calldata executions = executionCalldata.decodeBatch();
    if (execType == EXECTYPE_DEFAULT) _executeBatchNoReturndata(executions);
    else if (execType == EXECTYPE_TRY) _tryExecuteBatch(executions);
    else revert UnsupportedExecType(execType);
  }

  /// @dev Executes a single transaction based on the specified execution type.
  /// @param executionCalldata The calldata containing the transaction details (target address, value, and data).
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  function _handleDelegateCallExecution(bytes calldata executionCalldata, ExecType execType) internal {
    (address delegate, bytes calldata callData) = executionCalldata.decodeDelegateCall();
    if (execType == EXECTYPE_DEFAULT) {
      _executeDelegatecallNoReturndata(delegate, callData);
    } else if (execType == EXECTYPE_TRY) {
      (bool success, bytes memory result) = _tryExecuteDelegatecall(delegate, callData);
      if (!success) emit TryDelegateCallUnsuccessful(callData, result);
    } else {
      revert UnsupportedExecType(execType);
    }
  }

  /// @dev Executes a single transaction based on the specified execution type.
  /// @param executionCalldata The calldata containing the transaction details (target address, value, and data).
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  /// @return returnData An array containing the execution result. In the case of a single transaction, the array contains one element.
  function _handleSingleExecutionAndReturnData(
    bytes calldata executionCalldata,
    ExecType execType
  ) internal returns (bytes[] memory returnData) {
    (address target, uint256 value, bytes calldata callData) = executionCalldata.decodeSingle();
    returnData = new bytes[](1);
    bool success;
    // check if execType is revert(default) or try
    if (execType == EXECTYPE_DEFAULT) {
      returnData[0] = _execute(target, value, callData);
    } else if (execType == EXECTYPE_TRY) {
      (success, returnData[0]) = _tryExecute(target, value, callData);
      if (!success) emit TryExecuteUnsuccessful(target, callData, returnData[0]);
    } else {
      revert UnsupportedExecType(execType);
    }
  }

  /// @dev Executes a batch of transactions based on the specified execution type.
  /// @param executionCalldata The calldata for a batch of transactions.
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  /// @return returnData An array containing the execution results for each transaction in the batch.
  function _handleBatchExecutionAndReturnData(
    bytes calldata executionCalldata,
    ExecType execType
  ) internal returns (bytes[] memory returnData) {
    Execution[] calldata executions = executionCalldata.decodeBatch();
    if (execType == EXECTYPE_DEFAULT) returnData = _executeBatch(executions);
    else if (execType == EXECTYPE_TRY) returnData = _tryExecuteBatch(executions);
    else revert UnsupportedExecType(execType);
  }

  /// @dev Executes a single transaction based on the specified execution type.
  /// @param executionCalldata The calldata containing the transaction details (target address, value, and data).
  /// @param execType The execution type, which can be DEFAULT (revert on failure) or TRY (return on failure).
  /// @return returnData An array containing the result of the delegatecall execution.
  function _handleDelegateCallExecutionAndReturnData(
    bytes calldata executionCalldata,
    ExecType execType
  ) internal returns (bytes[] memory returnData) {
    (address delegate, bytes calldata callData) = executionCalldata.decodeDelegateCall();
    returnData = new bytes[](1);
    bool success;
    if (execType == EXECTYPE_DEFAULT) {
      returnData[0] = _executeDelegatecall(delegate, callData);
    } else if (execType == EXECTYPE_TRY) {
      (success, returnData[0]) = _tryExecuteDelegatecall(delegate, callData);
      if (!success) emit TryDelegateCallUnsuccessful(callData, returnData[0]);
    } else {
      revert UnsupportedExecType(execType);
    }
  }
}
