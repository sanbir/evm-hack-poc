2026-09-YamFinance
Registry folder: 2026-09-YamFinance_exp
Packed: 2026-10-02T05:01:21Z
Offline anvil_state.json: yes
output.txt contains [PASS]: no
Reproduce from registry/ with the shared anvil harness when state is present:
  _shared/run_poc.sh 2026-09-YamFinance_exp -vvvvv
