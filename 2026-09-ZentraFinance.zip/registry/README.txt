Authoritative Forge reproduction

Registry folder: 2026-09-ZentraFinance_exp
Registry base commit: 790312af3218bc887cb80cfae45d28a25c0c1d8e

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-09-ZentraFinance_exp -vvv
