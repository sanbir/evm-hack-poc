Authoritative Forge reproduction

Registry folder: 2026-10-AlpsCon_exp
Registry base commit: e2c573c40d1c9dbbe9a254a5f1bd7914e524bdb0

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-10-AlpsCon_exp -vvv
