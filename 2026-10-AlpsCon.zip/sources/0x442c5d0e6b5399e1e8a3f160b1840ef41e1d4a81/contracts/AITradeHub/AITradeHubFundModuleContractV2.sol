//SPDX-License-Identifier: UNLICENSED

pragma solidity ^0.8.19;

import {IERC20} from "../interfaces/IERC20.sol";
import {IVaultContract} from "../interfaces/IVaultContract.sol";
import {SafeERC20} from "../math/SafeERC20.sol";
import {SafeMath} from "../math/SafeMath.sol";

contract AITradeHubFundModuleContractV2 {
    using SafeMath for uint256;
    using SafeERC20 for IERC20;

    error AITradeHubFundPermissionDeniedError();
    error AITradeHubFundAmountInvalidError();
    error AITradeHubFundAmountLessThanFeeError();
    error AITradeHubFundAddressInvalidError();

    address internal owner;
    mapping(address => bool) internal aiTradeHubAddressesMap;
    address[] internal aiTradeHubAddresses;
    IVaultContract internal vaultContract;
    address internal baseToken; //ALPS
    address internal paymentToken; //USDC

    uint256 constant internal EXCHANGE_RATE = 10;

    modifier onlyOwner()  {
        if (msg.sender != owner) revert AITradeHubFundPermissionDeniedError();
        _;
    }

    modifier onlyAITradeHub()  {
        if (!aiTradeHubAddressesMap[msg.sender]) revert AITradeHubFundPermissionDeniedError();
        _;
    }

    constructor(address _vaultContractAddress, address _baseToken, address _paymentToken){
        owner = msg.sender;
        vaultContract = IVaultContract(_vaultContractAddress);
        baseToken = _baseToken;
        paymentToken = _paymentToken;
    }

    function getAITradeHubAddresses() external view returns (address[] memory){
        return aiTradeHubAddresses;
    }

    function onFeeReceived(address token, uint256 amount, uint256 includedFee) external onlyAITradeHub {
        _depositToVault(token,  amount, includedFee);
    }

    function withdrawalToken(uint256 amount) external onlyAITradeHub {
        _withdrawFromVault(paymentToken, msg.sender, amount);
    }

    //Convert USDC -> ALPS, USDC will transfer to Vault
    function convert(uint256 paymentAmount) external onlyAITradeHub {
        uint256 baseAmount = paymentAmount * EXCHANGE_RATE;
        _depositToVault(paymentToken, paymentAmount, 0);
        _withdrawFromVault(baseToken, msg.sender, baseAmount);
    }

    function addAITradeHubAddress(address _aiTradeHubAddress) external onlyOwner {
        aiTradeHubAddressesMap[_aiTradeHubAddress] = true;
        aiTradeHubAddresses.push(_aiTradeHubAddress);
    }

    //Internal function
    function _depositToVault(address token, uint256 amount, uint256 includedFee) internal {
        if (token == address(0)) revert AITradeHubFundAddressInvalidError();
        if (amount < includedFee) revert AITradeHubFundAmountLessThanFeeError();
        _approveIfNeeded(token,address(vaultContract), amount);
        vaultContract.moduleDepositToken(token, amount, includedFee);
    }

    function _withdrawFromVault(address token, address to, uint256 amount) internal {
        if (token == address(0)) revert AITradeHubFundAddressInvalidError();
        if (amount == 0) revert AITradeHubFundAmountInvalidError();
        vaultContract.moduleWithdrawToken(token, to, amount);
    }

    function _approveIfNeeded(address token, address spender, uint256 needed) internal {
        IERC20 erc20Token = IERC20(token);
        uint256 current = erc20Token.allowance(address(this), spender);
        if (current >= needed) return;
        erc20Token.safeApprove(spender, 0);
        erc20Token.safeApprove(spender, type(uint256).max);
    }

}