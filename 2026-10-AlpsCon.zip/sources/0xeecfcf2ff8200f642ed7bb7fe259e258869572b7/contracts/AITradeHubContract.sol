//SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.19;

import {IERC20} from "./interfaces/IERC20.sol";
import {ISwapContract} from "./interfaces/ISwapContract.sol";
import {Math} from "./math/Math.sol";
import {SafeERC20} from "./math/SafeERC20.sol";
import {SafeMath} from "./math/SafeMath.sol";
import {console} from "hardhat/console.sol";
import {PaymentAcceptance} from "./emission/PaymentAcceptance.sol";
import {IAITradeHubContractV3} from "./interfaces/IAITradeHubContractV3.sol";
import {IAITradeHubContractV2} from "./interfaces/IAITradeHubContractV2.sol";
import {AiTradeHubContractV3} from "./AITradeHubContractV3.sol";

/**
 * @title AI Trading Service Access Contract
 * @notice Manages TRAI utility tokens for AI trading service access
 * @dev IMPORTANT: This is NOT an investment contract.
 * - TRAI tokens are service credits for AI trading services
 * - Users pay for AI-powered trading services, not making investments
 * - AlpsCon trades with OWN capital, not user funds
 * - Distributions are service results from AI performance
 * - This is a technology service, not a financial product
 */
contract AiTradeHubContract {
    using SafeMath for uint256;
    using SafeERC20 for IERC20;

    //Enum
    enum ContributionType{
        NORMAL, RECOMPOUND, MIGRATE
    }
    enum PayoutPreference{
        NONE, COMPOUND, TRANSFER
    }
    //========
    //EVENTS
    //============================
    event Contribute(address indexed contributor, uint256 amount, uint256 fee, uint256 additionFee, uint256 lockedAmt, ContributionType contributionType);
    event NextTarget();
    event Indexed(address wallet, uint256 amountLocked, uint256 amountPending);
    event ClaimServiceResults(address indexed contributor, address paymentToken, uint256 lockedAmt, uint256 amount, uint256 withdrawalFee, uint256 tradingFee);
    event WithdrawFunds(address indexed contributor,  address to, uint256 amount, uint256 fee, address token);
    event ServiceResultsDistributed(uint256 amount);
    event MonthlyFeeCharged(address indexed contributor, uint256 lockedAmt, address token, uint256 fee, uint256 debtAdded);
    event Migrated(address indexed wallet, uint256 balance, uint256 lockedAmt, uint256 pendingAmt, uint256 paidAmt);
    event MigrateWallet(address indexed oldWallet, address indexed newWallet, uint256 balance, uint256 lockedAmt, uint256 pendingAmt, uint256 paidAmt, uint256 fee);
    event TransferFunds(address indexed from, address indexed to, uint256 amount, uint256 fee);
    //============================

    struct Contributor {
        uint256 balance; // Service result balance
        uint256 lockedAmount; // Active service credits
        uint256 pendingAmount; // Queued service credits
        uint256 paidAmount; //Total service results received
        uint256 entryProfitPerShare;
        uint256 lastFeeCharged;
        PayoutPreference payoutPreference; // distribution type
        bool migrated; // migrated from v1
        uint256 lastWalletMigrate; //last wallet migrate time
    }

    struct ContributionQueue {
        address walletAddress;
        uint256 amount;
    }

    struct ContractConfig {
        address owner;
        address fundAccount;
        address automationForwarder;
        ISwapContract swapContract;
        IAITradeHubContractV2 aiTradeHubContractV2;
        IAITradeHubContractV3 aiTradeHubContractV3;
        IERC20 payableERC20; // use for contributors contribute
        IERC20 paymentERC20; // use for payout to contributors
        uint256 tradingFee;
        uint256 withdrawalFee;
        uint256 contributionFee;
        uint256 monthlyFee;
        uint256 amountEachTarget;
        uint256 paymentTokenExchangeRate; //10 mean 10 TRAI = 1 USDT
        mapping(address => bool) feeExceptAddresses;
    }

    struct ContractStats {
        address[] contributorAddresses;
        mapping(address => uint256) addressIndexes;
        uint256 profitPerShare;
        uint256 totalLockedAmount;
        uint256 totalPendingAmount;
        uint256 lastDistributeProfit;
    }


    uint256 private constant  INTEREST_DECIMAL_PRECISION = 1e10;
    uint256 private constant FEE_DENOMINATOR = 1000;
    //Error
    error AITradeHubPermissionDeniedError();
    error AITradeHubNotVerifyError();
    error AITradeHubTransferFundAccountNotActiveError();
    error AITradeHubTransferLockedError();
    error AITradeHubAmountInvalidError();
    error AITradeHubNoProfitToClaimError();
    error AITradeHubAlreadyMigratedError();
    error AITradeHubWalletMigrateNotEmptyError();
    error AITradeHubWalletMigrateExceedNumberOfTimesError(uint256 nextTime);
    error AITradeHubPoolNotReadyError();
    error AITradeHubAddressInvalidError();
    error AITradeHubTokenAddressInvalidError();
    error AITradeHubDataInvalidError();
    error AITradeHubApprovalInvalidAddressError();
    error AITradeHubInsufficientAllowanceError(address tokenAddress, address spender, uint256 allowance, uint256 needed);
    error AITradeHubInsufficientFundsError();
    modifier onlyOwner() {
        if (!_isOwner()) revert AITradeHubPermissionDeniedError();
        _;
    }
    modifier onlyVerified() {
        if (!_isVerified(msg.sender)) revert AITradeHubNotVerifyError();
        _;
    }

    ContractConfig private config;
    ContractStats private stats;
    mapping(address => Contributor) private contributors;
    ContributionQueue[] private contributionQueue;
    // Structure: tokenAddress => owner => spender => amount
    mapping(address => mapping(address => mapping(address => uint256))) private allowances;

    struct InitConfig {
        address payableERC20;
        address paymentERC20;
        address fundAccount;
        address swapContract;
        address aiTradeHubContractV2;
        address aiTradeHubContractV3;
        uint256 trading_fee;
        uint256 withdrawal_fee;
        uint256 contribution_fee;
        uint256 monthly_fee;
        uint256 amount_each_target;
        uint256 payment_token_exchange_rate;
    }
    constructor(InitConfig memory cfg) {
        config.owner = msg.sender;
        config.automationForwarder = msg.sender;
        config.payableERC20 = IERC20(cfg.payableERC20);
        config.paymentERC20 = IERC20(cfg.paymentERC20);
        config.fundAccount = cfg.fundAccount;
        config.swapContract = ISwapContract(cfg.swapContract);
        config.aiTradeHubContractV2 = IAITradeHubContractV2(cfg.aiTradeHubContractV2);
        config.aiTradeHubContractV3 = IAITradeHubContractV3(cfg.aiTradeHubContractV3);
        config.tradingFee = cfg.trading_fee;
        config.withdrawalFee = cfg.withdrawal_fee;
        config.contributionFee = cfg.contribution_fee;
        config.monthlyFee = cfg.monthly_fee;
        config.amountEachTarget = cfg.amount_each_target;
        config.paymentTokenExchangeRate = cfg.payment_token_exchange_rate;
    }

    //OWNER function
    function distributeServiceResults(uint256 amount) external onlyOwner {
        return _distributeServiceResults(amount);
    }

    function setSwapContract(address swapContract) external onlyOwner {
        config.swapContract = ISwapContract(swapContract);
    }

    function migrate(address contributor) external onlyOwner {
        _migrate(contributor);
    }


    function setAutomationForwarder(address forwarder) external onlyOwner {
        config.automationForwarder = forwarder;
    }

    function chargeMonthlyFee(address wallet) external onlyOwner {
        _chargeProRatedMonthlyFee(wallet);
    }

    function setAddressFeeExempt(address wallet, bool exempt) external onlyOwner {
        config.feeExceptAddresses[wallet] = exempt;
    }

    //====END=====

    //automation function
    function checkAutomation(uint256 startIndex, uint256 maxResult) external view returns (uint256[] memory, uint256) {
        uint256 total = stats.contributorAddresses.length;
        uint256[] memory needToProcessIndexes = new uint256[](maxResult);
        if (total == 0 || maxResult == 0 || startIndex >= total) return (needToProcessIndexes, total);
        uint256 found = 0;
        for (uint256 i = startIndex; i < total; i++) {
            address wallet = stats.contributorAddresses[i];
            Contributor storage user = contributors[wallet];
            if (user.payoutPreference == PayoutPreference.NONE) continue;

            uint256 profit = _calculateUserProfit(wallet);
            uint256 tradingFee = _get_fee_trading(profit);
            uint256 netProfit = profit.sub(tradingFee);
            uint256 claimAmount = netProfit.add(user.balance);
            if (claimAmount == 0) continue;

            needToProcessIndexes[found++] = i;
            if (found == maxResult) break;
        }

        // Trim arrays
        uint256[] memory trimmed = new uint256[](found);
        for (uint256 j = 0; j < found; j++) {
            trimmed[j] = needToProcessIndexes[j];
        }
        return (trimmed, total);
    }

    function performAutomation(uint256[] calldata indexesToProcess) external {
        if (msg.sender != config.automationForwarder) revert AITradeHubPermissionDeniedError();

        uint256 total = stats.contributorAddresses.length;
        uint256 totalToProcess = indexesToProcess.length;
        if (total == 0 || totalToProcess == 0) return;

        for (uint256 i = 0; i < totalToProcess; i++) {
            uint256 index = indexesToProcess[i];
            if (index >= total) continue;
            address wallet = stats.contributorAddresses[index];
            Contributor storage user = contributors[wallet];
            if (user.payoutPreference == PayoutPreference.NONE) continue;
            if (user.payoutPreference == PayoutPreference.COMPOUND) {
                _recompound(wallet);
            } else if (user.payoutPreference == PayoutPreference.TRANSFER) {
                _claimServiceResults(wallet);
            }
        }
        _reAllocateTarget();
    }

    //======END=========

    //PUBLIC function
    function purchaseServiceCredits(uint256 amount) external onlyVerified {
        return _purchaseServiceCredits(msg.sender, amount, ContributionType.NORMAL, 0, true);
    }

    function claimServiceResults() external onlyVerified {
        return _claimServiceResults(msg.sender);
    }

    function recompound() external onlyVerified {
        return _recompound(msg.sender);
    }

    function migrateManual() external onlyVerified {
        _migrate(msg.sender);
    }

    function migrateWallet(address newWallet) external onlyVerified {
        _migrateWallet(newWallet);
    }

    function transferFunds(address to, uint256 amount) external onlyVerified {
        _transferFunds(to, amount);
    }

    function withdrawFunds(uint256 amount) external onlyVerified {
        return _withdrawFunds(msg.sender, amount);
    }

    function transfer(address tokenAddress, address to, uint256 amount) external onlyVerified {
        _transfer(tokenAddress, msg.sender, to, amount);
    }

    function transferFrom(address tokenAddress, address from, address to, uint256 amount) external onlyVerified {
        address spender = msg.sender;
        _spendAllowance(tokenAddress, from, spender, amount);
        _transfer(tokenAddress, from, to, amount);
    }

    function approve(address[] calldata tokenAddresses, address spender, uint256 amount) external onlyVerified {
        for (uint256 i = 0; i < tokenAddresses.length; i++) {
            _approve(tokenAddresses[i], msg.sender, spender, amount);
        }
    }

    function allowance(address tokenAddress, address owner, address spender) external view onlyVerified returns (uint256) {
        return allowances[tokenAddress][owner][spender];
    }

    function setPayoutPreference(PayoutPreference payoutPreference) external {
        _setPayoutPreference(msg.sender, payoutPreference);
    }


    function getStats(address wallet) external view returns (
        uint num_contributors,
        uint256 total_pending_amount,
        uint256 total_locked_amount,
        uint256 last_distribute_profit,
        uint256 user_locked_amount,
        uint256 user_pending_amount,
        uint256 user_paid_amount,
        uint256 user_balance,
        uint256 user_claimable_profit,
        uint256 user_current_service_fee,
        PayoutPreference user_payout_type
    ){
        num_contributors = stats.contributorAddresses.length;
        total_locked_amount = stats.totalLockedAmount;
        total_pending_amount = stats.totalPendingAmount;
        last_distribute_profit = stats.lastDistributeProfit;
        Contributor memory contributor = contributors[wallet];
        user_locked_amount = contributor.lockedAmount;
        user_pending_amount = contributor.pendingAmount;
        user_paid_amount = contributor.paidAmount;
        user_balance = contributor.balance;
        user_claimable_profit = _calculateUserProfit(wallet);
        user_claimable_profit = user_claimable_profit.sub(_get_fee_trading(user_claimable_profit));
        user_current_service_fee = _getProRatedMonthlyFee(wallet);
        user_payout_type = contributor.payoutPreference;
    }

    function getV2Stats(address wallet) public view returns (
        uint num_contributors,
        uint256 total_pending_amount,
        uint256 total_locked_amount,
        uint256 last_distribute_profit,
        uint256 user_locked_amount,
        uint256 user_pending_amount,
        uint256 user_debt_amount,
        uint256 user_paid_amount,
        uint256 user_balance,
        uint256 user_claimable_profit,
        uint256 user_current_service_fee,
        bool user_is_re_compound
    ){
        return config.aiTradeHubContractV2.getStats(wallet);
    }

    function getV3Stats(address wallet) public view returns (
        uint num_contributors,
        uint256 total_pending_amount,
        uint256 total_locked_amount,
        uint256 last_distribute_profit,
        uint256 user_locked_amount,
        uint256 user_pending_amount,
        uint256 user_paid_amount,
        uint256 user_balance,
        uint256 user_claimable_profit,
        uint256 user_current_service_fee,
        IAITradeHubContractV3.PayoutPreference user_payout_type
    ){
        return config.aiTradeHubContractV3.getStats(wallet);
    }

    function getConfig() external view
    returns (
        address owner,
        address paymentERC20,
        address payableERC20,
        uint256 amount_each_target,
        uint256 contribution_fee,
        uint256 trading_fee,
        uint256 withdrawal_fee,
        uint256 monthly_fee
    )
    {
        owner = config.owner;
        paymentERC20 = address(config.paymentERC20);
        payableERC20 = address(config.payableERC20);
        amount_each_target = config.amountEachTarget;
        contribution_fee = config.contributionFee;
        trading_fee = config.tradingFee;
        withdrawal_fee = config.withdrawalFee;
        monthly_fee = config.monthlyFee;
    }

    function isMigrateAllowed(address wallet) external view returns (bool){
        return _isMigrateAllowed(wallet);
    }
    //====END=====

    //INTERNAL function
    function _purchaseServiceCredits(address wallet, uint256 amount, ContributionType contributionType, uint256 additionFee, bool reAllocate) internal {
        uint256 contributionFee = 0;
        uint256 contributionAmount = amount;
        if (contributionType == ContributionType.NORMAL) {
            if (amount == 0) revert AITradeHubAmountInvalidError();
            contributionFee = _get_fee_contribution(amount);
            contributionAmount = amount.sub(contributionFee);
            //Transfer fee to fund wallet
            config.payableERC20.safeTransferFrom(wallet, config.fundAccount, contributionFee);
            config.payableERC20.safeTransferFrom(wallet, address(this), contributionAmount);
        } else if (contributionType == ContributionType.RECOMPOUND) {
            contributionFee = _get_fee_contribution(amount) / 2;
            contributionAmount = amount.sub(contributionFee);
            //Transfer fee to fund wallet
            config.payableERC20.safeTransferFrom(wallet, config.fundAccount, contributionFee);
        }
        _insert_address_if_not_existed(wallet);
        Contributor storage contributor = contributors[wallet];
        //Add pending amount
        _addPendingAmount(wallet, contributionAmount);
        emit Contribute(wallet, contributionAmount, contributionFee, additionFee, contributor.lockedAmount, contributionType);

        if (reAllocate)
            _reAllocateTarget();
    }

    function _distributeServiceResults(uint256 amount) internal {
        if (amount == 0) revert AITradeHubAmountInvalidError();
        if (stats.totalLockedAmount == 0) revert AITradeHubPoolNotReadyError();
        uint256 delta = amount.mul(INTEREST_DECIMAL_PRECISION).div(stats.totalLockedAmount);
        stats.profitPerShare = stats.profitPerShare.add(delta);
        stats.lastDistributeProfit = block.timestamp;
        _sendFromFundAccount(config.paymentERC20, address(this), amount);
        emit ServiceResultsDistributed(amount);
    }

    function _claimServiceResults(address wallet) internal {
        Contributor storage contributor = contributors[wallet];
        bool automation = (msg.sender == config.automationForwarder);

        if(!automation)
            _rebuildContributionQueue();

        uint256 tradingFee = _updateUserProfitCheckpoint(wallet);
        // Charge accurate monthly fee by time elapsed
        _chargeProRatedMonthlyFee(wallet);
        uint256 claimAmount = contributor.balance;
        if (claimAmount == 0) {
            if (!automation) revert AITradeHubNoProfitToClaimError();
            else return;
        }

        uint256 withdrawalFee = _get_fee_withdrawal(claimAmount);
        uint256 netClaimAmount = claimAmount.sub(withdrawalFee);

        if (netClaimAmount > 0) {
            config.paymentERC20.safeTransfer( wallet, netClaimAmount);
            contributor.paidAmount = contributor.paidAmount.add(netClaimAmount);
            //transfer fee to fund account
            _sendToFundAccount(config.paymentERC20,withdrawalFee);
        }

        //reset balance and share
        contributor.balance = 0;
        contributor.entryProfitPerShare = stats.profitPerShare;
        emit ClaimServiceResults(wallet, address(config.paymentERC20), contributor.lockedAmount, netClaimAmount, withdrawalFee, tradingFee);
    }

    function _recompound(address wallet) internal {
        Contributor storage contributor = contributors[wallet];
        bool automation = (msg.sender == config.automationForwarder);

        if(!automation)
            _rebuildContributionQueue();

        uint256 tradingFee = _updateUserProfitCheckpoint(wallet);
        // Charge accurate monthly fee by time elapsed
        _chargeProRatedMonthlyFee(wallet);
        uint256 claimAmount = contributor.balance;
        if (claimAmount == 0) {
            if (!automation) revert AITradeHubNoProfitToClaimError();
            else return;
        }
        uint256 netClaimAmountToTRAI = claimAmount.mul(config.paymentTokenExchangeRate);
        //Swap USDC to TRAI via fund wallet
        _sendToFundAccount(config.paymentERC20, claimAmount);
        _sendFromFundAccount(config.payableERC20, address(this), netClaimAmountToTRAI);

        contributor.paidAmount = contributor.paidAmount.add(claimAmount);
        _purchaseServiceCredits(wallet, netClaimAmountToTRAI, ContributionType.RECOMPOUND, tradingFee.mul(config.paymentTokenExchangeRate), !automation);

        //reset balance and share
        contributor.balance = 0;
        contributor.entryProfitPerShare = stats.profitPerShare;
    }

    function _withdrawFunds(address wallet, uint256 amount) internal {
        if (amount == 0) revert AITradeHubAmountInvalidError();

        _transfer(address(config.payableERC20), wallet, wallet, amount);
    }

    function _migrate(address contributorAddress) internal {
        Contributor storage contributor = contributors[contributorAddress];
        if (contributor.migrated) revert AITradeHubAlreadyMigratedError();
        uint256 user_locked_amount;
        uint256 user_pending_amount;
        uint256 user_paid_amount;
        uint256 user_balance;
        uint256 user_claimable_profit;
        IAITradeHubContractV3.PayoutPreference user_payout_type;
        bool user_is_re_compound;
        if (!config.aiTradeHubContractV3.isMigrateAllowed(contributorAddress)) {
            (,
            ,
            ,
            ,
                user_locked_amount,
                user_pending_amount,
                user_paid_amount,
                user_balance,
                user_claimable_profit,
            ,
                user_payout_type) = getV3Stats(contributorAddress);
        } else {
            (,
            ,
            ,
            ,
                user_locked_amount,
                user_pending_amount,
            ,
                user_paid_amount,
                user_balance,
                user_claimable_profit,
            ,
                user_is_re_compound) = getV2Stats(contributorAddress);
            if (user_is_re_compound)
                user_payout_type = IAITradeHubContractV3.PayoutPreference.COMPOUND;
        }
        uint256 totalMigrateAmount = user_locked_amount.add(user_pending_amount);
        _purchaseServiceCredits(contributorAddress, totalMigrateAmount, ContributionType.MIGRATE, 0, true);

        uint256 balance = user_balance.add(user_claimable_profit);
        contributor.balance += balance;
        contributor.paidAmount += user_paid_amount;
        contributor.migrated = true;
        if (user_payout_type == IAITradeHubContractV3.PayoutPreference.COMPOUND)
            contributor.payoutPreference = PayoutPreference.COMPOUND;
        else if (user_payout_type == IAITradeHubContractV3.PayoutPreference.TRANSFER)
            contributor.payoutPreference = PayoutPreference.TRANSFER;
        else
            contributor.payoutPreference = PayoutPreference.NONE;
        emit Migrated(contributorAddress, balance, user_locked_amount, user_pending_amount, user_paid_amount);
    }

    function _migrateWallet(address newWallet) internal {
        address oldWallet = msg.sender;
        Contributor storage from = contributors[oldWallet];
        Contributor storage to = contributors[newWallet];

        if (newWallet == address(0) || newWallet == oldWallet) {
            revert AITradeHubAddressInvalidError();
        }

        if (to.lockedAmount > 0 || to.pendingAmount > 0 || to.balance > 0 || to.entryProfitPerShare > 0) {
            revert AITradeHubWalletMigrateNotEmptyError(); // Target wallet must be empty
        }
        if (block.timestamp - from.lastWalletMigrate < 604800) { // only allow migration once a week
            revert AITradeHubWalletMigrateExceedNumberOfTimesError(from.lastWalletMigrate.add(604800));
        }
        // --- Calculate migration fee---
        uint256 totalMigrateAmount = from.pendingAmount + from.lockedAmount;
        _subFromPendingLocked(oldWallet, totalMigrateAmount);
        _addPendingAmount(newWallet, totalMigrateAmount);
        _insert_address_if_not_existed(newWallet);
        _reAllocateTarget();

        // Copy data
        to.balance = from.balance;
        to.paidAmount = from.paidAmount;
        to.lastFeeCharged = from.lastFeeCharged;
        to.entryProfitPerShare = from.entryProfitPerShare;
        to.payoutPreference = from.payoutPreference;
        to.migrated = from.migrated;
        to.lastWalletMigrate = block.timestamp;

        // Remove old wallet tracking
        from.balance = 0;
        from.paidAmount = 0;
        from.lastFeeCharged = 0;
        from.entryProfitPerShare = stats.profitPerShare;
        from.payoutPreference = PayoutPreference.NONE;

        _remove_address(oldWallet);
        emit MigrateWallet(oldWallet, newWallet, to.balance, to.lockedAmount, to.pendingAmount, to.paidAmount, 0);
    }

    function _transferFunds(address to, uint256 amount) internal {
        address from = msg.sender;
        if (to == address(0) || to == from) {
            revert AITradeHubAddressInvalidError();
        }
        if (!_isVerified(msg.sender) && !_isVerified(to)) {
            revert AITradeHubTransferFundAccountNotActiveError();
        }
        Contributor storage sender = contributors[from];

        uint256 transferable = sender.lockedAmount.add(sender.pendingAmount);
        if (amount == 0 || amount > transferable) {
            revert AITradeHubAmountInvalidError();
        }

        // Prioritize transfer from pending → locked
        _subFromPendingLocked(from, amount);
        _addPendingAmount(to, amount);
        _reAllocateTarget();

        emit TransferFunds(from, to, amount, 0);
    }

    //Transfer feature
    function _approve(address tokenAddress, address owner, address spender, uint256 amount) internal {
        if (owner == address(0) || spender == address(0))
            revert AITradeHubApprovalInvalidAddressError();
        allowances[tokenAddress][owner][spender] = amount;
    }

    function _spendAllowance(address tokenAddress, address owner, address spender, uint256 value) internal {
        uint256 currentAllowance = allowances[tokenAddress][owner][spender];
        if (currentAllowance != type(uint256).max) {
            if (currentAllowance < value) {
                revert AITradeHubInsufficientAllowanceError(tokenAddress, spender, currentAllowance, value);
            }
            unchecked{
                _approve(tokenAddress, owner, spender, currentAllowance - value);
            }
        }
    }

    //Transfer funds to external address
    function _transfer(address tokenAddress, address from, address to, uint256 amount) internal {
        if (from == address(0) || to == address(0)) revert AITradeHubAddressInvalidError();
        if (tokenAddress != address(config.payableERC20) && tokenAddress != address(config.paymentERC20))
            revert AITradeHubTokenAddressInvalidError();

        Contributor storage contributor = contributors[from];
        //Check payable token transfer
        if (tokenAddress == address(config.payableERC20)) {
            uint256 maxTransferAmt = contributor.pendingAmount.add(contributor.lockedAmount);
            if (maxTransferAmt < amount) revert AITradeHubInsufficientFundsError();
            _subFromPendingLocked(from, amount);
            _reAllocateTarget();
        }
        //Check payment token transfer
        if (tokenAddress == address(config.paymentERC20)) {
            _updateUserProfitCheckpoint(from);
            if (contributor.balance < amount) revert AITradeHubInsufficientFundsError();
            contributor.balance -= amount;
        }

        IERC20 transferToken = IERC20(tokenAddress);
        uint256 fee = 0;
        if (!config.feeExceptAddresses[to]) {
            //Send fee to fund account
            fee = _get_fee_withdrawal(amount);
            _sendToFundAccount(transferToken, fee);
        }
        transferToken.transfer(to, amount - fee);
        emit WithdrawFunds(from, to, amount, fee, tokenAddress);
    }

    function _chargeProRatedMonthlyFee(address wallet) internal {
        Contributor storage contributor = contributors[wallet];
        uint256 proratedFee = _getProRatedMonthlyFee(wallet);
        if (contributor.lastFeeCharged == 0) contributor.lastFeeCharged = block.timestamp;
        if (proratedFee == 0) return;

        uint256 remaining = proratedFee;
        //Sub from pending amount
        remaining = _subPendingAmount(wallet, proratedFee);
        uint256 chargedAmt = proratedFee.sub(remaining);
        _sendToFundAccount(config.payableERC20, chargedAmt);
        emit MonthlyFeeCharged(wallet, contributor.lockedAmount,address(config.payableERC20), chargedAmt, remaining);

        //Sub from balance
        if(remaining > 0){
            uint256 balance = contributor.balance;
            uint256 balanceToTRAI = balance.mul(config.paymentTokenExchangeRate);
            if(balanceToTRAI > 0){
                chargedAmt = Math.min(remaining,balanceToTRAI);
                remaining = remaining.sub(chargedAmt);
                balanceToTRAI = balanceToTRAI.sub(chargedAmt);
                contributor.balance = balanceToTRAI.div(config.paymentTokenExchangeRate);
                //convert fee back to USDC
                chargedAmt = balance.sub(contributor.balance);
                _sendToFundAccount(config.paymentERC20, chargedAmt);
                emit MonthlyFeeCharged(wallet, contributor.lockedAmount,address(config.paymentERC20), chargedAmt, remaining);
            }
        }
        // Update charged time
        contributor.lastFeeCharged = block.timestamp;


    }

    function _calculateUserProfit(address wallet) internal view returns (uint256) {
        Contributor storage user = contributors[wallet];
        uint256 gross = user.lockedAmount.mul(stats.profitPerShare).div(INTEREST_DECIMAL_PRECISION);
        uint256 claimed = user.lockedAmount.mul(user.entryProfitPerShare).div(INTEREST_DECIMAL_PRECISION);
        return gross.sub(claimed);
    }

    function _getProRatedMonthlyFee(address wallet) internal view returns (uint256){
        Contributor memory contributor = contributors[wallet];

        uint256 lastCharged = contributor.lastFeeCharged;
        uint256 nowTimestamp = block.timestamp;

        // First time: set lastFeeCharged but skip charging
        if (lastCharged == 0) {
            return 0;
        }

        uint256 elapsed = nowTimestamp - lastCharged;
        uint256 baseFee = _get_fee_monthly(contributor.lockedAmount);
        uint256 proratedFee = baseFee.mul(elapsed).div(2592000);//30 days in seconds
        return proratedFee;
    }

    function _updateUserProfitCheckpoint(address wallet) internal returns (uint256) {
        Contributor storage user = contributors[wallet];
        uint256 fee;
        uint256 profit = _calculateUserProfit(wallet);
        if (profit > 0) {
            fee = _get_fee_trading(profit);
            uint256 netProfit = profit.sub(fee);
            user.balance = user.balance.add(netProfit);
            //Transfer fee to fund account
            _sendToFundAccount(config.paymentERC20, fee);
        }
        user.entryProfitPerShare = stats.profitPerShare;
        return fee;
    }

    function _reAllocateTarget() internal {
        uint256 targetSize = config.amountEachTarget;
        uint256 totalLocked = stats.totalLockedAmount;
        uint256 amountToMoveOut = totalLocked % targetSize;

        // --- Move excess locked → pending to remove broken target ---
        if (amountToMoveOut > 0) {
            for (uint256 i = stats.contributorAddresses.length; i > 0 && amountToMoveOut > 0; i--) {
                address contributorAddress = stats.contributorAddresses[i - 1];
                Contributor storage contributor = contributors[contributorAddress];

                uint256 amount = Math.min(contributor.lockedAmount, amountToMoveOut);
                if (amount == 0) continue;
                _subLockedAmount(contributorAddress, amount);
                _addPendingAmount(contributorAddress, amount);
                amountToMoveOut -= amount;
            }
        }
        // --- Try to refill a complete target using pending → locked ---
        while (stats.totalPendingAmount >= targetSize) {
            uint256 locked = 0;
            uint256 len = contributionQueue.length;
            for (uint256 i = 0; i < len && locked < targetSize; i++) {
                address addr = contributionQueue[i].walletAddress;
                Contributor storage contributor = contributors[addr];
                uint256 take = Math.min(contributor.pendingAmount, targetSize - locked);
                if (take == 0) continue;
                _subPendingAmount(addr, take);
                _addLockedAmount(addr, take);
                locked += take;
            }

            if (locked == targetSize) {
                _rebuildContributionQueue(); // Rebuild queue per full target
            }
        }
    }


    function _addPendingAmount(address wallet, uint256 amount) internal {
        Contributor storage contributor = contributors[wallet];
        contributor.pendingAmount = contributor.pendingAmount.add(amount);
        stats.totalPendingAmount = stats.totalPendingAmount.add(amount);
        // Check if the last item is the same wallet — if yes, aggregate
        if (contributionQueue.length > 0 && contributionQueue[contributionQueue.length - 1].walletAddress == wallet) {
            contributionQueue[contributionQueue.length - 1].amount += amount;
        } else {
            //push to queue
            contributionQueue.push(ContributionQueue(wallet, amount));
        }
    }

    function _subPendingAmount(address wallet, uint256 amount) internal returns (uint256){
        Contributor storage contributor = contributors[wallet];
        uint256 amountSubbing = Math.min(amount, contributor.pendingAmount);
        if (amountSubbing == 0) return amount;
        contributor.pendingAmount = contributor.pendingAmount.sub(amountSubbing);
        stats.totalPendingAmount = stats.totalPendingAmount.sub(amountSubbing);

        uint256 amountSubbingInQueueLeft = amountSubbing;
        uint256 len = contributionQueue.length;
        for (uint256 i = 0; i < len; i++) {
            if (amountSubbingInQueueLeft == 0) break;
            if (contributionQueue[i].walletAddress != wallet) continue;
            uint256 amountSubbingInQueue = Math.min(contributionQueue[i].amount, amountSubbingInQueueLeft);
            contributionQueue[i].amount = contributionQueue[i].amount.sub(amountSubbingInQueue);
            amountSubbingInQueueLeft = amountSubbingInQueueLeft.sub(amountSubbingInQueue);
        }
        return amount.sub(amountSubbing);
    }


    function _subFromPendingLocked(address wallet, uint256 amountInTRAI) internal returns (uint256){
        uint256 remaining = 0;
        // Deduct from pending amount
        remaining = _subPendingAmount(wallet, amountInTRAI);
        // Deduct from locked amount
        if (remaining > 0)
            remaining = _subLockedAmount(wallet, remaining);

        return remaining;
    }

    function _addLockedAmount(address wallet, uint256 amount) internal {
        _updateUserProfitCheckpoint(wallet);
        Contributor storage contributor = contributors[wallet];
        contributor.lockedAmount = contributor.lockedAmount.add(amount);
        stats.totalLockedAmount = stats.totalLockedAmount.add(amount);
    }

    function _subLockedAmount(address wallet, uint256 amount) internal returns (uint256) {
        Contributor storage contributor = contributors[wallet];
        uint256 amountSubbing = Math.min(amount, contributor.lockedAmount);
        if (amountSubbing == 0)
            return amount;
        _updateUserProfitCheckpoint(wallet);

        contributor.lockedAmount = contributor.lockedAmount.sub(amountSubbing);
        stats.totalLockedAmount = stats.totalLockedAmount.sub(amountSubbing);
        return amount.sub(amountSubbing);
    }

    function _sendToFundAccount(IERC20 token, uint256 amount) internal {
        token.safeTransfer(config.fundAccount, amount);
    }

    function _sendFromFundAccount(IERC20 token, address to, uint256 amount) internal {
        token.safeTransferFrom(config.fundAccount, to, amount);
    }

    function _isVerified(address wallet) internal view returns (bool){
        return config.swapContract.isInWhiteList(wallet);
    }

    function _isOwner() internal view returns (bool){
        return msg.sender == config.owner;
    }

    function _isMigrateAllowed(address wallet) internal view returns (bool){
        Contributor storage contributor = contributors[wallet];
        if (contributor.migrated) return false;
        (,
            ,
            ,
            ,
            uint256 user_locked_amount,
            uint256 user_pending_amount,
            uint256 user_paid_amount,
            uint256 user_balance,
            uint256 user_claimable_profit,
            ,
        ) = config.aiTradeHubContractV3.getStats(wallet);
        bool hasData = (
            user_locked_amount > 0 ||
            user_pending_amount > 0 ||
            user_paid_amount > 0 ||
            user_balance > 0 ||
            user_claimable_profit > 0
        );
        return hasData;
    }

    function _setPayoutPreference(address wallet, PayoutPreference payoutPreference) internal {
        if (contributors[wallet].payoutPreference == payoutPreference) return;
        contributors[wallet].payoutPreference = payoutPreference;
    }

    function _get_fee_contribution(uint256 currency_balance) internal view returns (uint256) {
        return currency_balance.mul(config.contributionFee).div(FEE_DENOMINATOR);
    }

    function _get_fee_withdrawal(uint256 amount) internal view returns (uint256) {
        return amount.mul(config.withdrawalFee).div(FEE_DENOMINATOR);
    }

    function _get_fee_trading(uint256 amount) internal view returns (uint256) {
        return amount.mul(config.tradingFee).div(FEE_DENOMINATOR);
    }

    function _get_fee_monthly(uint256 amount) internal view returns (uint256) {
        return amount.mul(config.monthlyFee).div(FEE_DENOMINATOR);
    }

    function _rebuildContributionQueue() internal {
        uint256 len = contributionQueue.length;
        if (len == 0) return;
        uint256 j = 0;
        for (uint256 i = 0; i < len; i++) {
            if (contributionQueue[i].amount > 0) {
                if (i != j) {
                    contributionQueue[j] = contributionQueue[i];
                }
                j++;
            }
        }
        // Truncate the array
        while (contributionQueue.length > j) {
            contributionQueue.pop();
        }
    }

    function _insert_address_if_not_existed(address new_address) internal {
        // if addr is not already list
        if (stats.addressIndexes[new_address] == 0) {
            stats.addressIndexes[new_address] = stats.contributorAddresses.length + 1;
            stats.contributorAddresses.push(new_address);
        }
    }

    function _remove_address(address wallet) internal {
        uint256 indexPlusOne = stats.addressIndexes[wallet];
        if (indexPlusOne == 0) return; // Address not found

        uint256 index = indexPlusOne - 1;
        uint256 lastIndex = stats.contributorAddresses.length - 1;

        if (index != lastIndex) {
            // Swap with last element
            address lastAddress = stats.contributorAddresses[lastIndex];
            stats.contributorAddresses[index] = lastAddress;
            stats.addressIndexes[lastAddress] = index + 1;
        }
        // Remove last element and clear index
        stats.contributorAddresses.pop();
        delete stats.addressIndexes[wallet];
    }

    //====END=====
}