// SPDX-License-Identifier: MIT
// Original: https://github.com/gelatodigital/relay-contracts/blob/master/contracts/GelatoRelayConcurrentERC2771.sol
// Changes: Solidity version downgraded from ^0.8.12 to 0.8.7, added batch processing functionality, 
// adjusted import paths for project structure
pragma solidity 0.8.7;

import {
    IGelatoRelayConcurrentERC2771
} from "./interfaces/IGelatoRelayConcurrentERC2771.sol";
import {
    GelatoRelayConcurrentERC2771Base
} from "./abstract/GelatoRelayConcurrentERC2771Base.sol";
import {GelatoCallUtils} from "./lib/GelatoCallUtils.sol";
import {CallWithConcurrentERC2771} from "./types/CallTypes.sol";
import {
    _encodeFeeCollectorERC2771
} from "./lib/GelatoRelayUtils.sol";


/// @title  Gelato Relay contract
/// @notice This contract deals with concurrent ERC2771 meta-transactions
/// @dev    This contract must NEVER hold funds!
/// @dev    Maliciously crafted transaction payloads could wipe out any funds left here
contract GelatoRelayConcurrentERC2771 is
    IGelatoRelayConcurrentERC2771,
    GelatoRelayConcurrentERC2771Base
{
    using GelatoCallUtils for address;

    //solhint-disable-next-line const-name-snakecase
    string public constant name = "GelatoRelayConcurrentERC2771";
    //solhint-disable-next-line const-name-snakecase
    string public constant version = "1";

    modifier onlySelf() {
        require(msg.sender == address(this), "Only callable by self");
        _;
    }

    constructor() GelatoRelayConcurrentERC2771Base() {}

    function callWithSyncFeeConcurrentERC2771(
        CallWithConcurrentERC2771 calldata _call,
        address, // _feeToken kepts empty for api compatibility
        bytes calldata _userSignature,
        bool, // _isRelayContext kepts empty for api compatibility
        bytes32 _correlationId
    ) external override onlyTrustedRelayer {
        
        // CHECKS
        _requireChainId(
            _call.chainId,
            "GelatoRelayConcurrentERC2771.callWithSyncFeeConcurrentERC2771:"
        );
        _requireUserDeadline(
            _call.userDeadline,
            "GelatoRelayConcurrentERC2771.callWithSyncFeeConcurrentERC2771:"
        );
        bytes32 callHash = _hashCallWithSyncFeeConcurrentERC2771(_call);
        // For the user, we enforce hash-based replay protection
        _requireUnusedHash(
            callHash,
            "GelatoRelayConcurrentERC2771.callWithSyncFeeConcurrentERC2771:"
        );
        bytes32 domainSeparator = _getDomainSeparator();

        // Verify user's signature
        _requireCallWithSyncFeeConcurrentERC2771Signature(
            domainSeparator,
            callHash,
            _userSignature,
            _call.user
        );

        // EFFECTS
        hashUsed[callHash] = true;

        // INTERACTIONS
        _call.target.revertingContractCall(
            _encodeFeeCollectorERC2771(
                _call.data,
                address(0), // No fee collector needed
                _call.user
            ),
            "GelatoRelayConcurrentERC2771.callWithSyncFeeConcurrentERC2771:"
        );

        emit LogCallWithSyncFeeConcurrentERC2771(_call.target, _correlationId);
    }

    function batchCallWithSyncFeeConcurrentERC2771(
        CallWithConcurrentERC2771[] calldata _calls,
        address,
        bytes[] calldata _userSignatures,
        bool,
        bytes32[] calldata _correlationIds
    ) external override onlyTrustedRelayer returns (bool[] memory successes) {

        require(_calls.length == _userSignatures.length, "length mismatch");
        require(_calls.length == _correlationIds.length, "length mismatch");

        successes = new bool[](_calls.length);

        for (uint256 i = 0; i < _calls.length; i++) {
            try this._executeSingleCall(
                _calls[i],
                _userSignatures[i],
                _correlationIds[i]
            ) {
                successes[i] = true;
            } catch {
                successes[i] = false;
            }
        }

        emit BatchCallCompleted(_calls.length, successes);
    }

    /// @notice  function to execute a single call with all checks, designed for external self-call
    /// @dev This function is called by the batch function for each call
    /// @param _call The call to execute
    /// @param _userSignature The user's signature for the call
    /// @param _correlationId The correlation ID for the call
    function _executeSingleCall(
        CallWithConcurrentERC2771 calldata _call,
        bytes calldata _userSignature,
        bytes32 _correlationId
    ) external onlySelf {
        // CHECKS
        _requireChainId(
            _call.chainId,
            "GelatoRelayConcurrentERC2771.batchCallWithSyncFeeConcurrentERC2771:"
        );
        _requireUserDeadline(
            _call.userDeadline,
            "GelatoRelayConcurrentERC2771.batchCallWithSyncFeeConcurrentERC2771:"
        );
        bytes32 callHash = _hashCallWithSyncFeeConcurrentERC2771(_call);
        _requireUnusedHash(
            callHash,
            "GelatoRelayConcurrentERC2771.batchCallWithSyncFeeConcurrentERC2771:"
        );

        // Verify user's signature
        _requireCallWithSyncFeeConcurrentERC2771Signature(
            _getDomainSeparator(),
            callHash,
            _userSignature,
            _call.user
        );

        // EFFECTS
        hashUsed[callHash] = true;

        // INTERACTIONS
        _call.target.revertingContractCall(
            _encodeFeeCollectorERC2771(
                _call.data,
                address(0), // No fee collector needed
                _call.user
            ),
            "GelatoRelayConcurrentERC2771.batchCallWithSyncFeeConcurrentERC2771:"
        );

        emit LogCallWithSyncFeeConcurrentERC2771(_call.target, _correlationId);
    }

    //solhint-disable-next-line func-name-mixedcase
    function DOMAIN_SEPARATOR() external view returns (bytes32) {
        return _getDomainSeparator();
    }

    function _getDomainSeparator() internal view returns (bytes32) {
        return
            keccak256(
                abi.encode(
                    keccak256(
                        bytes(
                            //solhint-disable-next-line max-line-length
                            "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
                        )
                    ),
                    keccak256(bytes(name)),
                    keccak256(bytes(version)),
                    block.chainid,
                    address(this)
                )
            );
    }
}
