// SPDX-License-Identifier: MIT
// Original: https://github.com/gelatodigital/relay-contracts/blob/master/contracts/abstract/GelatoRelayConcurrentERC2771Base.sol
// Changes: Solidity version downgraded from ^0.8.12 to 0.8.7, adjusted import paths for project structure,
pragma solidity 0.8.7;

import {
    IGelatoRelayConcurrentERC2771Base
} from "../interfaces/IGelatoRelayConcurrentERC2771Base.sol";
import {GelatoString} from "../lib/GelatoString.sol";
import {CallWithConcurrentERC2771} from "../types/CallTypes.sol";
import {ECDSA} from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {Address} from "@openzeppelin/contracts/utils/Address.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/AccessControlEnumerable.sol";

import "hardhat/console.sol";

abstract contract GelatoRelayConcurrentERC2771Base is
    IGelatoRelayConcurrentERC2771Base,
    AccessControlEnumerable
{
    using GelatoString for string;

    // solhint-disable-next-line named-parameters-mapping
    mapping(bytes32 => bool) public override hashUsed;

    bytes32 public constant override CALL_WITH_SYNC_FEE_CONCURRENT_ERC2771_TYPEHASH =
        keccak256(
            bytes(
                // solhint-disable-next-line max-line-length
                "CallWithSyncFeeConcurrentERC2771(uint256 chainId,address target,bytes data,address user,bytes32 userSalt,uint256 userDeadline)"
            )
        );

    constructor() {
        _grantRole(DEFAULT_ADMIN_ROLE, _msgSender());
    }

    /* ================================================ ROLE HELPERS AND FUNCTION OVERRIDES ================================ */

    /**
     * @dev remove external access to {AccessControlEnumerable.grantRole}.
     */
    function grantRole(bytes32, address) public pure override {
        revert("GelatoRelayConcurrentERC2771Base: A role can only be granted using the corresponding specialized function");
    }

    /**
     * @dev remove external access to {AccessControlEnumerable.revokeRole}.
     */
    function revokeRole(bytes32, address) public pure override {
        revert("GelatoRelayConcurrentERC2771Base: A role can only be revoked using the corresponding specialized function");
    }

    /**
     * @dev Generic function to list all addresses that have a specific role.
     * @param role The role to list members for (e.g., DEFAULT_ADMIN_ROLE, TRUSTED_RELAYER_ROLE).
     * @return An array of addresses that have the specified role.
     */
    function listRoleMembers(bytes32 role) public view override returns (address[] memory) {
        uint256 memberCount = getRoleMemberCount(role);
        address[] memory members = new address[](memberCount);
        for (uint256 i = 0; i < memberCount; i++) {
            members[i] = getRoleMember(role, i);
        }
        return members;
    }

    /* ================================================ ADMIN ROLE ================================================ */


    /**
     * @dev Modifier that checks that the sender has the {DEFAULT_ADMIN_ROLE} role. 
     */
    modifier onlyAdmin() {
        require(hasRole(DEFAULT_ADMIN_ROLE, _msgSender()), "GelatoRelayConcurrentERC2771Base: Caller is missing role ADMIN.");
        _;
    }

    /**
     * @dev transfer the {DEFAULT_ADMIN_ROLE} role to another wallet.
     * 
     * note: because {grantRole} and {revokeRole} are not accessible externally, this function ensures that there
     * can only be a single admin for this contract at any time.
     */
    function transferAdmin(address _to) public override onlyAdmin() {
        super.grantRole(DEFAULT_ADMIN_ROLE, _to);
        super.revokeRole(DEFAULT_ADMIN_ROLE, _msgSender());
    }

    /**
     * @dev returns the address of the admin of this registry.
     */
    function admin() public view override returns (address) {
        return getRoleMember(DEFAULT_ADMIN_ROLE, 0);
    }


    /* ================================================ TRUSTED RELAYER ROLE ================================================ */

    /**
     * @dev the trusted relayer role that allows addresses to act as trusted relayers.
     */
    function TRUSTED_RELAYER_ROLE() public pure override returns(bytes32) {
        return keccak256("TRUSTED_RELAYER_ROLE");
    } 

    /**
     * @dev Modifier that checks that the sender has the {TRUSTED_RELAYER_ROLE} role.
     */
    modifier onlyTrustedRelayer() {
        require(hasRole(TRUSTED_RELAYER_ROLE(), _msgSender()), "GelatoRelayConcurrentERC2771Base: Caller is missing role TRUSTED_RELAYER_ROLE.");
        _;
    }

    /**
     * @dev grant the TRUSTED_RELAYER_ROLE role.
     */
    function grantTrustedRelayerRole(address account) public override onlyAdmin() {
        super.grantRole(TRUSTED_RELAYER_ROLE(), account);
    }

    /**
     * @dev revoke the TRUSTED_RELAYER_ROLE role.
     */
    function revokeTrustedRelayerRole(address account) public override onlyAdmin() {
        super.revokeRole(TRUSTED_RELAYER_ROLE(), account);
    }

    /**
     * @dev check if an address has the {TRUSTED_RELAYER_ROLE} role.
     */
    function hasTrustedRelayerRole(address account) public view override returns (bool) {
        return hasRole(TRUSTED_RELAYER_ROLE(), account);
    }

    /**
     * @dev list the addresses that have the {TRUSTED_RELAYER_ROLE} role.
     */
    function listTrustedRelayerRoleMembers() public view override returns (address[] memory) {
        return listRoleMembers(TRUSTED_RELAYER_ROLE());
    }

    /* ================================================ INTERNAL FUNCTIONS ================================================ */

    function _requireChainId(
        uint256 _chainId,
        string memory _errorTrace
    ) internal view {
        require(_chainId == block.chainid, _errorTrace.suffix("chainid"));
    }

    function _requireUserDeadline(
        uint256 _userDeadline,
        string memory _errorTrace
    ) internal view {
        require(
            // solhint-disable-next-line not-rely-on-time
            _userDeadline == 0 || _userDeadline >= block.timestamp,
            _errorTrace.suffix("deadline")
        );
    }

    function _requireUnusedHash(
        bytes32 _callWithSyncFeeConcurrentHash,
        string memory _errorTrace
    ) internal view {
        require(
            !hashUsed[_callWithSyncFeeConcurrentHash],
            _errorTrace.suffix("replay")
        );
    }

    function _requireCallWithSyncFeeConcurrentERC2771Signature(
        bytes32 _domainSeparator,
        bytes32 _callWithSyncFeeConcurrentHash,
        bytes calldata _signature,
        address _expectedSigner
    ) internal pure returns (bytes32 digest) {
        
        bytes memory encoded = abi.encodePacked(
            "\x19\x01",
            _domainSeparator,
            _callWithSyncFeeConcurrentHash
        );
        
        digest = keccak256(encoded);

        (address recovered, ECDSA.RecoverError error) = ECDSA.tryRecover(
            digest,
            _signature
        );
        // solhint-disable-next-line reason-string
        require(
            error == ECDSA.RecoverError.NoError && recovered == _expectedSigner,
            "GelatoRelayConcurrentERC2771Base._requireCallWithSyncFeeConcurrentERC2771Signature"
        );
    }

    function _hashCallWithSyncFeeConcurrentERC2771(
        CallWithConcurrentERC2771 calldata _call
    ) internal pure returns (bytes32) {
        bytes32 hash  = 
            keccak256(
                abi.encode(
                    CALL_WITH_SYNC_FEE_CONCURRENT_ERC2771_TYPEHASH,
                    _call.chainId,
                    _call.target,
                    keccak256(_call.data),
                    _call.user,
                    _call.userSalt,
                    _call.userDeadline
                )
            );
        return hash;
    }
}
