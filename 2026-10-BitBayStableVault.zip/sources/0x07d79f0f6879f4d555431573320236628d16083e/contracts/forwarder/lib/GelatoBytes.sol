// SPDX-License-Identifier: MIT
// Original: https://github.com/gelatodigital/relay-contracts/blob/master/contracts/lib/GelatoBytes.sol
// Changes: Solidity version downgraded from ^0.8.12 to 0.8.7
pragma solidity 0.8.7;

library GelatoBytes {
    function calldataSliceSelector(
        bytes calldata _bytes
    ) internal pure returns (bytes4 selector) {
        selector =
            _bytes[0] |
            (bytes4(_bytes[1]) >> 8) |
            (bytes4(_bytes[2]) >> 16) |
            (bytes4(_bytes[3]) >> 24);
    }

    function memorySliceSelector(
        bytes memory _bytes
    ) internal pure returns (bytes4 selector) {
        selector =
            _bytes[0] |
            (bytes4(_bytes[1]) >> 8) |
            (bytes4(_bytes[2]) >> 16) |
            (bytes4(_bytes[3]) >> 24);
    }

    function revertWithError(
        bytes memory _bytes,
        string memory _tracingInfo
    ) internal pure {
        // 68: 32-location, 32-length, 4-ErrorSelector, UTF-8 err
        if (_bytes.length % 32 == 4) {
            bytes4 selector;
            assembly {
                selector := mload(add(0x20, _bytes))
            }
            if (selector == 0x08c379a0) {
                // Function selector for Error(string)
                assembly {
                    _bytes := add(_bytes, 68)
                }
                revert(string(abi.encodePacked(_tracingInfo, string(_bytes))));
            }
        }

        // Bubble up unrecognised errors directly
        assembly {
            revert(add(_bytes, 0x20), mload(_bytes))
        }
    }
}
