// SPDX-License-Identifier: MIT
// Original: https://github.com/gelatodigital/relay-contracts/blob/master/contracts/lib/GelatoString.sol
// Changes: Solidity version downgraded from ^0.8.12 to 0.8.7
pragma solidity 0.8.7;

library GelatoString {
    function revertWithInfo(
        string memory _error,
        string memory _tracingInfo
    ) internal pure {
        revert(string(abi.encodePacked(_tracingInfo, _error)));
    }

    function prefix(
        string memory _second,
        string memory _first
    ) internal pure returns (string memory) {
        return string(abi.encodePacked(_first, _second));
    }

    function suffix(
        string memory _first,
        string memory _second
    ) internal pure returns (string memory) {
        return string(abi.encodePacked(_first, _second));
    }
}
