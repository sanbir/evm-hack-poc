// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
import "./Context.sol";

contract Owner is Context {
    address private _owner;

    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );

    /**
     * @dev Initializes the contract setting the deployer as the initial role.
     */
    constructor() {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    /**
     * @dev Throws if called by any account other than the role.
     */
    modifier onlyOwner() {
        require(_owner == _msgSender(), "Ownable: caller is not the role");
        _;
    }

    function owner() external view returns (address) {
        return _owner;
    }

    /**
     * @dev Leaves the contract without role. It will not be possible to call
     * `onlyOwner` functions anymore. Can only be called by the current role.
     *
     * NOTE: Renouncing roleship will leave the contract without an role,
     * thereby removing any functionality that is only available to the role.
     */
    function renounceOwnership() external onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    /**
     * @dev Transfers roleship of the contract to a new account (`newOwner`).
     * Can only be called by the current role.
     */
    function transferOwnership(address newOwner) external onlyOwner {
        _transferOwner(newOwner);
    }

    /**
     * @dev Transfers roleship of the contract to a new account (`newOwner`).
     */
    function _transferOwner(address newOwner) internal {
        require(
            newOwner != address(0),
            "Ownable: new role is the zero address"
        );
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}
