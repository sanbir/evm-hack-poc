// SPDX-FileCopyrightText: © Courtyard Inc. (https://courtyard.io)
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;

import "../utils/ERC20PaymentProcessorV2.sol";
import "@openzeppelin/contracts/access/AccessControlEnumerable.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Address.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/introspection/ERC165Checker.sol";

/**
 * @author The Courtyard Team
 * @title {TokenMintCheckoutBase} allows checkouts to mint NFTs using a particular ERC20 token (ex: USDC) for the payment.
 * 
 * It works as follows:
 * 
 *  1. A user starts the checkout process in a front-end application off-chain and is ready to pay.
 * 
 *  2. Upon receiving a checkout request, a back-end service would typically generate a {signature} containing the
 *     following information:
 * 
 *      - {operatingContract}: the address of the appropriate checkout contract.
 *      - {checkoutId}: a unique identifier for that checkout. The {checkoutId} is used to guarantee that each checkout
 *        would not be processed multiple times accidentally.
 *      - {expirationTimestamp}: timestamp in seconds from epoch after which the checkout cannot be completed anymore.
 *      - {paymentRecipient}: the account (i.e. address) that will receive the proceeds of the payment.
 *      - {paymentToken}: the payment token (must be an ERC20 token).
 *      - {paymentValue}: a uint256 representing the payment value in the smallest unit of the payment currency.
 *      - {tokenRecipient}: the recipient for the purchased tokens that will be minted.
 *      - {tokenRegistry}: the registry where the purchased tokens will be minted.
 *      - {tokenHashes}: AN array of the hashex (hex proofs) of the tokens that will be minted.
 * 
 *  4. The backend sends the signed data along with a checkout signature back to the front-end application so the transaction
 *     can be executed.
 * 
 *  5. On the front end:
 * 
 *      - If necessary, the user is first prompted to approve the appropriate token allowance to the checkout contract.
 *      - The user is then prompted to sign the checkout transaction.
 * 
 *  6. During the on-chain transaction:
 * 
 *      - If everything is in order according to the checkout contract processing the request, the funds are withdrawn
 *        and sent to the receiver wallet.
 *      - Then the tokens are minted.
 *      - Finally, the {checkoutId} is marked as processed and a {CheckoutSuccess} event is emitted.
 *  
 *  7. The user now has a successful transaction hash that is a "proof of payment" that can be used to retrieve the 
 *    full transaction result on a block explorer, containing all the information relevant to the checkout, including
 *    the emitted events. This is alike a transaction receipt.
 */

interface TokenRegistryInterface {
    function mintToken(address to, bytes32 proofOfIntegrity) external returns (uint256);
}

/**
 * Contract code.
 */
abstract contract TokenMintCheckoutBase is ReentrancyGuard, AccessControlEnumerable, Pausable, ERC20PaymentProcessorV2 {

    event CheckoutSuccess(address indexed caller, string checkoutId);
    event TokenPurchasedAndMinted(
        address indexed mintedToAddress,
        address mintedTokenAddress,
        uint256 mintedTokenId,
        address paymentTokenAddress,
        uint256 paymentAmount
    );

    /**
     * @dev using a struct to encapsulate all the data that is used to encode a checkout signature.
     */
    struct CheckoutRequest {
        address operatingContract;      // the contract that is supposed to process the given request (which should be this.address for a valid request)
        string checkoutId;              // the id of the checkout.
        uint256 expirationTimestamp;    // expiration timestamp of the request.
        address paymentRecipient;       // the recipient of the payment.
        address paymentToken;           // the payment token (must be an ERC20 token).
        uint256 paymentValue;           // the payment value in the smallest unit of the associated currency.
        address tokenRecipient;         // the recipient of the tokens to mint.
        address tokenRegistry;          // the registry where to mint the tokens.
        bytes32[] tokenHashes;          // the bytes32 ids (hex proofs) of the tokens to mint to the recipient.
    }

    string public name;                     // the name of this contract.
    mapping(bytes32 => bool) processed;     // mapping of all the checkouts that were processed to avoid duplicate charges.


    /* ========================================== CONSTRUCTOR AND SETTERS ========================================== */

    /**
     * @dev constructor.
     */
    constructor(string memory _name) ERC20PaymentProcessorV2() {
        // Set the admin
        AccessControlEnumerable._grantRole(DEFAULT_ADMIN_ROLE, _msgSender());

        // Set the name
        name = _name;
        
        // The contract starts its lifetime in the paused state.
        _pause();
    }


    /* =================================== ROLE HELPERS AND FUNCTIONS OVERRIDES =================================== */

    /**
     * @dev remove external access to {AccessControl.grantRole}.
     */
    function grantRole(bytes32, address) public pure override {
        revert("TokenMintCheckoutBase: A role can only be granted using the corresponding specialized function");
    }

    /**
     * @dev remove external access to {AccessControl.revokeRole}.
     */
    function revokeRole(bytes32, address) public pure override {
        revert("TokenMintCheckoutBase: A role can only be revoked using the corresponding specialized function");
    }

    /**
     * @dev list the addresses that have a particular role.
     */
    function listRoleMembers(bytes32 role) public view returns (address[] memory) {
        uint256 memberCount = getRoleMemberCount(role);
        address[] memory members = new address[](memberCount);
        for (uint ii = 0; ii < memberCount; ii++) {
            members[ii] = getRoleMember(role, ii);
        }
        return members;
    }


    /* ================================================ ADMIN ROLE ================================================ */


    /**
     * @dev Modifier that checks that the sender has the {DEFAULT_ADMIN_ROLE} role. 
     */
    modifier onlyAdmin() {
        require(hasRole(DEFAULT_ADMIN_ROLE, _msgSender()), "TokenMintCheckoutBase: Caller is missing role ADMIN.");
        _;
    }

    /**
     * @dev transfer the {DEFAULT_ADMIN_ROLE} role to another wallet.
     * 
     * note: because {grantRole} and {revokeRole} are not accessible externally, this function ensures that there
     * can only be a single admin for this contract at any time.
     */
    function transferAdmin(address _to) public onlyAdmin() {
        super.grantRole(DEFAULT_ADMIN_ROLE, _to);
        super.revokeRole(DEFAULT_ADMIN_ROLE, _msgSender());
    }

    /**
     * @dev returns the address of the admin of this registry.
     */
    function admin() public view returns (address) {
        return getRoleMember(DEFAULT_ADMIN_ROLE, 0);
    }

    /**
     * @dev same as {admin()}, to support Dapps that use {owner()} rather than {admin()} to check the ownership of 
     * a contract.
     */
    function owner() public view returns (address) {
        return admin();
    }


    /* ====================================== TRUSTED FORWARDER ROLE AND HELPERS ====================================== */

    /**
     * @dev the trusted forwarder role.
     * An "trused forwarder" has the ability to execute transactions on behalf of an account as if the account was executing
     * those transactions. This is helpful to allow a relayer to run transactions on behalf of an account.
     */
    function TRUSTED_FORWARDER_ROLE() internal pure returns(bytes32) {
        return keccak256("TRUSTED_FORWARDER_ROLE");
    } 

    /**
     * @dev grant the TRUSTED_FORWARDER_ROLE role.
     */
    function addTrustedForwarder(address account) public onlyAdmin() {
        super.grantRole(TRUSTED_FORWARDER_ROLE(), account);
    }

    /**
     * @dev revoke the TRUSTED_FORWARDER_ROLE role.
     */
    function removeTrustedForwarder(address account) public onlyAdmin() {
        super.revokeRole(TRUSTED_FORWARDER_ROLE(), account);
    }

    /**
     * @dev check if an address has the {TRUSTED_FORWARDER_ROLE} role.
     */
    function isTrustedForwarder(address account) public view returns (bool) {
        return hasRole(TRUSTED_FORWARDER_ROLE(), account);
    }

    /**
     * @dev list the addresses that have the {TRUSTED_FORWARDER_ROLE} role.
     */
    function listTrustedForwarders() public view returns (address[] memory) {
        return listRoleMembers(TRUSTED_FORWARDER_ROLE());
    }

    /**
     * @dev Override of {_msgSender()} that supports a trusted forwarder.
     * Heavily inspired from {openzeppelin/contracts/metatx/ERC2771Context.sol:ERC2771Context}.
     */
    function _msgSender() internal view virtual override returns (address sender) {
        if (isTrustedForwarder(msg.sender)) {
            // The assembly code is more direct than the Solidity version using `abi.decode`.
            assembly {
                sender := shr(96, calldataload(sub(calldatasize(), 20)))
            }
        } else {
            return super._msgSender();
        }
    }

    /**
     * @dev Override of {_msgData()} that supports a trusted forwarder.
     * Heavily inspired from {openzeppelin/contracts/metatx/ERC2771Context.sol:ERC2771Context}.
     */
    function _msgData() internal view virtual override returns (bytes calldata) {
        if (isTrustedForwarder(msg.sender)) {
            return msg.data[:msg.data.length - 20];
        } else {
            return super._msgData();
        }
    }


    /* ================================================ CHECKOUT ORACLE ROLE ================================================ */

    /**
     * @dev the trusted checkout oracle role. 
     */
    function TRUSTED_CHECKOUT_ORACLE_ROLE() internal pure returns(bytes32) {
        return keccak256("TRUSTED_CHECKOUT_ORACLE_ROLE");
    } 

    /**
     * @dev @dev Check that a specific address is a trusted checkout oracle.
     */
    modifier onlyTrustedCheckoutOracle(address account) {
        require(hasRole(TRUSTED_CHECKOUT_ORACLE_ROLE(), msg.sender), "TokenMintCheckoutBase: Caller is missing role TRUSTED_CHECKOUT_ORACLE_ROLE.");
        _ ;
    }

    /**
     * @dev grant the TRUSTED_CHECKOUT_ORACLE_ROLE role that allows an account to provide minting signatures for minting tokens.
     */
    function addTrustedCheckoutOracle(address account) public onlyAdmin {
        super.grantRole(TRUSTED_CHECKOUT_ORACLE_ROLE(), account);
    }

    /**
     * @dev revoke the TRUSTED_CHECKOUT_ORACLE_ROLE role.
     */
    function removeTrustedCheckoutOracle(address account) public onlyAdmin {
        super.revokeRole(TRUSTED_CHECKOUT_ORACLE_ROLE(), account);
    }

    /**
     * @dev check if an address has the {TRUSTED_CHECKOUT_ORACLE_ROLE} role.
     */
    function isTrustedCheckoutOracle(address account) public view returns (bool) {
        return hasRole(TRUSTED_CHECKOUT_ORACLE_ROLE(), account);
    }

    /**
     * @dev list the addresses that have the {TRUSTED_CHECKOUT_ORACLE_ROLE} role.
     */
    function listTrustedCheckoutOracles() public view returns (address[] memory) {
        return listRoleMembers(TRUSTED_CHECKOUT_ORACLE_ROLE());
    }


    /* ============================================= PAUSABLE HELPERS ============================================= */

    /**
     * @dev pause the contract
     * 
     * Requirements:
     * 
     *      - Only the admin of the contract can pause it. 
     */
    function pause() public onlyAdmin {
        _pause();
    }

    /**
     * @dev unpause the contract
     * 
     * Requirements:
     * 
     *      - Only the admin of the contract can unpause it. 
     */
    function unpause() public onlyAdmin {
        _unpause();
    }


    /* ========================================= CHECKOUT REQUEST HELPERS ========================================= */

    /**
     * @dev modifier to ensure that a checkout request signature is valid.
     * @param requestData the checkout request as bytes.
     * @param signature the signature block of {requestData}, signed by a trusted checkout oracle.
     */
    modifier onlyValidCheckoutSignature(
        bytes memory requestData,
        bytes memory signature
    ) {
        bytes32 expectedSignedMessage = ECDSA.toEthSignedMessageHash(requestData);
        address recoveredSigner = ECDSA.recover(expectedSignedMessage, signature);
        require(isTrustedCheckoutOracle(recoveredSigner), "TokenMintCheckoutBase: Invalid signature.");
        _;
    }

    /**
     * @dev helper to check the eligibility of a checkout request.
     * @param request the checkout request data as bytes.
     * 
     * Requirements:
     * 
     *      - {request.operatingContract} must be this contract.
     *      - {request.checkoutId} must not have been marked as processed.
     *      - {request.expirationTimestamp} must not have passed. 
     */
    function _checkEligibility(CheckoutRequest memory request) private view {
        require(request.operatingContract == address(this), "TokenMintCheckoutBase: Contract is not authorized to process this request.");
        require(!exists(request.checkoutId), "TokenMintCheckoutBase: Checkout with checkoutId was already processed.");
        require(request.expirationTimestamp >= block.timestamp, "TokenMintCheckoutBase: Checkout time window has expired.");
    }


    /* ============================================ CHECKOUT ID HELPERS ============================================ */

    /**
     * @dev helper to compute the hash of a {checkoutId}.
     * @param checkoutId the checkout id.
     * @return a keccak256 hash of the checkout id.
     */
    function _checkoutIdHash(string memory checkoutId) private pure returns (bytes32) {
        return keccak256(abi.encode(checkoutId));
    }

    /**
     * @dev helper to check if a checkoutId exists, i.e. if the checkout for that id was completed.
     * @param checkoutId the checkout id.
     * @return true if {checkoutId} has been processed, false otherwise.
     */
    function exists(string memory checkoutId) public view returns (bool) {
        return processed[_checkoutIdHash(checkoutId)];
    }


    /* ============================================== ERC20 CHECKOUT ============================================== */

    /**
     * @dev creates and encode a {CheckoutRequest}.
     * The {CheckoutRequest} is returned in an encoded form (bytes) and must be signed by the {checkoutOracle} to
     * authorize a checkout. That signature is then fed to {erc20Checkout} along with the encoded {CheckoutRequest} 
     * to be validated before proceeding with the checkout.
     * @param checkoutId the checkout id.
     * @param expirationTimestamp the expiration timestamp after which this checkout request is no longer valid.
     * @param paymentRecipient the recipient of the payment.
     * @param paymentToken the payment token.
     * @param paymentValue the payment value in the smallest unit of the associated currency
     * @param expirationTimestamp the expiration timestamp after which this checkout request is no longer valid.
     * @param tokenRecipient the recipient of the tokens to be minted.
     * @param tokenHashes the bytes32 ids (hex proofs) of the tokens to mint to the recipient.
     * @return the encoded checkout request as bytes, ready to be signed by the checkout oracle.
     *
     * Notes:
     * 
     *      - The returned encoded {CheckoutRequest} needs to be signed by a trusted checkout oracle to be valid.
     *      - If {data} is the result of this function, checkoutOracleAddress.signMessage(ethers.utils.arrayify(data))
     *        must be called in order to properly encode the hash before signing it.
     */
    function encodeCheckoutRequest(
        string calldata checkoutId,
        uint256 expirationTimestamp,
        address paymentRecipient,
        address paymentToken,
        uint256 paymentValue,
        address tokenRecipient,
        address tokenRegistry,
        bytes32[] memory tokenHashes
    ) public view returns (bytes memory) {
        return abi.encode(
            CheckoutRequest(
                address(this),
                checkoutId,
                expirationTimestamp,
                paymentRecipient,
                paymentToken,
                paymentValue,
                tokenRecipient,
                tokenRegistry,
                tokenHashes
            )
        );  
    }


    /**
     * @dev Mint tokens according to a checkout request and signature.
     * 
     * Requirements:
     *  - the contract is not paused
     *  - the checkout request and signature must be valid
     */
    function mintTokens(
        bytes calldata checkoutRequestData,
        bytes calldata checkoutSignature
    ) external nonReentrant whenNotPaused onlyValidCheckoutSignature(checkoutRequestData, checkoutSignature) {
        address caller = _msgSender();
        CheckoutRequest memory request = abi.decode(checkoutRequestData, (CheckoutRequest));
        _checkEligibility(request);
        _processPayment(caller, request.paymentRecipient, request.paymentToken, request.paymentValue);
        for (uint ii = 0 ; ii < request.tokenHashes.length ; ii++ ) {
            uint256 mintedTokenId = TokenRegistryInterface(request.tokenRegistry).mintToken(request.tokenRecipient, request.tokenHashes[ii]);
            uint256 unitPrice = request.paymentValue / request.tokenHashes.length; // this is safe because tokenHashes is empty, we would not be in this loop.
            emit TokenPurchasedAndMinted(request.tokenRecipient, request.tokenRegistry, mintedTokenId, request.paymentToken, unitPrice);
        }
        processed[_checkoutIdHash(request.checkoutId)] = true;
        emit CheckoutSuccess(caller, request.checkoutId);
    }


    /**
     * @dev Permit a transaction and mint tokens according to a checkout request and signature.
     * 
     * Requirements:
     *  - the contract is not paused
     *  - the checkout request and signature must be valid
     *  - A permit signature is required to approve the funds spending during the transaction
     *  - The originating caller of this function (returned by _msgSender()) has to be the signer of the permit signature.
     *  - The signature has to correspond to the price provided in the checkout request.
     *  - {permitExpiration} must correspond to the expiration time encoded in the permit signature
     */
    function permitFundsAndMintTokens(
        bytes calldata checkoutRequestData, // the checkout request data
        bytes calldata checkoutSignature,   // the checkout signature
        uint256 permitExpiration,           // the expiration of the permit signature
        uint8 v, bytes32 r, bytes32 s       // the parameters of the permit signature
    ) external nonReentrant whenNotPaused onlyValidCheckoutSignature(checkoutRequestData, checkoutSignature) {
        address caller = _msgSender();
        CheckoutRequest memory request = abi.decode(checkoutRequestData, (CheckoutRequest));
        _checkEligibility(request);
        _permitAndProcessPayment(
            caller,                     // the executor of the call
            request.paymentRecipient,   // the recipient of the payment
            request.paymentToken,       // the payment token
            request.paymentValue,       // the final purchase value
            request.paymentValue,       // the amount that is supposed to be approved for this transaction (and encoded in the permit signature)
            permitExpiration,           // the expiration of the permit signature
            v, r, s                     // the parameters of the permit signature
        );
        for (uint ii = 0 ; ii < request.tokenHashes.length ; ii++ ) {
            uint256 mintedTokenId = TokenRegistryInterface(request.tokenRegistry).mintToken(request.tokenRecipient, request.tokenHashes[ii]);
            uint256 unitPrice = request.paymentValue / request.tokenHashes.length; // this is safe because tokenHashes is empty, we would not be in this loop.
            emit TokenPurchasedAndMinted(request.tokenRecipient, request.tokenRegistry, mintedTokenId, request.paymentToken, unitPrice);
        }
        processed[_checkoutIdHash(request.checkoutId)] = true;
        emit CheckoutSuccess(caller, request.checkoutId);
    }


}