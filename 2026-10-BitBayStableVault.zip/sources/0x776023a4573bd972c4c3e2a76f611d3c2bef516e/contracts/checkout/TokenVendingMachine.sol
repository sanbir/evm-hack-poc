// SPDX-FileCopyrightText: © Courtyard Inc. (https://courtyard.io)
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;

import "./TokenMintCheckoutBase.sol";

/**
 * @title TokenVendingMachine is a base implementation of TokenMintCheckoutBase.
 */ 
contract TokenVendingMachine is TokenMintCheckoutBase {

    constructor(string memory name) TokenMintCheckoutBase(name) {}

}
