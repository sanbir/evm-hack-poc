// SPDX-FileCopyrightText: © Courtyard Inc. (https://courtyard.io)
// SPDX-License-Identifier: MIT

pragma solidity ^0.8.0;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * The IERC20Permit interface, used to permit funds to be transferred with a signature.
 */
interface IERC20Permit {
    function permit(address owner, address spender, uint256 value, uint256 expiration, uint8 v, bytes32 r, bytes32 s) external;
}

/**
 * @title processes payments in ERC20 and redirects them to a receiver address.
 * In comparison to the original version V2 supports defining the payment token and reviver address at the transaction time.
 */ 
abstract contract ERC20PaymentProcessorV2 {

    using SafeERC20 for IERC20;

    event PaymentProcessed(address indexed to, address indexed token, uint256 amount);

    constructor() {}

    /* ============================================ PAYMENT PROCESSING ============================================ */

    /**
     * @dev process the payment, assuming that {erc20Token} already knows that this contract is allowed to spend the funds on behalf of {from}.
     */
    function _processPayment(address fromAddress, address toAddress, address erc20Token, uint256 amount) internal {
        IERC20(erc20Token).safeTransferFrom(fromAddress, toAddress, amount);
        emit PaymentProcessed(toAddress, erc20Token, amount);
    }

    /**
     * @dev permit and process the payment of {erc20Token} by this contract on behalf of {fromAddress}.
     * Note that the
     *  - if requestAmount = permitAmount: the transaction would succeed
     *  - if requestAmount > permitAmount: the transaction would fail
     *  - if requestAmount < permitAmount: the transaction would succeed and the extra funds would be refunded to the payer. Note that this is 
     *    a deliberate choice to ensure that at the end of the transaction, there is no fund spending approval lingering around (since it is 
     *    not possible to self-cancel an approval on someone else behalf). The caveat is that if the authorizer permitted the spending of 
     *    funds they do not have in the first place, the transaction would fail, even if the requested amount is lower and the authorized does have that much funds.
     */
    function _permitAndProcessPayment(address fromAddress, address toAddress, address erc20Token, uint256 requestAmount, uint256 permitAmount, uint256 expiration, uint8 v, bytes32 r, bytes32 s) internal {
        // fail early if the requested amount is higher than the permitted amount.
        require(permitAmount >= requestAmount, "ERC20PaymentProcessor: request amount exceeds permit amount.");
        IERC20Permit(erc20Token).permit(fromAddress, address(this), permitAmount, expiration, v, r, s);
        // pull the funds.
        IERC20(erc20Token).safeTransferFrom(fromAddress, address(this), permitAmount);
        // pay the receiver.
        IERC20(erc20Token).safeTransfer(toAddress, requestAmount);
        // send the change back to the payer and cancel the approval in the process.
        IERC20(erc20Token).safeTransfer(fromAddress, permitAmount - requestAmount);
        emit PaymentProcessed(toAddress, erc20Token, requestAmount);
    }

}
