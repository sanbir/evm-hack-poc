Authoritative Forge reproduction

Registry folder: 2026-10-EtherVista_exp
Registry base commit: 7e14189a6c1e2a53bf7b9eb25987956bc20f5ba2

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-10-EtherVista_exp -vvv
