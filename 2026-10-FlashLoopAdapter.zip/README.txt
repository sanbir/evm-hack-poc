2026-10-FlashLoopAdapter
Registry folder: 2026-10-FlashLoopAdapter_exp
Packed: 2026-10-12T06:43:41Z
Offline anvil_state.json: no
output.txt passing: yes
Reproduce: _shared/run_poc.sh 2026-10-FlashLoopAdapter_exp -vvvvv
