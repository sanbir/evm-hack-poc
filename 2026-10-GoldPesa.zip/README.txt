2026-10-GoldPesa
Registry folder: 2026-10-GoldPesa_exp
Packed: 2026-10-12T06:43:41Z
Offline anvil_state.json: yes
output.txt passing: yes
Reproduce: _shared/run_poc.sh 2026-10-GoldPesa_exp -vvvvv
