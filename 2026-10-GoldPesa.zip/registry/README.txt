Authoritative Forge reproduction

Registry folder: 2026-10-GoldPesa_exp
Registry base commit: 254e2e7046b9bc89c11c5cd4bb5621ea0bbb7b47

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-10-GoldPesa_exp -vvv
