2026-10-MALT
Registry folder: 2026-10-MALT_exp
Packed: 2026-10-12T06:43:41Z
Offline anvil_state.json: yes
output.txt passing: yes
Reproduce: _shared/run_poc.sh 2026-10-MALT_exp -vvvvv
