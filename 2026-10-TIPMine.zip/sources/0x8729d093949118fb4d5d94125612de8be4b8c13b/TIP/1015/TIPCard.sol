// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

// 质押核心合约接口（用于自动设置等级）
interface ITIPStakeCore {
    function setUserLevel(address user, uint8 level) external;
}

// TIPCore合约接口（用于同步等级+检查直推）
interface ITIPCoreForCard {
    function setUserLevel(address user, uint8 level) external;
    function getDirectCount(address user) external view returns (uint256);
}

/**
 * @title TIP Card - TIP节点NFT卡合约
 * @dev 基于DQC改造，新增功能：
 *      1. SOL(BSC)入金和卖出
 *      2. 合伙人NFT类型（中心化处理后上链铸造）
 *      3. 一个地址只能买一张节点卡
 *      4. 原地补差额升级（A→B补1000U，B→C补3500U）
 *      5. 直推要求检查（A需5个，B需10个，C需15个有效账号）
 *      6. 加权份数：A=1, B=3, C=10
 *      7. 节点DQ/SOL奖励（累积器模式）
 *      8. 合伙人：爆块6%+手续费30%
 */
contract TIPCard is ERC721Enumerable, Ownable {
    using SafeERC20 for IERC20;
    
    // ============ SOL合约地址（BSC链，需部署后设置） ============
    address public solToken;
    
    // ============ 卡片类型 ============
    uint256 public constant CARD_A = 1;
    uint256 public constant CARD_B = 2;
    uint256 public constant CARD_C = 3;
    uint256 public constant CARD_PARTNER = 4; // 合伙人
    
    // ============ 卡片价格（SOL，18位小数） ============
    uint256 public constant PRICE_A = 500 * 10**18;      // 500 SOL
    uint256 public constant PRICE_B = 1500 * 10**18;     // 1500 SOL
    uint256 public constant PRICE_C = 5000 * 10**18;     // 5000 SOL
    uint256 public constant PRICE_PARTNER = 5000 * 10**18; // 5000 SOL
    
    // ============ 升级补差价 ============
    uint256 public constant UPGRADE_A_TO_B = 1000 * 10**18;  // A→B补1000 SOL
    uint256 public constant UPGRADE_B_TO_C = 3500 * 10**18;  // B→C补3500 SOL
    uint256 public constant UPGRADE_A_TO_C = 4500 * 10**18;  // A→C补4500 SOL
    
    // ============ 加权份数 ============
    uint256 public constant WEIGHT_A = 1;
    uint256 public constant WEIGHT_B = 3;
    uint256 public constant WEIGHT_C = 10;
    uint256 public constant WEIGHT_PARTNER = 0; // 合伙人独立分配，不参与节点加权
    
    // ============ 直推要求 ============
    uint256 public constant DIRECT_REQ_A = 5;
    uint256 public constant DIRECT_REQ_B = 10;
    uint256 public constant DIRECT_REQ_C = 15;
    uint256 public constant DIRECT_REQ_PARTNER = 20;
    
    // ============ 发行限制 ============
    uint256 public MAX_A = 3000;
    uint256 public MAX_B = 1000;
    uint256 public MAX_C = 300;
    uint256 public MAX_PARTNER = 50;  // 前50名合伙人
    
    // ============ 统计 ============
    uint256 public totalA;
    uint256 public totalB;
    uint256 public totalC;
    uint256 public totalPartner;
    
    // ============ 收款地址 ============
    address public treasury;
    
    // ============ 授权地址 ============
    address public miningContract;
    address public adminContract;
    address public stakeContract;
    address public coreContract;
    
    // ============ 数据映射 ============
    mapping(uint256 => uint256) public cardType;             // tokenId -> 卡片类型
    mapping(address => uint256) public userNodePerformance;  // 用户节点业绩
    mapping(address => uint256) public userCardType;         // 用户当前持有的最高卡片类型（0=无）
    mapping(address => bool) public isPartner;               // 是否为合伙人
    
    // ============ 节点TIP奖励（累积器） ============
    address public TIP_TOKEN;
    uint256[4] public nTIP;   // TIP累积器: nTIP[idx] = 每卡累计应得TIP (0=A,1=B,2=C,3=Partner)
    mapping(address => mapping(uint8 => uint256)) public userNodeTIPDebt;
    // 爆块分配比例：A=4%, B=5%, C=6%
    uint256 public nodeTIPRatioA = 4;
    uint256 public nodeTIPRatioB = 5;
    uint256 public nodeTIPRatioC = 6;
    uint256 public nodeTIPRatioPartner = 6; // 合伙人6%
    
    // ============ 节点SOL奖励（提现手续费40%分配） ============
    address public SOL_REWARD_TOKEN;
    uint256[4] public nSOL;  // SOL累积器
    mapping(address => mapping(uint8 => uint256)) public userNodeSOLDebt;
    // 手续费分配比例：节点40%, 合伙人30%, 基金会30%
    // 节点40%内：A=1, B=3, C=10 (加权比例，共14份)
    uint256 public nodeSOLRatioA = 1;
    uint256 public nodeSOLRatioB = 3;
    uint256 public nodeSOLRatioC = 10;
    uint256 public nodeSOLRatioPartner = 30;
    
    // ============ 紧急暂停 ============
    bool public paused;
    
    // ============ 事件 ============
    event CardMinted(address indexed to, uint256 indexed tokenId, uint256 cardType);
    event CardPurchased(address indexed buyer, uint256 indexed tokenId, uint256 cardType, uint256 price);
    event CardUpgraded(address indexed user, uint256 oldType, uint256 newType, uint256 upgradePrice);
    event PartnerMinted(address indexed partner, uint256 indexed tokenId);
    event NodePerformanceUpdated(address indexed user, uint256 performance);
    event AdminContractUpdated(address indexed adminContract);
    event MaxSupplyUpdated(uint8 cardType, uint256 newMax);
    event TreasuryUpdated(address indexed treasury);
    event NodeTIPDistributed(uint8 cardType, uint256 amountPerCard);
    event NodeTIPClaimed(address indexed user, uint8 cardType, uint256 amount);
    event NodeSOLDistributed(uint8 cardType, uint256 amountPerCard);
    event NodeSOLClaimed(address indexed user, uint8 cardType, uint256 amount);
    event Paused();
    event Unpaused();
    
    // ============ 修饰符 ============
    modifier onlyM() {
        require(msg.sender == stakeContract || msg.sender == adminContract || msg.sender == owner(), "!m");
        _;
    }
    
    modifier onlyOwnerOrAdmin() {
        require(msg.sender == owner() || msg.sender == adminContract, "!auth");
        _;
    }
    
    modifier whenNotPaused() {
        require(!paused, "paused");
        _;
    }
    
    constructor() ERC721("TIP Card", "TIPC") Ownable(msg.sender) {}
    
    // ============ 设置函数 ============
    
    function setSolToken(address _sol) external onlyOwnerOrAdmin {
        solToken = _sol;
    }
    
    function setTreasury(address _treasury) external onlyOwnerOrAdmin {
        treasury = _treasury;
        emit TreasuryUpdated(_treasury);
    }
    
    function setAdminContract(address _addr) external onlyOwnerOrAdmin {
        adminContract = _addr;
        emit AdminContractUpdated(_addr);
    }
    
    function setMiningContract(address _m) external onlyOwnerOrAdmin {
        miningContract = _m;
    }
    
    function setStakeContract(address _s) external onlyOwnerOrAdmin {
        stakeContract = _s;
    }
    
    function setCoreContract(address _c) external onlyOwnerOrAdmin {
        coreContract = _c;
    }
    
    function setMaxSupply(uint256 _maxA, uint256 _maxB, uint256 _maxC, uint256 _maxP) external onlyOwnerOrAdmin {
        MAX_A = _maxA;
        MAX_B = _maxB;
        MAX_C = _maxC;
        MAX_PARTNER = _maxP;
    }
    
    function setTIPToken(address _tip) external onlyOwnerOrAdmin {
        TIP_TOKEN = _tip;
    }
    
    function setSOLRewardToken(address _sol) external onlyOwnerOrAdmin {
        SOL_REWARD_TOKEN = _sol;
    }
    
    function setNodeTIPRatios(uint256 _a, uint256 _b, uint256 _c, uint256 _p) external onlyOwnerOrAdmin {
        require(_a + _b + _c == 15, "node !15");
        nodeTIPRatioA = _a;
        nodeTIPRatioB = _b;
        nodeTIPRatioC = _c;
        nodeTIPRatioPartner = _p;
    }
    
    function setNodeSOLRatios(uint256 _a, uint256 _b, uint256 _c, uint256 _p) external onlyOwnerOrAdmin {
        nodeSOLRatioA = _a;
        nodeSOLRatioB = _b;
        nodeSOLRatioC = _c;
        nodeSOLRatioPartner = _p;
    }
    
    // ============ 购买节点卡 ============
    
    /**
     * @notice 用户使用SOL购买节点卡
     * @param _type 卡片类型 (1=A, 2=B, 3=C)
     * 要求：一个地址只能买一张节点卡，需满足直推要求
     */
    function buyCard(uint256 _type) external whenNotPaused {
        require(_type >= CARD_A && _type <= CARD_C, "invalid type");
        require(userCardType[msg.sender] == 0, "already have card"); // 一个地址只能买一张
        require(treasury != address(0), "!treasury");
        require(solToken != address(0), "!sol");
        
        // 直推要求检查
        _checkDirectRequirement(msg.sender, _type);
        
        uint256 price;
        if (_type == CARD_A) {
            require(totalA < MAX_A, "A card sold out");
            totalA++;
            price = PRICE_A;
        } else if (_type == CARD_B) {
            require(totalB < MAX_B, "B card sold out");
            totalB++;
            price = PRICE_B;
        } else {
            require(totalC < MAX_C, "C card sold out");
            totalC++;
            price = PRICE_C;
        }
        
        // 收取SOL
        IERC20(solToken).safeTransferFrom(msg.sender, treasury, price);
        
        // 铸造NFT
        uint256 tokenId = totalSupply() + 1;
        _safeMint(msg.sender, tokenId);
        cardType[tokenId] = _type;
        userCardType[msg.sender] = _type;
        
        // 更新节点业绩
        userNodePerformance[msg.sender] += price;
        emit NodePerformanceUpdated(msg.sender, userNodePerformance[msg.sender]);
        
        // 自动设置等级：A卡→S1, B卡→S2, C卡→S3
        _setUserLevel(msg.sender, _type);
        
        emit CardPurchased(msg.sender, tokenId, _type, price);
    }
    
    /**
     * @notice 原地补差额升级节点卡
     * @param _newType 升级目标类型 (2=B, 3=C)
     */
    function upgradeCard(uint256 _newType) external whenNotPaused {
        require(_newType > userCardType[msg.sender], "must upgrade to higher type");
        require(userCardType[msg.sender] > 0, "no card to upgrade");
        require(treasury != address(0), "!treasury");
        require(solToken != address(0), "!sol");
        
        uint256 oldType = userCardType[msg.sender];
        uint256 upgradePrice;
        
        if (oldType == CARD_A && _newType == CARD_B) {
            require(totalB < MAX_B, "B card sold out");
            upgradePrice = UPGRADE_A_TO_B;
        } else if (oldType == CARD_A && _newType == CARD_C) {
            require(totalC < MAX_C, "C card sold out");
            upgradePrice = UPGRADE_A_TO_C;
        } else if (oldType == CARD_B && _newType == CARD_C) {
            require(totalC < MAX_C, "C card sold out");
            upgradePrice = UPGRADE_B_TO_C;
        } else {
            revert("invalid upgrade path");
        }
        
        // 直推要求检查
        _checkDirectRequirement(msg.sender, _newType);
        
        // 收取补差价SOL
        IERC20(solToken).safeTransferFrom(msg.sender, treasury, upgradePrice);
        
        // 更新统计数据
        if (oldType == CARD_A) totalA--;
        else if (oldType == CARD_B) totalB--;
        
        if (_newType == CARD_B) totalB++;
        else if (_newType == CARD_C) totalC++;
        
        // 找到用户持有的NFT并更新类型
        uint256 balance = balanceOf(msg.sender);
        for (uint256 i = 0; i < balance; i++) {
            uint256 tid = tokenOfOwnerByIndex(msg.sender, i);
            if (cardType[tid] == oldType) {
                cardType[tid] = _newType;
                break;
            }
        }
        
        // 更新业绩（补差价部分）
        uint256 newPrice = getCardPrice(_newType);
        userNodePerformance[msg.sender] = newPrice;
        userCardType[msg.sender] = _newType;
        
        emit NodePerformanceUpdated(msg.sender, userNodePerformance[msg.sender]);
        
        // 更新等级
        _setUserLevel(msg.sender, _newType);
        
        emit CardUpgraded(msg.sender, oldType, _newType, upgradePrice);
    }
    
    // ============ 合伙人铸造（中心化处理后上链） ============
    
    /**
     * @notice 铸造合伙人NFT（管理员调用，中心化审核后上链）
     * @param _to 合伙人地址
     */
    function mintPartner(address _to) external onlyOwnerOrAdmin {
        require(totalPartner < MAX_PARTNER, "partner sold out");
        require(!isPartner[_to], "already partner");
        
        totalPartner++;
        isPartner[_to] = true;
        
        uint256 tokenId = totalSupply() + 1;
        _safeMint(_to, tokenId);
        cardType[tokenId] = CARD_PARTNER;
        userCardType[_to] = CARD_PARTNER;
        
        userNodePerformance[_to] += PRICE_PARTNER;
        emit NodePerformanceUpdated(_to, userNodePerformance[_to]);
        
        // 合伙人等级设为S4
        _setUserLevel(_to, CARD_PARTNER);
        
        emit PartnerMinted(_to, tokenId);
    }
    
    /**
     * @notice 批量铸造合伙人NFT
     */
    function mintPartnerBatch(address[] calldata _partners) external onlyOwnerOrAdmin {
        for (uint256 i = 0; i < _partners.length; i++) {
            require(totalPartner < MAX_PARTNER, "partner sold out");
            require(!isPartner[_partners[i]], "already partner");
            
            totalPartner++;
            isPartner[_partners[i]] = true;
            
            uint256 tokenId = totalSupply() + 1;
            _safeMint(_partners[i], tokenId);
            cardType[tokenId] = CARD_PARTNER;
            userCardType[_partners[i]] = CARD_PARTNER;
            
            userNodePerformance[_partners[i]] += PRICE_PARTNER;
            emit NodePerformanceUpdated(_partners[i], userNodePerformance[_partners[i]]);
            
            _setUserLevel(_partners[i], CARD_PARTNER);
            emit PartnerMinted(_partners[i], tokenId);
        }
    }
    
    // ============ 管理员铸造 ============
    
    function mintByOwner(address _to, uint256 _type) external onlyM {
        _mintCard(_to, _type);
    }
    
    function mintBatchByOwner(address[] calldata _to, uint256[] calldata _types) external onlyOwnerOrAdmin {
        require(_to.length == _types.length, "length mismatch");
        for (uint256 i = 0; i < _to.length; i++) {
            _mintCard(_to[i], _types[i]);
        }
    }
    
    function _mintCard(address _to, uint256 _type) internal {
        require(_type >= CARD_A && _type <= CARD_C, "invalid type");
        
        uint256 price;
        if (_type == CARD_A) {
            require(totalA < MAX_A, "A card sold out");
            totalA++;
            price = PRICE_A;
        } else if (_type == CARD_B) {
            require(totalB < MAX_B, "B card sold out");
            totalB++;
            price = PRICE_B;
        } else {
            require(totalC < MAX_C, "C card sold out");
            totalC++;
            price = PRICE_C;
        }
        
        uint256 tokenId = totalSupply() + 1;
        _safeMint(_to, tokenId);
        cardType[tokenId] = _type;
        userCardType[_to] = _type;
        
        userNodePerformance[_to] += price;
        emit NodePerformanceUpdated(_to, userNodePerformance[_to]);
        
        _setUserLevel(_to, _type);
        
        emit CardMinted(_to, tokenId, _type);
    }
    
    // ============ 转移钩子 ============
    
    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        address from = _ownerOf(tokenId);
        
        if (from != address(0)) {
            uint256 _ctype = cardType[tokenId];
            uint256 price = getCardPrice(_ctype);
            userNodePerformance[from] -= price;
            userCardType[from] = 0; // 清除卡片类型
            if (_ctype == CARD_PARTNER) isPartner[from] = false;
            emit NodePerformanceUpdated(from, userNodePerformance[from]);
        }
        
        address previousOwner = super._update(to, tokenId, auth);
        
        if (to != address(0)) {
            uint256 _ctype = cardType[tokenId];
            uint256 price = getCardPrice(_ctype);
            userNodePerformance[to] += price;
            userCardType[to] = _ctype;
            if (_ctype == CARD_PARTNER) isPartner[to] = true;
            emit NodePerformanceUpdated(to, userNodePerformance[to]);
        }
        
        // NFT转移时更新TIP/SOL debt
        if (from != address(0)) {
            uint8 _ctype = uint8(cardType[tokenId]);
            _updateNodeDebt(from, _ctype);
            if (to != address(0)) {
                _updateNodeDebt(to, _ctype);
            }
        }
        
        return previousOwner;
    }
    
    // ============ 查询函数 ============
    
    function getCardPrice(uint256 _type) public pure returns (uint256) {
        if (_type == CARD_A) return PRICE_A;
        if (_type == CARD_B) return PRICE_B;
        if (_type == CARD_C) return PRICE_C;
        if (_type == CARD_PARTNER) return PRICE_PARTNER;
        return 0;
    }
    
    function getCardWeight(uint256 _type) public pure returns (uint256) {
        if (_type == CARD_A) return WEIGHT_A;
        if (_type == CARD_B) return WEIGHT_B;
        if (_type == CARD_C) return WEIGHT_C;
        return 0;
    }
    
    function getUserCardCount(address _user, uint256 _type) external view returns (uint256) {
        uint256 count;
        uint256 balance = balanceOf(_user);
        for (uint256 i = 0; i < balance; i++) {
            uint256 tokenId = tokenOfOwnerByIndex(_user, i);
            if (cardType[tokenId] == _type) {
                count++;
            }
        }
        return count;
    }
    
    function getNodePerformance(address _user) external view returns (uint256) {
        return userNodePerformance[_user];
    }
    
    function getRemainingSupply() external view returns (uint256 a, uint256 b, uint256 c, uint256 p) {
        a = MAX_A - totalA;
        b = MAX_B - totalB;
        c = MAX_C - totalC;
        p = MAX_PARTNER - totalPartner;
    }
    
    function cardCount(uint256 _type) external view returns (uint256) {
        if (_type == 0) return totalA;
        if (_type == 1) return totalB;
        if (_type == 2) return totalC;
        if (_type == 3) return totalPartner;
        return 0;
    }
    
    // ============ 节点TIP奖励分发 ============
    
    function distributeNodeTIP(uint256 _amount) external onlyOwnerOrAdmin {
        require(_amount > 0, "0 TIP");
        require(IERC20(TIP_TOKEN).balanceOf(address(this)) >= _amount, "!bal");
        _distributeNodeTIP(_amount);
    }
    
    function _distributeNodeTIP(uint256 _amount) internal {
        if (_amount == 0) return;
        
        // 按比例分配给A/B/C/合伙人
        uint256 _total = nodeTIPRatioA + nodeTIPRatioB + nodeTIPRatioC;
        uint256 shareA = _amount * nodeTIPRatioA / _total;
        uint256 shareB = _amount * nodeTIPRatioB / _total;
        uint256 shareC = _amount - shareA - shareB;
        
        if (totalA > 0) nTIP[0] += shareA / totalA;
        if (totalB > 0) nTIP[1] += shareB / totalB;
        if (totalC > 0) nTIP[2] += shareC / totalC;
        
        emit NodeTIPDistributed(0, totalA > 0 ? shareA / totalA : 0);
        emit NodeTIPDistributed(1, totalB > 0 ? shareB / totalB : 0);
        emit NodeTIPDistributed(2, totalC > 0 ? shareC / totalC : 0);
    }
    
    /// @notice 合伙人单独分发TIP奖励（爆块6%）
    function distributePartnerTIP(uint256 _amount) external onlyOwnerOrAdmin {
        require(_amount > 0, "0 TIP");
        require(IERC20(TIP_TOKEN).balanceOf(address(this)) >= _amount, "!bal");
        if (totalPartner > 0) {
            nTIP[3] += _amount / totalPartner;
            emit NodeTIPDistributed(3, _amount / totalPartner);
        }
    }
    
    function claimNodeTIPReward() external whenNotPaused {
        uint256 totalReward;
        for (uint8 i = 0; i < 4; i++) {
            uint256 count = _getCardCount(msg.sender, i);
            if (count > 0) {
                uint256 pending = count * nTIP[i];
                uint256 reward = pending - userNodeTIPDebt[msg.sender][i];
                if (reward > 0) {
                    userNodeTIPDebt[msg.sender][i] = pending;
                    totalReward += reward;
                    emit NodeTIPClaimed(msg.sender, i, reward);
                }
            }
        }
        require(totalReward > 0, "!reward");
        IERC20(TIP_TOKEN).safeTransfer(msg.sender, totalReward);
    }
    
    function pendingNodeTIP(address _user) external view returns (uint256) {
        uint256 total;
        for (uint8 i = 0; i < 4; i++) {
            uint256 count = _getCardCount(_user, i);
            total += count * nTIP[i] - userNodeTIPDebt[_user][i];
        }
        return total;
    }
    
    // ============ 节点SOL奖励分发 ============
    
    function distributeNodeSOL(uint256 _amount) external onlyOwnerOrAdmin {
        require(_amount > 0, "0 SOL");
        require(IERC20(SOL_REWARD_TOKEN).balanceOf(address(this)) >= _amount, "!bal");
        _distributeNodeSOL(_amount);
    }
    
    function _distributeNodeSOL(uint256 _amount) internal {
        if (_amount == 0) return;
        
        uint256 _total = nodeSOLRatioA + nodeSOLRatioB + nodeSOLRatioC;
        uint256 shareA = _amount * nodeSOLRatioA / _total;
        uint256 shareB = _amount * nodeSOLRatioB / _total;
        uint256 shareC = _amount - shareA - shareB;
        
        if (totalA > 0) nSOL[0] += shareA / totalA;
        if (totalB > 0) nSOL[1] += shareB / totalB;
        if (totalC > 0) nSOL[2] += shareC / totalC;
        
        emit NodeSOLDistributed(0, totalA > 0 ? shareA / totalA : 0);
        emit NodeSOLDistributed(1, totalB > 0 ? shareB / totalB : 0);
        emit NodeSOLDistributed(2, totalC > 0 ? shareC / totalC : 0);
    }
    
    /// @notice 合伙人单独分发SOL奖励（手续费30%）
    function distributePartnerSOL(uint256 _amount) external onlyOwnerOrAdmin {
        require(_amount > 0, "0 SOL");
        require(IERC20(SOL_REWARD_TOKEN).balanceOf(address(this)) >= _amount, "!bal");
        if (totalPartner > 0) {
            nSOL[3] += _amount / totalPartner;
            emit NodeSOLDistributed(3, _amount / totalPartner);
        }
    }
    
    function claimNodeSOLReward() external whenNotPaused {
        uint256 totalReward;
        for (uint8 i = 0; i < 4; i++) {
            uint256 count = _getCardCount(msg.sender, i);
            if (count > 0) {
                uint256 pending = count * nSOL[i];
                uint256 reward = pending - userNodeSOLDebt[msg.sender][i];
                if (reward > 0) {
                    userNodeSOLDebt[msg.sender][i] = pending;
                    totalReward += reward;
                    emit NodeSOLClaimed(msg.sender, i, reward);
                }
            }
        }
        require(totalReward > 0, "!reward");
        IERC20(SOL_REWARD_TOKEN).safeTransfer(msg.sender, totalReward);
    }
    
    function pendingNodeSOL(address _user) external view returns (uint256) {
        uint256 total;
        for (uint8 i = 0; i < 4; i++) {
            uint256 count = _getCardCount(_user, i);
            total += count * nSOL[i] - userNodeSOLDebt[_user][i];
        }
        return total;
    }
    
    function pendingAllNodeRewards(address _user) external view returns (uint256 tip, uint256 sol) {
        for (uint8 i = 0; i < 4; i++) {
            uint256 count = _getCardCount(_user, i);
            tip += count * nTIP[i] - userNodeTIPDebt[_user][i];
            sol += count * nSOL[i] - userNodeSOLDebt[_user][i];
        }
    }
    
    // ============ 内部工具 ============
    
    function _getCardCount(address _user, uint8 _type) internal view returns (uint256) {
        uint256 count;
        uint256 balance = balanceOf(_user);
        for (uint256 i = 0; i < balance; i++) {
            uint256 tokenId = tokenOfOwnerByIndex(_user, i);
            if (cardType[tokenId] == _type + 1 || (_type == 3 && cardType[tokenId] == CARD_PARTNER)) {
                count++;
            }
        }
        return count;
    }
    
    function _updateNodeDebt(address _user, uint8 _cardType) internal {
        uint8 idx;
        if (_cardType == CARD_PARTNER) {
            idx = 3;
        } else {
            idx = _cardType - 1; // cardType 1,2,3 → idx 0,1,2
        }
        uint256 count = _getCardCount(_user, idx);
        userNodeTIPDebt[_user][idx] = count * nTIP[idx];
        userNodeSOLDebt[_user][idx] = count * nSOL[idx];
    }
    
    function _setUserLevel(address _user, uint256 _cardType) internal {
        if (stakeContract != address(0)) {
            uint8 targetLevel = 0;
            if (_cardType == CARD_A) targetLevel = 1;       // S1
            else if (_cardType == CARD_B) targetLevel = 2;   // S2
            else if (_cardType == CARD_C) targetLevel = 3;   // S3
            else if (_cardType == CARD_PARTNER) targetLevel = 4; // S4
            
            if (targetLevel > 0) {
                ITIPStakeCore(stakeContract).setUserLevel(_user, targetLevel);
                if (coreContract != address(0)) {
                    ITIPCoreForCard(coreContract).setUserLevel(_user, targetLevel);
                }
            }
        }
    }
    
    /**
     * @dev 检查直推要求
     */
    function _checkDirectRequirement(address _user, uint256 _type) internal view {
        if (coreContract == address(0)) return; // 未设置Core合约则跳过检查
        
        uint256 directCount = ITIPCoreForCard(coreContract).getDirectCount(_user);
        if (_type == CARD_A) {
            require(directCount >= DIRECT_REQ_A, "need 5 direct");
        } else if (_type == CARD_B) {
            require(directCount >= DIRECT_REQ_B, "need 10 direct");
        } else if (_type == CARD_C) {
            require(directCount >= DIRECT_REQ_C, "need 15 direct");
        }
    }
    
    // ============ 紧急操作 ============
    
    function setPaused(bool _paused) external onlyOwnerOrAdmin {
        paused = _paused;
        if (_paused) emit Paused();
        else emit Unpaused();
    }
    
    function emergencyWithdraw(address _token, address _to) external onlyOwnerOrAdmin {
        require(_to != address(0), "!zero");
        if (_token == address(0)) {
            uint256 bal = address(this).balance;
            if (bal > 0) {
                (bool success, ) = payable(_to).call{value: bal}("");
                require(success, "transfer failed");
            }
        } else {
            uint256 bal = IERC20(_token).balanceOf(address(this));
            if (bal > 0) {
                IERC20(_token).safeTransfer(_to, bal);
            }
        }
    }
    
    function withdrawToken(address _token, address _to, uint256 _amount) external onlyOwnerOrAdmin {
        require(_to != address(0), "!zero");
        if (_token == address(0)) {
            (bool success, ) = payable(_to).call{value: _amount}("");
            require(success, "transfer failed");
        } else {
            IERC20(_token).safeTransfer(_to, _amount);
        }
    }
    
    receive() external payable {}
}
