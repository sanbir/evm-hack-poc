pragma solidity ^0.8.17;
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
/**
 * @title TIP StakeCore
 * @notice TIP质押核心合约 - 包含见点奖、管理奖、D等级、LP管理
 * 
 * 与DQMiningStakeCore的主要差异：
 * 1. 取消直推奖(0%)，见点奖32%(推1拿2层~推8拿16层)
 * 2. 见点奖中2%给直推人
 * 3. 管理奖42%（级差制S1:6%~S7:42%，小区业绩晋升）
 * 4. 能量值扣减机制（TIPCore管理，此处仅调用useEnergy检查）
 * 5. LP必须通过DAPP移除（合约持有LP代币）
 * 6. SOL替代SOL作为动态奖励代币
 * 7. D等级检查上级16层
 * 8. 管理等级S1-S7（7级）
 * 9. 动态U提现扣10%手续费
 */
interface ITIPCore {
    function useEnergy(address user, uint256 amount) external returns (bool);
    function getUserTotalInvest(address user) external view returns (uint256);
    function isBlacklisted(address user) external view returns (bool);
    function setReferrer(address _user, address _referrer) external;
    function getAvailableEnergy(address user) external view returns (uint256);
    function transferSOLToUser(address _user, uint256 _amount) external;
}
interface ITIPCard {
    function cardCount(uint256 _type) external view returns (uint256);
    function userCardType(address _user) external view returns (uint256);
}
interface IRouter {
    function removeLiquidity(
        address tokenA, address tokenB,
        uint256 liquidity,
        uint256 amountAMin, uint256 amountBMin,
        address to, uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB);
    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn, uint256 amountOutMin, address[] calldata path, address to, uint256 deadline
    ) external;
    function addLiquidity(
        address tokenA, address tokenB,
        uint256 amountADesired, uint256 amountBDesired,
        uint256 amountAMin, uint256 amountBMin,
        address to, uint256 deadline
    ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);
}
interface ILP {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
}
contract TIPStakeCore is ReentrancyGuard {
    using EnumerableSet for EnumerableSet.AddressSet;
    using SafeERC20 for IERC20;
    address public immutable OWNER;
    address public immutable SOL;
    address public tipToken;
    address public tipCard;
    address public coreContract;
    address public miningContract;
    address public adminContract;
    address public lpPair;
    address public lpRouter;
    address public vaultContract;
    uint256 public constant DIRECT_RATE = 0;        
    uint256 public constant SPOT_RATE = 32;          
    uint256 public constant SPOT_DIRECT_RATE = 2;    
    uint256 public constant MANAGEMENT_RATE = 42;    
    uint256 public constant MAX_SPOT_LAYERS = 16;    
    // 管理等级阈值（小区业绩，SOL 18 decimals）— 与 levelThresholds 一致
    uint256[7] public mgrThresh = [
        50 * 10**18,
        150 * 10**18,
        500 * 10**18,
        1500 * 10**18,
        5000 * 10**18,
        15000 * 10**18,
        30000 * 10**18
    ];
    uint8[7] public mgrRates = [6, 12, 18, 24, 30, 36, 42];
    uint256 public constant CLAIM_FEE = 1000;  
    address public feeReceiver;
    uint256 public lpLaunchTime;          
    uint256 public constant LP_DAILY_LIMIT = 500;  
    uint256 public constant LP_LIMIT_DAYS = 10;    
    bool public lpPurchaseEnabled = false; 
    mapping(uint8 => uint256) public lpLimitPerLevel; 
    mapping(address => uint256) public userLPPurchased; 
    uint256 public dailyLPPurchased;      
    uint256 public lastLPDay;             
    uint256 public constant RELEASE_DURATION = 60 days; 
    struct ReleaseOrder {
        uint256 amount;        
        uint256 startTime;     
        uint256 claimed;       
    }
    mapping(address => ReleaseOrder[]) public releaseOrders; 
    uint256[8] public dLevelThresholds = [
        30, 120, 360, 1000, 4000, 10000, 15000, 30000
    ];
    uint256[8] public dLevelCount;
    uint256[8] public dLevelAccReward;
    mapping(uint8 => mapping(address => bool)) public isDLevel;
    mapping(address => uint8) public userDLevel;
    mapping(address => uint256) public dLevelRewardDebt;
    mapping(address => uint256) public totalDRankRewardClaimed;
    mapping(address => uint256) public userPendingSOL;     
    mapping(address => uint256) public userDirectSales;
    mapping(address => uint8) public userNodeLevel;
    mapping(address => uint8) public userLevel;             
    mapping(address => address) public userReferrer;
    mapping(address => uint256) public directCount;
    mapping(address => EnumerableSet.AddressSet) internal userChildren;
    mapping(address => uint256) public totalSOLRewardClaimed;
    mapping(address => uint256) public totalLPRewardClaimed;
    mapping(address => uint256) public userLP;       
    mapping(address => uint256) public lpStakeTime;
    uint256 public tLP;       
    uint256 public lA;        
    mapping(address => uint256) public lpEquity;
    uint256 public totalLPEquity;
    mapping(address => uint256) public lpEquityDebt;
    mapping(address => uint256) public lpRewardDebt;
    mapping(address => uint256) public teamSales;
    mapping(address => mapping(address => uint256)) public directBranchSales;
    uint256[7] public levelThresholds = [
        50 * 10**18,
        150 * 10**18,
        500 * 10**18,
        1500 * 10**18,
        5000 * 10**18,
        15000 * 10**18,
        30000 * 10**18
    ];
    mapping(address => bool) public isBlacklisted;
    mapping(address => bool) public isLpRemovalBlocked;   // LP移除黑名单（管理员手动限制）
    modifier onlyOwner() {
        require(msg.sender == OWNER || msg.sender == adminContract, "!auth");
        _;
    }
    modifier onlyMining() {
        require(msg.sender == miningContract || msg.sender == adminContract || msg.sender == OWNER, "!m");
        _;
    }
    modifier onlyCore() {
        require(msg.sender == coreContract || msg.sender == OWNER, "!c");
        _;
    }
    modifier onlyOwnerOrCore() {
        require(msg.sender == OWNER || msg.sender == adminContract || msg.sender == coreContract, "!auth");
        _;
    }
    constructor(address _owner, address _sol) {
        OWNER = _owner;
        SOL = _sol;
    }
    function setAddresses(address _tip, address _card, address _lpPair) external onlyOwner {
        if (_tip != address(0)) tipToken = _tip;
        if (_card != address(0)) tipCard = _card;
        if (lpPair == address(0) && _lpPair != address(0)) lpPair = _lpPair;
    }
    function setCoreContract(address _addr) external onlyOwner {coreContract = _addr;}
    function setMiningContract(address _addr) external onlyOwner {miningContract = _addr;}
    function setAdminContract(address _addr) external onlyOwner {adminContract = _addr;}
    function setVaultContract(address _addr) external onlyOwner {vaultContract = _addr;}
    function setLpPair(address _pair) external onlyOwner {lpPair = _pair;}
    function setLpRouter(address _router) external onlyOwner {lpRouter = _router;}
    function setFeeReceiver(address _addr) external onlyOwner {feeReceiver = _addr;}
    function setMgrThresh(uint256[7] calldata _t) external onlyOwner {mgrThresh = _t;}
    function setMgrRates(uint8[7] calldata _r) external onlyOwner {mgrRates = _r;}
    function setLevelThresholds(uint256[7] calldata _t) external onlyOwner {levelThresholds = _t;}
    function setDLevelThresholds(uint256[8] calldata _t) external onlyOwner {dLevelThresholds = _t;}
    function bl(address _u, bool _s) external onlyOwner { isBlacklisted[_u] = _s; }
    function setLpRemovalBlocked(address _u, bool _s) external onlyOwner { isLpRemovalBlocked[_u] = _s; }
    function registerUser(address _u, address _r, uint8 _level) external onlyOwnerOrCore {
        if (userReferrer[_u] == address(0) && _r != address(0) && _u != _r) {
            userReferrer[_u] = _r;
            directCount[_r]++;
            userChildren[_r].add(_u);
        }
        if (_level > 0 && _level > userLevel[_u]) userLevel[_u] = _level;
    }
    function addDirectSales(address _u, uint256 _a) external onlyOwnerOrCore {
        userDirectSales[_u] += _a;
    }
    function registerDLevel(address _u, uint8 _lvl) external onlyOwner {
        if (userDLevel[_u] > 0) dLevelCount[userDLevel[_u] - 1]--;
        userDLevel[_u] = _lvl;
        if (_lvl > 0) {
            dLevelCount[_lvl - 1]++;
            isDLevel[_lvl][_u] = true;
            if (dLevelCount[_lvl - 1] > 0) dLevelRewardDebt[_u] = dLevelAccReward[_lvl - 1] / dLevelCount[_lvl - 1];
        }
    }
    function setUserNodeLevel(address _u, uint8 _lvl) external onlyOwner {
        userNodeLevel[_u] = _lvl;
    }
    function setUserLevel(address _u, uint8 _level) external {
        require(msg.sender == tipCard || msg.sender == adminContract || msg.sender == OWNER, "!auth");
        if (_level > userLevel[_u]) {
            userLevel[_u] = _level;
        }
    }
    function setReferrer(address _user, address _referrer) external onlyOwnerOrCore {
        if (userReferrer[_user] == address(0) && _referrer != address(0) && _user != _referrer) {
            userReferrer[_user] = _referrer;
            directCount[_referrer]++;
            userChildren[_referrer].add(_user);
        }
    }
    function onDeposit(address _user, uint256 _amount) external onlyOwnerOrCore {
        _updateTeamSalesAndUpgrade(_user, _amount);
        _checkDLevelUpgradeAuto(_user);
        _distributeRewards(_user, _amount);
    }
    function _updateTeamSalesAndUpgrade(address _user, uint256 _amount) internal {
        address cur = userReferrer[_user];
        uint8 dCheckCount = 0;
        while (cur != address(0)) {
            teamSales[cur] += _amount;
            address directChild = _user;
            address parent = userReferrer[directChild];
            while (parent != cur && parent != address(0)) {
                directChild = parent;
                parent = userReferrer[directChild];
            }
            if (parent == cur) {
                directBranchSales[cur][directChild] += _amount;
            }
            _checkAndAutoUpgrade(cur);
            if (dCheckCount < 16) {
                _checkDLevelUpgradeAuto(cur);
                dCheckCount++;
            }
            cur = userReferrer[cur];
        }
    }
    function _getTeamSalesExcludingMaxBranch(address _user) internal view returns (uint256) {
        uint256 maxBranchSales = 0;
        EnumerableSet.AddressSet storage children = userChildren[_user];
        uint256 len = children.length();
        for (uint256 i = 0; i < len; i++) {
            address child = children.at(i);
            if (directBranchSales[_user][child] > maxBranchSales) {
                maxBranchSales = directBranchSales[_user][child];
            }
        }
        return teamSales[_user] - maxBranchSales;
    }
    function _checkAndAutoUpgrade(address _user) internal {
        uint256 sales = _getTeamSalesExcludingMaxBranch(_user);
        uint8 currentLevel = userLevel[_user];
        uint8 newLevel = currentLevel;
        for (uint8 i = 7; i >= 1; i--) {
            if (sales >= levelThresholds[i - 1]) {
                newLevel = i;
                break;
            }
        }
        if (newLevel > currentLevel) {
            userLevel[_user] = newLevel;
        }
    }
    function _checkDLevelUpgradeAuto(address _user) internal {
        uint256 validCount = _countValidAddresses(_user);
        uint8 currentLevel = userDLevel[_user];
        uint8 newLevel = currentLevel;
        for (uint8 i = 8; i >= 1; i--) {
            if (validCount >= dLevelThresholds[i - 1]) {
                newLevel = i;
                break;
            }
        }
        if (newLevel > currentLevel) {
            if (currentLevel > 0) dLevelCount[currentLevel - 1]--;
            userDLevel[_user] = newLevel;
            dLevelCount[newLevel - 1]++;
            isDLevel[newLevel][_user] = true;
            if (dLevelCount[newLevel - 1] > 0) {
                dLevelRewardDebt[_user] = dLevelAccReward[newLevel - 1] / dLevelCount[newLevel - 1];
            }
        }
    }
    function _countValidAddresses(address _user) internal view returns (uint256) {
        uint256 count = 0;
        EnumerableSet.AddressSet storage children = userChildren[_user];
        uint256 len = children.length();
        for (uint256 i = 0; i < len; i++) {
            address child = children.at(i);
            if (ITIPCore(coreContract).getUserTotalInvest(child) > 0) count++;
            count += _countValidAddresses(child);
        }
        return count;
    }
    function _updLPDebt(address _u) internal {
        if (tLP > 0 && lA > 0) {
            lpRewardDebt[_u] = userLP[_u] * lA / tLP;
            lpEquityDebt[_u] = 0;
        }
    }
    function _distributeRewards(address _user, uint256 _amount) internal {
        address ref = userReferrer[_user];
        if (ref == address(0)) return;
        // 见点：32%总池，分16层，每层2%（推1拿2层~推8拿16层）
        uint256 spotPerLayer = _amount * SPOT_RATE / 100 / MAX_SPOT_LAYERS;
        uint256 spotDirectPool = _amount * SPOT_DIRECT_RATE / 100;
        _distSpot(_user, spotPerLayer, spotDirectPool, 1);
        _distMgr(_user, _amount * MANAGEMENT_RATE / 100);
    }
    /**
     * @notice 见点奖分配 - 32%/代，推1拿2层~推8拿16层
     * @param _user 入金用户
     * @param _spotPool 每代奖励金额
     * @param _spotDirectPool 直推额外2%
     * @param _depth 当前深度
     */
    function _distSpot(address _user, uint256 _spotPool, uint256 _spotDirectPool, uint8 _depth) internal {
        if (_depth > MAX_SPOT_LAYERS) return;
        address ref = userReferrer[_user];
        if (ref == address(0)) return;
        uint256 ds = directCount[ref];
        uint256 canLayers = ds * 2;
        if (canLayers > MAX_SPOT_LAYERS) canLayers = MAX_SPOT_LAYERS;
        if (_depth <= canLayers) {
            if (ITIPCore(coreContract).useEnergy(ref, _spotPool)) {
                userPendingSOL[ref] += _spotPool;
                if (_depth == 1 && _spotDirectPool > 0) {
                    if (ITIPCore(coreContract).useEnergy(ref, _spotDirectPool)) {
                        userPendingSOL[ref] += _spotDirectPool;
                    }
                }
            }
        }
        _distSpot(ref, _spotPool, _spotDirectPool, _depth + 1);
    }
    /**
     * @notice 管理奖分配 - 42%级差制(S1:6%~S7:42%)
     */
    function _distMgr(address _user, uint256 _mgrPool) internal {
        address cur = userReferrer[_user];
        uint8 prevRate = 0;
        while (cur != address(0) && prevRate < 42) {
            uint8 curLvl = userLevel[cur];
            if (curLvl > 0) {
                uint8 curRate = mgrRates[curLvl - 1];
                if (curRate > prevRate) {
                    uint8 diffRate = curRate - prevRate;
                    uint256 reward = _mgrPool * diffRate / 42;
                    if (reward > 0 && ITIPCore(coreContract).useEnergy(cur, reward)) {
                        userPendingSOL[cur] += reward;
                        prevRate = curRate;
                    }
                }
            }
            cur = userReferrer[cur];
        }
    }
    /**
     * @notice 用户提取SOL动态奖励（由TIPCore调用）
     * 扣10%手续费
     */
    function withdrawSOL(address _user, uint256 _amount) external onlyOwnerOrCore {
        require(_amount <= userPendingSOL[_user], "!balance");
        userPendingSOL[_user] -= _amount;
        totalSOLRewardClaimed[_user] += _amount;
        IERC20(SOL).safeTransfer(coreContract, _amount);
    }
    function batchImportReferrer(address[] calldata _users, address[] calldata _refs) external onlyOwner {
        for (uint256 i = 0; i < _users.length; i++) {
            userReferrer[_users[i]] = _refs[i];
            if (_refs[i] != address(0)) directCount[_refs[i]]++;
        }
    }
    function recordLP(address _user, uint256 _lpAmount) external onlyOwnerOrCore {
        require(_lpAmount > 0, "!a");
        if (lpEquity[_user] == 0 && userLP[_user] == 0) {
            lpStakeTime[_user] = block.timestamp;
        }
        userLP[_user] += _lpAmount;
        tLP += _lpAmount;
        lpEquity[_user] += _lpAmount;
        totalLPEquity += _lpAmount;
        _updLPDebt(_user);
    }
    function batchRecordLP(address[] calldata _users, uint256[] calldata _amounts) external onlyOwner {
        require(_users.length == _amounts.length, "!len");
        for (uint256 i = 0; i < _users.length; i++) {
            if (_amounts[i] > 0) {
                if (lpEquity[_users[i]] == 0 && userLP[_users[i]] == 0) {
                    lpStakeTime[_users[i]] = block.timestamp;
                }
                userLP[_users[i]] += _amounts[i];
                tLP += _amounts[i];
                lpEquity[_users[i]] += _amounts[i];
                totalLPEquity += _amounts[i];
                _updLPDebt(_users[i]);
            }
        }
    }
    function batchSetUserData(address[] calldata _users, uint256[] calldata _sales, uint256[] calldata _counts, uint256[] calldata _teamSales) external onlyOwner {
        require(_users.length == _sales.length, "!len");
        for (uint256 i = 0; i < _users.length; i++) {
            directCount[_users[i]] = _counts[i];
            teamSales[_users[i]] = _teamSales[i];
        }
    }
    /**
     * @notice 用户用SOL购买LP（需节点权限）
     * 需求：转SOL就参与打LP，合伙人>C>B>A优先级
     * 前10天每天限500LP，每等级独立配置份数
     * 普通用户需管理员开启 lpPurchaseEnabled
     */
    function buyLP(uint256 _solAmount) external nonReentrant {
        require(_solAmount > 0, "!a");
        require(lpPair != address(0), "!lpPair");
        require(lpRouter != address(0), "!router");
        require(tipToken != address(0), "!tip");
        require(!isBlacklisted[msg.sender], "blk");
        checkLPLimit(msg.sender, _solAmount);
        IERC20(SOL).safeTransferFrom(msg.sender, address(this), _solAmount);
        uint256 half = _solAmount / 2;
        address[] memory path = new address[](2);
        path[0] = SOL;
        path[1] = tipToken;
        IERC20(SOL).forceApprove(lpRouter, _solAmount);
        IRouter(lpRouter).swapExactTokensForTokensSupportingFeeOnTransferTokens(
            half, 0, path, address(this), block.timestamp + 300
        );
        uint256 tipBal = IERC20(tipToken).balanceOf(address(this));
        uint256 solBal = IERC20(SOL).balanceOf(address(this));
        IERC20(tipToken).forceApprove(lpRouter, tipBal);
        (, , uint256 lpReceived) = IRouter(lpRouter).addLiquidity(
            SOL, tipToken, solBal, tipBal, 0, 0, msg.sender, block.timestamp + 300
        );
        IERC20(SOL).forceApprove(lpRouter, 0);
        IERC20(tipToken).forceApprove(lpRouter, 0);
        lpStakeTime[msg.sender] = block.timestamp;
        userLP[msg.sender] += lpReceived;
        tLP += lpReceived;
        lpEquity[msg.sender] += lpReceived;
        totalLPEquity += lpReceived;
        _updLPDebt(msg.sender);
    }
    /**
     * TIP: LP代币由合约持有，用户只能通过DAPP发起移除
     * 手续费：<30天30%，30-90天20%，90-180天10%，>180天0%
     */
    function removeLP(uint256 _amount) external nonReentrant {
        require(_amount > 0, "!a");
        require(userLP[msg.sender] >= _amount, "!lp");
        require(_amount == userLP[msg.sender], "must remove all");
        require(lpPair != address(0), "!lpPair");
        require(lpRouter != address(0), "!router");
        require(!isBlacklisted[msg.sender], "blk");
        require(!isLpRemovalBlocked[msg.sender], "lp blocked");
        userLP[msg.sender] -= _amount;
        tLP -= _amount;
        lpEquity[msg.sender] -= _amount;
        totalLPEquity -= _amount;
        _updLPDebt(msg.sender);
        _breakLPAndDistribute(_amount, msg.sender);
    }
    function _breakLPAndDistribute(uint256 _lpAmount, address _user) internal {
        // 从用户钱包拉取 LP 代币（用户需先 approve StakeCore）
        IERC20(lpPair).safeTransferFrom(_user, address(this), _lpAmount);
        IERC20(lpPair).approve(lpRouter, _lpAmount);
        address token0 = ILP(lpPair).token0();
        (address tokenA, address tokenB) = token0 == SOL ? (SOL, tipToken) : (tipToken, SOL);
        (uint256 amountA, uint256 amountB) = IRouter(lpRouter).removeLiquidity(
            tokenA, tokenB, _lpAmount, 1, 1, address(this), block.timestamp + 3600
        );
        uint256 amountSOL = tokenA == SOL ? amountA : amountB;
        uint256 amountTIP = tokenA == SOL ? amountB : amountA;
        uint256 stakeDuration = block.timestamp - lpStakeTime[_user];
        uint256 feeRate;
        if (stakeDuration < 60 days) {
            feeRate = 2000;  
        } else if (stakeDuration < 180 days) {
            feeRate = 1000;  
        } else {
            feeRate = 0;     
        }
        uint256 solFee = amountSOL * feeRate / 10000;
        uint256 tipFee = amountTIP * feeRate / 10000;
        if (amountSOL > solFee) IERC20(SOL).safeTransfer(_user, amountSOL - solFee);
        uint256 tipToLock = amountTIP - tipFee;
        if (tipToLock > 0) {
            releaseOrders[_user].push(ReleaseOrder({
                amount: tipToLock,
                startTime: block.timestamp,
                claimed: 0
            }));
        }
        if (solFee > 0 && feeReceiver != address(0)) IERC20(SOL).safeTransfer(feeReceiver, solFee);
        if (tipFee > 0 && feeReceiver != address(0)) IERC20(tipToken).safeTransfer(feeReceiver, tipFee);
    }
    function claimLPEquityReward() external nonReentrant {
        require(!isBlacklisted[msg.sender], "blk");
        require(userLP[msg.sender] > 0, "!lp");
        require(tLP > 0, "!t");
        uint256 pending = userLP[msg.sender] * lA / tLP;
        uint256 reward = pending - lpRewardDebt[msg.sender];
        require(reward > 0, "!r");
        lpRewardDebt[msg.sender] = pending;
        IERC20(tipToken).safeTransfer(msg.sender, reward);
        totalLPRewardClaimed[msg.sender] += reward;
    }
    function updateLPDebt(address _user) external {
        require(msg.sender == miningContract || msg.sender == vaultContract || msg.sender == OWNER, "!auth");
        _updLPDebt(_user);
    }
    function distributeLPReward(uint256 _amount) external onlyMining {
        require(_amount > 0, "!a");
        if (tLP > 0) {
            lA += _amount;
        } else {
            IERC20(tipToken).safeTransfer(miningContract, _amount);
        }
    }
    // 节点奖励、单币质押已迁移至 TIPMine 合约
    // 用户请调用 TIPMine.claimNodeReward / stakeTIP / unstakeTIP 等
    function distributeDRankReward(uint256 _amount) external onlyMining {
        require(_amount > 0, "!a");
        for (uint8 i = 0; i < 8; i++) {
            if (dLevelCount[i] > 0) dLevelAccReward[i] += _amount / 8;
        }
    }
    function claimDRankReward() external nonReentrant {
        require(!isBlacklisted[msg.sender], "blk");
        uint8 dLvl = userDLevel[msg.sender];
        require(dLvl > 0, "!d");
        require(dLevelCount[dLvl - 1] > 0, "!c");
        uint256 rewardPerUser = dLevelAccReward[dLvl - 1] / dLevelCount[dLvl - 1];
        uint256 reward = rewardPerUser - dLevelRewardDebt[msg.sender];
        if (reward > 0) {
            dLevelRewardDebt[msg.sender] = rewardPerUser;
            totalDRankRewardClaimed[msg.sender] += reward;
            IERC20(tipToken).safeTransfer(msg.sender, reward);
        }
    }
    function setUserData(address _user, uint256 _sales, uint256 _count, uint256 _teamSales) external onlyOwnerOrCore {
        userDirectSales[_user] = _sales;
        directCount[_user] = _count;
        teamSales[_user] = _teamSales;
    }
    function adminSetLPZero(address _user) external onlyOwner {
        tLP -= userLP[_user];
        totalLPEquity -= lpEquity[_user];
        userLP[_user] = 0;
        lpEquity[_user] = 0;
        _updLPDebt(_user);
    }
    function getLP(address _u) external view returns (uint256) { return userLP[_u]; }
    function getLPEquity(address _u) external view returns (uint256) { return lpEquity[_u]; }
    function syncLP() external nonReentrant {
        require(lpPair != address(0), "!lp");
        uint256 bal = IERC20(lpPair).balanceOf(msg.sender);
        uint256 old = userLP[msg.sender];
        if (bal > old) {
            // 用户外部购买了额外 LP，只记账，不转移代币（LP 留在用户钱包）
            uint256 diff = bal - old;
            userLP[msg.sender] = bal;
            tLP += diff;
            lpEquity[msg.sender] += diff;
            totalLPEquity += diff;
            _updLPDebt(msg.sender);
        }
        // bal <= old 时不做任何操作，避免误清零
    }
    function withdrawToken(address _token, address _to, uint256 _amount) external onlyOwner {
        require(_to != address(0), "!0");
        if (_token == address(0)) {
            payable(_to).transfer(_amount);
        } else {
            IERC20(_token).safeTransfer(_to, _amount);
        }
    }
    function getLPLevel(address _user) public view returns (uint8) {
        uint256 ct = ITIPCard(tipCard).userCardType(_user);
        if (ct == 4) return 0;  // Partner → priority 0
        if (ct == 3) return 1;  // C → priority 1
        if (ct == 2) return 2;  // B → priority 2
        if (ct == 1) return 3;  // A → priority 3
        return 4;               // No card → normal user
    }
    function checkLPLimit(address _user, uint256 _lpAmount) internal {
        uint8 level = getLPLevel(_user);
        require(level <= 3 || lpPurchaseEnabled, "!lp");
        uint256 today = block.timestamp / 1 days;
        if (today != lastLPDay) {
            dailyLPPurchased = 0;
            lastLPDay = today;
        }
        if (lpLaunchTime > 0 && block.timestamp < lpLaunchTime + LP_LIMIT_DAYS * 1 days) {
            require(dailyLPPurchased + _lpAmount <= LP_DAILY_LIMIT, "!lpD");
        }
        uint256 limit = lpLimitPerLevel[level];
        if (limit > 0) {
            require(userLPPurchased[_user] + _lpAmount <= limit, "!lpL");
        }
        userLPPurchased[_user] += _lpAmount;
        dailyLPPurchased += _lpAmount;
    }
    function setLPLaunchTime(uint256 _time) external onlyOwner {lpLaunchTime = _time;}
    function setLPPurchaseEnabled(bool _enabled) external onlyOwner {lpPurchaseEnabled = _enabled;}
    function setLPLimitPerLevel(uint8 _level, uint256 _limit) external onlyOwner {lpLimitPerLevel[_level] = _limit;}
    // ============ 单币质押（已迁移至 TIPMine） ============
    // distributeSellFee 转发：Core/Token 卖出税 → StakeCore → Mine
    function distributeSellFee(uint256 _a) external {
        require(msg.sender == coreContract || msg.sender == tipToken || msg.sender == OWNER || msg.sender == adminContract, "!a");
        if (miningContract != address(0) && _a > 0) {
            IERC20(tipToken).safeTransfer(miningContract, _a);
            (bool s, ) = miningContract.call(abi.encodeWithSignature("distributeSellFee(uint256)", _a));
            require(s, "fwd");
        }
    }
    function claimReleasedTIP() external nonReentrant {
        ReleaseOrder[] storage orders = releaseOrders[msg.sender];
        uint256 totalClaimable = 0;
        for (uint256 i = 0; i < orders.length; i++) {
            if (orders[i].amount == 0 || orders[i].claimed >= orders[i].amount) continue;
            uint256 elapsed = block.timestamp - orders[i].startTime;
            if (elapsed >= RELEASE_DURATION) {
                totalClaimable += orders[i].amount - orders[i].claimed;
                orders[i].claimed = orders[i].amount;
            } else {
                uint256 releasable = orders[i].amount * elapsed / RELEASE_DURATION;
                if (releasable > orders[i].claimed) {
                    totalClaimable += releasable - orders[i].claimed;
                    orders[i].claimed = releasable;
                }
            }
        }
        require(totalClaimable > 0, "!r");
        IERC20(tipToken).safeTransfer(msg.sender, totalClaimable);
    }
    receive() external payable {}
}
