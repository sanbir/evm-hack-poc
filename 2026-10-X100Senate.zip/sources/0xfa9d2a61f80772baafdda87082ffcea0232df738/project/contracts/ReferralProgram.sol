// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

import {IFreezeHook} from "./interfaces/IFreezeHook.sol";
import {ITokenSource} from "./interfaces/ITokenSource.sol";

contract ReferralProgram is IFreezeHook, Ownable {
    using SafeERC20 for IERC20;

    uint256 public constant HUNDRED_PERCENT = 10_000;

    IERC20 private _token;
    address private _freezer;

    uint256 public referralRate;
    uint256 public referralWindow;
    uint256 public totalPaid;

    event ReferralPaid(address indexed referrer, address indexed owner, uint256 amount);
    event ReferralRateChanged(uint256 oldRate, uint256 newRate);
    event ReferralWindowChanged(uint256 oldWindow, uint256 newWindow);

    error ZeroAddress();
    error NotFreezer(address caller);
    error FreezerAlreadySet(address freezer);
    error AddressWithoutCode(address address_);
    error ReferralRateTooHigh(uint256 rate, uint256 max);

    constructor(uint256 rate, uint256 window) Ownable(_msgSender()) {
        _setReferralRate(rate);
        _setReferralWindow(window);
    }

    function onFreeze(address owner, address referrer, uint256 amount, uint256 firstFreezeAt) external {
        require(_msgSender() == _freezer, NotFreezer(_msgSender()));

        if (referralRate == 0) {
            return;
        }
        if (referrer == address(0) || referrer == owner || referrer == _freezer || referrer == address(this)) {
            return;
        }

        if (firstFreezeAt < block.timestamp && block.timestamp - firstFreezeAt > referralWindow) {
            return;
        }

        uint256 bonus = (amount * referralRate) / HUNDRED_PERCENT;
        uint256 balance = _token.balanceOf(address(this));
        if (bonus > balance) {
            bonus = balance;
        }
        if (bonus == 0) {
            return;
        }

        totalPaid += bonus;
        _token.safeTransfer(referrer, bonus);

        emit ReferralPaid(referrer, owner, bonus);
    }

    function setFreezer(address freezer_) external onlyOwner {
        require(_freezer == address(0), FreezerAlreadySet(_freezer));
        require(freezer_.code.length != 0, AddressWithoutCode(freezer_));

        IERC20 token_ = ITokenSource(freezer_).token();
        require(address(token_) != address(0), ZeroAddress());

        _freezer = freezer_;
        _token = token_;
        _transferOwnership(address(0));
    }

    function freezer() external view returns (address) {
        return _freezer;
    }

    function token() external view returns (IERC20) {
        return _token;
    }

    function available() external view returns (uint256) {
        return address(_token) == address(0) ? 0 : _token.balanceOf(address(this));
    }

    function bonusFor(uint256 amount) external view returns (uint256) {
        return (amount * referralRate) / HUNDRED_PERCENT;
    }

    function _setReferralRate(uint256 rate) private {
        require(rate <= HUNDRED_PERCENT, ReferralRateTooHigh(rate, HUNDRED_PERCENT));

        uint256 previous = referralRate;
        referralRate = rate;

        emit ReferralRateChanged(previous, rate);
    }

    function _setReferralWindow(uint256 window) private {
        uint256 previous = referralWindow;
        referralWindow = window;

        emit ReferralWindowChanged(previous, window);
    }
}
