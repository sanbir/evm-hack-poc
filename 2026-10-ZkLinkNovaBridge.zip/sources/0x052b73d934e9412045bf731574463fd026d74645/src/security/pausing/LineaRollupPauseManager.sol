// SPDX-License-Identifier: AGPL-3.0
pragma solidity ^0.8.33;

import { PauseManager } from "./PauseManager.sol";

/**
 * @title Contract to manage cross-chain function pausing roles for the LineaRollup.
 * @author ConsenSys Software Inc.
 * @custom:security-contact security-report@linea.build
 */
abstract contract LineaRollupPauseManager is PauseManager {
  /// @notice This is used to pause L1 to L2 communication.
  bytes32 public constant PAUSE_L1_L2_ROLE = keccak256("PAUSE_L1_L2_ROLE");

  /// @notice This is used to unpause L1 to L2 communication.
  bytes32 public constant UNPAUSE_L1_L2_ROLE = keccak256("UNPAUSE_L1_L2_ROLE");

  /// @notice This is used to pause L2 to L1 communication.
  bytes32 public constant PAUSE_L2_L1_ROLE = keccak256("PAUSE_L2_L1_ROLE");

  /// @notice This is used to unpause L2 to L1 communication.
  bytes32 public constant UNPAUSE_L2_L1_ROLE = keccak256("UNPAUSE_L2_L1_ROLE");

  /// @notice This is used to pause data submission.
  bytes32 public constant PAUSE_STATE_DATA_SUBMISSION_ROLE = keccak256("PAUSE_STATE_DATA_SUBMISSION_ROLE");

  /// @notice This is used to unpause data submission.
  bytes32 public constant UNPAUSE_STATE_DATA_SUBMISSION_ROLE = keccak256("UNPAUSE_STATE_DATA_SUBMISSION_ROLE");

  /// @notice This is used to pause finalization submission.
  bytes32 public constant PAUSE_FINALIZATION_ROLE = keccak256("PAUSE_FINALIZATION_ROLE");

  /// @notice This is used to unpause finalization submission.
  bytes32 public constant UNPAUSE_FINALIZATION_ROLE = keccak256("UNPAUSE_FINALIZATION_ROLE");

  /// @notice This is used to pause native-yield driven funding of external strategies.
  bytes32 public constant PAUSE_NATIVE_YIELD_STAKING_ROLE = keccak256("PAUSE_NATIVE_YIELD_STAKING_ROLE");

  /// @notice This is used to unpause native-yield driven funding of external strategies.
  bytes32 public constant UNPAUSE_NATIVE_YIELD_STAKING_ROLE = keccak256("UNPAUSE_NATIVE_YIELD_STAKING_ROLE");
}
