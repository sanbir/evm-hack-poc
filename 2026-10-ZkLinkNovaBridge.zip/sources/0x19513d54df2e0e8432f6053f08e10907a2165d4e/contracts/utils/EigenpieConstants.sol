// SPDX-License-Identifier: GPL-3.0-or-later
pragma solidity 0.8.21;

library EigenpieConstants {
    //contracts
    bytes32 public constant EIGENPIE_STAKING = keccak256("EIGENPIE_STAKING");
    bytes32 public constant EIGEN_STRATEGY_MANAGER = keccak256("EIGEN_STRATEGY_MANAGER");
    bytes32 public constant PRICE_PROVIDER = keccak256("PRICE_PROVIDER");

    //Roles
    bytes32 public constant DEFAULT_ADMIN_ROLE = 0x00;
    bytes32 public constant MANAGER = keccak256("MANAGER");
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant BURNER_ROLE = keccak256("BURNER_ROLE");

    bytes32 public constant ORACLE_ROLE = keccak256("ORACLE_ROLE");
    bytes32 public constant ORACLE_ADMIN_ROLE = keccak256("ORACLE_ADMIN_ROLE");
    bytes32 public constant PRICE_PROVIDER_ROLE = keccak256("PRICE_PROVIDER_ROLE");

    uint256 public constant DENOMINATOR = 10_000;
}
