// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.24;

import {PausableUpgradeable} from "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import {IAggregatorBase} from "interfaces/IAggregatorBase.sol";
import {CustomErrorRevert} from "libraries/CustomErrorRevert.sol";
import {
    OWNER_ROLE,
    PRODUCT_ROLE,
    ADMIN_ROLE,
    UPGRADER_ROLE,
    ERC7702_DESIGNATOR_SIZE,
    ERC7702_MAGIC_PREFIX
} from "constants/Constants.sol";

/**
 * @title AggregatorBaseUpgradeable
 * @author Michael.W
 * @notice Base contract providing a tiered Role-Based Access Control (RBAC) framework and circuit breakers.
 * @dev
 * - Implements a three-tier governance model: Owner (Governance), Admin (Operations), and Product (Business).
 * - Optimized for bytecode efficiency by wrapping modifier logic into internal functions to prevent bloating.
 * - UUPS/Transparent proxy compatible with an integrated storage gap for future-proof extensibility.
 */
contract AggregatorBaseUpgradeable is PausableUpgradeable, IAggregatorBase, UUPSUpgradeable {
    using CustomErrorRevert for bytes4;

    /**
     * @dev Internal mapping for entities authorized to submit price updates.
     * @custom:security Restricted to accounts granted with the PriceReporter status via {setPriceReporter}.
     */
    mapping(address => bool) internal _isPriceReporter;

    /**
     * @dev Internal mapping for authorized business-layer consumers.
     * @custom:security Managed by the PRODUCT_ROLE to enable granular access for specific business modules.
     */
    mapping(address => bool) internal _isAuthorizedCaller;

    /**
     * @dev Core RBAC storage structure: roleHash => account => status.
     * @custom:storage Utilizes a nested mapping to ensure O(1) verification complexity.
     */
    mapping(bytes32 => mapping(address => bool)) private _roles;

    /**
     * @dev [Security] Locks the implementation contract to prevent unauthorized initialization.
     * * In UUPS proxies, the upgrade logic resides in the implementation. If an attacker
     * initializes the implementation contract directly, they could potentially
     * trigger a delegatecall to a malicious contract containing a `selfdestruct`
     * opcode, bricking all proxies pointing to this implementation.
     * * By calling `_disableInitializers()` in the constructor, we ensure the
     * implementation contract itself can never be initialized, while leaving
     * the proxy's initialization logic (via delegatecall) unaffected.
     */
    /// @custom:oz-upgrades-unsafe-allow constructor
    constructor() {
        _disableInitializers();
    }

    /**
     * @notice Initializes the base governance and operational roles.
     * @dev Sets up core aggregator roles in an atomic transaction. Supports zero-length arrays for maximum initialization flexibility.
     * @param owner The address designated as the contract owner.
     * @param upgrader The address authorized to perform contract upgrades.
     * @param admins The array of initial addresses for administrative role assignment.
     * @param products The array of initial addresses for product role assignment.
     * @param priceReporters The array of initial addresses for price reporter authorization.
     * @param authorizedCallers The array of initial addresses for external caller authorization.
     */
    /// forge-lint: disable-next-line(mixed-case-function) // Follows OpenZeppelin's upgradeable naming convention to prevent function clashing.
    function __AggregatorBaseUpgradeable_init(
        address owner,
        address upgrader,
        address[] calldata admins,
        address[] calldata products,
        address[] calldata priceReporters,
        address[] calldata authorizedCallers
    ) internal onlyInitializing {
        __Pausable_init();

        if (owner == address(0) || upgrader == address(0)) {
            InvalidAddress.selector.revertWith();
        }

        for (uint256 i = 0; i < admins.length; ) {
            _setAdminStatus(admins[i], true);
            unchecked {
                ++i;
            }
        }

        for (uint256 i = 0; i < products.length; ) {
            _setProductStatus(products[i], true);
            unchecked {
                ++i;
            }
        }

        for (uint256 i = 0; i < priceReporters.length; ) {
            _setPriceReporterStatus(priceReporters[i], true);
            unchecked {
                ++i;
            }
        }

        for (uint256 i = 0; i < authorizedCallers.length; ) {
            _setAuthorizedCallerStatus(authorizedCallers[i], true);
            unchecked {
                ++i;
            }
        }

        _roles[OWNER_ROLE][owner] = true;
        emit OwnerChanged(address(0), owner);

        _roles[UPGRADER_ROLE][upgrader] = true;
        emit UpgraderChanged(address(0), upgrader);
    }

    // --- Access Control Modifiers ---

    /// @notice Restricts the decorated function to the Global Owner.
    modifier onlyOwner() {
        _onlyOwner();
        _;
    }

    /// @notice Restricts the decorated function to the Infrastructure Admin.
    modifier onlyAdmin() {
        _onlyAdmin();
        _;
    }

    /// @notice Restricts the decorated function to the Product Manager.
    modifier onlyProduct() {
        _onlyProduct();
        _;
    }

    /// @notice Restricts the decorated function to the Contract Upgrader.
    modifier onlyUpgrader() {
        _onlyUpgrader();
        _;
    }

    /// @notice Restricts the decorated function to whitelisted contracts or direct EOA calls.
    modifier onlyAuthorizedCallerAndNotPaused() {
        _onlyAuthorizedCallerAndNotPaused();
        _;
    }

    // --- Administrative & Governance Operations ---

    /**
     * @inheritdoc IAggregatorBase
     * @dev Implements an atomic 'grant-then-revoke' transition to maintain a single-owner invariant.
     */
    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) InvalidAddress.selector.revertWith();
        if (newOwner == msg.sender) TransferToSelfNotAllowed.selector.revertWith();
        _roles[OWNER_ROLE][newOwner] = true;
        _roles[OWNER_ROLE][msg.sender] = false;
        emit OwnerChanged(msg.sender, newOwner);
    }

    /**
     * @inheritdoc IAggregatorBase
     * @dev Explicitly requires the `oldUpgrader` address to prevent accidental privilege lock-in.
     */
    function transferUpgrader(address oldUpgrader, address newUpgrader) external onlyOwner {
        if (oldUpgrader == newUpgrader) TransferToSelfNotAllowed.selector.revertWith();
        if (newUpgrader == address(0)) InvalidAddress.selector.revertWith();
        if (!_roles[UPGRADER_ROLE][oldUpgrader]) NotCurrentUpgrader.selector.revertWith();
        _roles[UPGRADER_ROLE][newUpgrader] = true;
        _roles[UPGRADER_ROLE][oldUpgrader] = false;
        emit UpgraderChanged(oldUpgrader, newUpgrader);
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function setAdmins(address[] calldata admins, bool[] calldata statuses) external onlyOwner {
        if (admins.length == 0) ArrayEmpty.selector.revertWith();
        if (admins.length != statuses.length) MismatchedArrayLengths.selector.revertWith();

        for (uint256 i = 0; i < admins.length; ) {
            _setAdminStatus(admins[i], statuses[i]);

            unchecked {
                ++i;
            }
        }
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function setProducts(address[] calldata products, bool[] calldata statuses) external onlyOwner {
        if (products.length == 0) ArrayEmpty.selector.revertWith();
        if (products.length != statuses.length) MismatchedArrayLengths.selector.revertWith();

        for (uint256 i = 0; i < products.length; ) {
            _setProductStatus(products[i], statuses[i]);

            unchecked {
                ++i;
            }
        }
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function setPriceReporters(address[] calldata reporters, bool[] calldata statuses) external onlyOwner {
        if (reporters.length == 0) ArrayEmpty.selector.revertWith();
        if (reporters.length != statuses.length) MismatchedArrayLengths.selector.revertWith();

        for (uint256 i = 0; i < reporters.length; ) {
            _setPriceReporterStatus(reporters[i], statuses[i]);

            unchecked {
                ++i;
            }
        }
    }

    /**
     * @inheritdoc IAggregatorBase
     * @dev Facilitates business-logic-level whitelisting, managed by the Product role.
     */
    function setAuthorizedCallers(address[] calldata callers, bool[] calldata statuses) external onlyProduct {
        if (callers.length == 0) ArrayEmpty.selector.revertWith();
        if (callers.length != statuses.length) MismatchedArrayLengths.selector.revertWith();

        for (uint256 i = 0; i < callers.length; ) {
            _setAuthorizedCallerStatus(callers[i], statuses[i]);

            unchecked {
                ++i;
            }
        }
    }

    /**
     * @notice Triggers emergency circuit breaker to halt core operations.
     * @dev Restricted to the ADMIN role for rapid response.
     */
    function pause() external onlyAdmin {
        _pause();
    }

    /**
     * @notice Resumes core operations from the halted state.
     * @dev Restricted to the ADMIN role.
     */
    function unpause() external onlyAdmin {
        _unpause();
    }

    // --- View Functions ---

    /**
     * @inheritdoc IAggregatorBase
     */
    function isOwner(address account) external view returns (bool) {
        return _roles[OWNER_ROLE][account];
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function isAdmin(address account) external view returns (bool) {
        return _roles[ADMIN_ROLE][account];
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function isUpgrader(address account) external view returns (bool) {
        return _roles[UPGRADER_ROLE][account];
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function isProduct(address account) external view returns (bool) {
        return _roles[PRODUCT_ROLE][account];
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function isPriceReporter(address account) external view returns (bool) {
        return _isPriceReporter[account];
    }

    /**
     * @inheritdoc IAggregatorBase
     */
    function isAuthorizedCaller(address account) external view returns (bool) {
        return _isAuthorizedCaller[account];
    }

    // --- Internal Logic & Gas Optimization Wrappers ---

    function _setAdminStatus(address admin, bool status) private {
        if (admin == address(0)) InvalidAddress.selector.revertWith();
        _setRoleStatus(ADMIN_ROLE, admin, status);

        emit AdminChanged(admin, status);
    }

    function _setProductStatus(address product, bool status) private {
        if (product == address(0)) InvalidAddress.selector.revertWith();
        _setRoleStatus(PRODUCT_ROLE, product, status);

        emit ProductChanged(product, status);
    }

    function _setPriceReporterStatus(address reporter, bool status) private {
        if (reporter == address(0)) InvalidAddress.selector.revertWith();
        if (_isPriceReporter[reporter] == status) RoleStatusAlreadySet.selector.revertWith();
        _isPriceReporter[reporter] = status;

        emit PriceReporterStatusChanged(reporter, status);
    }

    function _setAuthorizedCallerStatus(address caller, bool status) private {
        if (caller == address(0)) InvalidAddress.selector.revertWith();
        if (_isAuthorizedCaller[caller] == status) RoleStatusAlreadySet.selector.revertWith();
        _isAuthorizedCaller[caller] = status;

        emit AuthorizedCallerStatusChanged(caller, status);
    }

    /**
     * @dev Internal helper for atomic role state updates.
     * @param role The bytes32 identifier of the target role.
     * @param account The address to update.
     * @param status The new boolean status.
     */
    function _setRoleStatus(bytes32 role, address account, bool status) private {
        if (account == address(0)) InvalidAddress.selector.revertWith();
        if (_roles[role][account] == status) RoleStatusAlreadySet.selector.revertWith();
        _roles[role][account] = status;
    }

    /**
     * @dev Encapsulated modifier logic to minimize bytecode duplication across implementation functions.
     * @custom:gas Adds a minor ~21 gas jump overhead but significantly reduces deployment costs.
     */
    function _onlyOwner() internal view {
        if (!_roles[OWNER_ROLE][msg.sender]) OnlyOwnerAllowed.selector.revertWith();
    }

    function _onlyAdmin() internal view {
        if (!_roles[ADMIN_ROLE][msg.sender]) OnlyAdminAllowed.selector.revertWith();
    }

    function _onlyProduct() internal view {
        if (!_roles[PRODUCT_ROLE][msg.sender]) OnlyProductAllowed.selector.revertWith();
    }

    function _onlyUpgrader() internal view {
        if (!_roles[UPGRADER_ROLE][msg.sender]) OnlyUpgraderAllowed.selector.revertWith();
    }

    /**
     * @dev Internal validation logic with the following characteristics:
     * - Access is granted if the caller is explicitly whitelisted in `_isAuthorizedCaller`.
     * - Direct interactions from End-User Accounts (EOAs) are permitted via `tx.origin` check.
     * - Prevents delegated EOAs from bypassing contract-level restrictions via tx.origin identity spoofing.
     * - This hybrid model ensures compatibility with both automated vaults and manual users.
     * - Checking the caller status first to minimize gas consumption for authorized contract calls.
     */
    function _onlyAuthorizedCallerAndNotPaused() internal view {
        if (paused()) EnforcedPause.selector.revertWith();
        // Grant access for whitelisted callers or verified non-delegated EOAs
        if (_isAuthorizedCaller[msg.sender] || (msg.sender == tx.origin && !isERC7702(msg.sender))) {
            return;
        }
        OnlyAuthorizedCallerAllowed.selector.revertWith();
    }

    /**
     * @notice Identifies if an address is an ERC-7702 delegated EOA
     * @dev Uses raw opcodes to bypass Solidity's memory management overhead.
     * @param account The target address to inspect
     * @return isDelegated Boolean flag indicating delegation status
     */
    function isERC7702(address account) internal view returns (bool isDelegated) {
        assembly ("memory-safe") {
            if eq(extcodesize(account), ERC7702_DESIGNATOR_SIZE) {
                extcodecopy(account, 0x00, 0, 3)

                if eq(shr(232, mload(0x00)), ERC7702_MAGIC_PREFIX) {
                    isDelegated := 1
                }
            }
        }
    }

    // --- UUPS Upgrade Authorization ---

    /**
     * @dev Restricted to the UPGRADER_ROLE.
     * Required by OpenZeppelin's UUPSUpgradeable module.
     */
    function _authorizeUpgrade(address newImplementation) internal override onlyUpgrader {}

    /**
     * @dev Reserved storage slots to allow for base contract expansion without compromising storage layout.
     * @custom:warning Size is strictly calculated to align storage slots in the inheritance chain.
     */
    /// forge-lint: disable-next-line(mixed-case-variable) // Follows OpenZeppelin's storage gap pattern to prevent storage collisions
    uint256[47] private __gap;
}
