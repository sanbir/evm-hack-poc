// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.24;

// Pre-computed using keccak256 and stored as constant to avoid consuming storage slots,
// ensuring the values are inlined directly into the bytecode.
bytes32 constant OWNER_ROLE = keccak256("OWNER_ROLE");
bytes32 constant PRODUCT_ROLE = keccak256("PRODUCT_ROLE");
bytes32 constant ADMIN_ROLE = keccak256("ADMIN_ROLE");
bytes32 constant UPGRADER_ROLE = keccak256("UPGRADER_ROLE");

// error OnlyPriceReporterAllowed() selector
bytes4 constant ONLY_PRICE_REPORTER_ALLOWED_SELECTOR = 0x0215792f;
// error MismatchedPayloadLength() selector
bytes4 constant MISMATCHED_PAYLOAD_LENGTH_SELECTOR = 0xe16cb5f6;
// error ReportTimestampOutOfBounds(bytes32) selector
bytes4 constant REPORT_TIMESTAMP_OUT_OF_BOUNDS_SELECTOR = 0x3ea5ce7e;
// error EmptyFeedData() selector
bytes4 constant EMPTY_FEED_DATA_SELECTOR = 0x204e557c;

// Standard EVM function selector size
uint256 constant SELECTOR_SIZE = 4;
// 60-second window to accommodate server cluster clock drift
uint256 constant MAX_FUTURE_DRIFT_THRESHOLD = 60;
// The exact size of an ERC-7702 delegation designator
uint256 constant ERC7702_DESIGNATOR_SIZE = 23;
// Identification of the 3-byte magic prefix required for delegation
uint256 constant ERC7702_MAGIC_PREFIX = 0xef0100;
