// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.24;

import {AggregatorV2V3Interface} from "interfaces/AggregatorV2V3Interface.sol";
import {ISingularAggregator} from "interfaces/ISingularAggregator.sol";
import {
    ONLY_PRICE_REPORTER_ALLOWED_SELECTOR,
    MISMATCHED_PAYLOAD_LENGTH_SELECTOR,
    REPORT_TIMESTAMP_OUT_OF_BOUNDS_SELECTOR,
    SELECTOR_SIZE,
    MAX_FUTURE_DRIFT_THRESHOLD
} from "constants/Constants.sol";
import {FeedCodec} from "libraries/FeedCodec.sol";
import {AggregatorBaseUpgradeable} from "base/AggregatorBaseUpgradeable.sol";

/**
 * @title SingularAggregatorUpgradeable
 * @author Michael.W
 * @notice A high-performance, single-pair optimized oracle aggregator.
 * @dev Fully compatible with Chainlink AggregatorV2 && V3. Utilizes FeedCodec for
 * single-slot storage packing and manual assembly for gas-efficient data retrieval.
 */
contract SingularAggregatorUpgradeable is AggregatorBaseUpgradeable, AggregatorV2V3Interface, ISingularAggregator {
    using FeedCodec for bytes32;

    uint256 private constant EXPECTED_PAYLOAD_SIZE = 20;

    // Sig of event FeedPrice(bytes16 feedRawData)
    bytes32 private constant FEED_PRICE_EVENT_SIG = 0x2bc717c424b344a33f86f9122ab9a958f06a0a9258688309fc5f9c4313db5019;

    // slither-disable-next-line uninitialized-state // This variable is updated elsewhere. Slither uninitialized-state is a false positive.
    bytes32 private _latestPackedFeed;

    /// @notice Human-readable description of the asset pair
    string public override description;

    // --- Initializer ---

    /**
     * @notice Sets the initial configuration and roles for the SingularAggregator.
     * @param owner The address designated as the contract owner.
     * @param upgrader The address authorized to perform contract upgrades.
     * @param admins The array of initial addresses for administrative role assignment.
     * @param products The array of initial addresses for product role assignment.
     * @param priceReporters The array of initial addresses for price reporter authorization.
     * @param authorizedCallers The array of initial addresses for external caller authorization.
     */
    function initialize(
        address owner,
        address upgrader,
        address[] calldata admins,
        address[] calldata products,
        address[] calldata priceReporters,
        address[] calldata authorizedCallers,
        string memory description_
    ) external initializer {
        __AggregatorBaseUpgradeable_init(owner, upgrader, admins, products, priceReporters, authorizedCallers);
        description = description_;
    }

    // --- High-Performance Core ---

    /**
     * @notice Updates the aggregator with a new price and timestamp payload.
     * @dev Optimized via inline assembly to minimize gas consumption.
     */
    /// forge-lint: disable-next-line(mixed-case-function) // Function name is intentionally optimized for gas via selector grinding.
    function feedPrice_2PSOZva6() external {
        assembly {
            mstore(0x00, caller())
            mstore(0x20, _isPriceReporter.slot)
            if iszero(sload(keccak256(0x00, 0x40))) {
                mstore(0x00, ONLY_PRICE_REPORTER_ALLOWED_SELECTOR)
                revert(0x00, SELECTOR_SIZE)
            }

            if iszero(eq(calldatasize(), EXPECTED_PAYLOAD_SIZE)) {
                mstore(0x00, MISMATCHED_PAYLOAD_LENGTH_SELECTOR)
                revert(0x00, SELECTOR_SIZE)
            }

            // Cache storage slot
            let slot := _latestPackedFeed.slot
            let rawfeedData := calldataload(SELECTOR_SIZE)
            let aggTs := and(shr(208, rawfeedData), 0xFFFFFFFFFFFF)

            /// @dev Design Choice: Happy Path First.
            if iszero(
                and(
                    gt(aggTs, and(shr(80, sload(slot)), 0xFFFFFFFFFFFF)),
                    lt(aggTs, add(timestamp(), MAX_FUTURE_DRIFT_THRESHOLD))
                )
            ) {
                /**
                 * @dev Revert Path Optimization Strategy:
                 * We intentionally perform a redundant SLOAD here to fetch 'latestAggregatedTs'.
                 * While this increases gas for the revert path, it is effectively ZERO COST because:
                 * 1. Off-chain Gatekeeping: Reporters use 'eth_call' to simulate the transaction
                 * before submission. Stale reports are intercepted locally at no cost.
                 * 2. Stack Hygiene: By not caching 'latestAggregatedTs' in a local variable,
                 * we save gas on the Happy Path (99% of txs) by minimizing stack management (SWAP/POP).
                 */
                mstore(0x00, REPORT_TIMESTAMP_OUT_OF_BOUNDS_SELECTOR)
                let diagnosticData := or(shl(48, and(shr(80, sload(slot)), 0xFFFFFFFFFFFF)), timestamp())
                mstore(0x04, diagnosticData)
                revert(0x00, 0x24)
            }

            sstore(slot, or(shl(128, timestamp()), shr(128, rawfeedData)))

            /**
             * @dev Gas-Optimized Event Emission:
             * Emits the raw payload directly to minimize gas consumption.
             *
             * Note: This strictly violates standard Solidity ABI 32-byte alignment for event
             * data. Downstream consumers (Indexers/SDKs) must parse the log data as a
             * contiguous packed segment.
             *
             * Benefits:
             * 1. Eliminates zero-padding, reducing LOG1 data gas costs.
             * 2. Avoids additional memory expansion and MSTORE operations.
             */
            mstore(0x00, rawfeedData)
            log1(0x00, 0x10, FEED_PRICE_EVENT_SIG)
        }
    }

    // --- Chainlink V2 Compatibility ---

    /**
     * @notice Returns the latest aggregated price.
     * @return answer Price in 18-decimal precision, cast to int256.
     */
    function latestAnswer() external view override onlyAuthorizedCallerAndNotPaused returns (int256) {
        uint80 aggregatedPrice = _latestPackedFeed.decodeAggregatedPrice();
        assembly {
            /**
             * @dev Casting uint80 to int256 is inherently safe because the maximum value
             * of uint80 (2^80 - 1) is significantly smaller than the positive limit of
             * int256 (2^255 - 1). In the EVM stack, this ensures the 255th bit (sign bit)
             * is always 0, treating the value as a positive integer.
             * Direct assembly return is used to bypass Solidity's implicit variable
             * cleaning and return overhead for gas optimization.
             */
            mstore(0x00, aggregatedPrice)
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns the block timestamp of the last successful update.
     * @return onchainTimestamp The Unix timestamp when the price was written on-chain.
     */
    function latestTimestamp() external view override onlyAuthorizedCallerAndNotPaused returns (uint256) {
        uint48 onchainTs = _latestPackedFeed.decodeOnchainTs();
        assembly {
            /**
             * @dev Returning uint48 as uint256 is inherently safe as it fits within
             * a single 32-byte EVM word without overflow.
             * Direct assembly return is used to bypass Solidity's default return
             * processing and variable cleaning, minimizing gas consumption for
             * this high-frequency read operation.
             */
            mstore(0x00, onchainTs)
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns a synthetic latest round ID.
     * @dev Returns '1' if initialized, '0' if no data has ever been fed.
     * This ensures compliance with DeFi protocols that check for non-zero round IDs.
     */
    function latestRound() external view override onlyAuthorizedCallerAndNotPaused returns (uint256) {
        bytes32 packedFeed = _latestPackedFeed;
        assembly {
            mstore(0x00, iszero(iszero(packedFeed)))
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns the price for a specific round ID.
     * @dev As this aggregator only stores the latest state in a single slot, historical
     * data is unavailable. We only return the current price if roundId is '1',
     * matching the synthetic value from latestRound().
     * @param roundId The round ID to query.
     * @return answer The price for the given round, or 0 if roundId is not 1 or price is uninitialized.
     */
    function getAnswer(uint256 roundId) external view override onlyAuthorizedCallerAndNotPaused returns (int256) {
        if (roundId != 1) {
            assembly {
                mstore(0x00, 0)
                return(0x00, 0x20)
            }
        }

        uint80 aggregatedPrice = _latestPackedFeed.decodeAggregatedPrice();
        assembly {
            /**
             * @dev Casting uint80 to int256 is inherently safe (sign bit at 255 remains 0).
             * Direct assembly return bypasses Solidity's implicit cleaning and overhead.
             */
            mstore(0x00, aggregatedPrice)
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns the timestamp for a specific round ID.
     * @dev As this aggregator only stores the latest state in a single slot, historical
     * data is unavailable. We only return the current on-chain timestamp if roundId is '1',
     * matching the synthetic value from latestRound().
     * @param roundId The round ID to query.
     * @return timestamp The on-chain timestamp for the given round, or 0 if roundId is not 1 or price is uninitialized.
     */
    function getTimestamp(uint256 roundId) external view override onlyAuthorizedCallerAndNotPaused returns (uint256) {
        if (roundId != 1) {
            assembly {
                mstore(0x00, 0)
                return(0x00, 0x20)
            }
        }

        uint48 onchainTs = _latestPackedFeed.decodeOnchainTs();

        assembly {
            /**
             * @dev Returning uint48 as uint256 is safe.
             * Direct assembly return bypasses Solidity's implicit cleaning and overhead.
             */
            mstore(0x00, onchainTs)
            return(0x00, 0x20)
        }
    }

    // --- Chainlink V3 Compatibility ---

    /**
     * @notice Returns the number of decimals used to represent the price.
     * @dev We use a hardcoded value 18 and return it via assembly for maximum gas efficiency.
     * 1. Cost: Returning via assembly bypasses Solidity's function epilogue and memory pointer
     * management, reducing gas per call by ~20-40.
     * 2. Immutability: Decimals are constant for the lifetime of this feed, making them an
     * ideal candidate for bytecode-level optimization rather than state-level storage.
     * @return The constant precision of the price feed.
     */
    function decimals() external pure override returns (uint8) {
        assembly {
            mstore(0x00, 18)
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns the version number of the aggregator implementation.
     * @dev Hardcoded to return '1' via assembly to minimize gas overhead.
     * @return The constant version number.
     */
    function version() external pure override returns (uint256) {
        assembly {
            mstore(0x00, 1)
            return(0x00, 0x20)
        }
    }

    /**
     * @notice Returns the data for a specific pricing round.
     * @dev High-performance implementation that balances modularity with low-level
     * assembly optimizations for gas efficiency.
     * * Design choice:
     * 1. Dual-Gate Validation: Validates both `_roundId` and initialization state.
     * If `_roundId != 1` or the aggregator has not been fed any price data yet,
     * returns all zeros as per Chainlink spec.
     * 2. Manual ABI Encoding: Bypasses standard Solidity return overhead by
     * manually constructing the 160-byte return buffer in memory.
     * @param _roundId The round ID to retrieve (only '1' is supported in this stateless model).
     * @return roundId The synthetic round ID (1 if data exists, 0 otherwise).
     * @return answer The latest aggregated price from storage.
     * @return startedAt The off-chain aggregated timestamp.
     * @return updatedAt The on-chain transaction timestamp.
     * @return answeredInRound The synthetic round ID (1 if data exists, 0 otherwise).
     */
    function getRoundData(
        uint80 _roundId
    ) external view override onlyAuthorizedCallerAndNotPaused returns (uint80, int256, uint256, uint256, uint80) {
        bytes32 packedFeedCached = _latestPackedFeed;

        if (_roundId != 1 || packedFeedCached.isEmpty()) {
            assembly {
                mstore(0x00, 0)
                mstore(0x20, 0)
                mstore(0x40, 0)
                mstore(0x60, 0)
                mstore(0x80, 0)
                return(0x00, 0xa0)
            }
        }

        (uint80 aggregatedPrice, uint48 aggregatedTs, uint48 onchainTs) = packedFeedCached.decode();

        // Optimized Return: Construct the ABI-compliant return packet manually
        assembly {
            mstore(0x00, 1)
            mstore(0x20, aggregatedPrice)
            mstore(0x40, aggregatedTs)
            mstore(0x60, onchainTs)
            mstore(0x80, 1)
            return(0x00, 0xa0)
        }
    }

    /**
     * @notice Returns the latest pricing round data from the single-slot feed.
     * @dev Optimized implementation using the single-slot storage layout.
     * 1. Dual-Gate Validation: Returns all zeros if the aggregator has not been fed
     * any price data yet, ensuring compliance with Chainlink-compatible consumers.
     * 2. Assembly Return: Manually constructs the ABI return packet to minimize
     * gas overhead from stack operations.
     * @return roundId The synthetic round ID (1 if data exists, 0 otherwise).
     * @return answer The latest aggregated price from storage.
     * @return startedAt The off-chain aggregated timestamp.
     * @return updatedAt The on-chain transaction timestamp.
     * @return answeredInRound The synthetic round ID (1 if data exists, 0 otherwise).
     */
    function latestRoundData()
        external
        view
        override
        onlyAuthorizedCallerAndNotPaused
        returns (uint80, int256, uint256, uint256, uint80)
    {
        bytes32 packedFeedCached = _latestPackedFeed;

        if (packedFeedCached.isEmpty()) {
            assembly {
                mstore(0x00, 0)
                mstore(0x20, 0)
                mstore(0x40, 0)
                mstore(0x60, 0)
                mstore(0x80, 0)
                return(0x00, 0xa0)
            }
        }

        (uint80 aggregatedPrice, uint48 aggregatedTs, uint48 onchainTs) = packedFeedCached.decode();

        assembly {
            mstore(0x00, 1)
            mstore(0x20, aggregatedPrice)
            mstore(0x40, aggregatedTs)
            mstore(0x60, onchainTs)
            mstore(0x80, 1)
            return(0x00, 0xa0)
        }
    }

    /**
     * @dev Reserved storage slots to allow for base contract expansion without compromising storage layout.
     * @custom:warning Size is strictly calculated to align storage slots in the inheritance chain.
     */
    /// forge-lint: disable-next-line(mixed-case-variable) // Follows OpenZeppelin's storage gap pattern to prevent storage collisions
    uint256[48] private __gap;
}
