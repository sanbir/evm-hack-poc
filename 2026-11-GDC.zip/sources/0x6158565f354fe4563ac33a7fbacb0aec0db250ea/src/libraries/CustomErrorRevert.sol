// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.24;

/**
 * @title CustomErrorRevert
 * @author Michael.W
 * @notice Provides gas-optimized utilities for reverting with custom error selectors
 */
library CustomErrorRevert {
    function revertWith(bytes4 selector) internal pure {
        assembly ("memory-safe") {
            mstore(0, selector)
            revert(0, 0x04)
        }
    }
}
