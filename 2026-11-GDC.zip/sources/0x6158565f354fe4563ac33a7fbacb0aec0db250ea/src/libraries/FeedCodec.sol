// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.24;

/**
 * @title FeedCodec
 * @author Michael.W
 * @notice Highly optimized codec for aggregated price feed records.
 * @dev Packs metadata into a single EVM word to achieve O(1) storage access gas cost.
 */
library FeedCodec {
    /**
     * @notice Fully decodes the packed bytes32 word into individual components.
     * @param word The 32-byte raw storage slot value.
     * @return aggregatedPrice The 80-bit aggregated price (usually 18 decimals).
     * @return aggregatedTs The 48-bit off-chain aggregation timestamp.
     * @return onchainTs The 48-bit on-chain transaction mining timestamp.
     */
    function decode(
        bytes32 word
    ) internal pure returns (uint80 aggregatedPrice, uint48 aggregatedTs, uint48 onchainTs) {
        assembly ("memory-safe") {
            aggregatedPrice := and(word, 0xFFFFFFFFFFFFFFFFFFFF)
            aggregatedTs := and(shr(80, word), 0xFFFFFFFFFFFF)
            onchainTs := shr(128, word)
        }
    }

    /**
     * @notice Extracts only the price component from the packed word.
     * @dev Best used when only the price is needed. Native casting is cleaner here.
     */
    function decodeAggregatedPrice(bytes32 word) internal pure returns (uint80 aggregatedPrice) {
        return uint80(uint256(word));
    }

    /**
     * @notice Extracts the off-chain payload (Price and Aggregation Timestamp).
     * @param word The 32-byte raw storage slot value.
     * @return aggregatedPrice The 80-bit price segment.
     * @return aggregatedTs The 48-bit aggregation timestamp segment.
     */
    function decodeAggregatedData(bytes32 word) internal pure returns (uint80 aggregatedPrice, uint48 aggregatedTs) {
        assembly ("memory-safe") {
            aggregatedPrice := and(word, 0xFFFFFFFFFFFFFFFFFFFF)
            aggregatedTs := and(shr(80, word), 0xFFFFFFFFFFFF)
        }
    }

    /**
     * @notice Extracts the on-chain mining timestamp from the packed word.
     * @dev Optimized via right-shift; relies on Reserved bits [255:176] being zero-filled.
     * @param word The 32-byte raw storage slot value.
     * @return onchainTs The 48-bit on-chain transaction timestamp segment.
     */
    function decodeOnchainTs(bytes32 word) internal pure returns (uint48 onchainTs) {
        assembly ("memory-safe") {
            onchainTs := shr(128, word)
        }
    }

    /**
     * @notice Checks if the packed word is uninitialized (all bits are zero).
     * @dev Used by the aggregator to determine if a price has ever been fed.
     * @param word The 32-byte raw storage slot value.
     * @return result True if the word is empty, false otherwise.
     */
    function isEmpty(bytes32 word) internal pure returns (bool result) {
        assembly ("memory-safe") {
            result := iszero(word)
        }
    }
}
