Authoritative Forge reproduction

Registry folder: 2026-11-Pennysia_exp
Registry base commit: 2ff8218dbd693deaa2296b014c9b0ca657e1b503

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-11-Pennysia_exp -vvv
