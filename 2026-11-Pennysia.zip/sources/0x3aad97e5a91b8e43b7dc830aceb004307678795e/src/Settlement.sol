// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {SettlementTypes} from "./libraries/SettlementTypes.sol";
import {TokenLib} from "./libraries/TokenLib.sol";
import {SettlementSodax} from "./modules/SettlementSodax.sol";
import {SettlementSync} from "./modules/SettlementSync.sol";

/// @title PennysiaSettlement — Ordered soft venues (SYNC + SODAX)
/// @notice Direct contract interaction is not recommended. Use the Pennysia web app
///         (https://app.pennysia.com) which builds valid calldata, validates SODAX hub
///         asset mappings off-chain, and handles route encoding. Calling `executeSwap`
///         directly requires constructing SODAX calldata, hub asset references, and
///         route parameters that the SDK manages — incorrect encoding will revert or
///         lose funds.
contract PennysiaSettlement is SettlementSodax, SettlementSync {
    uint8 public constant ROUTE_KIND_SYNC = 0;
    uint8 public constant ROUTE_KIND_SODAX = 1;

    receive() external payable {}

    /// @param routes Ordered list of route attempts (SYNC tried first, then SODAX).
    /// @param sellToken Input token (address(0) = native ETH).
    /// @param buyToken Output token (address(0) = native ETH).
    /// @param amountIn Gross sell amount pulled from caller.
    /// @param minTotalReturn Minimum net buy (SYNC) / minimum Intent.minOutputAmount (SODAX).
    /// @param deadline Swap must land at or before this timestamp.
    /// @return netReceived Sync net buy; 0 if SODAX.
    function executeSwap(
        SettlementTypes.Route[] calldata routes,
        address sellToken,
        address buyToken,
        uint256 amountIn,
        uint256 minTotalReturn,
        uint256 deadline
    ) external payable nonReentrant returns (uint256 netReceived) {
        address caller = msg.sender;
        if (!swapEnabled) revert SwapDisabled();
        if (sellToken == buyToken) revert AliasedSellBuy();
        if (amountIn == 0) revert EmptyRoutes();
        if (block.timestamp > deadline) revert DeadlineExpired();

        // Snapshot pre-tx buyToken balance for output measurement.
        SettlementTypes.SettleContext memory ctx = SettlementTypes.SettleContext({
            caller: caller, feeTo: feeRecipient, buyBefore: TokenLib.balanceOfStrict(buyToken), nativeInput: msg.value
        });

        // pull sellToken from caller to this contract
        if (sellToken != address(0)) TokenLib.safeTransferFrom(sellToken, caller, address(this), amountIn);

        // Fast path: ETH↔WETH wrap/unwrap, skip venues (no routes needed)
        if (TokenLib.isEthForm(sellToken) && TokenLib.isEthForm(buyToken)) {
            TokenLib.convert(sellToken, buyToken, amountIn);
            if (amountIn < minTotalReturn) revert TotalSlippageExceeded(amountIn, minTotalReturn);
            TokenLib.safeTransfer(buyToken, caller, amountIn);
            // Sweep excess msg.value (beyond amountIn) to feeRecipient
            uint256 excess = address(this).balance;
            if (excess > 0) TokenLib.safeTransfer(address(0), ctx.feeTo, excess);
            emit SwapExecuted(caller, sellToken, buyToken, amountIn, amountIn, 0);
            return amountIn;
        }

        uint256 n = routes.length;
        if (n == 0) revert EmptyRoutes();

        for (uint256 i = 0; i < n; i++) {
            SettlementTypes.Route calldata currentRoute = routes[i];
            uint8 kind = currentRoute.kind;
            if (kind == ROUTE_KIND_SYNC) {
                (bool ok, bytes memory returndata) = address(this)
                    .call(
                        abi.encodeWithSelector(
                            this.executeSyncAttempt.selector,
                            currentRoute,
                            sellToken,
                            buyToken,
                            amountIn,
                            minTotalReturn,
                            ctx
                        )
                    );
                if (ok) {
                    netReceived = abi.decode(returndata, (uint256));
                    emit SwapExecuted(caller, sellToken, buyToken, amountIn, netReceived, i);
                    return netReceived;
                }
            } else if (kind == ROUTE_KIND_SODAX) {
                (bool ok,) = address(this)
                    .call(
                        abi.encodeWithSelector(
                            this.executeSodaxAttempt.selector,
                            currentRoute.spendAs,
                            currentRoute.callData,
                            sellToken,
                            buyToken,
                            amountIn,
                            minTotalReturn,
                            caller,
                            deadline,
                            currentRoute.value,
                            ctx
                        )
                    );
                if (ok) {
                    emit SwapExecuted(caller, sellToken, buyToken, amountIn, 0, i);
                    return 0;
                }
            } else {
                revert BadRouteKind(kind);
            }
        }
        revert AllSoftAttemptsFailed();
    }
}
