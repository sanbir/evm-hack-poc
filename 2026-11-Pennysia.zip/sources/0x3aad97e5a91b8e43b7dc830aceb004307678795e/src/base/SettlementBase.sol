// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {ISettlementErrors} from "../interfaces/ISettlementErrors.sol";
import {ISettlementEvents} from "../interfaces/ISettlementEvents.sol";
import {TransientReentrancyGuard} from "./TransientReentrancyGuard.sol";
import {TokenLib} from "../libraries/TokenLib.sol";

/// @title SettlementBase — Shared state and helpers for PennysiaSettlement
abstract contract SettlementBase is ISettlementErrors, ISettlementEvents, TransientReentrancyGuard {
    /// @dev Owner kill-switch for `executeSwap` (default on).
    bool public swapEnabled = true;
    address public feeRecipient;
    address public owner;

    constructor() {
        address creator = msg.sender;
        owner = creator;
        feeRecipient = creator;
        emit OwnershipTransferred(address(0), creator);
    }

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        _checkAddress(newOwner);
        address previousOwner = owner;
        owner = newOwner;
        emit OwnershipTransferred(previousOwner, newOwner);
    }

    function setFeeRecipient(address recipient) external onlyOwner {
        _checkAddress(recipient);
        feeRecipient = recipient;
        emit FeeRecipientUpdated(recipient);
    }

    /// @notice Enable/disable `executeSwap` for everyone.
    function setSwapEnabled(bool enabled) external onlyOwner {
        swapEnabled = enabled;
        emit SwapEnabledUpdated(enabled);
    }

    /// @notice Rescue stuck tokens to the feeRecipient.
    /// @dev Intentionally public (no onlyOwner): during an incident anyone can
    ///      trigger a rescue, but funds always go to feeRecipient (owner-controlled).
    ///      This ensures stuck tokens are recoverable even if the owner is unavailable.
    function rescueTokens(address token, uint256 amount) external nonReentrant {
        address feeTo = feeRecipient;
        // Do not gate on balance — let the token transfer enforce sufficiency.
        TokenLib.safeTransfer(token, feeTo, amount);
        if (amount != 0) emit Rescued(token, feeTo, amount);
    }

    function _checkAddress(address target) private view {
        if (target == address(this) || target == address(0)) revert InvalidAddress();
    }
}
