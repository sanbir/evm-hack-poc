// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

/// @notice EIP-1153 transient reentrancy guard.
/// @dev Lock lives in transient storage only (no persistent slot).
abstract contract TransientReentrancyGuard {
    error ReentrancyGuardReentrantCall();

    bool private transient _locked;

    modifier nonReentrant() {
        if (_locked) revert ReentrancyGuardReentrantCall();
        _locked = true;
        _;
        _locked = false;
    }
}
