// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

/// @notice Pure surplus-fee math: fee applies only to positive quote improvement,
///         then hard-capped at `MAX_FEE_PPM` of gross swap output (excess stays with the user).
library FeeLib {
    uint32 public constant FEE_DENOMINATOR = 100_000;
    uint32 public constant MAX_FEE_PPM = 10_000; //10% of gross (`FEE_DENOMINATOR`).

    /// @dev Compute surplus fee from positive quote improvement.
    ///      Fee is capped at `MAX_FEE_PPM` of gross swap output.
    function getSurplusFee(uint256 grossAmount, uint256 quotedAmount) internal pure returns (uint256) {
        // No quote ⇒ do not treat the entire output as feeable surplus.
        if (quotedAmount == 0 || grossAmount <= quotedAmount) return 0;
        uint256 uncapped = grossAmount - quotedAmount;
        uint256 maxFee = (grossAmount * MAX_FEE_PPM) / FEE_DENOMINATOR; // revert on overflow
        return uncapped > maxFee ? maxFee : uncapped;
    }
}
