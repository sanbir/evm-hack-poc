// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

/// @notice Precomputed function selectors for external calls.
/// @dev Verified via `cast sig` and on-chain tests (see Selectors.t.sol).
library Selectors {
    // ERC-20
    bytes4 internal constant BALANCE_OF = 0x70a08231; // balanceOf(address)
    bytes4 internal constant ALLOWANCE = 0xdd62ed3e; // allowance(address,address)
    bytes4 internal constant TRANSFER = 0xa9059cbb; // transfer(address,uint256)
    bytes4 internal constant TRANSFER_FROM = 0x23b872dd; // transferFrom(address,address,uint256)
    bytes4 internal constant APPROVE = 0x095ea7b3; // approve(address,uint256)

    // Permit2 AllowanceTransfer
    bytes4 internal constant PERMIT2_ALLOWANCE = 0x927da105; // allowance(address,address,address)
    bytes4 internal constant PERMIT2_APPROVE = 0x87517c45; // approve(address,address,uint160,uint48)

    // WETH
    bytes4 internal constant WETH_WITHDRAW = 0x2e1a7d4d; // withdraw(uint256)
    bytes4 internal constant WETH_DEPOSIT = 0xd0e30db0; // deposit()

    // SODAX
    bytes4 internal constant SODAX_CREATE_INTENT = 0x016f02e3; // createIntent(Intent)
    bytes4 internal constant SODAX_CANCEL_INTENT = 0xca25d319; // cancelIntent(Intent)
    bytes4 internal constant SODAX_TRANSFER = 0xc6b4180b; // transfer(address,bytes,uint256,bytes)
    bytes4 internal constant SODAX_SEND_MESSAGE = 0x6ea9cec9; // sendMessage(uint256,bytes,bytes)
    bytes4 internal constant SODAX_CONNECTION = 0xfd19016c; // connection()
}
