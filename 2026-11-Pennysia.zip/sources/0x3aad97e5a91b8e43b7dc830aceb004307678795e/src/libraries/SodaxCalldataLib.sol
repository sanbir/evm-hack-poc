// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {Selectors} from "./Selectors.sol";

/// @title SodaxCalldataLib — SODAX decode / validate helpers
/// @dev Production Settlement only forwards pre-built calldata after checks.
///      Encoding lives off-chain (app/SDK) and in `test/helpers/SodaxEncoders.sol`.
library SodaxCalldataLib {
    error SodaxConnection();

    address internal constant SODAX_INTENTS = 0x6382D6ccD780758C5e8A6123c33ee8F4472F96ef;
    address internal constant SODAX_HUB_ASSET_MANAGER = 0x60c5681bD1DB4e50735c4cA3386005A4BA4937C0;
    address internal constant SODAX_ASSET_MANAGER = 0x39E77f86C1B1f3fbAb362A82b49D2E86C09659B4;

    uint256 internal constant SODAX_SPOKE_RELAY_CHAIN_ID = 2; // ETHEREUM
    uint256 internal constant SODAX_HUB_RELAY_CHAIN_ID = 146; // SONIC

    /// @dev `AssetManager.transfer(address,bytes,uint256,bytes)` args after the 4-byte selector.
    function decodeTransferArgs(bytes calldata data)
        internal
        pure
        returns (address token, bytes calldata to, uint256 amount, bytes calldata hubData)
    {
        bytes calldata params = data[4:];
        token = address(uint160(uint256(bytes32(params[0x00:0x20]))));
        uint256 toOffset = uint256(bytes32(params[0x20:0x40]));
        amount = uint256(bytes32(params[0x40:0x60]));
        uint256 hubOffset = uint256(bytes32(params[0x60:0x80]));
        uint256 toLen = uint256(bytes32(params[toOffset:toOffset + 32]));
        uint256 toStart = toOffset + 32;
        to = params[toStart:toStart + toLen];
        uint256 hubLen = uint256(bytes32(params[hubOffset:hubOffset + 32]));
        uint256 hubStart = hubOffset + 32;
        hubData = params[hubStart:hubStart + hubLen];
    }

    function isPackedAddressCd(bytes calldata encoded, address expected) internal pure returns (bool) {
        return encoded.length == 20 && address(bytes20(encoded)) == expected;
    }

    function isPackedAddress(bytes memory encoded, address expected) internal pure returns (bool) {
        return encoded.length == 20 && address(bytes20(encoded)) == expected;
    }

    function matchSelectorCd(bytes calldata data, bytes4 sel) internal pure returns (bool) {
        return data.length >= 4 && bytes4(data[0:4]) == sel;
    }

    function matchesSelector(bytes memory data, bytes4 sel) internal pure returns (bool) {
        return data.length >= 4 && selector4(data) == sel;
    }

    function selector4(bytes memory data) private pure returns (bytes4 sel) {
        assembly {
            sel := mload(add(data, 0x20))
        }
    }

    function slice(bytes memory data, uint256 start) internal pure returns (bytes memory out) {
        uint256 len = data.length - start;
        out = new bytes(len);
        assembly {
            let src := add(add(data, 0x20), start)
            let dst := add(out, 0x20)
            for {
                let i := 0
            } lt(i, len) {
                i := add(i, 0x20)
            } {
                mstore(add(dst, i), mload(add(src, i)))
            }
        }
    }

    function bubbleRevert(bytes memory returndata) internal pure {
        uint256 len = returndata.length;
        assembly {
            revert(add(returndata, 0x20), len)
        }
    }

    /// @dev Read the current Connection address from SpokeAssetManager.
    ///      SODAX can upgrade it via setConnection — we don't hardcode it.
    function connection() internal view returns (address conn) {
        (bool ok, bytes memory ret) = SODAX_ASSET_MANAGER.staticcall(abi.encodeWithSelector(Selectors.SODAX_CONNECTION));
        if (!ok || ret.length < 32) revert SodaxConnection();
        conn = abi.decode(ret, (address));
    }
}
