// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {ISettlementErrors} from "../interfaces/ISettlementErrors.sol";
import {ISettlementEvents} from "../interfaces/ISettlementEvents.sol";
import {Selectors} from "./Selectors.sol";

/// @notice ETH / ERC-20 helpers (USDT-safe approve, strict balance/allowance reads).
library TokenLib {
    /// @notice A standing Settlement→spender allowance was created (sticky max-approve under open SYNC).
    event ApprovalGranted(address indexed token, address indexed spender, bool viaPermit2);

    address public constant WETH = 0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2;
    address public constant PERMIT2 = 0x000000000022D473030F116dDEE9F6B43aC78BA3;
    uint8 public constant ROUTE_DIRECT_ALLOWANCE = 0;
    uint8 public constant ROUTE_PERMIT2 = 1;

    /// @dev Hard-fail balance read; any failure or malformed return reverts.
    function balanceOfStrict(address token) internal view returns (uint256) {
        if (token == address(0)) return address(this).balance;
        return _staticcallUint256(token, abi.encodeWithSelector(Selectors.BALANCE_OF, address(this)));
    }

    /// @dev Hard-fail allowance read; any failure or malformed return reverts.
    function allowance(address token, address owner, address spender) internal view returns (uint256) {
        if (token == address(0)) return 0;
        return _staticcallUint256(token, abi.encodeWithSelector(Selectors.ALLOWANCE, owner, spender));
    }

    function safeTransfer(address token, address to, uint256 amount) internal {
        if (amount == 0) return;
        if (token == address(0)) {
            (bool s,) = to.call{value: amount}("");
            if (!s) revert ISettlementErrors.TransferFailed();
            return;
        }
        require(
            _call(token, abi.encodeWithSelector(Selectors.TRANSFER, to, amount)), ISettlementErrors.TransferFailed()
        );
    }

    function safeTransferFrom(address token, address from, address to, uint256 amount) internal {
        if (amount == 0) return;
        if (token == address(0)) revert ISettlementErrors.InvalidToken();
        require(
            _call(token, abi.encodeWithSelector(Selectors.TRANSFER_FROM, from, to, amount)),
            ISettlementErrors.TransferFailed()
        );
    }

    /// @dev USDT-safe: retry via approve(0) then approve(amount) if first approve fails.
    function forceApprove(address token, address spender, uint256 amount) internal {
        if (token == address(0)) return;
        bytes memory data = abi.encodeWithSelector(Selectors.APPROVE, spender, amount);
        if (!_call(token, data)) {
            require(
                _call(token, abi.encodeWithSelector(Selectors.APPROVE, spender, uint256(0))),
                ISettlementErrors.ApproveFailed()
            );
            require(_call(token, data), ISettlementErrors.ApproveFailed());
        }
    }

    /// @dev Sticky max approval: if allowance < `amount`, set to max. Skip when already sufficient.
    ///      PERMIT2 mode also configures Permit2's internal allowance (max + never-expire).
    function approveRoute(address token, address spender, uint256 amount, uint8 routeApprovalMode) internal {
        if (token == address(0) || spender == address(0) || amount == 0) return;

        if (routeApprovalMode == ROUTE_DIRECT_ALLOWANCE) {
            if (allowance(token, address(this), spender) < amount) {
                forceApprove(token, spender, type(uint256).max);
                emit ApprovalGranted(token, spender, false);
            }
        } else if (routeApprovalMode == ROUTE_PERMIT2) {
            if (allowance(token, address(this), PERMIT2) < amount) {
                forceApprove(token, PERMIT2, type(uint256).max);
                emit ApprovalGranted(token, PERMIT2, false);
            }
            (bool ok, bytes memory ret) =
                PERMIT2.staticcall(abi.encodeWithSelector(Selectors.PERMIT2_ALLOWANCE, address(this), token, spender));
            if (!ok || ret.length < 96) revert ISettlementErrors.StaticCallFailed();
            (uint160 allowed, uint48 expiration,) = abi.decode(ret, (uint160, uint48, uint48));
            if (expiration <= block.timestamp || uint256(allowed) < amount) {
                if (!_call(
                        PERMIT2,
                        abi.encodeWithSelector(
                            Selectors.PERMIT2_APPROVE, token, spender, type(uint160).max, type(uint48).max
                        )
                    )) {
                    revert ISettlementErrors.ApproveFailed();
                }
                emit ApprovalGranted(token, spender, true);
            }
        } else {
            revert ISettlementErrors.BadApprovalMode();
        }
    }

    function isEthForm(address token) internal pure returns (bool) {
        return token == address(0) || token == WETH;
    }

    /// @dev Wrap/unwrap ETH <-> WETH. `from`/`to` must be ETH (address(0)) or WETH.
    function convert(address from, address to, uint256 amount) internal {
        if (from == to || amount == 0) return;
        require(isEthForm(from) && isEthForm(to), ISettlementErrors.UnsupportedWrapper(from, to));
        if (to == address(0)) {
            require(
                _call(WETH, abi.encodeWithSelector(Selectors.WETH_WITHDRAW, amount)), ISettlementErrors.WrapFailed()
            );
        } else {
            (bool ok,) = WETH.call{value: amount}(abi.encodeWithSelector(Selectors.WETH_DEPOSIT));
            if (!ok) revert ISettlementErrors.WrapFailed();
        }
    }

    /// @dev 1. Transfer `userBuyShare` of buyToken (or ETH) to user.
    ///      2. Sweep all remaining sellToken, spendAs, buyToken, and ETH to feeRecipient.
    ///      `spendAfter`/`buyAfter` are post-venue balances (avoids re-reading).
    function settleBalances(
        address sellToken,
        address spendAs,
        address buyToken,
        address user,
        address feeTo,
        uint256 userBuyShare,
        uint256 spendAfter,
        uint256 buyAfter
    ) internal {
        // Ensure spendAs and buyToken are not the same token (would double-sweep)
        if (spendAs == buyToken) revert ISettlementErrors.AliasedSellBuy();

        // 1. Transfer user's share to user
        if (userBuyShare > 0) safeTransfer(buyToken, user, userBuyShare);

        // 2. Sweep all remaining tokens to feeRecipient
        _sweep(buyToken, feeTo, buyAfter - userBuyShare);
        _sweep(sellToken, feeTo, balanceOfStrict(sellToken));
        if (spendAs != sellToken) _sweep(spendAs, feeTo, spendAfter);
        if (buyToken != address(0) && sellToken != address(0) && spendAs != address(0)) {
            _sweep(address(0), feeTo, balanceOfStrict(address(0)));
        }
    }

    function _sweep(address token, address feeTo, uint256 bal) private {
        if (bal > 0) {
            safeTransfer(token, feeTo, bal);
            emit ISettlementEvents.FeeCollected(token, feeTo, bal);
        }
    }

    //----------------------- private functions -----------------------

    function _staticcallUint256(address target, bytes memory data) private view returns (uint256) {
        (bool ok, bytes memory ret) = target.staticcall(data);
        if (!ok || ret.length < 32) revert ISettlementErrors.StaticCallFailed();
        return abi.decode(ret, (uint256));
    }

    function _call(address token, bytes memory data) private returns (bool) {
        (bool ok, bytes memory ret) = token.call(data);
        if (!ok || (ret.length > 0 && !abi.decode(ret, (bool)))) {
            return false;
        }
        return true;
    }
}
