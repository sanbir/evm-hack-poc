// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {SettlementBase} from "../base/SettlementBase.sol";
import {SettlementTypes} from "../libraries/SettlementTypes.sol";
import {TokenLib} from "../libraries/TokenLib.sol";
import {SodaxCalldataLib} from "../libraries/SodaxCalldataLib.sol";
import {Selectors} from "../libraries/Selectors.sol";

/// @title SettlementSodax — Settlement-owned SODAX open / cancel-and-recover
/// @dev Integrates SODAX bridging protocol for cross-chain swaps via the Sonic hub.
///      Settlement acts as the spoke-side caller: it deposits user funds into the SODAX
///      AssetManager on Ethereum, which relays to the user's hub wallet on Sonic. The hub
///      wallet executes a batched `[approve, createIntent]` call to open a SODAX intent.
///
///      Two flows:
///      - Open: `executeSodaxAttempt` → `AssetManager.transfer` (spoke) → hub executes
///        `[approve(inputAmount), createIntent]`.
///      - Cancel: `cancelAndRecoverSodax` → `Connection.sendMessage` (spoke) → hub executes
///        `[cancelIntent, AM.transfer→user]`, `[AM.transfer→user]`, or `[cancelIntent]`.
///
///      Limitations:
///      - Only spoke-source intents (Ethereum, chain ID 2) are supported. Hub-source
///        (Sonic → spoke) intents are rejected.
///      - `allowPartialFill` must be false — partial fills are not supported.
///      - `intent.solver` must be 0 — no solver support.
///      - `intent.data` must be empty — no partner fee support.
///      - `sodaxHubWallet` must be set via `setSodaxHubWallet` before opens work.
///
///      `Intent.outputToken` is the hub-chain (Sonic) representation of `buyToken`
///      (spoke chain). The spoke→hub mapping is validated off-chain by the SDK; Settlement
///      does not pin it on-chain — SODAX supports 160+ assets, addresses may change.
///      Integrators should use the Pennysia web app, not call directly.
abstract contract SettlementSodax is SettlementBase {
    /// @dev Owner kill-switch for SODAX opens (default on).
    bool public sodaxOpenEnabled = true;
    /// @dev SODAX hub wallet on Sonic chain.
    address public sodaxHubWallet;
    /// @dev Authorized cancel operator (set by owner). Separate from owner so cancel
    ///      operations can be delegated without granting full contract ownership.
    address public sodaxCancelOperator;
    /// @dev Keyed by `keccak256(abi.encode(Intent))` — canonical identity, not spoke calldata bytes.
    ///      Prevents duplicate opens (same intent submitted twice in one tx via a wrapper contract).
    ///      Stores the user (intent.dstAddress), inputToken, hubInputToken, and inputAmount for cancel validation.
    mapping(bytes32 => SettlementTypes.SodaxIntentRecord) public sodaxIntents;

    //----------------------- Owner functions -----------------------

    function setSodaxHubWallet(address hubWallet) external onlyOwner {
        if (hubWallet == address(0) || hubWallet == address(this)) revert InvalidAddress();
        address prev = sodaxHubWallet;
        sodaxHubWallet = hubWallet;
        emit SodaxHubWalletUpdated(prev, hubWallet);
    }

    /// @notice Set the authorized cancel operator. Cannot be zero or this contract.
    function setSodaxCancelOperator(address operator) external onlyOwner {
        if (operator == address(0) || operator == address(this)) revert InvalidAddress();
        sodaxCancelOperator = operator;
    }

    /// @notice Enable/disable SODAX opens for everyone.
    function setSodaxOpenEnabled(bool enabled) external onlyOwner {
        sodaxOpenEnabled = enabled;
        emit SodaxOpenEnabledUpdated(enabled);
    }

    //----------------------- Getter functions -----------------------

    /// @notice Backward-compatible getter for the intent user.
    function sodaxIntentUser(bytes32 intentHash) external view returns (address) {
        return sodaxIntents[intentHash].user;
    }

    //----------------------- SODAX execution -----------------------

    /// @notice Isolated SODAX open-intent attempt (self-call only).
    /// @dev Soft attempt — failure reverts only this call, `executeSwap` tries the next route.
    ///      Converts sellToken→inputToken, validates calldata, opens intent via AssetManager, settles balances.
    ///      Calldata must be `AssetManager.transfer(inputToken, hubWallet, inputAmount, hubData)`
    ///      where `hubData = [approve(inputToken→Intents, inputAmount), createIntent(intent)]`.
    ///      Intent fields validated: creator=hubWallet, srcAddress=this, dstAddress=user,
    ///      inputToken/inputAmount/deadline match params, srcChain/dstChain=2 (Ethereum),
    ///      allowPartialFill=false, solver=0, data empty, minOutputAmount≥minTotalReturn.
    /// @return 0 (SODAX output settles asynchronously cross-chain).
    function executeSodaxAttempt(
        address inputToken,
        bytes calldata calldata_,
        address sellToken,
        address buyToken,
        uint256 amountIn,
        uint256 minTotalReturn,
        address user,
        uint256 deadline,
        uint256 sodaxFee,
        SettlementTypes.SettleContext calldata ctx
    ) external returns (uint256) {
        if (msg.sender != address(this)) revert SoftAttemptOnlySelf();

        address hubWallet = sodaxHubWallet;
        if (!sodaxOpenEnabled || hubWallet == address(0)) revert SodaxOpenDisabled();
        if (!SodaxCalldataLib.matchSelectorCd(calldata_, Selectors.SODAX_TRANSFER)) {
            revert BadSodaxCalldata();
        }

        (address token, bytes calldata to, uint256 amount, bytes calldata hubData) =
            SodaxCalldataLib.decodeTransferArgs(calldata_);

        if (hubData.length == 0 || token != inputToken || amount != amountIn) {
            revert BadSodaxCalldata();
        }
        if (!SodaxCalldataLib.isPackedAddressCd(to, hubWallet)) revert BadSodaxCalldata();

        // --- Validate hubData: `[approve(hubToken→Intents, gross), createIntent]` ---
        SettlementTypes.HubCall[] memory calls = abi.decode(hubData, (SettlementTypes.HubCall[]));
        if (calls.length != 2) revert BadSodaxCalldata();

        address hubIntents = SodaxCalldataLib.SODAX_INTENTS;
        SettlementTypes.HubCall memory approveCall = calls[0];
        SettlementTypes.HubCall memory createCall = calls[1];
        if (
            approveCall.value != 0 || createCall.value != 0 || createCall.target != hubIntents
                || !SodaxCalldataLib.matchesSelector(approveCall.data, Selectors.APPROVE)
                || !SodaxCalldataLib.matchesSelector(createCall.data, Selectors.SODAX_CREATE_INTENT)
        ) revert BadSodaxCalldata();

        SettlementTypes.Intent memory intent =
            abi.decode(SodaxCalldataLib.slice(createCall.data, 4), (SettlementTypes.Intent));
        (address spender, uint256 approveAmount) =
            abi.decode(SodaxCalldataLib.slice(approveCall.data, 4), (address, uint256));

        if (intent.intentId == 0 || intent.minOutputAmount < minTotalReturn) revert BadSodaxCalldata();
        if (intent.allowPartialFill) revert PartialFillDisabled();
        if (intent.solver != address(0)) revert SolverNotAllowed();
        if (intent.data.length != 0) revert BadSodaxCalldata();

        if (
            approveCall.target != intent.inputToken || spender != hubIntents || approveAmount != amountIn
                || intent.creator != hubWallet || intent.inputAmount != amountIn || intent.deadline != deadline
                || intent.srcChain != SodaxCalldataLib.SODAX_SPOKE_RELAY_CHAIN_ID
                || intent.dstChain != SodaxCalldataLib.SODAX_SPOKE_RELAY_CHAIN_ID
                || !SodaxCalldataLib.isPackedAddress(intent.srcAddress, address(this))
                || !SodaxCalldataLib.isPackedAddress(intent.dstAddress, user)
        ) revert BadSodaxCalldata();

        bytes32 intentHash = keccak256(abi.encode(intent));
        if (sodaxIntents[intentHash].user != address(0)) revert SodaxIntentAlreadyExists();

        // --- Verify msg.value, convert, prepare funds, dispatch to AssetManager ---
        uint256 callValue = inputToken == address(0) ? amountIn + sodaxFee : sodaxFee;
        uint256 requiredFromMsg = sellToken == address(0) ? amountIn + sodaxFee : sodaxFee;
        if (ctx.nativeInput < requiredFromMsg) revert InsufficientMsgValue(ctx.nativeInput, requiredFromMsg);

        TokenLib.convert(sellToken, inputToken, amountIn);
        address assetManager = SodaxCalldataLib.SODAX_ASSET_MANAGER;
        TokenLib.approveRoute(inputToken, assetManager, amountIn, TokenLib.ROUTE_DIRECT_ALLOWANCE);

        uint256 ethBefore = address(this).balance;
        uint256 tokenBefore = inputToken == address(0) ? 0 : TokenLib.balanceOfStrict(inputToken);
        (bool ok, bytes memory err) = assetManager.call{value: callValue}(calldata_);
        if (!ok) {
            if (err.length > 0) SodaxCalldataLib.bubbleRevert(err);
            revert SodaxOpenFailed();
        }

        // Verify actual spent — AssetManager is a proxy, calldata amount may not match actual pull.
        uint256 spendAfter;
        if (inputToken == address(0)) {
            spendAfter = address(this).balance;
            if (ethBefore - spendAfter != callValue) revert SodaxOpenFailed();
        } else {
            spendAfter = TokenLib.balanceOfStrict(inputToken);
            if (tokenBefore - spendAfter != amountIn) revert SodaxOpenFailed();
        }

        sodaxIntents[intentHash] = SettlementTypes.SodaxIntentRecord({
            user: user, inputToken: inputToken, hubInputToken: intent.inputToken, inputAmount: amountIn
        });
        emit SodaxIntentExecuted(user, intentHash, inputToken, amountIn, deadline);

        // Settle: SODAX doesn't receive buyToken; buyAfter == buyBefore.
        TokenLib.settleBalances(sellToken, inputToken, buyToken, ctx.caller, ctx.feeTo, 0, spendAfter, ctx.buyBefore);
        return 0;
    }

    //------------------------------------ cancel ------------------------

    /// @notice Cancel + bridge remaining input to the original user.
    /// @dev Operator-only (`sodaxCancelOperator`, set by owner) — admin verifies hub-side
    ///      state off-chain before submitting. This prevents drain attacks on the shared hub
    ///      wallet (1-call transfer path has no hub-side replay protection, so user-initiated
    ///      cancels could be called multiple times to burn other users' tokens).
    ///
    ///      Sends `Connection.sendMessage(146, hubWallet, payload)` where payload is one of:
    ///      - `[cancelIntent, AM.transfer→user]` — cancel + withdraw (normal case).
    ///      - `[AM.transfer→user]` — withdraw only (already cancelled by a third party).
    ///      - `[cancelIntent]` — cancel only (no funds move, retry withdraw separately).
    ///
    ///      SODAX allows anyone to cancel an intent after its deadline has passed. If a third
    ///      party cancels first, the 2-call batch would revert (cancelIntent fails on
    ///      already-cancelled intent). The 1-call `[AM.transfer]` path recovers funds anyway.
    ///      The 1-call `[cancelIntent]` path is a fallback if the 2-call batch is rejected.
    ///
    ///      Recover amount must be `≤ inputAmount` (1 to inputAmount). Partial-fill opens are
    ///      rejected, so the full `inputAmount` is the normal case.
    function cancelAndRecoverSodax(bytes32 intentHash, bytes calldata sendMessageCalldata)
        external
        payable
        nonReentrant
    {
        address caller = msg.sender;
        if (caller != sodaxCancelOperator) revert NotAuthorizer();
        (uint256 recoverAmount, address inputToken) = _validateCancelAndRecover(sendMessageCalldata, intentHash);
        (bool ok, bytes memory err) = SodaxCalldataLib.connection().call{value: msg.value}(sendMessageCalldata);
        if (!ok) {
            if (err.length > 0) SodaxCalldataLib.bubbleRevert(err);
            revert SodaxCancelFailed();
        }

        emit SodaxCancelAndRecovered(caller, intentHash, inputToken, recoverAmount);
        // Don't delete sodaxIntents[intentHash] — Connection.sendMessage is fire-and-forget; the hub-side cancel may
        // fail asynchronously (pending fill, rate limit). Leaving the record lets the operator retry.
    }

    /// @return amount, inputToken (from record).
    function _validateCancelAndRecover(bytes calldata raw, bytes32 intentHash) private view returns (uint256, address) {
        SettlementTypes.SodaxIntentRecord memory record = sodaxIntents[intentHash];

        if (record.user == address(0)) revert BadSodaxCalldata();
        if (raw.length < 4 || bytes4(raw[0:4]) != Selectors.SODAX_SEND_MESSAGE) revert BadSodaxCalldata();

        (uint256 dstChainId, bytes memory dst, bytes memory payload) = abi.decode(raw[4:], (uint256, bytes, bytes));
        if (dstChainId != SodaxCalldataLib.SODAX_HUB_RELAY_CHAIN_ID || payload.length == 0) revert BadSodaxCalldata();

        SettlementTypes.HubCall[] memory calls = abi.decode(payload, (SettlementTypes.HubCall[]));
        if (calls.length != 1 && calls.length != 2) revert BadSodaxCalldata();

        // Identify the cancel call (if any) and the transfer call (if any).
        bool hasCancel = false;
        bool hasTransfer = false;
        SettlementTypes.HubCall memory cancelCall;
        SettlementTypes.HubCall memory transferCall;

        for (uint256 i = 0; i < calls.length; i++) {
            SettlementTypes.HubCall memory c = calls[i];
            if (c.value != 0) revert BadSodaxCalldata();
            if (SodaxCalldataLib.matchesSelector(c.data, Selectors.SODAX_CANCEL_INTENT)) {
                if (c.target != SodaxCalldataLib.SODAX_INTENTS) revert BadSodaxCalldata();
                if (hasCancel) revert BadSodaxCalldata();
                hasCancel = true;
                cancelCall = c;
            } else if (SodaxCalldataLib.matchesSelector(c.data, Selectors.SODAX_TRANSFER)) {
                if (c.target != SodaxCalldataLib.SODAX_HUB_ASSET_MANAGER) revert BadSodaxCalldata();
                if (hasTransfer) revert BadSodaxCalldata();
                hasTransfer = true;
                transferCall = c;
            } else {
                revert BadSodaxCalldata();
            }
        }

        // Must have at least one of cancel or transfer.
        if (!hasCancel && !hasTransfer) revert BadSodaxCalldata();

        // Validate the cancel call (if present) — hash must match.
        SettlementTypes.Intent memory intent;
        if (hasCancel) {
            intent = abi.decode(SodaxCalldataLib.slice(cancelCall.data, 4), (SettlementTypes.Intent));
            if (keccak256(abi.encode(intent)) != intentHash) revert BadSodaxCalldata();
        }

        // Validate the transfer call (if present) — funds go to user, capped at inputAmount.
        uint256 amount = 0;
        if (hasTransfer) {
            (address hubToken, bytes memory to, uint256 transferAmount, bytes memory data) =
                abi.decode(SodaxCalldataLib.slice(transferCall.data, 4), (address, bytes, uint256, bytes));

            if (data.length != 0 || !SodaxCalldataLib.isPackedAddress(to, record.user)) revert BadSodaxCalldata();
            if (transferAmount == 0) revert BadSodaxCalldata();

            address expectedHubToken = hasCancel ? intent.inputToken : record.hubInputToken;
            if (hubToken != expectedHubToken) revert BadSodaxCalldata();
            if (transferAmount > record.inputAmount) revert BadSodaxCalldata();

            amount = transferAmount;
        }

        // Validate dst: intent.creator (if cancel present) or sodaxHubWallet (transfer-only).
        address expectedDst = hasCancel ? intent.creator : sodaxHubWallet;
        if (!SodaxCalldataLib.isPackedAddress(dst, expectedDst)) revert BadSodaxCalldata();

        return (amount, record.inputToken);
    }
}
