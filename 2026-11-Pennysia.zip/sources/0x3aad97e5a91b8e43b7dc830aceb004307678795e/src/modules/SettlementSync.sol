// SPDX-License-Identifier: BUSL-1.1
pragma solidity 0.8.36;

import {SettlementBase} from "../base/SettlementBase.sol";
import {SettlementTypes} from "../libraries/SettlementTypes.sol";
import {TokenLib} from "../libraries/TokenLib.sol";
import {FeeLib} from "../libraries/FeeLib.sol";

/// @title SettlementSync — SYNC soft-route attempt (self-call isolated)
abstract contract SettlementSync is SettlementBase {
    /// @notice Isolated SYNC swap attempt (self-call only).
    /// @dev Soft attempt — failure reverts only this call, `executeSwap` tries the next route.
    ///      Converts sellToken→spendAs, calls venue, verifies spend/output, applies surplus fee,
    ///      settles balances. ETH↔WETH trades bypass this via the fast path in `executeSwap`.
    /// @return netBuy Net buy-token amount credited to user (after surplus fee).
    function executeSyncAttempt(
        SettlementTypes.Route calldata step,
        address sellToken,
        address buyToken,
        uint256 amountIn,
        uint256 minTotalReturn,
        SettlementTypes.SettleContext calldata ctx
    ) external returns (uint256 netBuy) {
        if (msg.sender != address(this)) revert SoftAttemptOnlySelf();

        address spendAs = step.spendAs;
        bool nativeSell = spendAs == address(0);
        bool nativeBuy = buyToken == address(0);
        address venue = step.venue;
        uint256 venueValue = step.value;
        address allowanceTarget = step.allowanceTarget;

        // Validate route
        if (venue == address(0) || venue == address(this)) revert SelfVenueForbidden();
        if (spendAs != address(0) && allowanceTarget == address(0)) revert InvalidAddress();
        if (allowanceTarget == address(this)) revert SelfVenueForbidden();

        // Verify msg.value covers venue fee (+ amountIn when selling ETH)
        uint256 requiredFromMsg = sellToken == address(0) ? amountIn + venueValue : venueValue;
        if (ctx.nativeInput < requiredFromMsg) revert InsufficientMsgValue(ctx.nativeInput, requiredFromMsg);

        // Convert sellToken → spendAs, then approve or add to call value
        TokenLib.convert(sellToken, spendAs, amountIn);
        if (nativeSell) {
            venueValue += amountIn;
        } else if (step.approvalMode == TokenLib.ROUTE_PERMIT2 && amountIn > type(uint160).max) {
            revert BadPermit2Amount();
        } else {
            TokenLib.approveRoute(spendAs, allowanceTarget, amountIn, step.approvalMode);
        }

        // Call venue
        uint256 spendBefore = TokenLib.balanceOfStrict(spendAs);
        (bool ok,) = venue.call{value: venueValue}(step.callData);
        if (!ok) revert SyncAttemptFailed();

        // Verify sell-side spend
        uint256 spendAfter = TokenLib.balanceOfStrict(spendAs);
        uint256 actualSpent = spendBefore > spendAfter ? spendBefore - spendAfter : 0;
        if (actualSpent == 0 || actualSpent > (nativeSell ? venueValue : amountIn)) revert SyncAttemptFailed();

        // Verify buy-side output (add back venueValue for ETH buy — it left as input+fee)
        uint256 buyAfter = TokenLib.balanceOfStrict(buyToken);
        uint256 adjusted = nativeBuy ? buyAfter + venueValue : buyAfter;
        if (adjusted < ctx.buyBefore) revert SyncAttemptFailed();
        netBuy = adjusted - ctx.buyBefore;
        if (netBuy == 0) revert ZeroOutput();

        // Surplus fee + slippage
        netBuy -= FeeLib.getSurplusFee(netBuy, step.quotedReturn);
        if (netBuy < minTotalReturn) revert TotalSlippageExceeded(netBuy, minTotalReturn);

        // Settle: user gets netBuy, rest swept to feeRecipient
        TokenLib.settleBalances(sellToken, spendAs, buyToken, ctx.caller, ctx.feeTo, netBuy, spendAfter, buyAfter);
    }
}

