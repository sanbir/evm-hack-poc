Authoritative Forge reproduction

Registry folder: 2026-11-Premia_exp
Registry base commit: fdb2b69b1327f5b8d7b0d9c88ce74cdea1616550

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-11-Premia_exp -vvv
