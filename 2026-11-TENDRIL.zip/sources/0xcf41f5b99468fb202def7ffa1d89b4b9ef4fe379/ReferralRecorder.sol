// SPDX-License-Identifier: MIT  0x1B43D3880b6c9897716eE3eDd4E86cb936858a7c
pragma solidity ^0.8.20;

abstract contract Ownable {
    address private _owner;
    address private _previousOwner;
    uint256 private _lockTime;
    event OwnershipTransferred(
        address indexed previousOwner,
        address indexed newOwner
    );

    constructor() {
        address msgSender = msg.sender;
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == msg.sender, "Ownable: caller is not the owner");
        _;
    }

    function renounceOwnership() public virtual onlyOwner {
        emit OwnershipTransferred(_owner, address(0));
        _owner = address(0);
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(
            newOwner != address(0),
            "Ownable: new owner is the zero address"
        );
        emit OwnershipTransferred(_owner, newOwner);
        _owner = newOwner;
    }
}

contract ReferralRecorder is Ownable {
    mapping(address => address) public referrerOf;
    mapping(address => mapping(address => bool)) public transferred;

    mapping(address => address[]) private _referralList;
    mapping(address => mapping(address => bool)) private _isInReferralList;

    mapping(address => bool) public isExcluded;

    mapping(address => uint256) public teamCount;

    mapping(address => mapping(uint256 => uint256)) public teamCountByLevel;

    address public tokenContract;

    modifier onlyToken() {
        require(msg.sender == tokenContract, "Only token contract can call");
        _;
    }

    function setTokenContract(address _tokenContract) external onlyOwner {
        require(_tokenContract != address(0), "Invalid address");
        tokenContract = _tokenContract;
    }

    function addToExcluded(address user) external onlyOwner {
        require(user != address(0), "Invalid address");
        isExcluded[user] = true;
    }

    function removeFromExcluded(address user) external onlyOwner {
        require(user != address(0), "Invalid address");
        isExcluded[user] = false;
    }

    function batchAddToExcluded(address[] calldata users) external onlyOwner {
        for (uint256 i = 0; i < users.length; i++) {
            require(users[i] != address(0), "Invalid address");
            isExcluded[users[i]] = true;
        }
    }

    function batchRemoveFromExcluded(
        address[] calldata users
    ) external onlyOwner {
        for (uint256 i = 0; i < users.length; i++) {
            require(users[i] != address(0), "Invalid address");
            isExcluded[users[i]] = false;
        }
    }

    function isExcludedUser(address user) external view returns (bool) {
        return isExcluded[user];
    }

    function recordTransfer(address from, address to) external onlyToken {
        if (isExcluded[from] || isExcluded[to] || transferred[from][to]) return;

        require(from != to, "self transfer");

        if (!transferred[to][from] && referrerOf[from] == address(0)) {
            return;
        }

        transferred[from][to] = true;

        if (transferred[to][from] && referrerOf[from] == address(0)) {
            referrerOf[from] = to;
            _addToReferralList(from, to);
            _updateTeamCount(to);
        }
    }

    function _addToReferralList(address referred, address referrer) private {
        if (!_isInReferralList[referrer][referred]) {
            _referralList[referrer].push(referred);
            _isInReferralList[referrer][referred] = true;
        }
    }

    function _updateTeamCount(address referrer) private {
        address current = referrer;
        address[] memory uplines = new address[](50);
        uint256 uplineCount = 0;

        for (uint256 i = 0; i < 50 && current != address(0); i++) {
            uplines[uplineCount] = current;
            uplineCount++;
            current = referrerOf[current];
        }

        for (uint256 i = 0; i < uplineCount; i++) {
            address upline = uplines[i];
            teamCount[upline]++;

            for (uint256 level = 1; level <= i + 1; level++) {
                teamCountByLevel[upline][level]++;
            }
        }
    }

    function setSeedReferrer(
        address user,
        address referrer
    ) external onlyOwner {
        require(referrerOf[user] == address(0), "Already has referrer");
        referrerOf[user] = referrer;
        _addToReferralList(user, referrer);
        _updateTeamCount(referrer);
    }

    function getTeamCount(address user) external view returns (uint256) {
        return teamCount[user];
    }

    function getTeamCountByLevel(
        address user,
        uint256 level
    ) external view returns (uint256) {
        require(level >= 1 && level <= 50, "Level must be between 1 and 50");
        return teamCountByLevel[user][level];
    }

    function getAllTeamLevels(
        address user
    ) external view returns (uint256[50] memory) {
        uint256[50] memory result;
        for (uint256 i = 1; i <= 50; i++) {
            result[i - 1] = teamCountByLevel[user][i];
        }
        return result;
    }

    function getReferrer(address user) external view returns (address) {
        return referrerOf[user];
    }

    function getReferralList(
        address referrer
    ) external view returns (address[] memory) {
        return _referralList[referrer];
    }

    function getReferralCount(
        address referrer
    ) external view returns (uint256) {
        return _referralList[referrer].length;
    }
}