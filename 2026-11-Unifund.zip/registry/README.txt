Authoritative Forge reproduction

Registry folder: 2026-11-Unifund_exp
Registry base commit: 8fb958ffdc018d82920c0e482c55e18f757528ec

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-11-Unifund_exp -vvv
