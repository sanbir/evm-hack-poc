Authoritative Forge reproduction

Registry folder: 2026-11-sBOLD_exp
Registry base commit: 0e49cf9886bb4a09223d67727548f4b4ccd326aa

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-11-sBOLD_exp -vvv
