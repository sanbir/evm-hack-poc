Authoritative Forge reproduction

Registry folder: 29663-unprotected-callcode-allows-anyone-to-destroy-the-hyvm-maste_exp
Registry base commit: b934861ada0f5d2335b76bde4ec4477b9c68fd3d

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 29663-unprotected-callcode-allows-anyone-to-destroy-the-hyvm-maste_exp -vvv
