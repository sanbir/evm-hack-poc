Authoritative Forge reproduction

Registry folder: 31548-h-03-workers-could-withdraw-without-deregister-and-waiting-f_exp
Registry base commit: 429303ee3dad9bf8654f174cbf90076d12c37b57

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 31548-h-03-workers-could-withdraw-without-deregister-and-waiting-f_exp -vvv
