Authoritative Forge reproduction

Registry folder: 35217-h-15-baseloanchecks-check-errors-for-expire-code4rena-gondi_exp
Registry base commit: ffc4b5ba0ec5cf6053111cb9bd0a17e5c039e69d

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 35217-h-15-baseloanchecks-check-errors-for-expire-code4rena-gondi_exp -vvv
