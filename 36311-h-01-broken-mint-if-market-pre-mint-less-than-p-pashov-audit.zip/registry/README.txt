Authoritative Forge reproduction

Registry folder: 36311-h-01-broken-mint-if-market-pre-mint-less-than-p-pashov-audit_exp
Registry base commit: a35f3640aae29f3b1f40441dfa2ab350f04c0bce

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 36311-h-01-broken-mint-if-market-pre-mint-less-than-p-pashov-audit_exp -vvv
