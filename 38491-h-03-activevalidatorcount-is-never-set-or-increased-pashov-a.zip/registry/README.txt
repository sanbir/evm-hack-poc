Authoritative Forge reproduction

Registry folder: 38491-h-03-activevalidatorcount-is-never-set-or-increased-pashov-a_exp
Registry base commit: 6081658a74b3addb4ebcaf51064400fd186dc381

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 38491-h-03-activevalidatorcount-is-never-set-or-increased-pashov-a_exp -vvv
