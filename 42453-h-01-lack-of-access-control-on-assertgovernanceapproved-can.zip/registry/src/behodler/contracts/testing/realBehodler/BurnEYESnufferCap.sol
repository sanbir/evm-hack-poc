
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.4;


enum FeeExemption{
    NO_EXEMPTIONS,
    
    SENDER_EXEMPT,
    SENDER_AND_RECEIVER_EXEMPT,
    REDEEM_EXEMPT_AND_SENDER_EXEMPT,
    
    REDEEM_EXEMPT_AND_SENDER_AND_RECEIVER_EXEMPT,

    RECEIVER_EXEMPT,
    REDEEM_EXEMPT_AND_RECEIVER_EXEMPT,
    REDEEM_EXEMPT_ONLY
}

abstract contract LiquidityReceiverLike {
    function setFeeExemptionStatusOnPyroForContract(
        address pyroToken,
        address target,
        FeeExemption exemption
    ) public virtual;

    function setPyroTokenLoanOfficer(address pyroToken, address loanOfficer)
        public
        virtual;

    function getPyroToken(address baseToken)
        public
        view
        virtual
        returns (address);

    function registerPyroToken(
        address baseToken,
        string memory name,
        string memory symbol
    ) public virtual;

    function drain(address baseToken) external virtual returns (uint);
}


/*Snuffs out fees for given address */
abstract contract SnufferCap {
    LiquidityReceiverLike public _liquidityReceiver;

    constructor(address liquidityReceiver) {
        _liquidityReceiver = LiquidityReceiverLike(liquidityReceiver);
    }

    function snuff (address pyroToken, address targetContract, FeeExemption exempt) public virtual returns (bool);

    //after perfroming business logic, call this function
    function _snuff(address pyroToken, address targetContract, FeeExemption exempt)
        internal
    {
        _liquidityReceiver.setFeeExemptionStatusOnPyroForContract(pyroToken,targetContract,exempt);
    }
}

/**
 * @dev Interface of the ERC20 standard as defined in the EIP but with a burn friendly extra param added to transfer
 */
interface IERC20 {
    /**
     * @dev Returns the name of the token.
     */
    function name() external view returns (string memory);

    /**
     * @dev Returns the symbol of the token.
     */
    function symbol() external view returns (string memory);

    /**
     * @dev Returns the decimals places of the token.
     */
    function decimals() external view returns (uint8);

    /**
     * @dev Returns the amount of tokens in existence.
     */
    function totalSupply() external view returns (uint256);

    /**
     * @dev Returns the amount of tokens owned by `account`.
     */
    function balanceOf(address account) external view returns (uint256);

    /**
     * @dev Moves `amount` tokens from the caller's account to `recipient`.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transfer(address recipient, uint256 amount)
        external
        returns (bool);

    /**
     * @dev Returns the remaining number of tokens that `spender` will be
     * allowed to spend on behalf of `owner` through {transferFrom}. This is
     * zero by default.
     *
     * This value changes when {approve} or {transferFrom} are called.
     */
    function allowance(address owner, address spender)
        external
        view
        returns (uint256);

    /**
     * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * IMPORTANT: Beware that changing an allowance with this method brings the risk
     * that someone may use both the old and the new allowance by unfortunate
     * transaction ordering. One possible solution to mitigate this race
     * condition is to first reduce the spender's allowance to 0 and set the
     * desired value afterwards:
     * https://github.com/ethereum/EIPs/issues/20#issuecomment-263524729
     *
     * Emits an {Approval} event.
     */
    function approve(address spender, uint256 amount) external returns (bool);

    /**
     * @dev Moves `amount` tokens from `sender` to `recipient` using the
     * allowance mechanism. `amount` is then deducted from the caller's
     * allowance.
     *
     * Returns a boolean value indicating whether the operation succeeded.
     *
     * Emits a {Transfer} event.
     */
    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external returns (bool);

    /**
     * @dev Emitted when `value` tokens are moved from one account (`from`) to
     * another (`to`).
     *
     * Note that `value` may be zero.
     */
    event Transfer(
        address indexed from,
        address indexed to,
        uint128 value,
        uint128 burnt
    );

    /**
     * @dev Emitted when the allowance of a `spender` for an `owner` is set by
     * a call to {approve}. `value` is the new allowance.
     */
    event Approval(
        address indexed owner,
        address indexed spender,
        uint256 value
    );
}


abstract contract Burnable is IERC20 {
    function burn (uint value) public virtual;
}

contract BurnEYESnufferCap is SnufferCap {
    Burnable eye;

    constructor(address EYE, address receiver) SnufferCap(receiver) {
        eye = Burnable(EYE);
    }

    function snuff(
        address pyroToken,
        address targetContract,
        FeeExemption exempt
    ) public override returns (bool) {
        require(eye.transferFrom(msg.sender,address(this), 1000 * (1 ether)),"ERC20: transfer failed.");
        uint balance = eye.balanceOf(address(this));
        eye.burn(balance);
        _snuff(pyroToken, targetContract, exempt);
        return true;
    }
}
