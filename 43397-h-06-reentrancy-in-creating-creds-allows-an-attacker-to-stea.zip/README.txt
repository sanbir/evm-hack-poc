EVM Hack Analyzer — crypto.training scripted POC (ZIP projection)

Slug:     43397-h-06-reentrancy-in-creating-creds-allows-an-attacker-to-stea
Chain id: 1

Layout:
  anvil_state.json       — fork state (accounts + storage + code + block).
  sources/<addr>/…       — verified Solidity sources.
  sources/exploit/…      — attacker exploit source (if present).
  poc-data/runner.json   — scripted exploit config (no accounts/source bodies).
  manifest.json          — summary metadata.

Drop this ZIP onto the EVM Hack Analyzer — it re-runs the scripted exploit
in-browser and opens the opcode-level playground.
