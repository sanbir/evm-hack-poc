Authoritative Forge reproduction

Registry folder: 45408-cancelling-bytes320-allows-timelock-takeover-spearbit-none-c_exp
Registry base commit: a35f3640aae29f3b1f40441dfa2ab350f04c0bce

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 45408-cancelling-bytes320-allows-timelock-takeover-spearbit-none-c_exp -vvv
