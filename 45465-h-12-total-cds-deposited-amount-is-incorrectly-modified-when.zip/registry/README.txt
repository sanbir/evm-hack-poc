Authoritative Forge reproduction

Registry folder: 45465-h-12-total-cds-deposited-amount-is-incorrectly-modified-when_exp
Registry base commit: 33a2591e5da73b8bd7295c7e290b4440e25bc890

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 45465-h-12-total-cds-deposited-amount-is-incorrectly-modified-when_exp -vvv
