Authoritative Forge reproduction

Registry folder: 46636-claiming-original-allocation-without-staking-rewards-can-lea_exp
Registry base commit: 0d6f44ae9dd50d034a9baa7b0d31cc182abd4ffa

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 46636-claiming-original-allocation-without-staking-rewards-can-lea_exp -vvv
