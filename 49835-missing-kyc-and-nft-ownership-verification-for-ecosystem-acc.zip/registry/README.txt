Authoritative Forge reproduction

Registry folder: 49835-missing-kyc-and-nft-ownership-verification-for-ecosystem-acc_exp
Registry base commit: 585cc3d97b48bc4368c2a74f444402d2212c8d4e

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 49835-missing-kyc-and-nft-ownership-verification-for-ecosystem-acc_exp -vvv
