Authoritative Forge reproduction

Registry folder: 52869-distributefor-might-be-reentered-leading-to-the-loss-of-bgt_exp
Registry base commit: 12420f5dca0ae6d6076c3e1de745dc84d2306cab

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 52869-distributefor-might-be-reentered-leading-to-the-loss-of-bgt_exp -vvv
