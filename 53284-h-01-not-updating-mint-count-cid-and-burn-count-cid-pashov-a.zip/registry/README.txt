Authoritative Forge reproduction

Registry folder: 53284-h-01-not-updating-mint-count-cid-and-burn-count-cid-pashov-a_exp
Registry base commit: a35f3640aae29f3b1f40441dfa2ab350f04c0bce

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 53284-h-01-not-updating-mint-count-cid-and-burn-count-cid-pashov-a_exp -vvv
