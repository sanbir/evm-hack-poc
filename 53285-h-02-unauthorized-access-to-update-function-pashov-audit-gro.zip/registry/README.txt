Authoritative Forge reproduction

Registry folder: 53285-h-02-unauthorized-access-to-update-function-pashov-audit-gro_exp
Registry base commit: 53da01753e70814c13479dcbe1d9410e9a3e131d

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 53285-h-02-unauthorized-access-to-update-function-pashov-audit-gro_exp -vvv
