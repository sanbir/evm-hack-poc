Authoritative Forge reproduction

Registry folder: 55168-incorrect-condition-for-post-only-orders-mixbytes-none-hanji_exp
Registry base commit: 801ce32117e30d2495db49cca4775931c0e71906

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 55168-incorrect-condition-for-post-only-orders-mixbytes-none-hanji_exp -vvv
