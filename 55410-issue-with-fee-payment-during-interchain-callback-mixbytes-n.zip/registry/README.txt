Authoritative Forge reproduction

Registry folder: 55410-issue-with-fee-payment-during-interchain-callback-mixbytes-n_exp
Registry base commit: 5c7f5abf8051a2b9b8e55c7c8a83ba9482859389

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 55410-issue-with-fee-payment-during-interchain-callback-mixbytes-n_exp -vvv
