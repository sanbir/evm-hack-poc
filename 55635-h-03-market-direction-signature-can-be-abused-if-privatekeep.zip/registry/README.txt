Authoritative Forge reproduction

Registry folder: 55635-h-03-market-direction-signature-can-be-abused-if-privatekeep_exp
Registry base commit: 5c7f5abf8051a2b9b8e55c7c8a83ba9482859389

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 55635-h-03-market-direction-signature-can-be-abused-if-privatekeep_exp -vvv
