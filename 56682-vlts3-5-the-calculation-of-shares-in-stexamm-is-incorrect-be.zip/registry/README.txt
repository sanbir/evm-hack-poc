Authoritative Forge reproduction

Registry folder: 56682-vlts3-5-the-calculation-of-shares-in-stexamm-is-incorrect-be_exp
Registry base commit: cbba00de0819914dc94c879201b467e5a196d309

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 56682-vlts3-5-the-calculation-of-shares-in-stexamm-is-incorrect-be_exp -vvv
