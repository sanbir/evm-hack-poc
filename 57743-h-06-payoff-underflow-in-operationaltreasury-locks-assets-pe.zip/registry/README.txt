Authoritative Forge reproduction

Registry folder: 57743-h-06-payoff-underflow-in-operationaltreasury-locks-assets-pe_exp
Registry base commit: a35f3640aae29f3b1f40441dfa2ab350f04c0bce

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 57743-h-06-payoff-underflow-in-operationaltreasury-locks-assets-pe_exp -vvv
