Authoritative Forge reproduction

Registry folder: 57867-c-02-the-deadline-parameter-in-uniswapv3-swap-causes-sniping_exp
Registry base commit: 8499d3e682c9d09124733c1fdaacfbcf72fcf8a6

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 57867-c-02-the-deadline-parameter-in-uniswapv3-swap-causes-sniping_exp -vvv
