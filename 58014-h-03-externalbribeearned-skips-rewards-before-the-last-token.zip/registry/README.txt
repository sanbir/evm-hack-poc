Authoritative Forge reproduction

Registry folder: 58014-h-03-externalbribeearned-skips-rewards-before-the-last-token_exp
Registry base commit: 554323ffc61255804dec30d430d85a9e953fcc39

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 58014-h-03-externalbribeearned-skips-rewards-before-the-last-token_exp -vvv
