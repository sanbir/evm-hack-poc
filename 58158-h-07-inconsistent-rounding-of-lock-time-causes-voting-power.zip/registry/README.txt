Authoritative Forge reproduction

Registry folder: 58158-h-07-inconsistent-rounding-of-lock-time-causes-voting-power_exp
Registry base commit: 953e664c8b64eafefaf683652b1d59dead325bd1

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 58158-h-07-inconsistent-rounding-of-lock-time-causes-voting-power_exp -vvv
