Authoritative Forge reproduction

Registry folder: 58375-lend-cross-chain-borrow-ignores-existing-debt-in-collateral-validation_exp
Registry base commit: 44be671da57a426f8cd9dc0ba3970303c620cb8d

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 58375-lend-cross-chain-borrow-ignores-existing-debt-in-collateral-validation_exp -vvv
