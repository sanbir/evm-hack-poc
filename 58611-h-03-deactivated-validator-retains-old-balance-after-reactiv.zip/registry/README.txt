Authoritative Forge reproduction

Registry folder: 58611-h-03-deactivated-validator-retains-old-balance-after-reactiv_exp
Registry base commit: b4afc434c9c5b503bb8fcc1c72c2746257586c9a

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 58611-h-03-deactivated-validator-retains-old-balance-after-reactiv_exp -vvv
