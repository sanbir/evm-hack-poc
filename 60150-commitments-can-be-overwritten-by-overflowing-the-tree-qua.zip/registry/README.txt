Authoritative Forge reproduction

Registry folder: 60150-commitments-can-be-overwritten-by-overflowing-the-tree-qua_exp
Registry base commit: e128c996241fecc8d9ac92cd55dd17c472384c9f

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 60150-commitments-can-be-overwritten-by-overflowing-the-tree-qua_exp -vvv
