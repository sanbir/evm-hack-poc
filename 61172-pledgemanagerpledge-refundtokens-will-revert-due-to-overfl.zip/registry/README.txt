Authoritative Forge reproduction

Registry folder: 61172-pledgemanagerpledge-refundtokens-will-revert-due-to-overfl_exp
Registry base commit: 0618d2d374f43764e661bce79a871a05677e038c

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 61172-pledgemanagerpledge-refundtokens-will-revert-due-to-overfl_exp -vvv
