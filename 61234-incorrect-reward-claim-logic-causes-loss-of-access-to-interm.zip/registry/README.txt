Authoritative Forge reproduction

Registry folder: 61234-incorrect-reward-claim-logic-causes-loss-of-access-to-interm_exp
Registry base commit: a35f3640aae29f3b1f40441dfa2ab350f04c0bce

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 61234-incorrect-reward-claim-logic-causes-loss-of-access-to-interm_exp -vvv
