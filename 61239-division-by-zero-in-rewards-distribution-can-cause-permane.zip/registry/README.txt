Authoritative Forge reproduction

Registry folder: 61239-division-by-zero-in-rewards-distribution-can-cause-permane_exp
Registry base commit: e128c996241fecc8d9ac92cd55dd17c472384c9f

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 61239-division-by-zero-in-rewards-distribution-can-cause-permane_exp -vvv
