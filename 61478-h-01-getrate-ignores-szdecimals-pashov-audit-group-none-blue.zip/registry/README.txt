Authoritative Forge reproduction

Registry folder: 61478-h-01-getrate-ignores-szdecimals-pashov-audit-group-none-blue_exp
Registry base commit: dad11617c557af5a115b7d61748a0092f047180b

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 61478-h-01-getrate-ignores-szdecimals-pashov-audit-group-none-blue_exp -vvv
