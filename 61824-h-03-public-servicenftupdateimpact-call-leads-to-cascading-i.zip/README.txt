EVM Hack Analyzer — crypto.training scripted POC (ZIP projection)

Slug:     61824-h-03-public-servicenftupdateimpact-call-leads-to-cascading-i
Chain id: 8453

Layout:
  anvil_state.json       — fork state (accounts + storage + code + block).
  sources/<addr>/…       — verified Solidity sources.
  sources/exploit/…      — attacker exploit source (if present).
  poc-data/runner.json   — scripted exploit config (no accounts/source bodies).
  manifest.json          — summary metadata.

Drop this ZIP onto the EVM Hack Analyzer — it re-runs the scripted exploit
in-browser and opens the opcode-level playground.
