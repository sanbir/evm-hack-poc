Authoritative Forge reproduction

Registry folder: 61950-c-01-carryvoteforward-enables-double-voting-pashov-audit-gro_exp
Registry base commit: 354ef2c2039b4cec14d4831d62bf65c8a474b1f1

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 61950-c-01-carryvoteforward-enables-double-voting-pashov-audit-gro_exp -vvv
