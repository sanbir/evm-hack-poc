Authoritative Forge reproduction

Registry folder: 62486-h-5-migraterewardpool-fails-due-to-incompatible-storage-desi_exp
Registry base commit: 354ef2c2039b4cec14d4831d62bf65c8a474b1f1

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 62486-h-5-migraterewardpool-fails-due-to-incompatible-storage-desi_exp -vvv
