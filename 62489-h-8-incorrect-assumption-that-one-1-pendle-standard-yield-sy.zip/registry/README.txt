Authoritative Forge reproduction

Registry folder: 62489-h-8-incorrect-assumption-that-one-1-pendle-standard-yield-sy_exp
Registry base commit: 5b8d8e4c7c487a84acef92fa0d25ee6dbc90c6fb

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 62489-h-8-incorrect-assumption-that-one-1-pendle-standard-yield-sy_exp -vvv
