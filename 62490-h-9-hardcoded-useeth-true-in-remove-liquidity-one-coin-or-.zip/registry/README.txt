Authoritative Forge reproduction

Registry folder: 62490-h-9-hardcoded-useeth-true-in-remove-liquidity-one-coin-or-_exp
Registry base commit: 7344764d4dbe652f812ac86b8218b1e9a0d5bd53

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 62490-h-9-hardcoded-useeth-true-in-remove-liquidity-one-coin-or-_exp -vvv
