Authoritative Forge reproduction

Registry folder: 62539-h-02-insufficient-restrictions-in-instantopenpacket-risk-dos_exp
Registry base commit: 8e5a0b9097135be6a913d39ba2b50b48e52730b6

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 62539-h-02-insufficient-restrictions-in-instantopenpacket-risk-dos_exp -vvv
