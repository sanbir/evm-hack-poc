Authoritative Forge reproduction

Registry folder: 62758-h-03-fee-avoidance-possible-by-uncollected-fees-in-pool-acco_exp
Registry base commit: 8e73faf48ba0a764ad646b196a453408a78a4d46

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 62758-h-03-fee-avoidance-possible-by-uncollected-fees-in-pool-acco_exp -vvv
