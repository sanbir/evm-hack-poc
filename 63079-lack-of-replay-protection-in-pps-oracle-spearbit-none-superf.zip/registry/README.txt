Authoritative Forge reproduction

Registry folder: 63079-lack-of-replay-protection-in-pps-oracle-spearbit-none-superf_exp
Registry base commit: 8499d3e682c9d09124733c1fdaacfbcf72fcf8a6

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 63079-lack-of-replay-protection-in-pps-oracle-spearbit-none-superf_exp -vvv
