Authoritative Forge reproduction

Registry folder: 63445-h-01-stakers-may-fail-to-claim-all-incentives-pashov-audit-g_exp
Registry base commit: dad11617c557af5a115b7d61748a0092f047180b

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 63445-h-01-stakers-may-fail-to-claim-all-incentives-pashov-audit-g_exp -vvv
