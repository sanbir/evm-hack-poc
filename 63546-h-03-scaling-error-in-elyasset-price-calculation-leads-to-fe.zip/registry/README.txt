Authoritative Forge reproduction

Registry folder: 63546-h-03-scaling-error-in-elyasset-price-calculation-leads-to-fe_exp
Registry base commit: 6fef14bfa2b3a2e21c7d8c447bfc10bcf3f5d6a9

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 63546-h-03-scaling-error-in-elyasset-price-calculation-leads-to-fe_exp -vvv
