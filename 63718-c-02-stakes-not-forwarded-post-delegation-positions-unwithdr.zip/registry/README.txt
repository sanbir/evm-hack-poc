Authoritative Forge reproduction

Registry folder: 63718-c-02-stakes-not-forwarded-post-delegation-positions-unwithdr_exp
Registry base commit: 8e73faf48ba0a764ad646b196a453408a78a4d46

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 63718-c-02-stakes-not-forwarded-post-delegation-positions-unwithdr_exp -vvv
