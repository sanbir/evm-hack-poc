Authoritative Forge reproduction

Registry folder: 64858-h-10-protocol-fails-to-charge-fees-from-swap-amount-code4ren_exp
Registry base commit: 354ef2c2039b4cec14d4831d62bf65c8a474b1f1

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 64858-h-10-protocol-fails-to-charge-fees-from-swap-amount-code4ren_exp -vvv
