Authoritative Forge reproduction

Registry folder: 65730-h-02-variable-overwrite-in-checkpoolandgetcenterprice-create_exp
Registry base commit: 5dafdbe43ee46a19cce3528063ea4c114b36ecf5

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 65730-h-02-variable-overwrite-in-checkpoolandgetcenterprice-create_exp -vvv
