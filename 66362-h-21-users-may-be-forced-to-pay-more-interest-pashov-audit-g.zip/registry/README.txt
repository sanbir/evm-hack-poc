Authoritative Forge reproduction

Registry folder: 66362-h-21-users-may-be-forced-to-pay-more-interest-pashov-audit-g_exp
Registry base commit: 585cc3d97b48bc4368c2a74f444402d2212c8d4e

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 66362-h-21-users-may-be-forced-to-pay-more-interest-pashov-audit-g_exp -vvv
