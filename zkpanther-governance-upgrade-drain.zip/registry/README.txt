Authoritative Forge reproduction

Registry folder: 2026-08-ZKPantherGovernanceUpgrade_exp
Registry base commit: e3174d720b6ad53ec231b135ca7be49a3c0379fc

The analyzer files in poc-data/ are a browser-compatible projection.
The exact source-backed reproduction is under this registry/ directory.
This archive contains the validated registry working-tree test/source files
as shipped; the base commit above identifies the checkout they came from.
Run the test from the registry checkout with:
  forge test --root 2026-08-ZKPantherGovernanceUpgrade_exp -vvv
